// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  API_ENDPOINT : 'http://52.172.38.208:9090',
  XMPP_DOMAIN_NAME : '10.0.0.4',
  XMPP_BOSH_SERVICE : 'http://52.172.38.208:7070/http-bind/',
  GET_ROOM_SERVICE : 'http://52.172.38.208:9080/v1/homestay/list/user/chatroom'
};
