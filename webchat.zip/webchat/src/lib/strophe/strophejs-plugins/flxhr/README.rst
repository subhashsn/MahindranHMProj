# flXHR plugin

This plugin implements cross-domain XmlHttpRequests via an invisible
Flash plugin.

In order for this to work, the BOSH service *must* serve a
crossdomain.xml file that allows the client access.

flXHR.js should be loaded before this plugin.

Note: this plugin was moved from Strophejs core and is no longer
maintained. For more info, [see this ticket](https://github.com/strophe/strophejs/issues/45).
