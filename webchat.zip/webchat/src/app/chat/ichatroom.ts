export class iChatRoom {
  roomName : string;
  subject : string;
  description : string;
  members = [];
  owners = [];
}
