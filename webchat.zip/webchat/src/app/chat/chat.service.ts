import { Component, Input } from '@angular/core';
import { Injectable }     from '@angular/core';
import { environment } from '../../environments/environment';
import { iChatRoom } from './ichatroom';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

var roomItems = [];
var ichatroom : any;

@Injectable()
export class ChatService {

    constructor(public http:Http) { }

      public getRoomList(): Observable<any> {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        var userName: string = localStorage.getItem('username');
        var postparam:any = {};//'{"username":"anish.kumar_happiestminds.com"}';//{"username :" + localStorage.getItem('username')};
        postparam["username"] = userName;
        //var jsonObject : any = JSON.parse(postparam || null )
         return this.http.post(environment.GET_ROOM_SERVICE, postparam, options)
                         .map((res:any) =>  {
                          // var data = res.json();
                           roomItems = this.mapChatRooms(res.json());
                          return roomItems;
                         })
                         .catch((error:any) => {

                          if (error.status == 500) {
                              console.log(error.statusText);
                          } else if (error.status == 588) {
                              console.log(error.statusText);
                          }

                          return Observable.throw(error.statusText);
                      });

            }

          public mapChatRooms(mapdata:any): iChatRoom[]  {
              var roomData = [];
              var dataset = mapdata["chatRoom"];
              if(dataset.length > 1) {
               for(var i = 0; i < dataset.length; i++){
                 ichatroom = new iChatRoom();
                 ichatroom.roomName = dataset[i]['roomName'];
                 ichatroom.subject = dataset[i]['subject'];
                 ichatroom.description = dataset[i]['description'];

                 var datamember = dataset[i]['members'];
                 ichatroom.members = this.mapObject(datamember, "member");

                 var dataowner = dataset[i]['owners'];
                 ichatroom.owners = this.mapObject(dataowner, "owner");

                 roomData.push(ichatroom);
               }
             }else {
               ichatroom = new iChatRoom();
               ichatroom.roomName = dataset['roomName'];
               ichatroom.subject = dataset['subject'];
               ichatroom.description = dataset['description'];

               var datamember = dataset['members'];
               ichatroom.members = this.mapObject(datamember, "member");

               var dataowner = dataset['owners'];
               ichatroom.owners = this.mapObject(dataowner, "owner");

               roomData.push(ichatroom);
             }

             return roomData;
           }

           public mapObject(mapobj:any, participantType:string) {

             if(mapobj[participantType] instanceof Object === true) {
               var objArray = [];
               var membersDict = mapobj[participantType];
               objArray.push(membersDict);
               return objArray;
             }else if (mapobj[participantType] instanceof Array === true){
               var objArray = [];
               objArray = mapobj[participantType];
               return objArray;
             }else if (mapobj[participantType] instanceof String === true){
               var objArray = [];
               var membersDict = mapobj[participantType];
               objArray.push(membersDict);
               return objArray;
             }else if (typeof mapobj[participantType] === "string"){
               var objArray = [];
               var membersDict = mapobj[participantType];
               objArray.push(membersDict);
               return objArray;
             }

           }
          }
