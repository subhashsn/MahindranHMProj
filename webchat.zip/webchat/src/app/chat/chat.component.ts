import { Component, OnInit } from '@angular/core';
import { ChatService } from './chat.service';
import { iChatRoom } from './ichatroom';
import { StropheService } from '../shared/strophe.service';
import { Observable } from 'rxjs/Observable';
import { GroupChatMessage } from '../shared/message.builder';
import { Subject } from 'rxjs/Subject';
// import { subscribe } from 'rxjs/Subscribe';

@Component({
  //selector: 'app-chat',
  //providers: [ChatService],
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css'],
})

export class ChatComponent implements OnInit {

  errorMessage : string;
  roomItems = [];
  messageData = [];
  roasterName : string;
  roomId : string;
  currentUserName : string;
  subject = new Subject();
  sendMessageContent : string;
  ichatroom : any;

constructor( public _chatService : ChatService, private _stropheService: StropheService) {
  // console.log("Strophe service "+ _stropheService.sampleText);
  //_chatService.joinChat(subject);
}

  ngOnInit() {
    this.currentUserName = localStorage.getItem('username');
    this.getAllRooms()
    this.subject.subscribe(
      msg => {
        console.log("Received message is"+msg);
        var msgitem = {};
        msgitem['body'] = msg['body'];

        let dateFormat = new Date(msg['date']);

        msgitem['date'] = dateFormat;
        msgitem['messageId'] = msg['messageId'];
        msgitem['isFromMe'] = msg['isFromMe'];
        var from = msg['from'];
        var splitted = from.split("/", 2);
        msgitem['from'] = splitted[1];

        console.log ("MsgDetails " + msgitem);

        this.messageData.push(msgitem);
      }
    );
 }

 //MARK: To get all rooms of the loggedin user
  getAllRooms(){
    this._chatService.getRoomList().subscribe(data   =>
    {
      this.roomItems = data;
    },
     error => console.log(error));
    }

    selectroom(item){
       this.messageData = [];
       this._stropheService.joinToRoom(item,this.subject);
       this.roasterName = item.subject;
       this.roomId = item.roomName;
       this.chatscrollBottom();
     }

     sendmsg(){
       let isWhitespace = (this.sendMessageContent || '').trim().length === 0;
       let isValid = !isWhitespace;
       if(isValid){
         this._stropheService.sendMessage(this.sendMessageContent,this.roomId);
         console.log("Message"+this.sendMessageContent);
         this.chatscrollBottom();
         this.sendMessageContent = "";
       }else {
         this.sendMessageContent = "";
       }
     }

     chatscrollBottom(){
       setTimeout(()=>{    //<<<---    using ()=> syntax
         let d = document.querySelector('.chat-history');
         if(d)
         {
           d.scrollTop = d.scrollHeight;
         }
       },500);
     }
}
