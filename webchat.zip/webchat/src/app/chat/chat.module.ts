import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatComponent } from './chat.component';
import { ChatService } from './chat.service';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { SearchFilterPipe } from './search-filter.pipe';
// import { StropheService } from '../shared/strophe.service';
@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'chat', component: ChatComponent }
    ]),
    CommonModule,
    HttpModule,
    FormsModule
  ],
//  exports: [ChatComponent],
  declarations: [ChatComponent, SearchFilterPipe],
  providers: [ChatService]
})

export class ChatModule { }
