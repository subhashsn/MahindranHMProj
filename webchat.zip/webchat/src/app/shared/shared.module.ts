import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StropheService } from '../shared/strophe.service';
import { UtilityService } from './utility.service';
 import { MessageBuilder } from './message.builder';
//import { MessageService } from './message.service';
//import { APP_CONFIG, APP_DI_CONFIG } from '../app.config';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [StropheService, UtilityService, MessageBuilder/*,{
    provide: APP_CONFIG,
    useValue: APP_DI_CONFIG
  }*/]
})
export class SharedModule {

}
