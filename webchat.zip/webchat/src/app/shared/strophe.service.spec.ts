import { TestBed, inject } from '@angular/core/testing';

import { StropheService } from './strophe.service';

describe('StropheService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StropheService]
    });
  });

  it('should be created', inject([StropheService], (service: StropheService) => {
    expect(service).toBeTruthy();
  }));
});
