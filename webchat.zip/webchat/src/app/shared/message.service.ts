import { Injectable } from '@angular/core';

//import { MessageBuilder } from './message.builder';

@Injectable()
export class MessageService {

  constructor() { }

}
