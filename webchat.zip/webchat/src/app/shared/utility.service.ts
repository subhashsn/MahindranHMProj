import { Injectable } from '@angular/core';

@Injectable()
export class UtilityService {

 private username:string = 'loggedinuser';

  constructor() { }

 saveUser(content:Object) {
    if (content != null){
        localStorage.setItem(this.username, JSON.stringify(content));
    }
  }

  getUser(){
      return JSON.parse(localStorage.getItem(this.username));
  }


  isJson(str) {
      try {
          JSON.parse(str);
      } catch (e) {
          return false;
      }
      return true;
  }

  //getNodeFromJid

}
