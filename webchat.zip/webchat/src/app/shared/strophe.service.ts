import { Injectable, Inject, EventEmitter } from '@angular/core';
import { environment } from '../../environments/environment';
import { UtilityService } from './utility.service';
import { GroupChatMessage } from './message.builder';
import { MessageBuilder } from './message.builder';
import { Subject } from 'rxjs/Subject';

enum ChatStates {
    Paused,
    Composing,
    Active,
    InActive
}

//const uuidv1 = require('uuid/v1');
// To inclide 3rd party javascript libraries
/// <reference path = "lib/strophe/strophe.js"/>
/// <reference path = "lib/strophe/strophejs-plugins/strophe.muc.js"/>

//import { APP_CONFIG, ChatAppConfig } from '../app.config';

// declare var Strophe : any;
 declare var Strophe;
 declare var $pres, $msg, $iq;
 type xmppConnectionHandler = (status: number) => void;
 // type RoomObjects = { roomId: string; object: any };

@Injectable()
export class StropheService {

  public subject:Subject<any>;
  static _chatState: ChatStates;
  //public myCallback: {(): void;};
  //public xmppConnectionHandler: {() : number};
  //public xmppHandler: xmppConnectionHandler;
  public messageReceived$: EventEmitter<GroupChatMessage>
                    = new EventEmitter<GroupChatMessage>();


  public connection = null;
  private jid;// = "anoop_hm.com@10.0.0.4/chatapp";
  private password;// = "test";
  private g_roomId;
  private connectionStatus;

  public connectionHandler : xmppConnectionHandler;
// @Inject(APP_CONFIG) private config: AppConfig
//@Inject(APP_CONFIG) private config: ChatAppConfig
//private _helper:UtilityService
  constructor(private _helper:UtilityService, private _builder: MessageBuilder) {

   }

/* Connection to XMPP Server */
 connectToXmpp = ((_jid:string, _password: string, handler:xmppConnectionHandler) => {
  //  console.log("Room is"+ muc);
     this.connectionHandler = handler;
     this.jid = _jid;
     this.password = _password;

     var BOSH_SERVICE = environment.XMPP_BOSH_SERVICE;//this.config.XMPP_BOSH_SERVICE;
     this.connection = new Strophe.Connection(BOSH_SERVICE,{ 'keepalive': true });
     //console.log("This connection is "+this.connection);
     //console.log(new Strophe.Connection(BOSH_SERVICE,{ 'keepalive': true }));
     this.connection.connect(_jid,_password,this.onConnect);
    //  this.connection.muc.init(this.connection)
    //  this.connection.rawInput = function (data)
    //   {
    //           console.log("Input Data is ****"+data);
    //   };
    //   this.connection.rawOutput = function (data)
    //    {
    //           console.log("Output Data is ****"+data);
    //    };
  });

//callback: (result: string) => any
  onConnect = ((status) => {
      var self = this;
      this.connectionStatus = status;
      console.log("Connection"+self.connection);
      console.log("Status: "+status);
      if (status == Strophe.Status.CONNECTING) {
			console.log('Strophe is connecting.');
		} else if (status == Strophe.Status.CONNFAIL) {
			console.log('Strophe failed to connect.');
		} else if (status == Strophe.Status.DISCONNECTING) {
			console.log('Strophe is disconnecting.');
		} else if (status == Strophe.Status.DISCONNECTED) {
			console.log('Strophe is disconnected.');
		}else if (status == Strophe.Status.AUTHFAIL) {
          console.log('Failed to authenticate to xmpp server.');
    }
    else if (status == Strophe.Status.CONNECTED) {
          console.log("Strophe is connected.");
          //Get User Name from JID
          this._helper.saveUser(Strophe.getNodeFromJid(this.jid));
          self.connection.send($pres().tree());
          self.connection.addHandler(this.onUserPresenceHandler, null, "presence");
          //self.connection.addHandler(this.onMessageReceivedHandler, null, 'message', null, null, null);
          //self.connection.addHandler(this.onMessageReceivedHandler, null, "message");
          //self.connection.sendPingToServer();
      }

      /* Reset connection handler to null after callback, because 'onConnect'
       will be called whenever there is a change in the connection. */
      if ((this.connectionHandler != undefined || this.connectionHandler != null)){
          this.connectionHandler(status);
          //this.connectionHandler = null;
      }
      // return true;
   });

   /**
      Disconnect
    */

   disconnect(){
      this.connection.disconnect("Logged Out")
   }


   onUserPresenceHandler = ((presence) => {
     var self = this;
      console.log("On Presence"+presence);
      /*if (this.connectionStatus == Strophe.Status.CONNECTED){
          self.joinToRoom("1880fa05-f73c-4b1f-b47b-c0f4e3dac56e");
      }
      else{
            self.connectToXmpp(this.jid,this.password,(status: number) => {
                this.connectionStatus  = status;
                console.log("XMPP Status is "+status);
            });
      }*/
      return true;
      //self.joinToRoom("f7e68a86-5683-4bf7-ac85-23e038c7fc0b")
   })

   /*
      Function: To join the chat room
    */
   joinToRoom(roomId:string, sub:Subject<any>){
      var roomJid = this.getRoomJid(roomId);
      this.subject = sub;
      //Nick name is same as Username
      var nickName = this._helper.getUser();
      console.log("Nick name is"+nickName);
      //function(room, nick, msg_handler_cb,
              //pres_handler_cb, roster_cb, password, history_attrs, extended_presence)
      if (this.connectionStatus == Strophe.Status.CONNECTED){
          this.connection.muc.join(roomJid,nickName,this.joinRoomMessageHandler,
                                 this.joinRoomPresenceHandler,this.joinRoomRosterHandler,null,null,null);
      }
      else{
          this.connectToXmpp(this.jid,this.password,(status: number) => {
            this.connectionStatus  = status;
            console.log("XMPP Status is "+status);
            if (this.connectionStatus == Strophe.Status.CONNECTED){
                this.connection.muc.join(roomJid,nickName,this.joinRoomMessageHandler,
                                       this.joinRoomPresenceHandler,this.joinRoomRosterHandler,null,null,null);
            }
            else{
                console.log("Could not join the room "+roomJid+". Because XMPP Stream is disconnected");
            }
        });
      }
   }
   //getNodeFromJid - returns username
   //getDomainFromJid - domain portion of jid string
   //getResourceFromJid - returns resource from jid
   //getBareJidFromJid - returns bareJid from jid
   /*
      Callback: Join Room Message Callback
    */

   joinRoomMessageHandler= ((a,b,c) => {
     //console.log("In Message Handler" + a);
     var type = a.getAttribute('type');
     /*if (type == "groupchat" && (message.hasChild("composing")
       || message.hasChild("paused") || message.hasChild("active") || message.hasChild("inactive"))){
        console.log("Message Typing status");
     }
     else{*/
       console.log("Message received: "+a);
       //returns `GroupChatMessage` object
       var msg = this._builder.object(a);
       if (msg){
         this.subject.next(msg);
         console.log("Message Object is "+ msg);
       }
       return true;
   });

   /*
      Callback: Join Room Presence Callback
      a - presence
      Example: <presence xmlns="jabber:client" from="happychat@conference.10.0.0.4/anoop_hm.com"
              to="anoop_hm.com@10.0.0.4/chatapp"><x xmlns="http://jabber.org/protocol/muc#user">
          <item affiliation="member" role="participant"/>
          <status code="110"/></x>
          </presence>

      b - XmppRoom Object
    */
   joinRoomPresenceHandler = ((a,b,c) => {
     var presence = a;
     var roomBareJid = Strophe.getBareJidFromJid(presence.getAttribute('from'));
     console.log("In Presence Handler "+ Strophe.getBareJidFromJid(presence.getAttribute('from')));
      /*setTimeout(() => {
        this.sendMessage("Chat Message",roomBareJid);
      }, 1000);*/

     return true;
   });

   /*
      Callback: Join Room Roster Callback
    */

   joinRoomRosterHandler = ((a,b,c) => {
     console.log("In Roster Handler");
     return true;
   });

   /*
     Function: Send Message
   */

   //  groupchat: function(room, message, html_message, msgid) {
   sendMessage(text: string, roomId: string){
     //This should be changed. Check UUID Library
     var roomJid = this.getRoomJid(roomId)
     var message = this._builder.build(text,0,roomJid);
     this.connection.muc.groupchat(roomJid, message, null, null);
   }

   /*
      callback: When Message is received
      Example:
      <message xmlns="jabber:client" from="766ab0d9-66e0-4d89-a6c9-d8afbb69363b@conference.hmecd001128/anish"
      roomName="766ab0d9-66e0-4d89-a6c9-d8afbb69363b" slaFlag="false"
        slaTime="0" id="481D1E37-FA97-48E4-82C7-7BFC30870417"
        to="anish@hmecd001128/CMOCHATIPHONE" type="groupchat"><request xmlns="urn:xmpp:receipts"/><body>{
          "body" : “Hello",
          "mediaItem" : "0",
          "slaTime" : “10",
          "slaFlag" : “true",
          "date" : "2017-01-19 11:31:13.355 +0530",
          "isConfidential" : “1"
          }</body><thread>A4DE8433-CD4E-4C62-B253-CBFC7803CA1B</thread></message>
    */

   /*onMessageReceivedHandler = (message) => {
      var type = message.getAttribute('type');

        console.log("Message received: "+message);
        //returns `GroupChatMessage` object
        var msg = this._builder.object(message);
        if (msg){
          this.subject.next(msg);
          //this.messageReceived$.emit(msg);
          console.log("Message Object is "+ msg);
        }
    //  }
      return msg;
   }*/
   //Room Utility functions

   /* Config Chat Room - Pending */
   configChatRoom(roomJid: string){
      this.connection.muc.configure(roomJid,this.configureSuccessHandler,this.configureFailureHandler);
   }

   configureSuccessHandler = ((a,b,c) => {
      console.log("Success Configure Handler");
      var status;
      var configXml = null;
      var nodes;
        configXml = a;
        var list = configXml.childNodes[0]
        var list1 = list.childNodes[0]
        nodes = list1.childNodes
        var value1 = document.implementation.createDocument(null, 'value', null); //document.createElement("value");
        var node = document.createTextNode('moderator');
        value1.documentElement.appendChild(node);
        //	doc.documentElement.appendChild
        var value2 = document.implementation.createDocument(null, 'value', null);
        var node = document.createTextNode("visitor");
        value2.documentElement.appendChild(node);

        var value3 = document.implementation.createDocument(null, 'value', null);
        var node = document.createTextNode("participant");
        value3.documentElement.appendChild(node);
        for (var index = 0; index < nodes.length; index++) {
            var element = nodes[index];
            var attr = element.getAttribute('var')

            if (attr === "muc#roomconfig_presencebroadcast") {
                if (element.childNodes.length == 3) {
                    status = true;
                    element.appendChild(value1.firstChild)
                    element.appendChild(value3.firstChild)
                    element.appendChild(value2.firstChild)
                } else {
                    status = false;
                }
                break;
            }
        }

        if (status){
          var xmlArray = [];
          nodes.forEach(function(element) {
              xmlArray.push(element)
          }, this);
          console.log('configure_success_handler')
          this.connection.muc.saveConfiguration();
          //self.saveConfiguration(RoomIdGlobalVar, xmlArray)
        }
        return true;

   });

   configureFailureHandler = () => {
      console.log("Failure Configure Handler");
   }

   /*
    function: XMPP Ping
   */

   sendPingToServer(){
     this.connection.ping.ping(this.jid,this.pingSuccess,this.pingFailed,6000);
     this.connection.ping.addPingHandler(this.pingHandler);
   }

   private pingSuccess(){console.log("Ping Success");}
   private pingFailed(){console.log("Ping Failed");}
   private pingHandler(){console.log("Ping Handler");}


   // Room Related utility functions
   getRoomJid(roomId:string){
        var roomJid = roomId
        if (!(roomJid == undefined)) {
            if (roomJid.indexOf('@') == -1) {
                roomJid = roomId + "@conference." + environment.XMPP_DOMAIN_NAME;
            }
        }
        return roomJid;
   }

   getNicknameFromRoomJid(roomJid:string){
     if (roomJid.indexOf("/") < 0) { return null; }
     return roomJid.split("/")[1];
   }

}
