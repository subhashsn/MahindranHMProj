import { Injectable } from '@angular/core';
import { UtilityService } from './utility.service';
import { UUID } from 'angular2-uuid';
//import * as $ from 'jquery';

/// <reference path = "lib/strophe/strophe.js"/>

declare var Strophe;

export class GroupChatMessage{
    body: string;
    date: Date;
    mediaType: number;
    messageId: string;
    from: string;
    to: string;
    isFromMe:boolean;
}


@Injectable()
export class MessageBuilder {
    constructor(private _helper:UtilityService){}

    build(text: string, mediaType: number, roomJid: string){
        let uuid = UUID.UUID();//Message Id
        //console.log("UUID Value: "+ uuid);
      //  var uuid = <string> <any>(Math.floor(Math.random() * 100000) + 1);
        var groupchat = new GroupChatMessage();
        groupchat.body = text;
        groupchat.date = new Date();
        groupchat.mediaType = mediaType;
        groupchat.messageId = uuid;
        groupchat.isFromMe = true;
        var json = JSON.stringify(groupchat);
        console.log("JSON Data is "+json);
        return json;
    }


    /*
        {"body":"Hello","date":"2017-09-25T09:41:41.434Z","mediaType":0,"messageId":88215}
      */
    /*
    <message xmlns="jabber:client" from="766ab0d9-66e0-4d89-a6c9-d8afbb69363b@conference.hmecd001128/anish"
     roomName="766ab0d9-66e0-4d89-a6c9-d8afbb69363b" slaFlag="false" slaTime="0"
     id="481D1E37-FA97-48E4-82C7-7BFC30870417" to="anish@hmecd001128/CMOCHATIPHONE"
      type="groupchat"><request xmlns="urn:xmpp:receipts"/><body>{
      "body" : “Hello",
      "mediaItem" : "0",
      "slaTime" : “10",
      "slaFlag" : “true",
      "date" : "2017-01-19 11:31:13.355 +0530",
      "isConfidential" : “1"
      }</body><thread>A4DE8433-CD4E-4C62-B253-CBFC7803CA1B</thread></message>
    */
    object(message: any){
        var body = message.getElementsByTagName('body')[0];
        if (body){
          var content = Strophe.getText(body).replace(/&quot;/g, '\\"').replace(/\\/g, "");
          var isValidJson = this._helper.isJson(content);
          var from = message.getAttribute('from');
          var to = message.getAttribute('to');
          var groupchat = new GroupChatMessage()
          if (isValidJson){
              var jsonContent = JSON.parse(content);
              groupchat.body = jsonContent["body"];
              groupchat.date = jsonContent["date"];
              groupchat.mediaType = jsonContent["mediaType"] ? jsonContent["mediaType"] : 0;
              groupchat.messageId = jsonContent["messageId"];
              groupchat.from = from;
              groupchat.to = to;
          }
          else{
              groupchat.body = content;
              groupchat.date = new Date();
              groupchat.from = from;
              groupchat.to = to;
          }

          if (from){
            if (Strophe.getResourceFromJid(from) === localStorage.getItem('username')){
                groupchat.isFromMe = true;
            }
          }
          //if loggedinuser == message.from then
              //groupchat.isFromMe = true
          return groupchat;
        }
      return null;
    }




}
