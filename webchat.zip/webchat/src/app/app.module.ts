import { BrowserModule } from '@angular/platform-browser';
import { InjectionToken, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ChatModule } from './chat/chat.module';
import { SharedModule } from './shared/shared.module';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { ChatComponent } from './chat/chat.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot([
        { path: 'login', component: LoginComponent },
        { path: '', redirectTo: 'login', pathMatch: 'full'},
        { path: '**', redirectTo: 'login', pathMatch: 'full'}
    ]),
    ChatModule,
    SharedModule,
  ],
  providers: [/*{
    provide: APP_CONFIG,
    useValue: APP_DI_CONFIG
  }*/],
  bootstrap: [AppComponent]
})
export class AppModule {
    /*constructor() {
      var BOSH_SERVICE = environment.XMPP_BOSH_SERVICE;//this.config.XMPP_BOSH_SERVICE;
      //this.connection = new Strophe.Connection(BOSH_SERVICE,{ 'keepalive': true });
      console.log(new Strophe.Connection(BOSH_SERVICE,{ 'keepalive': true }));
    }*/

}
/*{
  provide: APP_CONFIG,
  useValue: AppConfig
}*/
