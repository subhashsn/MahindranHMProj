import { InjectionToken } from "@angular/core";


export interface ChatAppConfig {
    API_ENDPOINT: string;
    XMPP_DOMAIN_NAME: string;
    XMPP_BOSH_SERVICE: string;
}

export const APP_DI_CONFIG : ChatAppConfig = {
   API_ENDPOINT : 'http://52.172.38.208:9090',
   XMPP_DOMAIN_NAME : '10.0.0.4',
   XMPP_BOSH_SERVICE : 'http://52.172.38.208:7070/http-bind/'
};

export let APP_CONFIG = new InjectionToken<ChatAppConfig>("app.config");
