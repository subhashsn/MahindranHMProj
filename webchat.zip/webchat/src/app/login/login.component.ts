import { Component, OnInit } from '@angular/core';
import { StropheService } from '../shared/strophe.service';
import { Router } from '@angular/router';
import { GroupChatMessage } from '../shared/message.builder';
import { environment } from '../../environments/environment';

declare var Strophe;


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public username;
  public password;
  rememberMe: boolean = false;;


  constructor(private _stropheService: StropheService, private _router: Router) {
    console.log("Loading Login Component");
    _stropheService.messageReceived$.subscribe(item => {
      this.onMessageReceived(item)
    });
    //todoService.itemAdded$.subscribe(item => this.onItemAdded(item))
  }

  onMessageReceived(msg){
      //console.log("New Message received "+msg);
      var gMessage = <GroupChatMessage>msg;
      console.log("Message Body is "+gMessage.body);
  }

  ngOnInit() {
    //  this._stropheService.connectToXmpp(this.jid,this.password);
      if(localStorage.getItem('login_rememberme') === "true") {
          this.username = localStorage.getItem('login_username');
          this.password = localStorage.getItem('login_password');
          this.rememberMe = true;

      }

  }

  onLogin() {

    if(this.username.length > 0 && this.password.length > 0) {

      var jid = this.username + "@" + environment.XMPP_DOMAIN_NAME + "/chatapp";

      this._stropheService.connectToXmpp(jid,this.password,(status: number) => {

        console.log("XMPP Status is "+ status);

        switch (status){
          case Strophe.Status.CONNECTING:
                console.log('Strophe is connecting.');
                break;
          case Strophe.Status.CONNFAIL:
                console.log('Strophe failed to connect.');
                break;
          case Strophe.Status.DISCONNECTING:
                console.log('Strophe is disconnecting.');
                break;
          case Strophe.Status.DISCONNECTED:
                console.log('Strophe is disconnected.');
                break;
          case Strophe.Status.AUTHFAIL:
                console.log('Failed to authenticate to xmpp server.');
                break;
          case Strophe.Status.CONNECTED:
                console.log('Connected to xmpp server.');
                if (this.rememberMe) {
                  localStorage.setItem ('login_username', this.username);
                  localStorage.setItem ('login_password', this.password);
                  localStorage.setItem ('login_rememberme', "true");
                }else {
                  localStorage.setItem ('login_username', null);
                  localStorage.setItem ('login_password', null);
                  localStorage.setItem ('login_rememberme',"false");
                }

                localStorage.setItem('username', Strophe.getNodeFromJid(jid));
                this._router.navigate(['/chat']);
                break;
          default:
                console.log('Strophe is connecting.');
                break;
        }
      });

    }

  }
}
