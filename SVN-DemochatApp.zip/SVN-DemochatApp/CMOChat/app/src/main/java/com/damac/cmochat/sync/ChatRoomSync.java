package com.damac.cmochat.sync;

import android.content.Context;

import com.damac.cmochat.api.APIManager;
import com.damac.cmochat.api.RetrofitAPIInterface;
import com.damac.cmochat.model.CMOChatRooms;

import retrofit2.Call;

/**
 * Created by Barun.Gupta on 1/28/2017.
 *
 */

public class ChatRoomSync extends AbsSync {

    private Context mContext;
    private Call<CMOChatRooms> getCMOChatRooms = null;
    private RetrofitAPIInterface retrofitAPIService = null;
    private final String TAG = ChatRoomSync.class.getSimpleName();

    public ChatRoomSync(Context context) {
        super(context);
        mContext = context;
        retrofitAPIService = APIManager.getRetrofitServiceInstance(mContext);
    }

    @Override
    protected void doSync() {
      /*  String jid = AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, mContext);
        if (jid != null) {
            String userName = jid.substring(0, jid.indexOf('@'));
            String responseTime = AppUtils.getSharedPref(mContext).getString(AppUtils.RESPONSE_TIME, "0");
            //getCMOChatRooms = retrofitAPIService.getChatRooms(userName, Long.parseLong(responseTime));
            getCMOChatRooms = retrofitAPIService.getChatRooms();
            getCMOChatRooms.enqueue(new Callback<CMOChatRooms>() {
                @Override
                public void onResponse(Call<CMOChatRooms> call, final Response<CMOChatRooms> response) {
                    if (response != null && response.isSuccessful()) {
                        AsyncTask.execute(new Runnable() {
                            @Override
                            public void run() {
                                Realm realm = Realm.getDefaultInstance();
                                try {
                                    final CMOChatRooms cmoChatRooms = response.body();
                                    List<ChatRoom> chatRoomResponseList = cmoChatRooms.getChatRoom();
                                    List<String> chatRoomNameList = new ArrayList<>();
                                    log(TAG, "chatRoomResponseList size::" + chatRoomResponseList.size());
                                    for (ChatRoom chatRoom : chatRoomResponseList) {
                                        if (chatRoom.getSubject() != null) {
                                            CMORepositoryService.getInstance().saveCMOChatRoom(realm, chatRoom);
                                        }
                                        chatRoomNameList.add(chatRoom.getRoomName());
                                    }
                                    RealmResults<ChatRoom> chatRoomResults = CMORepositoryService.getInstance().getAllChatRoom(realm);
                                    List<ChatRoom> chatRoomDBList;
                                    if (chatRoomResults != null && chatRoomResults.size() > 0) {
                                        chatRoomDBList = realm.copyFromRealm(chatRoomResults);
                                        log(TAG, "chatRoomDBList size::" + chatRoomDBList.size());
                                        if (chatRoomDBList != null && chatRoomDBList.size() > 0) {
                                            for (ChatRoom chatRoom : chatRoomDBList) {
                                                if (chatRoomNameList.contains(chatRoom.getRoomName())) {
                                                    log(TAG, "Room not to be deleted::" + chatRoom.getRoomName());
                                                } else {
                                                    log(TAG, "Room to be deleted::" + chatRoom.getRoomName());
                                                    CMORepositoryService.getInstance().deleteChatRoom(realm, chatRoom);
                                                }
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    logError(TAG, e.getMessage(), e);
                                } finally {
                                    if (realm != null) {
                                        realm.close();
                                    }
                                    EventBus.getDefault().post(new SyncRequestEvent(SyncType.CMO_CHATROOM_SYNC));
                                }
                            }
                        });
                    }
                }

                @Override
                public void onFailure(Call<CMOChatRooms> call, Throwable t) {
                    if (call != null) {
                        log(TAG, "Error  occured::" + t.getMessage());
                        EventBus.getDefault().post(new SyncRequestEvent(SyncType.CMO_CHATROOM_SYNC));
                    }
                }
            });
        }*/
    }

}