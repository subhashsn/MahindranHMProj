package com.damac.cmochat.model;

/**
 * Created by Barun.Gupta on 1/23/2017.
 *
 */

public class CMOChatRoomOwner {
    private String owner;

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }
}
