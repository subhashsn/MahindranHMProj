package com.damac.cmochat.util;

import android.content.Context;
import android.text.format.DateUtils;

import com.damac.cmochat.R;
import com.damac.cmochat.model.ChatRoom;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import io.realm.RealmList;

import static com.damac.cmochat.util.AppUtils.logError;

/**
 * Created by Barun.Gupta on 1/16/2017.
 */

public class CMOChatRoomConverter implements JsonSerializer<ArrayList<ChatRoom>>,
        JsonDeserializer<ArrayList<ChatRoom>> {

    private Context mContext;
    private static final String TAG = CMOChatRoomConverter.class.getSimpleName();

    public CMOChatRoomConverter(Context context) {
        mContext = context;
    }

    @Override
    public JsonElement serialize(ArrayList<ChatRoom> src, Type typeOfSrc, JsonSerializationContext context) {
        JsonArray ja = new JsonArray();
        ja.add(context.serialize(src));
        return ja;
    }

    @Override
    public ArrayList<ChatRoom> deserialize(JsonElement jsonElement, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        ArrayList<ChatRoom> chatRoomArrayList = new ArrayList<>();
        if (jsonElement != null) {
            if (jsonElement.isJsonArray()) {
                JsonArray asJsonArray = jsonElement.getAsJsonArray();
                for (int i = 0; i < asJsonArray.size(); i++) {
                    RealmList<RealmString> memberList = new RealmList<>();
                    JsonObject memberObjct = asJsonArray.get(i).getAsJsonObject();
                    ChatRoom chatRoom = createChatRoomObjfromJson(memberObjct);
                    chatRoomArrayList.add(chatRoom);
                }
            } else {
                JsonObject memberObjct = jsonElement.getAsJsonObject();
                ChatRoom chatRoom = createChatRoomObjfromJson(memberObjct);
                chatRoomArrayList.add(chatRoom);
            }
        }
        return chatRoomArrayList;
    }

    private ChatRoom createChatRoomObjfromJson(JsonObject memberObjct) {
        String dateStrTimeAgo;
        String dateCreationDate;
        RealmList<RealmString> memberList = new RealmList<>();
        ChatRoom chatRoom = new ChatRoom();
        try {
            if (memberObjct.get("subject").getAsString() != null) {
                chatRoom.setSubject(memberObjct.get("subject").getAsString());
            }
            try {
                String datemodification = memberObjct.get("modificationDate").getAsString();
                if (datemodification == null || datemodification.isEmpty()) {
                    datemodification = mContext.getString(R.string.defaultdate);
                }

                Date date = null;
                try {
                    date = AppUtils.dateFormat.parse(datemodification);
                } catch (Exception e) {
                    date = AppUtils.dateFormat2.parse(datemodification);
                }

                dateStrTimeAgo = (String) DateUtils.getRelativeTimeSpanString(date.getTime(), Calendar.getInstance().getTimeInMillis(), DateUtils.MINUTE_IN_MILLIS);
                if (dateStrTimeAgo.isEmpty() || datemodification == null) {
                    dateStrTimeAgo = mContext.getString(R.string.defaulttimeAgo);
                }
                chatRoom.setModificationDate(dateStrTimeAgo);
                String dateCreation = memberObjct.get("creationDate").getAsString();
                if (dateCreation == null || dateCreation.isEmpty()) {
                    dateCreation = mContext.getString(R.string.defaultdate);
                }

                try {
                    date = AppUtils.dateFormat.parse(dateCreation);
                } catch (Exception e) {
                    date = AppUtils.dateFormat2.parse(dateCreation);
                }

                //date = AppUtils.dateFormat.parse(dateCreation);
                dateCreationDate = (String) DateUtils.getRelativeTimeSpanString(date.getTime(), Calendar.getInstance().getTimeInMillis(), DateUtils.MINUTE_IN_MILLIS);
                chatRoom.setCreationDate(dateCreationDate);
            } catch (ParseException e) {
                logError(TAG, e.getMessage(), e);
            }
            JsonElement innerMember = memberObjct.get("members");
            if (!innerMember.isJsonNull()) {
                JsonObject memberObj = innerMember.getAsJsonObject();
                JsonElement memberElement = memberObj.get("member");
                if (memberElement != null && memberElement.isJsonArray()) {
                    JsonArray membersArray = memberElement.getAsJsonArray();
                    for (int j = 0; j < membersArray.size(); j++) {
                        RealmString realmString = new RealmString();
                        realmString.setValue(String.valueOf(membersArray.get(j)));
                        memberList.add(realmString);
                    }
                } else if (memberElement != null) {
                    RealmString realmString = new RealmString();
                    realmString.setValue(memberElement.getAsString());
                    memberList.add(realmString);
                }
            }
            if (memberObjct.get("subject").getAsString() != null) {
                chatRoom.setSubject(memberObjct.get("subject").getAsString());
            }
            if (memberObjct.get("roomName").getAsString() != null) {
                chatRoom.setRoomName(memberObjct.get("roomName").getAsString());
            }
            if (memberObjct.get("naturalName").getAsString() != null) {
                chatRoom.setNaturalName(memberObjct.get("naturalName").getAsString());
            }
            if (memberList.size() > 0) {
                chatRoom.setMembers(memberList);
                chatRoom.setMemberCount(String.valueOf(memberList.size()) + " " + mContext.getString(R.string.participants));
            }
        } catch (Exception ex) {
            logError(TAG, ex.getMessage(), ex);
        }

        return chatRoom;
    }
}