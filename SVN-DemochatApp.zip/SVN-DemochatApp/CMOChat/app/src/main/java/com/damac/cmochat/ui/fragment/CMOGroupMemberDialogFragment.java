package com.damac.cmochat.ui.fragment;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.damac.cmochat.R;
import com.damac.cmochat.adapter.GroupMemberAdapter;
import com.damac.cmochat.databinding.CmogrpMemberFragmentBinding;
import com.damac.cmochat.model.CMOGroupMembers;
import com.damac.cmochat.model.User;
import com.damac.cmochat.realm.CMORepositoryService;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.jivesoftware.smack.packet.Presence;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmResults;

import static com.damac.cmochat.util.AppUtils.log;

/**
 * Created by Barun.Gupta on 1/17/2017.
 *
 */

public class CMOGroupMemberDialogFragment extends DialogFragment {

    private CmogrpMemberFragmentBinding mDataBinder;
    private String mGrpName;
    private RealmResults<CMOGroupMembers> mCMOGroupMembersRealmResults;
    private Realm realm;
    private GroupMemberAdapter mGrpMemberAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    List<User> userList;
    private String TAG = CMOGroupMemberDialogFragment.class.getSimpleName();

    public static CMOGroupMemberDialogFragment newInstance() {
        CMOGroupMemberDialogFragment fragment = new CMOGroupMemberDialogFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.DialogTheme);
        realm = Realm.getDefaultInstance();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        log(TAG, "onCreateView called for CMOGroupMemberDialogFragment");
        mDataBinder = DataBindingUtil.inflate(inflater, R.layout.cmogrp_member_fragment, container, false);
        mGrpName = getArguments().getString("GrpName");
        mCMOGroupMembersRealmResults = CMORepositoryService.getInstance().getCMOGroupMemberByGrpname(realm, mGrpName);
        List<CMOGroupMembers> cmoGroupMemberList = realm.copyFromRealm(mCMOGroupMembersRealmResults);
        if (cmoGroupMemberList != null && cmoGroupMemberList.size() > 0) {
            userList =new ArrayList<>();
            for (CMOGroupMembers cmoGroupMembers : cmoGroupMemberList) {
                User user = CMORepositoryService.getInstance().getCMOUserByUsername(realm, cmoGroupMembers.getmMembersStr());
                if (user != null) {
                    userList.add(realm.copyFromRealm(user));
                }
            }
        }
        mDataBinder.grpMemberRecyclerview.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mDataBinder.grpMemberRecyclerview.setLayoutManager(mLayoutManager);
        mGrpMemberAdapter = new GroupMemberAdapter(userList);
        mDataBinder.grpMemberRecyclerview.setAdapter(mGrpMemberAdapter);
        return mDataBinder.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        mDataBinder.ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        EventBus.getDefault().register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (realm != null) {
            realm.close();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onPresenceEvent(Presence presence) {

        String jid = presence.getFrom().toString();
        String userName = jid.substring(0, jid.indexOf("@"));
        log(TAG, "onPresenceEvent for::" + userName);

        if (!jid.isEmpty()) {
            User cmoUserDetails = null;
            for (User cmouser : userList) {
                if (cmouser.getUsername() != null && cmouser.getUsername().equals(userName)) {
                    cmoUserDetails = cmouser;
                }
                if (cmoUserDetails != null)
                    break;
            }
            if (userList != null && cmoUserDetails != null) {
                if (presence.isAvailable())
                    cmoUserDetails.setDrawbleId(R.drawable.round_green_circle);
                else
                    cmoUserDetails.setDrawbleId(R.drawable.round_gray_circle);

                CMORepositoryService.getInstance().updateCMORosterUsers(realm, cmoUserDetails);
            }
        }
    }
}
