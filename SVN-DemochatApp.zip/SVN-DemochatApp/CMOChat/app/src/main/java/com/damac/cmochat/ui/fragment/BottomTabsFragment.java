package com.damac.cmochat.ui.fragment;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.damac.cmochat.R;
import com.damac.cmochat.adapter.BottomTabAdapter;

/**
 * A simple {@link Fragment} subclass.
 */
public class BottomTabsFragment extends Fragment {
    private static final String TAG = BottomTabsFragment.class.getSimpleName();
    private static final String VIEW_PAGER_POS = "VIEW_PAGER_POSITION";
    private ViewPager mViewPager;

    public BottomTabsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bottom_tabs, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable final Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // Setup the mViewPager
        getActivity().setTitle(getString(R.string.btmtab_conversation));
        // Setup the mViewPager
        mViewPager = (ViewPager) getView().findViewById(R.id.view_pager);
        BottomTabAdapter pagerAdapter = new BottomTabAdapter(getFragmentManager(), getActivity());
        if (mViewPager != null) {
            mViewPager.setAdapter(pagerAdapter);

            //Commented for handling tablet use cases
/*            mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                    int previousPos = -1;
                    if (savedInstanceState != null)
                        previousPos = savedInstanceState.getInt(VIEW_PAGER_POS, -1);

                    FragmentManager fm = getFragmentManager();
                    Fragment fragment = fm.findFragmentById(R.id.right_container);
                    if (fragment != null && previousPos != position) {
                       // fm.beginTransaction().remove(fragment).commitNow();
                    }
                }

                @Override
                public void onPageSelected(int position) {

                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });*/
        }
        TabLayout mTabLayout = (TabLayout) getActivity().findViewById(R.id.tab_layout);
        if (mTabLayout != null) {
            mTabLayout.setupWithViewPager(mViewPager);
            for (int i = 0; i < mTabLayout.getTabCount(); i++) {
                TabLayout.Tab tab = mTabLayout.getTabAt(i);
                if (tab != null)
                    tab.setCustomView(pagerAdapter.getTabView(i));
            }

            mTabLayout.getTabAt(0).getCustomView().setSelected(true);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mViewPager != null)
            outState.putInt(VIEW_PAGER_POS, mViewPager.getCurrentItem());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
