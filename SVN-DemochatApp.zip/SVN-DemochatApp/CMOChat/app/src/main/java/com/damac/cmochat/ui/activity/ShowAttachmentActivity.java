package com.damac.cmochat.ui.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.damac.cmochat.R;
import com.damac.cmochat.model.XMPPBody;
import com.damac.cmochat.ui.listener.OnSwipeTouchListener;
import com.damac.cmochat.util.AppUtils;

import java.util.ArrayList;

import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_ATTACHMENTS;

public class ShowAttachmentActivity extends AppCompatActivity {
    private ImageView mImageView;
    private WebView mWebView;
    private ArrayList<XMPPBody> attachments;
    int index;

    private RequestListener mGlideRequestListener;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_attachment);

        mImageView = (ImageView) findViewById(R.id.image_view);
        mWebView = (WebView) findViewById(R.id.web_view);
        attachments = getIntent().getParcelableArrayListExtra(CHAT_ROOM_ATTACHMENTS);
        index = getIntent().getIntExtra("Index", 0);


        String atatchmentURL = getIntent().getStringExtra(AppUtils.ATTACHMENT_URL);
        if (atatchmentURL.endsWith(".png") || atatchmentURL.endsWith(".jpg")) {
            showImage(atatchmentURL);
        } else {
            loadDocument(atatchmentURL);
        }

        mImageView.setOnTouchListener(new OnSwipeTouchListener(this) {

            public void onSwipeTop() {

            }
            public void onSwipeRight() {
                if (index <= attachments.size() && index != 0) {
                    index = index - 1;
                    XMPPBody message = attachments.get(index);
                    showImage(message.getBody());
                }
            }
            public void onSwipeLeft() {
                if (index < attachments.size()) {
                    index = index + 1;
                    XMPPBody message = attachments.get(index);
                    showImage(message.getBody());
                }
            }
            public void onSwipeBottom() {

            }


        });
    }

    private void showImage(String atatchmentURL) {
        mWebView.setVisibility(View.GONE);
        mGlideRequestListener = new RequestListener() {
            @Override
            public boolean onException(Exception e, Object model, Target target, boolean isFirstResource) {
                Toast.makeText(ShowAttachmentActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                return false;
            }

            @Override
            public boolean onResourceReady(Object resource, Object model, Target target, boolean isFromMemoryCache, boolean isFirstResource) {
                mImageView.setScaleType(ImageView.ScaleType.FIT_XY);
                return false;
            }
        };
        AppUtils.loadBitmapFromWebDAV(atatchmentURL, this, mGlideRequestListener, mImageView);
    }

    private void loadDocument(String atatchmentURL) {
        mImageView.setVisibility(View.GONE);
    }
}
