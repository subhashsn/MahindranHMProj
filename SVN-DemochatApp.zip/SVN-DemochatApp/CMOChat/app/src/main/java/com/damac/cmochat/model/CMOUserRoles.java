package com.damac.cmochat.model;

/**
 * Created by Barun.Gupta on 1/10/2017.
 *
 */

public class CMOUserRoles {
    private CMORoster users;
    private int roleId;
    private String roleName;

    public CMORoster getUsers() {
        return users;
    }

    public void setUsers(CMORoster users) {
        this.users = users;
    }

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
