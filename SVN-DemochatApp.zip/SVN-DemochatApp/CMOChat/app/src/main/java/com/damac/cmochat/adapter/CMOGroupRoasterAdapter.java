package com.damac.cmochat.adapter;

import android.databinding.DataBindingUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import com.damac.cmochat.R;
import com.damac.cmochat.api.RetrofitAPIInterface;
import com.damac.cmochat.databinding.GroupListItemBinding;
import com.damac.cmochat.model.CMOGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Barun.Gupta on 1/11/2017.
 *
 */

public class CMOGroupRoasterAdapter extends RecyclerView.Adapter<CMOGroupRoasterAdapter.ViewHolder> implements Filterable{
    private final String TAG = CMOGroupRoasterAdapter.class.getSimpleName();
    public List<CMOGroup> mGroupMembersList;
    public List<CMOGroup> mSearchList;
    private RetrofitAPIInterface retrofitAPIService;

    public CMOGroupRoasterAdapter(List<CMOGroup> membersList, RetrofitAPIInterface retrofitAPIService) {
        this.mGroupMembersList = membersList;
        this.retrofitAPIService = retrofitAPIService;
        this.mSearchList = membersList;
    }

    @Override
    public CMOGroupRoasterAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.group_list_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final CMOGroup cmoGroup = (mGroupMembersList.get(position));
        holder.bind(cmoGroup);
    }

    @Override
    public int getItemCount() {
        return mGroupMembersList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private GroupListItemBinding binding;

        public ViewHolder(View view) {
            super(view);
            binding = DataBindingUtil.bind(view);
        }

        public void bind(CMOGroup cmoGroup) {
            binding.setCmoGroup(cmoGroup);
        }
    }

    @Override
    public Filter getFilter() {
        Filter filter = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                List<CMOGroup> list = mSearchList;
                if (!charSequence.toString().isEmpty()) {
                    List<CMOGroup> mlist = new ArrayList<>();
                    for (CMOGroup cmoGroup: list) {
                        if (cmoGroup.getName().toString().toLowerCase().contains(charSequence.toString().toLowerCase())) {
                            mlist.add(cmoGroup);
                        }

                    }
                    filterResults.values = mlist;
                } else {
                    filterResults.values = list;
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mGroupMembersList = ( List<CMOGroup>) filterResults.values;
                notifyDataSetChanged();
            }
        };
        return filter;
    }
}
