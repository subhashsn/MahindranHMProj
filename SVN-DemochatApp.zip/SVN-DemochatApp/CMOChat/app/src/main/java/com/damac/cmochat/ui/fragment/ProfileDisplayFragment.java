package com.damac.cmochat.ui.fragment;


import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.damac.cmochat.R;
import com.damac.cmochat.ui.activity.ProfileEditActivity;
import com.damac.cmochat.util.AppUtils;
import com.damac.cmochat.xmpp.XMPPManager;

import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smackx.vcardtemp.packet.VCard;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.damac.cmochat.util.AppUtils.logError;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileDisplayFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileDisplayFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = ProfileDisplayFragment.class.getSimpleName();
    private ImageView editProfileClick;
    private RelativeLayout profileImageBackground;
    private CircleImageView profileImage;
    private TextView profileName;
    private TextView designation;
    private TextView mobileNumber;
    private TextView emailID;
    private static String jID;
    private boolean isUsername=false;

    public ProfileDisplayFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment ProfileDisplayFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProfileDisplayFragment newInstance(String jid) {
        jID=jid;
        return new ProfileDisplayFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        String jid = AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext());
        if(jid.equals(jID))
            isUsername=true;
        else
            isUsername=false;
        View fragmentView = inflater.inflate(R.layout.fragment_profile_display, container, false);
        editProfileClick = (ImageView) fragmentView.findViewById(R.id.iv_edit_profile);
        profileName = (TextView) fragmentView.findViewById(R.id.user_profile_name);
        designation = (TextView) fragmentView.findViewById(R.id.tv_set_desgination);
        mobileNumber = (TextView) fragmentView.findViewById(R.id.tv_set_mobilenum);
        emailID = (TextView) fragmentView.findViewById(R.id.tv_set_email_id);
        profileImage = (CircleImageView) fragmentView.findViewById(R.id.profile_image);
        profileImageBackground = (RelativeLayout) fragmentView.findViewById(R.id.profile_image_layout);
        if(isUsername) {
            String profilefirstname = AppUtils.getFromAppPrefs(AppUtils.PROFILE_FIRST_NAME, getContext());
            String profilelastname = AppUtils.getFromAppPrefs(AppUtils.PROFILE_LAST_NAME, getContext());
            if (profilefirstname != null && !profilefirstname.isEmpty())
                profileName.setText(profilefirstname + " " + profilelastname);
            String designtion = AppUtils.getFromAppPrefs(AppUtils.DESIGNATION, getContext());
            if (designtion != null && !designtion.isEmpty())
                designation.setText(designtion);
            String mobilenum = AppUtils.getFromAppPrefs(AppUtils.MOBILE_NUMBER, getContext());
            if (mobilenum != null && !mobilenum.isEmpty())
                mobileNumber.setText(mobilenum);
            String emilid = AppUtils.getFromAppPrefs(AppUtils.EMAIL_ID, getContext());
            if (emilid != null && !emilid.isEmpty())
                emailID.setText(emilid);
            String profImage = AppUtils.getFromAppPrefs(AppUtils.PROFILE_IMAGE, getContext());
            if (profImage != null && !profImage.isEmpty()) {
                byte[] imageByte = Base64.decode(profImage, Base64.DEFAULT);
                if (imageByte != null) {
                    int len = imageByte.length;
                    profileImage.setImageBitmap(BitmapFactory.decodeByteArray(imageByte, 0, len));
                    Drawable drawable = new BitmapDrawable(getResources(), AppUtils.blur(BitmapFactory.decodeByteArray(imageByte, 0, len), getContext()));
                    profileImageBackground.setBackground(drawable);
                }
            }
        }
        editProfileClick.setOnClickListener(this);
        new ProfileDisplayFragment.GetProfileDetailInAsyctask().execute();
        return fragmentView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    /*@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.menu_profile, menu);
    }*/

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.iv_edit_profile) {
            Intent startIntent = new Intent(getActivity(), ProfileEditActivity.class);
            startActivity(startIntent);
        }
    }

    private class GetProfileDetailInAsyctask extends AsyncTask {
        private Bitmap imageBitmap;
        private Bitmap imageBackgroundBitmap;
        private String profileFirstNameAsynck;
        private String profileLastNameAsynck;
        private String designationAsynck;
        private String mobileNumAsynck;
        private String emailIdAsynck;
        private Activity activity;
        private byte[] profileImgByte;

        @Override
        protected Object doInBackground(Object... params) {
            try {
        if(getContext()==null)
            return null;
                String jid = AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext());
                String vcardtxt="";
                if(isUsername)
                    vcardtxt=jid;
                else
                    vcardtxt= jID;

                VCard card = XMPPManager.getInstance(getContext()).getVCard(vcardtxt);
                if (card != null) {
                    profileImgByte = card.getAvatar();
                    if (profileImgByte != null) {
                        int len = profileImgByte.length;
                        imageBitmap = BitmapFactory.decodeByteArray(profileImgByte, 0, len);
                        imageBackgroundBitmap = BitmapFactory.decodeByteArray(profileImgByte, 0, len);
                    }
                    profileFirstNameAsynck = card.getFirstName();
                    profileLastNameAsynck = card.getLastName();
                    // profileNameAsynck = card.getFirstName()+" "+card.getLastName();
                    designationAsynck = card.getOrganizationUnit();
                    mobileNumAsynck = card.getPhoneWork("CELL");
                    emailIdAsynck = card.getEmailHome();
                }

            } catch (XMPPException.XMPPErrorException | SmackException.NoResponseException |
                    SmackException.NotConnectedException e) {
                logError(TAG, e.getMessage(), e);
            }
            return "Executed";
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onPostExecute(Object o) {
            //super.onPostExecute(o);
            activity = getActivity();
            if (isRemoving() || activity == null)
                return;
            if (imageBitmap != null && profileImgByte != null) {
                profileImage.setImageBitmap(imageBitmap);
                Drawable drawable = new BitmapDrawable(getResources(), AppUtils.blur(imageBackgroundBitmap, getContext()));
                profileImageBackground.setBackground(drawable);
                if(isUsername)
                  AppUtils.addToAppPrefs(AppUtils.PROFILE_IMAGE, Base64.encodeToString(profileImgByte, Base64.DEFAULT), getContext());
            }
            if (profileFirstNameAsynck != null && !profileFirstNameAsynck.isEmpty()) {
                profileName.setText(profileFirstNameAsynck + " " + profileLastNameAsynck);
                if(isUsername) {
                    AppUtils.addToAppPrefs(AppUtils.PROFILE_FIRST_NAME, profileFirstNameAsynck, getContext());
                    AppUtils.addToAppPrefs(AppUtils.PROFILE_LAST_NAME, profileLastNameAsynck, getContext());
                }
            }
            if (designationAsynck != null && !designationAsynck.isEmpty()) {
                designation.setText(designationAsynck);
                if(isUsername)
                    AppUtils.addToAppPrefs(AppUtils.DESIGNATION, designationAsynck, getContext());
            }
            if (mobileNumAsynck != null && !mobileNumAsynck.isEmpty()) {
                mobileNumber.setText(mobileNumAsynck);
                if(isUsername)
                    AppUtils.addToAppPrefs(AppUtils.MOBILE_NUMBER, mobileNumAsynck, getContext());
            }
            if (emailIdAsynck != null && !emailIdAsynck.isEmpty()) {
                emailID.setText(emailIdAsynck);
                if(isUsername)
                    AppUtils.addToAppPrefs(AppUtils.EMAIL_ID, emailIdAsynck, getContext());
            }
        }
    }
}
