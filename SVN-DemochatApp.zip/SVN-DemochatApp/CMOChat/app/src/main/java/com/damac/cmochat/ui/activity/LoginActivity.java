package com.damac.cmochat.ui.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.Toast;

import com.damac.cmochat.R;
import com.damac.cmochat.events.XMPPAuthenticationEvent;
import com.damac.cmochat.util.AppURLs;
import com.damac.cmochat.util.AppUtils;
import com.damac.cmochat.xmpp.SmackService;
import com.damac.cmochat.xmpp.XMPPManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String PORT = "5222";
    private Button connectBtn;
    private EditText userName, password;
    private Intent connectionIntent;
    private ProgressBar progressBar;
    private Switch remmberSwitch;

    public static boolean verifyJabberID(String jid) {
        try {
            String parts[] = jid.split("@");
            if (parts.length != 2 || parts[0].length() == 0 || parts[1].length() == 0) {
                return false;
            }
        } catch (NullPointerException e) {
            return false;
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        connectBtn = (Button) findViewById(R.id.connect);
        userName = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        connectBtn.setOnClickListener(this);
        if (SmackService.getState().equals(XMPPManager.ConnectionState.CONNECTED)) {
            connectBtn.setText(getString(R.string.disconnect));
            Toast.makeText(this, "Authenticated Successfully!!", Toast.LENGTH_SHORT).show();
            Intent startIntent = new Intent(this, ConversationsActivity.class);
            startActivity(startIntent);
            finish();
        }

        remmberSwitch = (Switch) findViewById(R.id.remember_switch);
        remmberSwitch.setChecked(false);

        Boolean rememberPwd = AppUtils.getSharedPref(this).getBoolean(AppUtils.REMEMBER_PWD, true);

        if (rememberPwd) {
            String username = AppUtils.getSharedPref(this).getString(AppUtils.USERNAME, "");
            userName.setText(username);
            String pwd = AppUtils.getSharedPref(this).getString(AppUtils.PASSWORD, "");
            password.setText(pwd);
            remmberSwitch.setChecked(true);
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onClick(View v) {
        String username = userName.getText().toString() + "@" + AppURLs.DOMAIN;
        String pwd = password.getText().toString();
        if (remmberSwitch.isChecked() == true) {
            SharedPreferences.Editor editor = AppUtils.getSharedPref(this).edit();
            editor.putBoolean(AppUtils.REMEMBER_PWD, remmberSwitch.isChecked());
            editor.putString(AppUtils.USERNAME, userName.getText().toString());
            editor.putString(AppUtils.PASSWORD, password.getText().toString());
            editor.commit();
        }
        connect(username, pwd);
    }

    private void connect(String username, String pwd) {
        if (!verifyJabberID(username)) {
            Toast.makeText(this, "Invalid ID", Toast.LENGTH_SHORT).show();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        if (SmackService.getState().equals(XMPPManager.ConnectionState.DISCONNECTED)) {
            ArrayList<String> keys = new ArrayList<>();
            ArrayList<String> values = new ArrayList<>();
            keys.add(AppUtils.XMPP_JID);
            keys.add(AppUtils.XMPP_PASSWORD);
            keys.add(AppUtils.XMPP_PORT);
            keys.add(AppUtils.XMPP_HOST);
            values.add(username);
            values.add(pwd);
            values.add(PORT);
            values.add(AppURLs.HOST);
            AppUtils.addToAppPrefs(keys, values, this);
            Intent intent = new Intent(this, SmackService.class);
            Bundle bundle = new Bundle();
            bundle.putString("UserName",username);
            bundle.putString("Password",pwd);
            intent.putExtras(bundle);
            startService(intent);
        } else {
            connectBtn.setText(getString(R.string.login));
            connectionIntent = new Intent(this, SmackService.class);
            stopService(connectionIntent);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(XMPPAuthenticationEvent event) {
        progressBar.setVisibility(View.GONE);
        if (event.getState().equals(XMPPManager.ConnectionState.CONNECTED)) {
            Toast.makeText(this, "Authenticated Successfully!!", Toast.LENGTH_SHORT).show();
            Intent startIntent = new Intent(this, ConversationsActivity.class);
            startActivity(startIntent);
            finish();
        } else {
            AppUtils.clearData(this);
            Toast.makeText(this, "" + event.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }
}
