package com.damac.cmochat.model;

import com.damac.cmochat.util.AppURLs;

import java.util.ArrayList;

/**
 * Created by Narasimha.HS on 2/23/2017.
 * <p>
 * Model class to create a new chatroom. To be used by XMPP REST API
 */

public class NewChatRoom {
    private String roomName;
    private String naturalName;
    private String description;
    private String subject;
    private String persistent;
    private String membersOnly;
    private Members members;
    private String canOccupantsInvite;
    private String maxUsers;
    private String publicRoom;
    private Owners owners;

    /**
     * Constructor will be called from Builder class only
     *
     * @param roomName           -
     * @param naturalName        -
     * @param description        -
     * @param subject            -
     * @param persistent         -
     * @param membersOnly        -
     * @param members            -
     * @param canOccupantsInvite -
     * @param maxUsers           -
     * @param publicRoom         -
     */
    private NewChatRoom(String roomName, String naturalName, String description, String subject, String persistent,
                        String membersOnly, Members members, String canOccupantsInvite, String maxUsers, String publicRoom, Owners owners) {
        this.roomName = roomName;
        this.naturalName = naturalName;
        this.description = description;
        this.subject = subject;
        this.persistent = persistent;
        this.membersOnly = membersOnly;
        this.members = members;
        this.canOccupantsInvite = canOccupantsInvite;
        this.maxUsers = maxUsers;
        this.publicRoom = publicRoom;
        this.owners = owners;
    }

    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public String getNaturalName() {
        return naturalName;
    }

    public void setNaturalName(String naturalName) {
        this.naturalName = naturalName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getPersistent() {
        return persistent;
    }

    public void setPersistent(String persistent) {
        this.persistent = persistent;
    }

    public String getMembersOnly() {
        return membersOnly;
    }

    public void setMembersOnly(String membersOnly) {
        this.membersOnly = membersOnly;
    }

    public Members getMembers() {
        return members;
    }

    public void setMembers(Members members) {
        this.members = members;
    }

    public String getCanOccupantsInvite() {
        return canOccupantsInvite;
    }

    public void setCanOccupantsInvite(String canOccupantsInvite) {
        this.canOccupantsInvite = canOccupantsInvite;
    }

    public String getMaxUsers() {
        return maxUsers;
    }

    public void setMaxUsers(String maxUsers) {
        this.maxUsers = maxUsers;
    }

    public String getPublicRoom() {
        return publicRoom;
    }

    public void setPublicRoom(String publicRoom) {
        this.publicRoom = publicRoom;
    }

    public Owners getOwners() {
        return owners;
    }

    public void setOwners(Owners owners) {
        this.owners = owners;
    }

    /**
     * Class to Build the a NewChatRoom Instance
     */
    public static class Builder {
        private String roomName;
        private String naturalName;
        private String description;
        private String subject;
        private String persistent;
        private String membersOnly;
        private Members members;
        private String canOccupantsInvite;
        private String maxUsers;
        private String publicRoom;
        private Owners owners;

        public Builder setRoomName(String roomName) {
            this.roomName = roomName;
            return this;
        }

        public Builder setNaturalName(String naturalName) {
            this.naturalName = naturalName;
            return this;
        }

        public Builder setDescription(String description) {
            this.description = description;
            return this;
        }

        public Builder setSubject(String subject) {
            this.subject = subject;
            return this;
        }

        public Builder setPersistent(String persistent) {
            this.persistent = persistent;
            return this;
        }

        public Builder setMembersOnly(String membersOnly) {
            this.membersOnly = membersOnly;
            return this;
        }

        public Builder setMembers(Members members) {
            this.members = members;
            return this;
        }

        public Builder setCanOccupantsInvite(String canOccupantsInvite) {
            this.canOccupantsInvite = canOccupantsInvite;
            return this;
        }

        public Builder setMaxUsers(String maxUsers) {
            this.maxUsers = maxUsers;
            return this;
        }

        public Builder setPublicRoom(String publicRoom) {
            this.publicRoom = publicRoom;
            return this;
        }

        public Builder setOwners(Owners owners) {
            this.owners = owners;
            return this;
        }

        public NewChatRoom createNewChatRoom() {
            return new NewChatRoom(roomName, naturalName, description, subject, persistent, membersOnly, members, canOccupantsInvite, maxUsers, publicRoom, owners);
        }
    }

    /**
     * Class to encapsulate Chatroom members
     */
    public static class Members {
        private ArrayList<String> member;

        public Members(ArrayList<String> member) {
            this.member = member;
        }

        public ArrayList<String> getMember() {
            return member;
        }

        public void setMember(ArrayList<String> member) {
            this.member = member;
        }
    }

    /**
     * Class to encapsulate Chatroom owners
     */
    public static class Owners {
        private String owner;

        public Owners(String owner) {
            this.owner = owner;
        }

        public String getOwner() {
            return owner;
        }

        public void setOwner(String owner) {
            this.owner = owner;
        }
    }
}

