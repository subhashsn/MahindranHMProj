package com.damac.cmochat.util;

import com.damac.cmochat.model.CMOGroup;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;
import java.util.ArrayList;

import static com.damac.cmochat.util.AppUtils.logError;

/**
 * Created by Barun.Gupta on 1/16/2017.
 *
 */

public class CMOGroupConverter implements JsonSerializer<ArrayList<CMOGroup>>,
        JsonDeserializer<ArrayList<CMOGroup>> {

    @Override
    public JsonElement serialize(ArrayList<CMOGroup> src, Type typeOfSrc, JsonSerializationContext context) {
        JsonArray ja = new JsonArray();
        ja.add(context.serialize(src));
        return ja;
    }

    @Override
    public ArrayList<CMOGroup> deserialize(JsonElement jsonElement, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        ArrayList<CMOGroup> groupArray = new ArrayList<CMOGroup>();

        if (jsonElement != null) {
            if (jsonElement.isJsonArray()) {
                JsonArray membersArray = jsonElement.getAsJsonArray();
                for (int i = 0; i < membersArray.size(); i++) {
                    JsonObject memberObjct = membersArray.get(i).getAsJsonObject();
                    try {
                        CMOGroup cmGrp = new CMOGroup();
                        cmGrp.setName(memberObjct.get("name").getAsString());
                        cmGrp.setDescription(memberObjct.get("description").getAsString());
                        groupArray.add(cmGrp);
                    } catch (Exception ex) {
                        logError(CMOGroupConverter.class.getSimpleName(), ex.getMessage(), ex);
                    }
                }
            } else {
                JsonObject memberObjct = jsonElement.getAsJsonObject();
                CMOGroup cmGrp = new CMOGroup();
                cmGrp.setName(memberObjct.get("name").getAsString());
                cmGrp.setDescription(memberObjct.get("description").getAsString());
                groupArray.add(cmGrp);
            }
        }
        return groupArray;
    }
}
