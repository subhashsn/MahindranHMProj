package com.damac.cmochat.model;

/**
 * Created by Barun.Gupta on 1/23/2017.
 *
 */

public class CMOChatRoomMember {
    private String[] member;

    public String[] getMember() {
        return member;
    }

    public void setMember(String[] member) {
        this.member = member;
    }
}
