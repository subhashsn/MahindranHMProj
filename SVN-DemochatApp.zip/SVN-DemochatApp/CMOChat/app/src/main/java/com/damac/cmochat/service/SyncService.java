package com.damac.cmochat.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.damac.cmochat.events.SyncRequestEvent;
import com.damac.cmochat.sync.SyncManager;
import com.damac.cmochat.sync.SyncType;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.realm.Realm;

import static com.damac.cmochat.util.AppUtils.log;

/**
 * Created by Barun.Gupta on 1/28/2017.
 *
 */

public class SyncService extends Service {

    private ExecutorService executor = null;
    private final String TAG = SyncService.class.getSimpleName();
    private SyncManager syncManager = null;
    private Realm realm;

    @Override
    public void onCreate() {
        log(TAG, "SyncService onCreate");
        executor = Executors.newSingleThreadExecutor();
        realm = Realm.getDefaultInstance();
        syncManager = new SyncManager(getApplicationContext(), realm);
        EventBus.getDefault().register(this);
    }

    @Override
    public void onDestroy() {
        log(TAG, "SyncService onDestroy");
        super.onDestroy();
        EventBus.getDefault().unregister(this);
        if (realm != null) {
            realm.close();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        log(TAG, "SyncService onStartCommand startId" + startId);
        executor.execute(new Runnable() {
            @Override
            public void run() {
                log(TAG, "doSync CMO_CHATROOM_SYNC");
                syncManager.doSync(SyncType.CMO_CHATROOM_SYNC);
            }
        });
        return super.onStartCommand(intent, flags, startId);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        log(TAG, "SyncService onBind");
        return null;
    }

    @Subscribe
    public void onEvent(@NonNull final SyncRequestEvent event) {
        switch (event.getSyncType()) {
            case CMO_CHATROOM_SYNC:
                log(TAG, "doSync CMO_GROUP_SYNC");
                syncManager.doSync(SyncType.CMO_GROUP_SYNC);
                break;
            case CMO_GROUP_SYNC:
                log(TAG, "doSync CMO_GROUP_MEMBER_SYNC");
                stopSelf();
                //syncManager.doSync(SyncType.CMO_GROUP_MEMBER_SYNC);
                break;
            case CMO_GROUP_MEMBER_SYNC:
                stopSelf();
                break;
        }
    }
}
