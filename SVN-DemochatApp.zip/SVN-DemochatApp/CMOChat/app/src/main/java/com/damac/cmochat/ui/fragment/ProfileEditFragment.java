package com.damac.cmochat.ui.fragment;


import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.damac.cmochat.R;
import com.damac.cmochat.adapter.CountryCodeAdapter;
import com.damac.cmochat.model.CountryCodeCallBack;
import com.damac.cmochat.model.CountryCodeList;
import com.damac.cmochat.util.AppUtils;
import com.google.gson.Gson;

import java.io.InputStream;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileEditFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileEditFragment extends Fragment implements View.OnClickListener, CountryCodeCallBack {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private RelativeLayout profileImageBackground;
    private RelativeLayout countryCodeLayout;
    private CircleImageView profileImage;
    private EditText profileFirstName;
    private EditText profileLastName;
    private EditText designation;
    private EditText mobileNumber;
    private EditText emailID;
    private TextView tv_countryCode;
    private CountryCodeList countryCodeList;
    private RecyclerView lv_countrylist;
    private EditText inputSearchCountry;
    private CountryCodeAdapter countryCodeAdapter = null;
    private String countryCode = "";

    public ProfileEditFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ProfileEditFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProfileEditFragment newInstance(String param1, String param2) {
        ProfileEditFragment fragment = new ProfileEditFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View fragmentView = inflater.inflate(R.layout.fragment_profile_edit, container, false);
        profileFirstName = (EditText) fragmentView.findViewById(R.id.et_firstname);
        profileFirstName.setEnabled(false);
        profileLastName = (EditText) fragmentView.findViewById(R.id.et_lastname);
        profileLastName.setEnabled(false);
        designation = (EditText) fragmentView.findViewById(R.id.et_designation);
        designation.setEnabled(false);
        mobileNumber = (EditText) fragmentView.findViewById(R.id.et_mobilenumber);
        emailID = (EditText) fragmentView.findViewById(R.id.et_emailid);
        emailID.setEnabled(false);
        profileImage = (CircleImageView) fragmentView.findViewById(R.id.edit_profile_image);
        profileImageBackground = (RelativeLayout) fragmentView.findViewById(R.id.edit_profile_layout);
        countryCodeLayout = (RelativeLayout) fragmentView.findViewById(R.id.rl_countryCode_layout);
        tv_countryCode = (TextView) fragmentView.findViewById(R.id.et_country_code);
        countryCodeLayout.setOnClickListener(this);
        String profilefirstname = AppUtils.getFromAppPrefs(AppUtils.PROFILE_FIRST_NAME, getContext());
        if (profilefirstname != null && !profilefirstname.isEmpty())
            profileFirstName.setText(profilefirstname);
        String profilelastname = AppUtils.getFromAppPrefs(AppUtils.PROFILE_LAST_NAME, getContext());
        if (profilelastname != null && !profilelastname.isEmpty())
            profileLastName.setText(profilelastname);
        String designtion = AppUtils.getFromAppPrefs(AppUtils.DESIGNATION, getContext());
        if (designtion != null && !designtion.isEmpty())
            designation.setText(designtion);
        String mobilenum = AppUtils.getFromAppPrefs(AppUtils.MOBILE_NUMBER, getContext());
        if (mobilenum != null && !mobilenum.isEmpty())
            mobileNumber.setText(mobilenum);
        String emilid = AppUtils.getFromAppPrefs(AppUtils.EMAIL_ID, getContext());
        if (emilid != null && !emilid.isEmpty())
            emailID.setText(emilid);
        String profImage = AppUtils.getFromAppPrefs(AppUtils.PROFILE_IMAGE, getContext());
        if (profImage != null && !profImage.isEmpty()) {
            byte[] imageByte = Base64.decode(profImage, Base64.DEFAULT);
            if (imageByte != null) {
                int len = imageByte.length;
                profileImage.setImageBitmap(BitmapFactory.decodeByteArray(imageByte, 0, len));
                Drawable drawable = new BitmapDrawable(getResources(), AppUtils.blur(BitmapFactory.decodeByteArray(imageByte, 0, len), getContext()));
                profileImageBackground.setBackground(drawable);
            }
        }

        //Reading source from local file
        InputStream inputStream = this.getResources().openRawResource(R.raw.countrycode);
        String jsonString = AppUtils.readJsonFile(inputStream);
        Gson gson = new Gson();
        countryCodeList = gson.fromJson(jsonString, CountryCodeList.class);
        return fragmentView;
    }


    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.rl_countryCode_layout) {
            FragmentManager fm = getFragmentManager();
            final CountryCodeDailogFragment dialogFrag = CountryCodeDailogFragment.newInstance(countryCodeList);
            dialogFrag.setTargetFragment(this, 0);
            dialogFrag.show(fm, CountryCodeDailogFragment.class.getSimpleName());
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (countryCode != null && !countryCode.isEmpty())
            tv_countryCode.setText(countryCode);
    }

    @Override
    public void onCountryCodeCallBack(final String countryCode) {
        if (getActivity() == null)
            return;
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (countryCode != null && !countryCode.isEmpty())
                    tv_countryCode.setText(countryCode);
            }
        });
    }
}
