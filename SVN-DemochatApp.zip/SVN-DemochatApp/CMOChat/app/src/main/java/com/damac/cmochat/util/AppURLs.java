package com.damac.cmochat.util;

/**
 * Created by Narasimha.HS on 1/24/2017.
 * <p>
 * Class which holds all the fixed urls.
 */

public class AppURLs {
    /*Server seting goes here
    /*/
   /* public static final String DOMAIN = "10.0.0.4";
    public static final String HOST = "52.172.38.208";
    public static final String USERNAME = "barun";
    public static final String OPENFIRE_REST_TOKEN = "1dSkHzCplsV61Nj4";*/

    public static final String DOMAIN = "10.0.0.4";
    public static final String HOST = "devhomestaycare.southindia.cloudapp.azure.com";
    public static final String PORT = "5222";
    public static final String USERNAME = "barun";
    public static final String OPENFIRE_REST_TOKEN = "1dSkHzCplsV61Nj4";


    /* Azure Account Credentials */

    public static final String AZURE_ACCOUNT_NAME = "smileschat";
    public static final String AZURE_ACCOUNT_KEY = "9DqlpTXHrQD5ASJieP64J91VQXibBLvIynB1DEg8Mh1HjXCd1k32X+jjHRySsSTePezGqJQSOC1uabk4vl7KnA==";
    public static final String AZURE_BLOB_STORAGE_API = "https://smileschat.blob.core.windows.net/";
    public static final String AZURE_CONTAINER_NAME = "sharedfiles";


    /**
     * Class is not meant to be initialized
     */
    private AppURLs() {

    }
}
