package com.damac.cmochat.xmpp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.util.Log;

import com.damac.cmochat.events.RoomCreatedEvent;
import com.damac.cmochat.model.XMPPBody;
import com.damac.cmochat.util.AppURLs;
import com.damac.cmochat.util.AppUtils;
import com.google.gson.Gson;

import org.greenrobot.eventbus.EventBus;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.ConnectionListener;
import org.jivesoftware.smack.MessageListener;
import org.jivesoftware.smack.ReconnectionManager;
import org.jivesoftware.smack.SmackConfiguration;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.chat.Chat;
import org.jivesoftware.smack.chat.ChatManager;
import org.jivesoftware.smack.chat.ChatManagerListener;
import org.jivesoftware.smack.chat.ChatMessageListener;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.provider.ProviderManager;
import org.jivesoftware.smack.roster.Roster;
import org.jivesoftware.smack.roster.RosterListener;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;
import org.jivesoftware.smackx.chatstates.ChatState;
import org.jivesoftware.smackx.chatstates.packet.ChatStateExtension;
import org.jivesoftware.smackx.muc.DiscussionHistory;
import org.jivesoftware.smackx.muc.InvitationListener;
import org.jivesoftware.smackx.muc.InvitationRejectionListener;
import org.jivesoftware.smackx.muc.MultiUserChat;
import org.jivesoftware.smackx.muc.MultiUserChatManager;
import org.jivesoftware.smackx.vcardtemp.VCardManager;
import org.jivesoftware.smackx.vcardtemp.packet.VCard;
import org.jivesoftware.smackx.xdata.Form;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import static com.damac.cmochat.util.AppUtils.XMPP_HOST;
import static com.damac.cmochat.util.AppUtils.XMPP_PORT;
import static com.damac.cmochat.util.AppUtils.log;
import static com.damac.cmochat.util.AppUtils.logError;

/**
 * Created by Narasimha
 * Interface for all XMPP tasks in the app
 */
public class XMPPManager implements ConnectionListener, RosterListener, InvitationListener,
        InvitationRejectionListener, MessageListener {

    private static final String TAG = "SMACK_CONN";
    private static XMPPTCPConnection mConnection;
    private static String Resource = "Android_Chat";
    //private boolean isGroup;
    //private String toId;
    //private ChatManager chatManager;
    public static XMPPManager instance;
    private static String CONFERENCE_ADDRESS;
    private static Roster mRoster;
    private ChatMessageListener messageListener;

    static {
        //See - http://op-co.de/blog/posts/XEP-0198/
        XMPPTCPConnection.setUseStreamManagementDefault(true);
        XMPPTCPConnection.setUseStreamManagementResumptionDefault(true);
        //Enable Smack logging
        SmackConfiguration.DEBUG = true;
        //See http://download.igniterealtime.org/smack/docs/latest/documentation/roster.html
        Roster.setDefaultSubscriptionMode(Roster.SubscriptionMode.accept_all);
        ProviderManager.addExtensionProvider(CustomMessageExtension.ELEMENT, CustomMessageExtension.NAMESPACE, new CustomMessageExtension.CustomMessageExtensionProvider());
    }

    private final Context mApplicationContext;
    private final String mPassword;
    private final String mUsername;
    private final String mPort;
    private final String mHost;
    private final String mServiceName;
    private String jid;
    private MultiUserChatManager mucManager;
    private MultiUserChat mucChat;
    private BroadcastReceiver mReceiver;
    private WeakReference<SmackService> mSmackService;

    /**
     * Constructor - Singleton
     *
     * @param mCtx - Context
     */
    private XMPPManager(Context mCtx) {
        log(TAG, "ChatConnection()");
        mApplicationContext = mCtx.getApplicationContext();
        mPassword = AppUtils.getFromAppPrefs(AppUtils.XMPP_PASSWORD, mApplicationContext, "admin");
        jid = AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, mApplicationContext, AppURLs.USERNAME + "@" + AppURLs.DOMAIN);
        mPort = AppUtils.getFromAppPrefs(XMPP_PORT, mApplicationContext, "");
        mHost = AppUtils.getFromAppPrefs(XMPP_HOST, mApplicationContext, "");
        mServiceName = jid.split("@")[1];
        mUsername = jid.split("@")[0];
        if (mCtx instanceof SmackService)
            mSmackService = new WeakReference<>((SmackService) mCtx);
         CONFERENCE_ADDRESS = "conference." + AppURLs.DOMAIN;
    }

    public static Roster getmRoster() {
        if (mRoster != null)
            return mRoster;
        else if (mConnection != null) {
            mRoster = Roster.getInstanceFor(mConnection);
            return mRoster;
        }
        log("mCOnnection is NULL!!");
        return null;
    }

    /**
     * Method to get the {@link XMPPManager} instance
     *
     * @param c - Context to use
     * @return - XMPP instance
     */
    public static XMPPManager getInstance(Context c) {
        if (instance == null) {
            return instance = new XMPPManager(c);
        } else {
            return instance;
        }
    }

    /**
     * Returns the {@link XMPPTCPConnection} instance
     *
     * @return -
     */
    public static XMPPTCPConnection getXMPPTCPConnectionInstance() {
        return mConnection;
    }

    /**
     * Method to Check userconnection is connected or not
     */
    private static void checkXmppConnection() {
        if (mConnection != null) {
            if (!mConnection.isConnected()) {
                try {
                    mConnection.connect();
                } catch (SmackException | IOException | XMPPException e) {
                    logError(TAG, e.getMessage(), e);
                }
            }
        }
    }

    /**
     * Method to add roster Listener whenever data is fetched from DB
     *
     * @param mContext - Application context
     */
    public static void addRosterListner(Context mContext) {
        checkXmppConnection();
        getmRoster();
        mRoster.addRosterListener(getInstance(mContext));
    }

    /**
     * Initiate a connection to XMPP server with all the required configurations
     *
     * @throws IOException    -
     * @throws XMPPException  -
     * @throws SmackException -
     */
    public void connect(String username, String Password) throws IOException, XMPPException, SmackException {
        log(TAG, "connect()");
        XMPPTCPConnectionConfiguration.Builder builder = XMPPTCPConnectionConfiguration.builder();
        builder.setServiceName(mServiceName);
        if (mHost.isEmpty()) {
            builder.setHost("devhomestaycare.southindia.cloudapp.azure.com");
        }else {
            builder.setHost(mHost);
        }

        if (mPort.isEmpty()) {
            builder.setPort(Integer.parseInt("5222"));
        }else {
            builder.setPort(Integer.parseInt(mPort));
        }

        builder.setResource(Resource);
        //FIXME - Remove this
        builder.setSecurityMode(ConnectionConfiguration.SecurityMode.disabled);
        builder.setUsernameAndPassword(mUsername, mPassword);
        builder.setKeystoreType("BKS");

        //FIXME - Figure out this
        /*SSLContext sslContext;
        try {
            sslContext = SSLContext.getInstance("TLS");
            MemorizingTrustManager mtm = new MemorizingTrustManager(mApplicationContext);
            sslContext.init(null, new X509TrustManager[]{mtm}, new java.security.SecureRandom());
            builder.setCustomSSLContext(sslContext);
            builder.setHostnameVerifier(mtm.wrapHostnameVerifier(new org.apache.http.conn.ssl.StrictHostnameVerifier()));
        } catch (NoSuchAlgorithmException | KeyManagementException e) {
            log(e.getMessage());
        }*/

        mConnection = new XMPPTCPConnection(builder.build());
        Roster.getInstanceFor(mConnection).setRosterLoadedAtLogin(true);
        //Set ConnectionListener here to catch initial connect();
        mConnection.addConnectionListener(this);
        mConnection.connect();
        mConnection.login();
        //Timeout of 15 secs
        mConnection.setPacketReplyTimeout(15000);
        // Set status to online / available
        Presence presence = new Presence(Presence.Type.available);
        mConnection.sendStanza(presence);
        //Ping every 10 minutes
        //TODO - Do we need this
        /*PingManager.setDefaultPingInterval(600);
        PingManager pingManager = PingManager.getInstanceFor(mConnection);
        pingManager.registerPingFailedListener(this);*/
        /*Roster.getInstanceFor(mConnection).addRosterListener(this);
        Roster.getInstanceFor(mConnection).setSubscriptionMode(Roster.SubscriptionMode.accept_all);*/

        mucManager = MultiUserChatManager.getInstanceFor(mConnection);
        mucManager.addInvitationListener(this);
        messageListener = new ChatMessageListener() {
            @Override
            public void processMessage(Chat chat, Message message) {
                if (message != null) {
                    String from = message.getFrom();
                    String contactJid;
                    if (from.contains("/")) {
                        contactJid = from.split("/")[0];
                        Log.d(TAG, "The real jid is :" + contactJid);
                    } else {
                        contactJid = from;
                    }
                    if (contactJid.contains("@")) {
                        contactJid = contactJid.split("@")[0];
                    }
                    if (message.getBody() != null) {
                        XMPPBody xmppBody = new XMPPBody();
                        xmppBody.setFrom(contactJid);
                        xmppBody.setBody(message.getBody());
                        EventBus.getDefault().post(xmppBody);
                    }
                }
            }
        };
        ChatManager.getInstanceFor(mConnection).addChatListener(new ChatManagerListener() {
            @Override
            public void chatCreated(Chat chat, boolean createdLocally) {

                //If the line below is missing ,processMessage won't be triggered and you won't receive messages.
                chat.addMessageListener(messageListener);

            }
        });
        ReconnectionManager reconnectionManager = ReconnectionManager.getInstanceFor(mConnection);
        reconnectionManager.setEnabledPerDefault(true);
        reconnectionManager.enableAutomaticReconnection();
        getmRoster();
    }

    /**
     * Disconnect from XMPP server
     */
    void disconnect() {
        log(TAG, "disconnect()");
        if (mConnection != null) {
            mConnection.disconnect();
        }

        mConnection = null;
        if (mReceiver != null) {
            mApplicationContext.unregisterReceiver(mReceiver);
            mReceiver = null;
        }
    }

    /**
     * Callback for handling chat room invitations
     *
     * @param conn     - {@link XMPPTCPConnection}
     * @param room     - Chatroom
     * @param inviter  - User who is inviting
     * @param reason   - Reason
     * @param password - password for the group
     * @param message  - Message
     */
    @Override
    public void invitationReceived(XMPPConnection conn, final MultiUserChat room, final String inviter, String reason, String password, Message message) {
        log(TAG, "Invitation received ...... " + inviter + ":" + reason + ":" + room.getRoom());
        try {
            EventBus.getDefault().post(new RoomCreatedEvent());
            mucChat = room;
            room.join(getNickNameForJID(jid));
            room.addMessageListener(this);
            //Send an acceptance message
            Message acceptanceMessage = new Message();
            acceptanceMessage.setFrom(AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, mApplicationContext));
            acceptanceMessage.setType(Message.Type.groupchat);
            message.setBody("I accept!!");
            room.sendMessage(acceptanceMessage);
        } catch (SmackException.NoResponseException | SmackException.NotConnectedException | XMPPException.XMPPErrorException e) {
            logError(TAG, e.getMessage(), e);
        }
    }

    /**
     * Callback for handling message from the chatroom
     *
     * @param message - {@link Message} object
     */
    @Override
    public void processMessage(Message message) {
        //TODO - Think of a logic, create format to xmpp body model
        if (message.getBody() == null) {
            //For Handling typing status
            log("Message Body is null!!");
            EventBus.getDefault().post(message);
            return;
        }
        try {
            String body = message.getBody();
            String jsonBody;
            String jsonRoomName;
            String jsonFrom;
            String jsonDate;
            String mediaTypeStr;
            boolean isConcluded;
            boolean mediaType = false;
            if (body.startsWith("{")) {
                //FIXME - Is this logic correct??
                JSONObject json = new JSONObject(body);
                jsonBody = json.optString(AppUtils.BODY);
                jsonRoomName = json.optString(AppUtils.ROOM_NAME);
                if (jsonRoomName.isEmpty())
                    jsonRoomName = message.getFrom().substring(0, message.getFrom().indexOf('@'));
                jsonFrom = message.getFrom();
                jsonDate = json.optString(AppUtils.DATE);
                isConcluded = json.optBoolean(AppUtils.IS_CONCLUDED);
                mediaType = json.optBoolean(AppUtils.MEDIA_TYPE);
                mediaTypeStr = json.optString(AppUtils.MEDIA_TYPE);
                if (mediaTypeStr.equalsIgnoreCase("1")) {
                    mediaType = true;
                }
            } else {
                jsonBody = message.getBody();
                jsonRoomName = message.getFrom().substring(0, message.getFrom().indexOf('@'));
                jsonFrom = message.getFrom();
                jsonDate = null;
                isConcluded = true;
            }
            XMPPBody chatMessage = new XMPPBody().setBody(jsonBody).setRoomName(jsonRoomName).setFrom(jsonFrom).setDate(jsonDate).setConcluded(isConcluded).setMediaType(mediaType);
            //CMORepositoryService.getInstance().saveChatRoomMessage(Realm.getDefaultInstance(), chatMessage, mApplicationContext);
            EventBus.getDefault().post(chatMessage);
        } catch (JSONException e) {
            logError(TAG, e.getMessage(), e);
        }
    }

    /**
     * Callback for handling MUC invitation rejections
     *
     * @param invitee - User who declined the invitation
     * @param reason  - Reason for declining
     */
    @Override
    public void invitationDeclined(String invitee, String reason) {
        log(TAG, "rejected ... " + invitee + ":" + reason);
    }

    //TODO - Do we need this?
   /*public void removeListeners() {
        if (mucManager != null && mucManager.getMultiUserChat(toId) != null)
            mucManager.getMultiUserChat(toId).removeMessageListener(this);
        if (mChat != null)
            mChat.removeMessageListener(this);
    }*/

    /**
     * Method called to send message to a chat room
     *
     * @param roomName - Room Name
     * @param body     - Message String
     */
    public void sendGroupMessage(final String roomName, final XMPPBody body) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                log(TAG, "sendGroupMessage ... " + roomName);
                Message message = new Message();
                message.setType(Message.Type.groupchat);
                message.setBody(new Gson().toJson(body));
                message.setFrom(AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, mApplicationContext));
                addExtensionElement(message, body);
                if (mucChat != null) {
                    try {
                        mucChat.sendMessage(message);
                    } catch (SmackException.NotConnectedException e) {
                        logError(TAG, e.getMessage(), e);
                    }
                } else {
                    log("Unable to send group chat!! mucChat is NULL!!");
                }
            }
        }).start();
    }

    private void addExtensionElement(Message message, XMPPBody body) {
        if (message == null)
            return;
        //TODO - Handle null
        CustomMessageExtension customExt = new CustomMessageExtension(body.getRoomName(), "Test String", "test String");
        message.addExtension(customExt);
    }

    /**
     * Method to create a room an invite a user
     *
     * @param roomName - Room Name
     * @param jid      - Current User's Nick
     * @param toUser   - User to be invited
     */
    public void createConference(final String roomName, final String jid, final String toUser) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                log(TAG, "start createConference");
                // Create a MultiUserChat using a Connection for a room
                if (mucManager == null) {
                    mucManager = MultiUserChatManager.getInstanceFor(mConnection);
                    mucManager.addInvitationListener(XMPPManager.this);
                }
                //MultiUserChat muc = new MultiUserChat(connection, roomName + "@" + CONFERENCE_ADDRESS, MultiUserChatManager.getInstanceFor(connection));
                //Room Name in valid form
                MultiUserChat muc = mucManager.getMultiUserChat(roomName + "@" + CONFERENCE_ADDRESS);
                try {
                    //Create or join room
                    muc.createOrJoin(getNickNameForJID(jid));
                    log("Joined Room!! " + "as " + jid);
                    muc.addMessageListener(XMPPManager.this);
                    //Set the configurations - Refer XEP-0045
                    Form form = muc.getConfigurationForm();
                    Form answerForm = form.createAnswerForm();
                    answerForm.setAnswer("muc#roomconfig_roomname", roomName);
                    answerForm.setAnswer("muc#roomconfig_changesubject", true);
                    List<String> maxusers = new ArrayList<>();
                    maxusers.add("50");
                    answerForm.setAnswer("muc#roomconfig_maxusers", maxusers);
                    answerForm.setAnswer("muc#roomconfig_persistentroom", true);
                    answerForm.setAnswer("muc#roomconfig_allowinvites", true);
                    answerForm.setAnswer("muc#roomconfig_membersonly", true);

                    muc.sendConfigurationForm(answerForm);
                    mucChat = muc;

                    log(TAG, "Create room passed");
                    log(TAG, "Send configration passed");
                    log(TAG, "join room passed");
                    inviteToChat(toUser, roomName, muc);
                } catch (Exception ex) {
                    logError(TAG, ex.getMessage(), ex);
                }
            }
        }).start();
    }

    /**
     * Method to join an existing chat room
     *
     * @param roomName - Room Name
     */
    public void joinChatRoom(final String roomName, final boolean getAllMessages, final Date since) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                log(TAG, "joining ... " + roomName);
                checkXmppConnection();
                if (mConnection == null) {
                    log("XMPPConnection is null!");
                    return;
                }
                if (mucManager == null) {
                    mucManager = MultiUserChatManager.getInstanceFor(mConnection);
                    mucManager.addInvitationListener(XMPPManager.this);
                }
                mucChat = mucManager.getMultiUserChat(roomName + "@" + CONFERENCE_ADDRESS);
                mucChat.addMessageListener(XMPPManager.this);
                try {
                    String nickname = getNickNameForJID(jid);
                    if (getAllMessages)
                        mucChat.join(nickname);
                    else {
                        DiscussionHistory history = new DiscussionHistory();
                        if (since != null)
                            history.setSince(since);
                        mucChat.join(getNickNameForJID(jid), null, history, SmackConfiguration.getDefaultPacketReplyTimeout());
                      //  mucChat.join(nickname);
                    }
                } catch (SmackException.NoResponseException | SmackException.NotConnectedException | XMPPException.XMPPErrorException e) {
                    logError(TAG, e.getMessage(), e);
                } catch (SmackException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /**
     * Method to invite a user to existing chatroom
     *
     * @param toJid - jid of invitee
     */
    public void inviteUser(String toJid) {
        log(TAG, "inviting ... " + toJid);

        if (mConnection == null) {
            log("XMPPConnection is null!");
            return;
        }

        if (mucChat == null) {
            log("mucChat is null!");
            return;
        }

        try {
            mucChat.invite(toJid, "Join Me!!");
        } catch (SmackException.NotConnectedException e) {
            logError(TAG, e.getMessage(), e);
        }
    }

    /**
     * Method for adding users to a {@link Roster}
     *
     * @param jid - ids of users to be added to roster
     * @throws SmackException.NotLoggedInException
     * @throws XMPPException.XMPPErrorException
     * @throws SmackException.NotConnectedException
     * @throws SmackException.NoResponseException
     */
    public void addRosterEntries(final String jid) throws SmackException.NotLoggedInException, XMPPException.XMPPErrorException,
            SmackException.NotConnectedException, SmackException.NoResponseException {
        if (mConnection == null) {
            log("Connection is null!!");
            return;
        }
        checkXmppConnection();
        getmRoster();
        mRoster.addRosterListener(XMPPManager.this);
        log("jid::" + jid);
        if (jid != null && !jid.isEmpty()) {
            int indexOfAt = jid.indexOf('@') == -1 ? 0 : jid.indexOf('@');
            try {
                log("jid substring::" + jid.substring(0, indexOfAt));
                mRoster.createEntry(jid, jid.substring(0, indexOfAt), null);
            } catch (SmackException.NotLoggedInException | SmackException.NoResponseException | XMPPException.XMPPErrorException
                    | SmackException.NotConnectedException e) {
                logError(TAG, e.getMessage(), e);
            }
        } else {
            log("JID is null!!");
        }

    }

    /**
     * Method to handle inviting a user to a chat room
     *
     * @param id       - UserID of invitee
     * @param roomName - Room Name
     * @param muc      - {@link MultiUserChat} instance
     */
    private void inviteToChat(String id, String roomName, MultiUserChat muc) {
        log(TAG, "inviteToChat ... " + id);

        try {
            muc.invite(id, "Join me");
            log("XMPPChatDemoActivi", "Room invite sent");
        } catch (Exception ex) {
            logError(TAG, "Invite Failed!!" + ex.getMessage(), ex);
        }
    }

    /**
     * Method to get vCard of a particular user
     *
     * @param jid - JID of the user
     * @throws SmackException.NotConnectedException
     * @throws XMPPException.XMPPErrorException
     * @throws SmackException.NoResponseException
     */
    public VCard getVCard(String jid) throws SmackException.NotConnectedException, XMPPException.XMPPErrorException, SmackException.NoResponseException {
        checkXmppConnection();
        if (mConnection != null)
            return VCardManager.getInstanceFor(mConnection).loadVCard(jid);
        return null;
    }

    /**
     * Method to send a typing status to multi chat
     *
     * @param isTyping - whether the user is typing or not
     * @param from     - User's JID
     * @throws SmackException.NotConnectedException
     */
    public void sendComposingStatus(final boolean isTyping, final String from) throws SmackException.NotConnectedException {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (mucChat == null) {
                    log("mucChat is null!! Not sending status");
                    return;
                }
                Message msg = new Message();
                msg.setFrom(from);
                msg.setBody(null);
                if (isTyping)
                    msg.addExtension(new ChatStateExtension(ChatState.composing));
                else
                    msg.addExtension(new ChatStateExtension(ChatState.inactive));

                try {
                    mucChat.sendMessage(msg);
                } catch (SmackException.NotConnectedException e) {
                    logError(TAG, e.getMessage(), e);
                }
            }
        }).start();
    }

    //ConnectionListener
    @Override
    public void connected(XMPPConnection connection) {
        SmackService.sConnectionState = ConnectionState.CONNECTED;
        log(TAG, "connected()");
    }

    @Override
    public void authenticated(XMPPConnection connection, boolean resumed) {
//        if (mSmackService == null)
//            mSmackService = new WeakReference<>((SmackService) );

        SmackService mService = mSmackService.get();

        if (mService != null)
            mService.setConnState(ConnectionState.CONNECTED, "SUCCESS");
        log(TAG, "authenticated()");
    }

    @Override
    public void connectionClosed() {
        SmackService mService = mSmackService.get();
        instance = null;
        if (mService != null)
            mService.setConnState(ConnectionState.DISCONNECTED, "Authentication Failed");
        log(TAG, "connectionClosed()");
    }

    @Override
    public void connectionClosedOnError(Exception e) {
        SmackService mService = mSmackService.get();
        if (mService != null)
            mService.setConnState(ConnectionState.DISCONNECTED, e.getMessage());
        log(TAG, "connectionClosedOnError()");
    }

    @Override
    public void reconnectingIn(int seconds) {
        SmackService.sConnectionState = ConnectionState.RECONNECTING;
        log(TAG, "reconnectingIn()");
    }

    @Override
    public void reconnectionSuccessful() {
        SmackService.sConnectionState = ConnectionState.CONNECTED;
        log(TAG, "reconnectionSuccessful()");
    }

    @Override
    public void reconnectionFailed(Exception e) {
        SmackService.sConnectionState = ConnectionState.DISCONNECTED;
        log(TAG, "reconnectionFailed()");
    }

    //RosterListener
    @Override
    public void entriesAdded(Collection<String> addresses) {
        log(TAG, "entriesAdded()");
        //TODO - Commented
        //rebuildRoster();
    }

    @Override
    public void entriesUpdated(Collection<String> addresses) {
        log(TAG, "entriesUpdated()");
        //TODO - Commented
        //rebuildRoster();
    }

    @Override
    public void entriesDeleted(Collection<String> addresses) {
        log(TAG, "entriesDeleted()");
        //TODO - Commented
        //rebuildRoster();
    }

    @Override
    public void presenceChanged(Presence presence) {
        log(TAG, "presenceChanged()");
        EventBus.getDefault().post(presence);
    }

    public String getNickNameForJID(String jid) {
        try {
            if (jid != null && !jid.isEmpty() && jid.contains("@")) {
                return jid.substring(0, jid.indexOf('@'));
            } else {
                return jid;
            }
        } catch (Exception e) {
            Log.d(TAG, "Exception :" + e.getMessage());
        }
        return null;
    }

    public enum ConnectionState {
        CONNECTED, CONNECTING, RECONNECTING, DISCONNECTED;
    }

    public static void removeRosterListner(Context mContext) {
        mRoster.removeRosterListener(getInstance(mContext));
    }

    public void sendSingleMessage(XMPPBody body, String toJid) {
        Log.d(TAG, "Sending message to :" + toJid);
        Chat chat = ChatManager.getInstanceFor(mConnection)
                .createChat(toJid, messageListener);
        try {
            chat.sendMessage(body.getBody());
        } catch (SmackException.NotConnectedException e) {
            e.printStackTrace();
        }
    }
}
