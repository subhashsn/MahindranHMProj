package com.damac.cmochat.adapter;

import android.databinding.DataBindingUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.damac.cmochat.R;
import com.damac.cmochat.databinding.SearchListItemBinding;
import com.damac.cmochat.model.ChatRoom;

import java.util.List;

import static com.damac.cmochat.util.AppUtils.log;

/**
 * Created by Barun.Gupta on 2/13/2017.
 *
 */

public class SearchResultsAdapter  extends RecyclerView.Adapter<SearchResultsAdapter.ViewHolder>  {
    private static final String TAG = SearchResultsAdapter.class.getSimpleName();
    private List<ChatRoom> searchResultChatRoomList;

    public SearchResultsAdapter(List<ChatRoom> chatroomDataset) {
        this.searchResultChatRoomList = chatroomDataset;
    }

    @Override
    public SearchResultsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_list_item, parent, false);
        SearchResultsAdapter.ViewHolder vh = new SearchResultsAdapter.ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(final SearchResultsAdapter.ViewHolder holder, int position) {
        final ChatRoom chatroom = searchResultChatRoomList.get(position);
        log(TAG ,"chatroon"+chatroom.getSubject());
        holder.bind(chatroom);
        holder.getBinding().executePendingBindings();
    }

    @Override
    public int getItemCount() {
        return searchResultChatRoomList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private SearchListItemBinding binding;

        public ViewHolder(View view) {
            super(view);
            binding = DataBindingUtil.bind(view);
        }

        public void bind(ChatRoom chatroom) {
            binding.setSearchChatRoom(chatroom);
        }

        public SearchListItemBinding getBinding() {
            return binding;
        }
    }
}
