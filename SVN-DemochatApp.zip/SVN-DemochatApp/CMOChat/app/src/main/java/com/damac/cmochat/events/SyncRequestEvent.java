package com.damac.cmochat.events;

import android.support.annotation.NonNull;

import com.damac.cmochat.sync.SyncType;

/**
 * Created by Barun.Gupta on 1/29/2017.
 *
 */

public class SyncRequestEvent {

    private SyncType syncType;

    public SyncRequestEvent(@NonNull SyncType syncType) {
        this.syncType = syncType;
    }

    public SyncType getSyncType() {
        return syncType;
    }
}
