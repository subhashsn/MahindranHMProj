package com.damac.cmochat.events;

/**
 * Created by Narasimha.HS on 4/5/2017.
 * Class to notify that a new group chat has been created
 * 
 */

public class RoomCreatedEvent {
}
