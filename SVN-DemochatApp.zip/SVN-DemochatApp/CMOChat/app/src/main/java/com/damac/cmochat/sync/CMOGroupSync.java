package com.damac.cmochat.sync;

import android.content.Context;
import android.os.AsyncTask;

import com.damac.cmochat.api.APIManager;
import com.damac.cmochat.api.RetrofitAPIInterface;
import com.damac.cmochat.events.SyncRequestEvent;
import com.damac.cmochat.model.CMOGroup;
import com.damac.cmochat.model.CMORosterGroup;
import com.damac.cmochat.realm.CMORepositoryService;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.damac.cmochat.util.AppUtils.log;
import static com.damac.cmochat.util.AppUtils.logError;

/**
 * Created by Barun.Gupta on 1/30/2017.
 */

public class CMOGroupSync extends AbsSync {

    private Context mContext;
    private RetrofitAPIInterface retrofitAPIService = null;
    private Call<CMORosterGroup> getCMORoasterGroup = null;
    private static final String TAG = CMOGroupSync.class.getSimpleName();

    public CMOGroupSync(Context context) {
        super(context);
        mContext = context;
        retrofitAPIService = APIManager.getRealmCMOGroupInstance(mContext);
    }

    @Override
    protected void doSync() {
        getCMORoasterGroup = retrofitAPIService.getCMORoasterGroup();
        getCMORoasterGroup.enqueue(new Callback<CMORosterGroup>() {
            @Override
            public void onResponse(Call<CMORosterGroup> call, Response<CMORosterGroup> response) {
                if (response != null && response.isSuccessful()) {
                    final CMORosterGroup cmoRosterGroup = response.body();
                    final ArrayList<CMOGroup> groupArrayList = cmoRosterGroup.getCmoGroup();
                    log(TAG, "Syncing cmo group");
                    if (groupArrayList != null) {
                        AsyncTask.execute(new Runnable() {
                            @Override
                            public void run() {
                                Realm realm = Realm.getDefaultInstance();
                                try {
                                    for (CMOGroup cmoGroup : groupArrayList) {
                                        log(TAG, "Syncing cmo group" + cmoGroup.getName());
                                        cmoGroup.setMemberCount(String.valueOf("3"));
                                        CMORepositoryService.getInstance().saveCMOGroup(realm, cmoGroup);
                                    }
                                } catch (Exception e) {
                                    logError(TAG, e.getMessage(), e);
                                } finally {
                                    if (realm != null) {
                                        realm.close();
                                    }
                                    EventBus.getDefault().post(new SyncRequestEvent(SyncType.CMO_GROUP_SYNC));
                                }
                            }
                        });
                    }
                }
            }

            @Override
            public void onFailure(Call<CMORosterGroup> call, Throwable t) {
                log(TAG, "onFailure::" + t.getMessage());
                EventBus.getDefault().post(new SyncRequestEvent(SyncType.CMO_CHATROOM_SYNC));
            }
        });
    }
}
