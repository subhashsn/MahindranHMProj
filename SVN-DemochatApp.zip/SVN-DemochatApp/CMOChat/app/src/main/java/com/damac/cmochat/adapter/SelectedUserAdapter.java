package com.damac.cmochat.adapter;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.damac.cmochat.R;
import com.damac.cmochat.databinding.SelectedUserListItemBinding;
import com.damac.cmochat.model.User;

import java.util.List;

/**
 * Created by Barun.Gupta on 2/1/2017.
 *
 */

public class SelectedUserAdapter extends RecyclerView.Adapter<SelectedUserAdapter.ViewHolder> {
    private List<User> mUserSet;

    public SelectedUserAdapter(List<User> myDataset) {
        this.mUserSet = myDataset;
    }

    @Override
    public SelectedUserAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.selected_user_list_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(SelectedUserAdapter.ViewHolder holder, int position) {
        final User user = (mUserSet.get(position));
        holder.bind(user);
        holder.getBinding().executePendingBindings();
    }

    @Override
    public int getItemCount() {
        return mUserSet.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private SelectedUserListItemBinding binding;

        public ViewHolder(View view) {
            super(view);
            binding = DataBindingUtil.bind(view);
        }

        public void bind(User user) {
            binding.setCmoUser(user);

        }
        public ViewDataBinding getBinding() {
            return binding;
        }
    }
}
