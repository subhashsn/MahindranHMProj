package com.damac.cmochat.util;

import com.damac.cmochat.model.CMOGroupMembers;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;

import io.realm.RealmList;

/**
 * Created by Barun.Gupta on 1/16/2017.
 *
 */

public class CMOMemberRealmListConverter implements JsonSerializer<CMOGroupMembers>,
        JsonDeserializer<CMOGroupMembers> {

    @Override
    public JsonElement serialize(CMOGroupMembers src, Type typeOfSrc, JsonSerializationContext context) {
        JsonArray ja = new JsonArray();
        ja.add(context.serialize(src));
        return ja;
    }

    @Override
    public CMOGroupMembers deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        CMOGroupMembers cmoGroupMembers = new CMOGroupMembers();
        if (json != null) {
            JsonObject memberObjct = json.getAsJsonObject();

            /*  For single member*/

            JsonElement tempElement = memberObjct.get("member");
            if (tempElement.isJsonPrimitive()) {
                String memberStr = tempElement.getAsString();
                RealmList<RealmString> temp = new RealmList<>();
                RealmString tempObj = new RealmString();
                tempObj.setValue(memberStr.split("@")[0]);
                temp.add(tempObj);
                cmoGroupMembers.setMember(temp);
                return cmoGroupMembers;
            }

            /* For multiple members*/

            JsonArray ja = memberObjct.getAsJsonArray("member");
            RealmList<RealmString> temp = new RealmList<>();
            for (JsonElement str : ja) {
                RealmString tempObj = new RealmString();
                tempObj.setValue(str.getAsString().split("@")[0]);
                temp.add(tempObj);
            }
            cmoGroupMembers.setMember(temp);
        }

        return cmoGroupMembers;
    }
}
