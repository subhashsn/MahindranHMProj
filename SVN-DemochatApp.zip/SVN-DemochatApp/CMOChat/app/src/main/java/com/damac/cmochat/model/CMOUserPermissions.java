package com.damac.cmochat.model;

/**
 * Created by Barun.Gupta on 1/10/2017.
 *
 */

public class CMOUserPermissions {
    private int permissionId;
    private String conversationHistoryAvailable;
    private String canConfigureReminderTimeAndFrequency;
    private CMORoster users;
    private String chatInitiation;
    private String canCreateGroups;
    private String canDeleteUsers;
    private String canDeleteRecipients;
    private String addRecipientInAnOngoingChat;
    private String canSetSlaTime;
    private String canSetConfidentiality;
    private String canBlockAndProvideAccessToUsers;

    public int getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(int permissionId) {
        this.permissionId = permissionId;
    }

    public String getConversationHistoryAvailable() {
        return conversationHistoryAvailable;
    }

    public void setConversationHistoryAvailable(String conversationHistoryAvailable) {
        this.conversationHistoryAvailable = conversationHistoryAvailable;
    }

    public String getCanConfigureReminderTimeAndFrequency() {
        return canConfigureReminderTimeAndFrequency;
    }

    public void setCanConfigureReminderTimeAndFrequency(String canConfigureReminderTimeAndFrequency) {
        this.canConfigureReminderTimeAndFrequency = canConfigureReminderTimeAndFrequency;
    }

    public CMORoster getUsers() {
        return users;
    }

    public void setUsers(CMORoster users) {
        this.users = users;
    }

    public String getChatInitiation() {
        return chatInitiation;
    }

    public void setChatInitiation(String chatInitiation) {
        this.chatInitiation = chatInitiation;
    }

    public String getCanCreateGroups() {
        return canCreateGroups;
    }

    public void setCanCreateGroups(String canCreateGroups) {
        this.canCreateGroups = canCreateGroups;
    }

    public String getCanDeleteUsers() {
        return canDeleteUsers;
    }

    public void setCanDeleteUsers(String canDeleteUsers) {
        this.canDeleteUsers = canDeleteUsers;
    }

    public String getCanDeleteRecipients() {
        return canDeleteRecipients;
    }

    public void setCanDeleteRecipients(String canDeleteRecipients) {
        this.canDeleteRecipients = canDeleteRecipients;
    }

    public String getAddRecipientInAnOngoingChat() {
        return addRecipientInAnOngoingChat;
    }

    public void setAddRecipientInAnOngoingChat(String addRecipientInAnOngoingChat) {
        this.addRecipientInAnOngoingChat = addRecipientInAnOngoingChat;
    }

    public String getCanSetSlaTime() {
        return canSetSlaTime;
    }

    public void setCanSetSlaTime(String canSetSlaTime) {
        this.canSetSlaTime = canSetSlaTime;
    }

    public String getCanSetConfidentiality() {
        return canSetConfidentiality;
    }

    public void setCanSetConfidentiality(String canSetConfidentiality) {
        this.canSetConfidentiality = canSetConfidentiality;
    }

    public String getCanBlockAndProvideAccessToUsers() {
        return canBlockAndProvideAccessToUsers;
    }

    public void setCanBlockAndProvideAccessToUsers(String canBlockAndProvideAccessToUsers) {
        this.canBlockAndProvideAccessToUsers = canBlockAndProvideAccessToUsers;
    }
}
