package com.damac.cmochat.ui.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.damac.cmochat.R;
import com.damac.cmochat.databinding.SearchDialogFragmentBinding;
import com.damac.cmochat.ui.activity.CMOContactsListActivity;
import com.damac.cmochat.ui.listener.SearchListener;

import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_NAME;
import static com.damac.cmochat.util.AppUtils.IS_GROUP_CHAT;
import static com.damac.cmochat.util.AppUtils.USER_IDS_REQUEST_CODE;

/**
 * Created by Barun.Gupta on 2/10/2017.
 */

public class SearchDialogFragment extends DialogFragment implements View.OnClickListener {
    private SearchDialogFragmentBinding mDataBinderBinding;
    private SearchListener mSearchListener;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mDataBinderBinding = DataBindingUtil.inflate(inflater, R.layout.search_dialog_fragment, container, false);
        try {
            mSearchListener = (SearchListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement Callback interface");
        }
        mDataBinderBinding.cancel.setOnClickListener(this);
        mDataBinderBinding.search.setOnClickListener(this);
        return mDataBinderBinding.getRoot();
    }


    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.cancel:
                dismiss();
                break;
            case R.id.search:
                //mSearchListener.onSearch(mDataBinderBinding.editText.getText().toString(), mDataBinderBinding.editText2.getText().toString());
                mSearchListener.getRoomName(mDataBinderBinding.roomname.getText().toString());
                //addParticipants(mDataBinderBinding.roomname.getText().toString());
                dismiss();
                break;
        }
    }

    private void addParticipants(String roomName) {
        //Start the activity
        Intent intent = new Intent(getActivity(), CMOContactsListActivity.class);
        intent.putExtra(IS_GROUP_CHAT, true);
        intent.putExtra(CHAT_ROOM_NAME,roomName);
        startActivityForResult(intent, USER_IDS_REQUEST_CODE);
    }


}
