package com.damac.cmochat.model;

import java.util.ArrayList;

public class CMOChatRooms {

    private Meta meta;

    public ArrayList<ChatRoom> chatRoom;

    public ChatRoom chatRoomResponse;

    public ChatRoom getChatRoomResponse() {
        return chatRoomResponse;
    }

    public CMOChatRooms(ChatRoom chatroom) {
        this.chatRoomResponse = chatroom;
    }

    public CMOChatRooms(ArrayList<ChatRoom> chatroom) {
        this.chatRoom = chatroom;
    }

    public ArrayList<ChatRoom> getChatRoom() {
        return chatRoom;
    }

    public Meta getMeta() {
        return meta;
    }

    public void setMeta(Meta meta) {
        this.meta = meta;
    }
}