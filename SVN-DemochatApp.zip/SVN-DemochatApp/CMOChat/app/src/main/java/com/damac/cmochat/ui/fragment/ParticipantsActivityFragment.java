package com.damac.cmochat.ui.fragment;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.damac.cmochat.R;
import com.damac.cmochat.adapter.CMOUserRosterAdapter;
import com.damac.cmochat.adapter.GroupMemberAdapter;
import com.damac.cmochat.model.CMOGroupMembers;
import com.damac.cmochat.model.ChatRoom;
import com.damac.cmochat.model.User;
import com.damac.cmochat.realm.CMORepositoryService;
import com.damac.cmochat.util.AppURLs;
import com.damac.cmochat.util.AppUtils;
import com.damac.cmochat.util.RealmString;
import com.damac.cmochat.xmpp.XMPPManager;

import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smackx.vcardtemp.packet.VCard;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmResults;

import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_Members;
import static com.damac.cmochat.util.AppUtils.logError;

/**
 * A placeholder fragment containing a simple view.
 */
public class ParticipantsActivityFragment extends Fragment {

    private String mGrpName;
    private Realm realm;
    private ArrayList<String> chatRoomMember;
    private RecyclerView recyclerView;
    private final String TAG = ParticipantsActivityFragment.class.getSimpleName();


    private CMOUserRosterAdapter mGrpMemberAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    List<User> userList;

    public ParticipantsActivityFragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        realm = Realm.getDefaultInstance();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_participants, container, false);
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Participants");
        mGrpName = getActivity().getIntent().getStringExtra("RoomName");
        chatRoomMember = getActivity().getIntent().getStringArrayListExtra(CHAT_ROOM_Members);
        userList =new ArrayList<>();
        for (String member: chatRoomMember) {
            member = member.replaceAll("\"", "");
            String name = XMPPManager.getInstance(getActivity()).getNickNameForJID(member);
            User user = new User (name, member, "");
            Presence availability = XMPPManager.getInstance(getContext()).getmRoster().getPresence(
                    member);
            if (availability.isAvailable()) {
                user.setDrawbleId(R.drawable.round_green_circle);
            } else {
                user.setDrawbleId(R.drawable.round_gray_circle);
            }

            try {
                VCard card = XMPPManager.getInstance(getContext()).getVCard(member);
                byte[] imgs = card.getAvatar();
                if (imgs != null) {
                    user.setImgBitmap(imgs);
                } else {
                    Bitmap bMap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
                    user.setImgBitmap(AppUtils.getBytesFromBitmap(bMap));
                }
            } catch (XMPPException.XMPPErrorException | SmackException.NoResponseException | SmackException.NotConnectedException e){
                logError(TAG, e.getMessage(), e);
            }

            userList.add(user);
        }

        recyclerView = (RecyclerView) getActivity().findViewById(R.id.participants_list);
        recyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        mGrpMemberAdapter = new CMOUserRosterAdapter(userList);
        recyclerView.setAdapter(mGrpMemberAdapter);

    }
}
