package com.damac.cmochat.model;

import io.realm.Realm;
import io.realm.RealmObject;

/**
 * Created by Barun.Gupta on 3/2/2017.
 */

public class Meta extends RealmObject {
    private String requestTime;

    private String responseTime;

    public String getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(String requestTime) {
        this.requestTime = requestTime;
    }

    public String getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(String responseTime) {
        this.responseTime = responseTime;
    }
}
