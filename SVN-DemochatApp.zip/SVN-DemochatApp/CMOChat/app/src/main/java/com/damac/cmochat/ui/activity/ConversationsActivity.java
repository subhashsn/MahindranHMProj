package com.damac.cmochat.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.damac.cmochat.R;
import com.damac.cmochat.events.XMPPAuthenticationEvent;
import com.damac.cmochat.ui.fragment.ChatFragment;
import com.damac.cmochat.util.AppUtils;
import com.damac.cmochat.xmpp.XMPPManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;

import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_NAME;
import static com.damac.cmochat.util.AppUtils.RIGHT_CONTAINER_FRAGMENT_TAG;
import static com.damac.cmochat.util.AppUtils.USER_IDS;
import static com.damac.cmochat.util.AppUtils.USER_IDS_RESULT_CODE;

public class ConversationsActivity extends AppCompatActivity {
    private static final String TAG = ConversationsActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tabs_pager_main_layout);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(XMPPAuthenticationEvent event) {
        if (event.getState().equals(XMPPManager.ConnectionState.CONNECTED)) {
            Toast.makeText(this, "Authenticated Successfully!!", Toast.LENGTH_SHORT).show();
        } else if (event.getState().equals(XMPPManager.ConnectionState.DISCONNECTED)) {
            Toast.makeText(this, "Disconnected!!" + event.getMessage(), Toast.LENGTH_SHORT).show();
            Intent startIntent = new Intent(this, LoginActivity.class);
            startActivity(startIntent);
            finish();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == USER_IDS_RESULT_CODE) {
            ArrayList<String> userIds = data.getStringArrayListExtra(USER_IDS);
            String roomname = data.getStringExtra(CHAT_ROOM_NAME);
            ChatFragment fragment = (ChatFragment) getSupportFragmentManager().findFragmentByTag(RIGHT_CONTAINER_FRAGMENT_TAG);
            if (fragment != null) {
                fragment.participantsSelected(userIds);
            }
            Intent intent = new Intent(getApplicationContext(), ChatActivity.class);
            intent.putExtra(AppUtils.CREATE_CHAT_ROOM, true);
            intent.putExtra(CHAT_ROOM_NAME, roomname);
            intent.putStringArrayListExtra(AppUtils.PARTICIPANTS_ID, userIds);
            startActivity(intent);
        }
    }



}
