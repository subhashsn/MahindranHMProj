package com.damac.cmochat.model;

import android.databinding.Bindable;
import android.databinding.Observable;
import android.databinding.PropertyChangeRegistry;

import com.damac.cmochat.util.RealmString;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.Ignore;

/**
 * Created by Barun.Gupta on 1/19/2017.
 *
 */

public class ChatRoom extends RealmObject implements Observable {

    public String loginRestrictedToNickname;
    public String subject;
    public String canAnyoneDiscoverJID;
    public String membercount;
    public String timeleft;
    public String logEnabled;
    public String moderated;
    public String canOccupantsChangeSubject;
    public String maxUsers;
    public String registrationEnabled;
    public String description;
    public String roomName;
    public RealmList<RealmString> members;
    public String naturalName;
    public String membersOnly;
    public String canChangeNickname;
    public String canOccupantsInvite;
    public String creationDate;
    public String persistent;
    public String modificationDate;
    //public static CMOChatRoomOwner owners;
    public String publicRoom;
    public String memberCount;
    @Ignore
    private transient PropertyChangeRegistry mCallbacks;

    public String getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(String memberCount) {
        this.memberCount = memberCount;
    }

    public  ChatRoom(){
    }

    @Bindable
    public String getTimeleft() {
        return timeleft;
    }

    public void setTimeleft(String timeleft) {
        this.timeleft = timeleft;
        //notifyPropertyChanged(BR.timeleft);
    }

    public String getLoginRestrictedToNickname() {
        return loginRestrictedToNickname;
    }

    public void setLoginRestrictedToNickname(String loginRestrictedToNickname) {
        this.loginRestrictedToNickname = loginRestrictedToNickname;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getCanAnyoneDiscoverJID() {
        return canAnyoneDiscoverJID;
    }

    public void setCanAnyoneDiscoverJID(String canAnyoneDiscoverJID) {
        this.canAnyoneDiscoverJID = canAnyoneDiscoverJID;
    }

    public String getMembercount() {
        return membercount;
    }

    public void setMembercount(String membercount) {
        this.membercount = membercount;
    }

    public String getLogEnabled() {
        return logEnabled;
    }

    public void setLogEnabled(String logEnabled) {
        this.logEnabled = logEnabled;
    }

    public String getModerated() {
        return moderated;
    }

    public void setModerated(String moderated) {
        this.moderated = moderated;
    }

    public String getCanOccupantsChangeSubject() {
        return canOccupantsChangeSubject;
    }

    public void setCanOccupantsChangeSubject(String canOccupantsChangeSubject) {
        this.canOccupantsChangeSubject = canOccupantsChangeSubject;
    }

    public String getMaxUsers() {
        return maxUsers;
    }

    public void setMaxUsers(String maxUsers) {
        this.maxUsers = maxUsers;
    }

    public String getRegistrationEnabled() {
        return registrationEnabled;
    }

    public void setRegistrationEnabled(String registrationEnabled) {
        this.registrationEnabled = registrationEnabled;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public RealmList<RealmString> getMembers() {
        return members;
    }

    public void setMembers(RealmList<RealmString> members) {
        this.members = members;
    }

    public String getNaturalName() {
        return naturalName;
    }

    public void setNaturalName(String naturalName) {
        this.naturalName = naturalName;
    }

    public String getMembersOnly() {
        return membersOnly;
    }

    public void setMembersOnly(String membersOnly) {
        this.membersOnly = membersOnly;
    }

    public String getCanChangeNickname() {
        return canChangeNickname;
    }

    public void setCanChangeNickname(String canChangeNickname) {
        this.canChangeNickname = canChangeNickname;
    }

    public String getCanOccupantsInvite() {
        return canOccupantsInvite;
    }

    public void setCanOccupantsInvite(String canOccupantsInvite) {
        this.canOccupantsInvite = canOccupantsInvite;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getPersistent() {
        return persistent;
    }

    public void setPersistent(String persistent) {
        this.persistent = persistent;
    }

    public String getModificationDate() {
        return modificationDate;
    }

   /* public CMOChatRoomOwner getOwners() {
        return owners;
    }

    public void setOwners(CMOChatRoomOwner owners) {
        this.owners = owners;
    }*/

    public void setModificationDate(String modificationDate) {
        this.modificationDate = modificationDate;
    }

    public String getPublicRoom() {
        return publicRoom;
    }

    public void setPublicRoom(String publicRoom) {
        this.publicRoom = publicRoom;
    }

    @Override
    public void addOnPropertyChangedCallback(OnPropertyChangedCallback onPropertyChangedCallback) {
        if (mCallbacks == null) {
            mCallbacks = new PropertyChangeRegistry();
        }
        mCallbacks.add(onPropertyChangedCallback);
    }

    @Override
    public void removeOnPropertyChangedCallback(OnPropertyChangedCallback onPropertyChangedCallback) {
        if (mCallbacks != null) {
            mCallbacks.remove(onPropertyChangedCallback);
        }
    }

    /**
     * Notifies listeners that a specific property has changed. The getter for the property
     * that changes should be marked with {@link Bindable} to generate a field in
     * <code>BR</code> to be used as <code>fieldId</code>.
     *
     * @param fieldId The generated BR id for the Bindable field.
     */
    public void notifyPropertyChanged(int fieldId) {
        if (mCallbacks != null) {
            mCallbacks.notifyCallbacks(this, fieldId, null);
        }
    }
}
