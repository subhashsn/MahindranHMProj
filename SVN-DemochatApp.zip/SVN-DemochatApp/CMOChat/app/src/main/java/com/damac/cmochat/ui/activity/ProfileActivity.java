package com.damac.cmochat.ui.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.damac.cmochat.R;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}
