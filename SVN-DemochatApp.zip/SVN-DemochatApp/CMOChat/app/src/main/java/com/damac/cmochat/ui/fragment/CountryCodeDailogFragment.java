package com.damac.cmochat.ui.fragment;


import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.damac.cmochat.R;
import com.damac.cmochat.adapter.CountryCodeAdapter;
import com.damac.cmochat.model.CountryCodeCallBack;
import com.damac.cmochat.model.CountryCodeList;
import com.damac.cmochat.ui.listener.CMOItemClickListener;


public class CountryCodeDailogFragment extends android.support.v4.app.DialogFragment  {
    RecyclerView myCoutryCodelist;
    private EditText searchCountry;
    private CountryCodeAdapter countryCodeAdapter = null;
    private static CountryCodeList countryCodeList;
    public String countryCode =null;
    public Dialog dialog=null;
    private CountryCodeCallBack mCallBackCountryCode;

    public static CountryCodeDailogFragment newInstance(CountryCodeList countrycodelist) {
        CountryCodeDailogFragment fragment = new CountryCodeDailogFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        countryCodeList = countrycodelist;
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.DialogTheme);
        try {
            mCallBackCountryCode= (CountryCodeCallBack )getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement Callback interface");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.dialog_country_code, container, false);
        myCoutryCodelist= (RecyclerView) rootView.findViewById(R.id.lv_country_code);
        searchCountry = (EditText) rootView.findViewById(R.id.et_country_search);
        getDialog().setTitle("Select Country Code");
        myCoutryCodelist.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        myCoutryCodelist.setLayoutManager(mLayoutManager);
        countryCodeAdapter = new CountryCodeAdapter(countryCodeList.getCountries());
        myCoutryCodelist.setAdapter(countryCodeAdapter);
        myCoutryCodelist.addOnItemTouchListener(new CMOItemClickListener(getActivity(), new CMOItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position, float x, float y) {
                TextView tv_countryCode = (TextView)view.findViewById(R.id.country_code);
                if(tv_countryCode!=null) {
                    countryCode = tv_countryCode.getText().toString();
                    mCallBackCountryCode.onCountryCodeCallBack(countryCode);
                }
                getDialog().dismiss();
            }
        }));


        searchCountry.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                countryCodeAdapter.getFilter().filter(s.toString());
            }
        });
        return rootView;
    }

    @Override
    public void onStart() {
        super.onStart();
        dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.setTitle("Select Country Code");
        }
    }
}