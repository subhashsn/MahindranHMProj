package com.damac.cmochat.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.damac.cmochat.R;
import com.damac.cmochat.model.CountryCode;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Barun.Gupta on 12/30/2016.
 *
 */

public class CountryCodeAdapter extends RecyclerView.Adapter<CountryCodeAdapter.ViewHolder> implements Filterable {
    private List<CountryCode> countryCodeList;
    private List<CountryCode> searchcountryCodeList;

    public CountryCodeAdapter(List<CountryCode> countryCodeList) {
        this.countryCodeList = countryCodeList;
        searchcountryCodeList = countryCodeList;
    }

    @Override
    public CountryCodeAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.country_code_layout, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final CountryCodeAdapter.ViewHolder holder, int position) {
        final CountryCode countryCode = (countryCodeList.get(position));
        holder.countryName.setText(countryCode.getName());
        holder.countryCode.setText(countryCode.getCode());

    }

    @Override
    public int getItemCount() {
        return countryCodeList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView countryName;
        public TextView countryCode;
        public ViewHolder(View view) {
            super(view);

            countryName = (TextView) view.findViewById(R.id.country_name);
            countryCode = (TextView) view.findViewById(R.id.country_code);
        }
    }

    @Override
    public Filter getFilter() {
        Filter filter = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                List<CountryCode> list = searchcountryCodeList;
                if (!charSequence.toString().isEmpty()) {
                    List<CountryCode> mlist = new ArrayList<>();
                    for (CountryCode countrycode: list) {
                        if (countrycode.getName().toString().toLowerCase().contains(charSequence.toString().toLowerCase())) {
                            mlist.add(countrycode);
                        }
                    }
                    filterResults.values = mlist;
                } else {
                    filterResults.values = list;
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                countryCodeList = ( List<CountryCode>) filterResults.values;
                notifyDataSetChanged();
            }
        };
        return filter;
    }
}
