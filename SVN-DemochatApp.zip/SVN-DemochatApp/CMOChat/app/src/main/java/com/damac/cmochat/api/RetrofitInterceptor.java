package com.damac.cmochat.api;

import android.content.Context;

import com.damac.cmochat.BuildConfig;
import com.damac.cmochat.util.AppURLs;
import com.google.gson.annotations.Expose;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

import static com.damac.cmochat.util.AppUtils.log;

/**
 * Created by Barun.Gupta on 1/6/2017.
 *
 */

public class RetrofitInterceptor implements Interceptor {
    private static RetrofitInterceptor interceptor = null;
    @Expose
    private final String version = BuildConfig.VERSION_NAME;
    @Expose
    private String token;

    private RetrofitInterceptor() {
    }

    public static RetrofitInterceptor getInterceptor(Context context) {
        if (interceptor == null) {
            interceptor = new RetrofitInterceptor();
        }
        return interceptor;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request original = chain.request();
        log("Header", "Android-App-Version" + version);
        Request request = original.newBuilder()
                .header("Accept", "application/json")
                .header("Authorization", AppURLs.OPENFIRE_REST_TOKEN)
                .method(original.method(), original.body())
                .build();

        return chain.proceed(request);
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
