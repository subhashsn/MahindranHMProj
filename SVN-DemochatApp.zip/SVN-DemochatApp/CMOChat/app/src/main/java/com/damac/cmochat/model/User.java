package com.damac.cmochat.model;

import android.databinding.Bindable;
import android.databinding.Observable;
import android.databinding.PropertyChangeRegistry;

import com.damac.cmochat.BR;
import com.google.gson.annotations.Expose;

import io.realm.RealmObject;
import io.realm.annotations.Ignore;

/**
 * Created by gautam.honavar on 1/19/2017.
 *
 */
public class User extends RealmObject implements Observable {
    @Expose
    public String username;
    @Expose
    public String name;
    @Expose
    public String email;
    public byte[] imgBitmap;
    public int drawbleId;
    private boolean isSelected;
    public String jID;

    public String getjID() {
        return jID;
    }

    public void setjID(String jID) {
        this.jID = jID;
    }



    // FROM BASE OBSERVABLE
    @Ignore
    private transient PropertyChangeRegistry mCallbacks;

    public User(String username, String name, String email) {
        this.username = username;
        this.name = name;
        //this.email = email;
    }

    public User() {
        super();
    }

    public String getUsername() {
        return username;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    @Bindable
    public byte[] getImgBitmap() {
        return imgBitmap;
    }

    public void setImgBitmap(byte[] imgBitmap) {
        this.imgBitmap = imgBitmap;
        notifyPropertyChanged(BR.imgBitmap);
    }

    @Bindable
    public int getDrawbleId() {
        return drawbleId;
    }

    public void setDrawbleId(int drawbleId) {
        this.drawbleId = drawbleId;
        notifyPropertyChanged(BR.drawbleId);
    }
    @Override
    public void addOnPropertyChangedCallback(OnPropertyChangedCallback callback) {
        if (mCallbacks == null) {
            mCallbacks = new PropertyChangeRegistry();
        }
        mCallbacks.add(callback);
    }

    @Override
    public void removeOnPropertyChangedCallback(OnPropertyChangedCallback callback) {
        if (mCallbacks != null) {
            mCallbacks.remove(callback);
        }
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public void notifyPropertyChanged(int fieldId) {
        if (mCallbacks != null) {
            mCallbacks.notifyCallbacks(this, fieldId, null);
        }
    }
}
