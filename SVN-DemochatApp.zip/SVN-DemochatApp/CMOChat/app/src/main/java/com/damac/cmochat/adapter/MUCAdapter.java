package com.damac.cmochat.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.damac.cmochat.R;
import com.damac.cmochat.application.ChatApplication;
import com.damac.cmochat.model.XMPPBody;
import com.damac.cmochat.ui.muc.adapter.MUCBaseAdapter;
import com.damac.cmochat.util.AppURLs;
import com.damac.cmochat.util.AppUtils;
import com.damac.cmochat.xmpp.XMPPManager;

import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smackx.vcardtemp.packet.VCard;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static com.damac.cmochat.util.AppUtils.log;
import static com.damac.cmochat.util.AppUtils.logError;

public class MUCAdapter extends RecyclerView.Adapter<MUCAdapter.MUCMessageViewHolder> implements MUCBaseAdapter<XMPPBody> {
    public static final int TYPE_TEXT_RIGHT = 1;
    public static final int TYPE_TEXT_LEFT = 2;
    public static final int TYPE_IMAGE_RIGHT = 3;
    public static final int TYPE_IMAGE_LEFT = 4;
    protected static final int TYPE_OWN_VIDEO_ATTACH = 5;
    protected static final int TYPE_OPPONENT_VIDEO_ATTACH = 6;

    private static final String TAG = MUCAdapter.class.getSimpleName();
    protected LayoutInflater inflater;
    protected Context context;
    private String currentUser;
    private RequestListener glideRequestListener;
    private ArrayList<String> jidsDownloading;
    private SparseIntArray containerLayoutRes = new SparseIntArray() {
        {
            put(TYPE_TEXT_RIGHT, com.quickblox.ui.kit.chatmessage.adapter.R.layout.list_item_text_right);
            put(TYPE_TEXT_LEFT, com.quickblox.ui.kit.chatmessage.adapter.R.layout.list_item_text_left);
            put(TYPE_IMAGE_RIGHT, com.quickblox.ui.kit.chatmessage.adapter.R.layout.list_item_attach_right);
            put(TYPE_IMAGE_LEFT, com.quickblox.ui.kit.chatmessage.adapter.R.layout.list_item_attach_left);
        }
    };
    private MUCAdapter.MUCMessageViewHolder mucViewHolder;
    private List<XMPPBody> chatMessages;
    private ArrayList<XMPPBody> filterChatHistory = new ArrayList<>();

    public MUCAdapter(Context context, List<XMPPBody> chatMessages, String currentUser) {
        this.context = context;
        this.chatMessages = chatMessages;
        log(TAG, "Chat msg size::" + chatMessages.size());
        this.inflater = LayoutInflater.from(context);
        this.currentUser = currentUser;
    }

    @Override
    public MUCMessageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {

            case TYPE_TEXT_RIGHT:
                mucViewHolder = new MUCAdapter.TextMessageHolder(inflater.inflate(containerLayoutRes.get(viewType), parent, false),
                        com.quickblox.ui.kit.chatmessage.adapter.R.id.msg_text_message, com.quickblox.ui.kit.chatmessage.adapter.R.id.msg_text_time_message, R.id.date_display, R.id.presenceColor);
                return mucViewHolder;
            case TYPE_TEXT_LEFT:
                mucViewHolder = new MUCAdapter.TextMessageHolder(inflater.inflate(containerLayoutRes.get(viewType), parent, false),
                        com.quickblox.ui.kit.chatmessage.adapter.R.id.msg_text_message, com.quickblox.ui.kit.chatmessage.adapter.R.id.msg_text_time_message, R.id.date_display, R.id.presenceColor);
                return mucViewHolder;
            case TYPE_IMAGE_RIGHT:
                mucViewHolder = new MUCAdapter.ImageAttachHolder(inflater.inflate(containerLayoutRes.get(viewType), parent, false),
                        com.quickblox.ui.kit.chatmessage.adapter.R.id.msg_image_attach, com.quickblox.ui.kit.chatmessage.adapter.R.id.msg_progressbar_attach, R.id.date_display, R.id.presenceColor);
                return mucViewHolder;
            case TYPE_IMAGE_LEFT:
                mucViewHolder = new MUCAdapter.ImageAttachHolder(inflater.inflate(containerLayoutRes.get(viewType), parent, false),
                        com.quickblox.ui.kit.chatmessage.adapter.R.id.msg_image_attach, com.quickblox.ui.kit.chatmessage.adapter.R.id.msg_progressbar_attach, R.id.date_display, R.id.presenceColor);
                return mucViewHolder;

            default:
                log(TAG, "onCreateViewHolder case default");
                // resource must be set manually by creating custom adapter
                return onCreateCustomViewHolder(parent, viewType);
        }
    }

    protected int customViewType(int position) {
        XMPPBody chatMessage = getItem(position);
        //TODO - Handle different types like video
        /*if (hasAttachments(chatMessage)) {
            QBAttachment attachment = chatMessage.getAttachments().iterator().next();
            if (QBAttachment.VIDEO_TYPE.equals(attachment.getType())) {
                return isIncoming(chatMessage) ? TYPE_OPPONENT_VIDEO_ATTACH : TYPE_OWN_VIDEO_ATTACH;
            }
        }*/
        return -1;
    }

    private MUCMessageViewHolder onCreateCustomViewHolder(ViewGroup parent, int viewType) {
        log(TAG, "onCreateCustomViewHolder viewType= " + viewType);
        return viewType == TYPE_OWN_VIDEO_ATTACH ? new ImageAttachHolder(inflater.inflate(R.layout.list_item_attach_right, parent, false),
                R.id.msg_image_attach, R.id.msg_progressbar_attach, R.id.date_display, R.id.presenceColor) : null;
    }

    private void displayAttachment(MUCMessageViewHolder holder, int position) {
        //int preferredImageSizePreview = (int) (80 * Resources.getSystem().getDisplayMetrics().density);
        int valueType = getItemViewType(position);
        log(TAG, "displayAttachment valueType= " + valueType);
        initGlideRequestListener((ImageAttachHolder) holder);

        XMPPBody chatMessage = getItem(position);
        String body = chatMessage.getBody();
        if (body == null)
            return;

        AppUtils.loadBitmapFromWebDAV(body, context, glideRequestListener, ((MUCAdapter.ImageAttachHolder) holder).attachImageView);
    }

    protected void setMsgLayoutResourceByType(int typeLayout, @LayoutRes int messageLayoutResource) {
        containerLayoutRes.put(typeLayout, messageLayoutResource);
    }

    @Override
    public void onBindViewHolder(MUCMessageViewHolder holder, int position) {
        XMPPBody chatMessage = getItem(position);
        int valueType = getItemViewType(position);
        switch (valueType) {
            case TYPE_TEXT_RIGHT:
                onBindViewMsgRightHolder((TextMessageHolder) holder, chatMessage, position);
                break;
            case TYPE_TEXT_LEFT:
                onBindViewMsgLeftHolder((TextMessageHolder) holder, chatMessage, position);
                break;
            case TYPE_IMAGE_RIGHT:
                log(TAG, "onBindViewHolder TYPE_IMAGE_RIGHT");
                onBindViewAttachRightHolder((ImageAttachHolder) holder, chatMessage, position);
                break;
            case TYPE_IMAGE_LEFT:
                log(TAG, "onBindViewHolder TYPE_IMAGE_LEFT");
                onBindViewAttachLeftHolder((ImageAttachHolder) holder, chatMessage, position);
                break;
            default:
                onBindViewCustomHolder(holder, chatMessage, position);
                log(TAG, "onBindViewHolder TYPE_ATTACHMENT_CUSTOM");
                break;
        }
    }

    private void onBindViewCustomHolder(MUCMessageViewHolder holder, XMPPBody chatMessage, int position) {
        //TODO - Handle this
    }

    private void onBindViewAttachRightHolder(ImageAttachHolder holder, XMPPBody chatMessage, int position) {
        displayAttachment(holder, position);
        int valueType = getItemViewType(position);
        String avatarUrl = obtainAvatarUrl(valueType, chatMessage);
        log(TAG, "dateDisplay::" + chatMessage.getDateDisplay());
        log(TAG, "isTobeDisplay::" + chatMessage.isToDisplayed());
        log(TAG, "body::" + chatMessage.getBody());
        log(TAG, "date::" + chatMessage.getDate());
        // holder.presenceColor =
        if (chatMessage.isToDisplayed()) {
            holder.displayDate.setVisibility(View.VISIBLE);
            holder.displayDate.setText(chatMessage.getDateDisplay());
        } else {
            holder.displayDate.setVisibility(View.GONE);
        }
        if (avatarUrl != null) {
            displayAvatarImage(avatarUrl, holder.avatar);
        }
    }

    private void onBindViewAttachLeftHolder(ImageAttachHolder holder, XMPPBody chatMessage, int position) {
        displayAttachment(holder, position);
        log(TAG, "dateDisplay::" + chatMessage.getDateDisplay());
        log(TAG, "isTobeDisplay::" + chatMessage.isToDisplayed());
        log(TAG, "body::" + chatMessage.getBody());
        log(TAG, "date::" + chatMessage.getDate());
        if (chatMessage.isToDisplayed()) {
            holder.displayDate.setVisibility(View.VISIBLE);
            holder.displayDate.setText(chatMessage.getDateDisplay());
        } else {
            holder.displayDate.setVisibility(View.GONE);
        }
        int valueType = getItemViewType(position);
        String avatarUrl = obtainAvatarUrl(valueType, chatMessage);
        if (avatarUrl != null) {
            displayAvatarImage(avatarUrl, holder.avatar);
        }
    }

    private void onBindViewMsgLeftHolder(TextMessageHolder holder, XMPPBody chatMessage, int position) {
        holder.messageTextView.setText(chatMessage.getBody());
        //TODO - Show the message time
        int lastIndexOfSlash = chatMessage.getFrom().lastIndexOf('/');
        holder.timeTextMessageTextView.setText(/*getDate(*/chatMessage.getFrom().substring(lastIndexOfSlash + 1) /** 1000)*/);
        int valueType = getItemViewType(position);
        String avatarUrl = obtainAvatarUrl(valueType, chatMessage);
        if (avatarUrl != null) {
            displayAvatarImage(avatarUrl, holder.avatar);
        }
        log(TAG, "dateDisplay::" + chatMessage.getDateDisplay());
        log(TAG, "isTobeDisplay::" + chatMessage.isToDisplayed());
        log(TAG, "body::" + chatMessage.getBody());
        log(TAG, "date::" + chatMessage.getDate());
        if (chatMessage.isToDisplayed()) {
            holder.displayDate.setText(chatMessage.getDateDisplay());
            holder.displayDate.setVisibility(View.VISIBLE);
        } else {
            holder.displayDate.setVisibility(View.GONE);
        }

    }

    private void onBindViewMsgRightHolder(TextMessageHolder holder, XMPPBody chatMessage, int position) {

        holder.messageTextView.setText(chatMessage.getBody());
        int lastIndexOfSlash = chatMessage.getFrom().lastIndexOf('/');
        holder.timeTextMessageTextView.setText(/*getDate(*/chatMessage.getFrom().substring(lastIndexOfSlash + 1) /** 1000)*/);
        int valueType = getItemViewType(position);
        String avatarUrl = obtainAvatarUrl(valueType, chatMessage);
        if (avatarUrl != null) {
            displayAvatarImage(avatarUrl, holder.avatar);
        }
        log(TAG, "dateDisplay::" + chatMessage.getDateDisplay());
        log(TAG, "isTobeDisplay::" + chatMessage.isToDisplayed());
        log(TAG, "body::" + chatMessage.getBody());
        log(TAG, "date::" + chatMessage.getDate());
        if (chatMessage.isToDisplayed()) {
            holder.displayDate.setVisibility(View.VISIBLE);
            holder.displayDate.setText(chatMessage.getDateDisplay());

        } else {
            holder.displayDate.setVisibility(View.GONE);
        }
    }

    /**
     * ObtainAvatarUrl must be implemented in derived class
     *
     * @return String avatar url
     */
    @Nullable
    public String obtainAvatarUrl(int valueType, XMPPBody chatMessage) {
        return chatMessage.getFrom();
    }

    @Override
    public int getItemCount() {
        return chatMessages.size();
    }

    @Override
    public XMPPBody getItem(int position) {
        return chatMessages.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        XMPPBody chatMessage = getItem(position);
        if (hasAttachments(chatMessage)) {
            return isIncoming(chatMessage) ? TYPE_IMAGE_RIGHT : TYPE_IMAGE_LEFT;
        } else {
            return isIncoming(chatMessage) ? TYPE_TEXT_RIGHT : TYPE_TEXT_LEFT;
        }
    }

    @Override
    public void add(XMPPBody item) {
        String dateDisplay = null;
        boolean isToDisplay = AppUtils.getSharedPref(context).getBoolean(AppUtils.IS_TO_DISPLAY, true);
        log(TAG, "item body::" + item.getBody());
        log(TAG, "item getDate::" + item.getDate());
        log(TAG, "item isConcluded::" + item.isConcluded());
        try {
            dateDisplay = AppUtils.isDayToday(item.getDate());
            log(TAG, "item dateDisplay::" + dateDisplay);
        } catch (ParseException e) {
            logError(TAG, e.getMessage(), e);
        }
        if (chatMessages != null && chatMessages.size() == 0) {
            item.setToDisplayed(true);
            item.setDateDisplay(dateDisplay);
        }
        if (chatMessages != null && chatMessages.size() > 0) {
            XMPPBody xchatMessages = chatMessages.get(chatMessages.size() - 1);
            try {
                dateDisplay = AppUtils.isDayToday(item.getDate());
                item.setDateDisplay(dateDisplay);
            } catch (ParseException e) {
                logError(TAG, e.getMessage(), e);
            }
            log(TAG, "xchatMessages getDateDisplay::" + xchatMessages.getDateDisplay());
            log(TAG, "item getDateDisplay::" + item.getDateDisplay());
            if (xchatMessages.getDateDisplay() != null && xchatMessages.getDateDisplay().equals(item.getDateDisplay())) {
                item.setToDisplayed(false);
            } else {
                item.setToDisplayed(true);
            }
        }
        if (isToDisplay) {
            chatMessages.add(item);
        } else {
            if (item.isConcluded()) {
                chatMessages.add(item);
            }
        }
        notifyDataSetChanged();

    }

    @Override
    public List<XMPPBody> getList() {
        return chatMessages;
    }

    @Override
    public void addList(List<XMPPBody> items) {
        chatMessages.clear();
        chatMessages.addAll(items);
        notifyDataSetChanged();
    }

    private boolean isIncoming(XMPPBody chatMessage) {
        String fromUser = "";
        if (chatMessage != null && chatMessage.getFrom() != null)
            fromUser = chatMessage.getFrom().substring(chatMessage.getFrom().lastIndexOf('/') + 1);
        if (currentUser.indexOf('@') > -1) {
            //currentUser contains jid. remove the domain to get the username
            String currentUserName = currentUser.substring(0, currentUser.indexOf('@'));
            return currentUserName.equals(fromUser);
        } else {
            return currentUser.startsWith(fromUser);
        }
    }

    private boolean hasAttachments(XMPPBody chatMessage) {

        if (chatMessage.isMediaType()) {
            return true;
        }else {
            return false;
        }
//        String body = chatMessage.getBody();
//        //TODO - Add logic for handling all supported file types
//        return !(body == null || body.isEmpty()) && (body.indexOf('.') > -1);
    }

    protected String getDate(long milliseconds) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd", Locale.getDefault());
        return dateFormat.format(new Date(milliseconds));
    }

    private void initGlideRequestListener(final ImageAttachHolder holder) {
        glideRequestListener = new RequestListener() {
            @Override
            public boolean onException(Exception e, Object model, Target target, boolean isFirstResource) {
                e.printStackTrace();
                holder.attachImageView.setScaleType(ImageView.ScaleType.FIT_XY);
                holder.attachmentProgressBar.setVisibility(View.GONE);
                return false;
            }

            @Override
            public boolean onResourceReady(Object resource, Object model, Target target, boolean isFromMemoryCache, boolean isFirstResource) {
                holder.attachImageView.setScaleType(ImageView.ScaleType.FIT_XY);
                holder.attachmentProgressBar.setVisibility(View.GONE);
                return false;
            }
        };
    }

    @Override
    public void displayAvatarImage(String url, final ImageView imageView) {
        final String jid = url.substring(url.lastIndexOf('/') + 1) + "@" + AppURLs.DOMAIN;
        final ChatApplication appCtx = (ChatApplication) context.getApplicationContext();
        if (jid.isEmpty())
            return;

        //LRU Cache
        final Bitmap bitmap = appCtx.getBitmapFromMemCache(jid);
        if (bitmap != null) {
            imageView.setImageBitmap(bitmap);
            return;
        }

        if (jidsDownloading != null && jidsDownloading.contains(jid))
            return;

        if (jidsDownloading == null)
            jidsDownloading = new ArrayList<>();

        jidsDownloading.add(jid);

        //Get it from vCard
        new Thread(new Runnable() {
            @Override
            public void run() {
                VCard vCard = null;
                try {
                    vCard = XMPPManager.getInstance(context).getVCard(jid);
                } catch (SmackException.NotConnectedException | XMPPException.XMPPErrorException
                        | SmackException.NoResponseException e) {
                    logError(TAG, e.getMessage(), e);
                }
                if (vCard == null)
                    return;

                byte[] avatar = vCard.getAvatar();
                if (avatar == null)
                    return;

                Bitmap bmp = BitmapFactory.decodeByteArray(avatar, 0, avatar.length);
                //imageView.setImageBitmap(bmp);
                appCtx.addBitmapToMemoryCache(jid, bmp);
            }
        }).start();
    }

    private static class TextMessageHolder extends MUCMessageViewHolder {
        TextView messageTextView;
        TextView timeTextMessageTextView;
        TextView displayDate;
        ImageView presenceColor;

        TextMessageHolder(View itemView, @IdRes int msgId, @IdRes int timeId, @IdRes int dateId, @IdRes int presenceState) {
            super(itemView);
            messageTextView = (TextView) itemView.findViewById(msgId);
            timeTextMessageTextView = (TextView) itemView.findViewById(timeId);
            displayDate = (TextView) itemView.findViewById(dateId);
            presenceColor = (ImageView) itemView.findViewById(presenceState);
        }
    }

    private static class ImageAttachHolder extends MUCMessageViewHolder {
        ImageView attachImageView;
        ProgressBar attachmentProgressBar;
        TextView displayDate;
        ImageView presenceColor;

        ImageAttachHolder(View itemView, @IdRes int attachId, @IdRes int progressBarId, @IdRes int dateId, @IdRes int presenceState) {
            super(itemView);
            attachImageView = (ImageView) itemView.findViewById(attachId);
            attachmentProgressBar = (ProgressBar) itemView.findViewById(progressBarId);
            displayDate = (TextView) itemView.findViewById(dateId);
            presenceColor = (ImageView) itemView.findViewById(presenceState);
        }
    }

    abstract static class MUCMessageViewHolder extends RecyclerView.ViewHolder {
        ImageView avatar;
        View itemView;

        MUCMessageViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            avatar = (ImageView) itemView.findViewById(com.quickblox.ui.kit.chatmessage.adapter.R.id.msg_image_avatar);
        }

        void hideView() {
            itemView.setVisibility(View.GONE);
            //itemView.setLayoutParams(new ViewGroup.LayoutParams(0, 0));
        }

        void showView() {
            itemView.setVisibility(View.VISIBLE);
            // itemView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        }
    }

    public void setData(List<XMPPBody> chatMessages) {
        this.chatMessages = chatMessages;
        log(TAG, "data set chatMessages size::" + chatMessages.size());
    }
}
