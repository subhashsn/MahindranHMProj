package com.damac.cmochat.model;

import java.util.ArrayList;

/**
 * Created by Barun.Gupta on 1/6/2017.
 *
 */

public class CMOUser {
    public ArrayList<User> user;
    private int getusercount;

    public CMOUser(ArrayList<User> user) {
        this.user = user;
    }

    public CMOUser() {
        super();
    }

    public int getGetusercount() {
        return getusercount;
    }

    public void setGetusercount(int getusercount) {
        this.getusercount = getusercount;
    }

    public ArrayList<User> getUser() {
        return user;
    }

    public void setUser(ArrayList<User> user) {
        this.user = user;
    }
}


