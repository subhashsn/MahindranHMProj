package com.damac.cmochat.ui.custom;

import android.content.Context;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.widget.EditText;

/**
 * Created by Narasimha.HS on 1/13/2017.
 * <p>
 * Class for handling Typing/Stopped status in XMPP MUC
 */

public class TextWatchingEditText extends android.support.v7.widget.AppCompatEditText implements TextWatcher {
    private static final int TYPING_INTERVAL = 1500;
    private OnTypingModified typingChangedListener;

    private boolean currentTypingState = false;
    private Handler handler = new Handler();
    private Runnable stoppedTypingNotifier = new Runnable() {
        @Override
        public void run() {
            //Send stopped typing status.
            if (null != typingChangedListener) {
                typingChangedListener.onIsTypingModified(TextWatchingEditText.this, false);
                currentTypingState = false;
            }
        }
    };

    public TextWatchingEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.addTextChangedListener(this);
    }

    public void setOnTypingModifiedListener(OnTypingModified typingChangedListener) {
        this.typingChangedListener = typingChangedListener;
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {
        //If the user is typing, send started styping status
        if (null != typingChangedListener && getText() != null && !getText().toString().isEmpty()) {
            if (!currentTypingState) {
                typingChangedListener.onIsTypingModified(this, true);
                currentTypingState = true;
            }

            handler.removeCallbacks(stoppedTypingNotifier);
            handler.postDelayed(stoppedTypingNotifier, TYPING_INTERVAL);
        }
    }

    /**
     * //Listener interface that you implement anonymously from the Activity/Fragment
     */
    public interface OnTypingModified {
        void onIsTypingModified(EditText view, boolean isTyping);
    }
}
