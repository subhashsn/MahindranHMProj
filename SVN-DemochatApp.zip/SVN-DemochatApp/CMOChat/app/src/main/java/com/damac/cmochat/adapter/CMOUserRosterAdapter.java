package com.damac.cmochat.adapter;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import com.damac.cmochat.R;
import com.damac.cmochat.databinding.ContactListItemBinding;
import com.damac.cmochat.model.User;
import com.viethoa.RecyclerViewFastScroller;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Barun.Gupta on 12/30/2016.
 *
 */

public class CMOUserRosterAdapter extends RecyclerView.Adapter<CMOUserRosterAdapter.ViewHolder> implements Filterable,
        RecyclerViewFastScroller.BubbleTextGetter {

    private List<User> mUserList;
    private List<User> mSearchList;

    public CMOUserRosterAdapter(List<User> myDataset) {
        this.mUserList = myDataset;
        this.mSearchList = myDataset;
    }

    @Override
    public CMOUserRosterAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_list_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final CMOUserRosterAdapter.ViewHolder holder, int position) {
        final User user = mUserList.get(position);
        holder.bind(user);
        holder.getBinding().executePendingBindings();
    }

    @Override
    public int getItemCount() {
        return mUserList.size();
    }



    public class ViewHolder extends RecyclerView.ViewHolder {

        private ContactListItemBinding binding;

        public ViewHolder(View view) {
            super(view);
            binding = DataBindingUtil.bind(view);

        }

        public void bind(User user) {
            binding.setCmoUser(user);
            if(user.isSelected()){
                binding.selected.setVisibility(View.VISIBLE);
            }else {
                binding.selected.setVisibility(View.INVISIBLE);
            }

        }
        public ViewDataBinding getBinding() {
            return binding;
        }
    }


    @Override
    public Filter getFilter() {
        Filter filter = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                List<User> list = mSearchList;
                if (!charSequence.toString().isEmpty()) {
                    List<User> mlist = new ArrayList<>();
                    for (User user: list) {
                        if (user.getUsername().toString().toLowerCase().contains(charSequence.toString().toLowerCase())) {
                            mlist.add(user);
                        }
                    }
                    filterResults.values = mlist;
                } else {
                    filterResults.values = list;
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mUserList = ( List<User>) filterResults.values;
                notifyDataSetChanged();
            }
        };
        return filter;


    }

    @Override
    public String getTextToShowInBubble(int pos) {
        if (pos < 0 || pos >= mSearchList.size())
            return null;
        String name = mSearchList.get(pos).getName();
        if (name == null || name.length() < 1)
            return null;
        return mSearchList.get(pos).getName().substring(0, 1);
    }
}
