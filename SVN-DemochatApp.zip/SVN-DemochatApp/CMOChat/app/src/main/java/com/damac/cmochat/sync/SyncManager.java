package com.damac.cmochat.sync;

import android.content.Context;
import android.support.annotation.NonNull;

import java.util.HashMap;

import io.realm.Realm;

/**
 * Created by Barun.Gupta on 1/28/2017.
 *
 */

public class SyncManager {
    private HashMap<SyncType, AbsSync> syncMap;

    public SyncManager(@NonNull Context context,final Realm realm) {
        syncMap = new HashMap<>();
        syncMap.put(SyncType.CMO_CHATROOM_SYNC, new ChatRoomSync(context));
        syncMap.put(SyncType.CMO_GROUP_SYNC, new CMOGroupSync(context));
        syncMap.put(SyncType.CMO_GROUP_MEMBER_SYNC, new GroupMemberSync(context,realm));
    }

    public void doSync(@NonNull SyncType syncType) {
        syncMap.get(syncType).doSync();
    }
}
