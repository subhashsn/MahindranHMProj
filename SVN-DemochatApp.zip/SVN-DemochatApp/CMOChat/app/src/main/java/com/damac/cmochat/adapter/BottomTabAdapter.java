package com.damac.cmochat.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.damac.cmochat.R;
import com.damac.cmochat.ui.fragment.CMOContactsListFragment;
import com.damac.cmochat.ui.fragment.ConversationsFragment;
import com.damac.cmochat.ui.fragment.SettingsFragment;
import com.damac.cmochat.util.AppUtils;

import java.util.WeakHashMap;

/**
 * Created by gautam.honavar on 1/9/2017.
 * Adapter for showing the navigation options in the landing screen of the app
 */

public class BottomTabAdapter extends FragmentPagerAdapter {

    private final int PAGE_COUNT = 3;
    private Context mContext;
    private FragmentManager mFragmentManager;
    private String[] mTabsTitle = new String[3];
    private int[] mTabsIcons = {
            R.drawable.ic_conversations_selector,
            R.drawable.ic_contacts_selector,
            R.drawable.ic_settings_selector};

    private WeakHashMap<Integer, Fragment> bottomTabFragmentReference = new WeakHashMap<Integer, Fragment>();

    public BottomTabAdapter(FragmentManager fm, Context context) {
        super(fm);
        mFragmentManager = fm;
        mContext = context;
        mTabsTitle[0] = mContext.getString(R.string.btmtab_conversation);
        mTabsTitle[1] = mContext.getString(R.string.btmtab_contacts);
        mTabsTitle[2] = mContext.getString(R.string.btmtab_settings);
    }

    public View getTabView(int position) {
        // Given you have a custom layout in `res/layout/custom_tab.xml` with a TextView and ImageView
        View view = LayoutInflater.from(mContext).inflate(R.layout.custom_bottom_tabs, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        title.setText(mTabsTitle[position]);
        ImageView icon = (ImageView) view.findViewById(R.id.icon);
        icon.setImageResource(mTabsIcons[position]);
        return view;
    }

    @Override
    public android.support.v4.app.Fragment getItem(int pos) {
        switch (pos) {
            case 0: {
                if (bottomTabFragmentReference.containsKey(0))
                    return bottomTabFragmentReference.get(0);
                else {
                    Fragment converstationFragement = ConversationsFragment.newInstance();
                    bottomTabFragmentReference.put(0, converstationFragement);
                    return converstationFragement;
                }
            }
            case 1:
                if (bottomTabFragmentReference.containsKey(1))
                    return bottomTabFragmentReference.get(1);
                else {
                    Fragment contactsFragement = CMOContactsListFragment.newInstance();
                    bottomTabFragmentReference.put(1, contactsFragement);
                    return contactsFragement;
                }
            case 2:
                if (bottomTabFragmentReference.containsKey(2))
                    return bottomTabFragmentReference.get(2);
                else {
                    Fragment settingsFragement = SettingsFragment.newInstance(AppUtils.getFromAppPrefs(AppUtils.XMPP_JID,mContext),mContext.getResources().getBoolean(R.bool.twoPaneMode));
                    bottomTabFragmentReference.put(2, settingsFragement);
                    return settingsFragement;
                }
        }
        return null;
    }

    @Override
    public int getCount() {
        return PAGE_COUNT;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mTabsTitle[position];
    }
}

