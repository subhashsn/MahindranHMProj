package com.damac.cmochat.util;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.preference.PreferenceManager;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.util.Base64;
import android.util.Log;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import com.bumptech.glide.request.RequestListener;
import com.damac.cmochat.R;

import org.joda.time.DateTime;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Copyright 2015 (C) Happiest Minds Pvt Ltd..
 * <p>
 * <P> Generic Utility functionality
 * <p>
 * <P>Notes:
 * <P>Dependency:
 *
 * @author Sunil Rao S (sunil.sindhe@happiestminds.com)
 * @created on: 4-Jan-2016
 */
public class AppUtils {
    private static String TAG = "DAMAC CMOChat";
    private static final String VERSION = "1.0";
    private static final boolean ENABLE_LOGGER = true;
    public static final String BASE_URL = "http://" + AppURLs.HOST + "/plugins/restapi/v1/";
    //public static final String BASE_URL = "http://192.168.0.101:9090/plugins/restapi/v1/";

    //XMPP Strings
    public static final String XMPP_JID = "XMPP_JID";
    public static final String XMPP_PASSWORD = "XMPP_PASSWORD";
    public static final String XMPP_PORT = "XMPP_PORT";
    public static final String XMPP_HOST = "XMPP_HOST";

    public static final String RIGHT_CONTAINER_FRAGMENT_TAG = "FRAGMENT_RIGHT_CONTAINER";

    //conversations string
    public static final String CONVERSATION_MOD_DATE = "modificationDate";

    public static final String CHAT_ROOM_NAME = "chatRoomName";
    public static final String CHAT_ROOM_Members = "chatRoomMembers";
    public static final String CHAT_ROOM_ATTACHMENTS = "chatRoomAttachments";

    public static final String CHAT_ROOM_SUBJECT = "chatRoomSubject";

    public static final String CREATE_CHAT_ROOM = "createChatRoom";
    public static final String CHAT_ROOM_PARTICIPANTS = "chatRoomParticipants";
    public static final String IS_GROUP_CHAT = "isGroupChat";
    public static final String PARTICIPANTS_ID = "participantIds";

    public static final String CHAT_ROOM = "ChatRoom";


    //xmpp message body data
    public static final String BODY = "body";
    public static final String MEDIA_ITEM = "mediaItem";
    public static final String SLA_TIME = "slaTime";
    public static final String SLA_FLAG = "slaFlag";
    public static final String DATE = "date";
    public static final String IS_CONCLUDED = "isConcluded";
    public static final String IS_CONFIDENTIAL = "isConfidential";
    public static final String ROOM_NAME = "roomName";
    public static final String FROM = "from";
    public static final String TO = "to";
    public static final String MEDIA_TYPE = "mediaType";


    public static final String USER_IDS = "USERIDS";
    public static final int USER_IDS_RESULT_CODE = 101;
    public static final int USER_IDS_REQUEST_CODE = 102;

    //date format
    public static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
    public static final DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static final DateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

//1970-01-01T00:00:00Z
    /* IOS chat code date formatter
    DATE_FORMAT @"yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ"
    SLA_DATE_FORMAT @"E, d MMM yyyy HH:mm:ss Z"
    MESSAGE_TIME_FORMAT @"yyyy-MM-dd HH:mm:ss.SSS Z"
    SHOW_CROSSED_SLA_DATE_FORMAT @"dd MMM yyyy HH:mm"
    */
    //public static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z");

    //profile Data
    public static final String PROFILE_NAME = "PROFILE_NAME";
    public static final String PROFILE_FIRST_NAME = "PROFILE_FIRST_NAME";
    public static final String PROFILE_LAST_NAME = "PROFILE_LAST_NAME";
    public static final String PROFILE_IMAGE = "PROFILE_IMAGE";
    public static final String DESIGNATION = "DESIGNATION";
    public static final String MOBILE_NUMBER = "MOBILE_NUMBER";
    public static final String EMAIL_ID = "EMAIL_ID";
    public static final String ATTACHMENT_URL = "ATTACHMENT_URL";
    public static final String CMO_SHARED_PREF = "CMO_SHARED_PREF";
    public static final String IS_TO_DISPLAY = "IS_TO_DISPLAY";
    public static final String RESPONSE_TIME = "responseTime";

    public static final String REMEMBER_PWD = "REMEMBER_PWD";
    public static final String USERNAME = "USERNAME";
    public static final String PASSWORD = "PASSWORD";



    public static SharedPreferences sharedpreferences;
    public static SharedPreferences.Editor prefsEditor;

    /**
     * App level Logger
     *
     * @param paramString -
     */
    public static void log(String paramString) {
        if (!ENABLE_LOGGER)
            return;

        /*if ((DETAIL_LOG) && (!"user".equals(Build.TYPE)))
            Log.i(TAG, getCallingMethod() + paramString);
        else*/
        Log.i(TAG, paramString);
    }

    /**
     * App level Logger
     *
     * @param paramString -
     */
    public static void log(String TAG, String paramString) {
        if (!ENABLE_LOGGER)
            return;

        /*if ((DETAIL_LOG) && (!"user".equals(Build.TYPE)))
            Log.d(TAG, getCallingMethod() + paramString);
        else*/
        Log.d(TAG, paramString);
    }

    /**
     * App level Logger for ERRORS
     */
    public static void logError(String TAG, String paramString, Throwable throwable) {
        if (!ENABLE_LOGGER)
            return;
        Log.e(TAG, paramString, throwable);
    }

    /**
     * App Level Logger
     *
     * @param cxt         -
     * @param paramString -
     */
    public static void log(Context cxt, String paramString) {
        if (!ENABLE_LOGGER)
            return;

        /*if ((DETAIL_LOG) && (!"user".equals(Build.TYPE)))
            Log.d(TAG + getAppVersion(cxt), getCallingMethod() + paramString);
        else*/
        Log.d(TAG + getAppVersion(cxt), paramString);
    }

    /**
     * Method to get app version
     *
     * @param cxt -
     * @return -
     */
    private static String getAppVersion(Context cxt) {
        PackageInfo pInfo;

        if (cxt == null)
            return VERSION;

        try {
            pInfo = cxt.getPackageManager().getPackageInfo(cxt.getPackageName(), 0);
            return pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            logError(TAG, e.getMessage(), e);
        }

        return VERSION;
    }

    /**
     * Method to save data in Shared preferences
     *
     * @param key     -
     * @param value   -
     * @param context -
     */
    public static void addToAppPrefs(String key, String value, Context context) {
        PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext()).edit()
                .putString(key, value)
                .apply();
    }

    /**
     * Method to save a list in Shared preferences
     *
     * @param keys    -
     * @param values  -
     * @param context -
     */
    public static void addToAppPrefs(List<String> keys, List<String> values, Context context) {

        if (keys == null || values == null || keys.isEmpty() || values.isEmpty())
            return;

        if (keys.size() != values.size()) {
            log("Keys and Values Don't match");
            return;
        }
        prefsEditor = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext()).edit();
        for (int i = 0, length = keys.size(); i < length; i++) {
            prefsEditor.putString(keys.get(i), values.get(i));
        }
        prefsEditor.apply();

    }

    /**
     * Method to ClearShared preferences
     *
     * @param context -
     */
    public static void clearData(Context context) {
        prefsEditor.clear();
        prefsEditor.apply();
    }

    /**
     * Method to fetch data from Shared Preferences
     *
     * @param key     -
     * @param context -
     * @return - Data from Shared Prefs
     */
    public static String getFromAppPrefs(String key, Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        return prefs.getString(key, null);
    }

    /**
     * Method to fetch data from Shared Preferences
     *
     * @param key          -
     * @param context      -
     * @param defaultValue -
     * @return - Data from Shared Prefs
     */
    public static String getFromAppPrefs(String key, Context context, String defaultValue) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        return prefs.getString(key, defaultValue);
    }

    // convert from bitmap to byte array
    public static byte[] getBytesFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        return stream.toByteArray();
    }

    //Set the radius of the Blur. Supported range 0 < radius <= 25
    private static final float BLUR_RADIUS = 25f;

    /**
     * Method to blur a Bitmap
     *
     * @param image    -
     * @param mContext -
     * @return - Blurred Bitmap
     */
    public static Bitmap blur(Bitmap image, Context mContext) {
        if (null == image) return null;

        Bitmap outputBitmap = Bitmap.createBitmap(image);
        final RenderScript renderScript = RenderScript.create(mContext);
        Allocation tmpIn = Allocation.createFromBitmap(renderScript, image);
        Allocation tmpOut = Allocation.createFromBitmap(renderScript, outputBitmap);

        //Intrinsic Gausian blur filter
        ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript));
        theIntrinsic.setRadius(BLUR_RADIUS);
        theIntrinsic.setInput(tmpIn);
        theIntrinsic.forEach(tmpOut);
        tmpOut.copyTo(outputBitmap);
        return outputBitmap;
    }

    /**
     * Method to read JSON from a file
     *
     * @param inputStream - InputStream
     * @return - JSON String
     */
    public static String readJsonFile(InputStream inputStream) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        byte bufferByte[] = new byte[1024];
        int length;
        try {
            while ((length = inputStream.read(bufferByte)) != -1) {
                outputStream.write(bufferByte, 0, length);
            }
            outputStream.close();
            inputStream.close();
        } catch (IOException e) {
            logError(TAG, e.getMessage(), e);
        }
        return outputStream.toString();
    }

    /**
     * Method to load Image from WEBDAV Server
     *
     * @param url                  -
     * @param ctx                  -
     * @param glideRequestListener -
     * @param imageView            -
     */
    public static void loadBitmapFromWebDAV(String body, Context ctx, RequestListener glideRequestListener, ImageView imageView) {

        String url = AppURLs.AZURE_BLOB_STORAGE_API + AppURLs.AZURE_CONTAINER_NAME + "/thumb_" + body ;
       // String credentials = "admin@dotcms.com" + ":" + "admin";
      //  final String basic =
        //        "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
//addHeader("Authorization", basic)
        GlideUrl glideUrl = new GlideUrl(url, new LazyHeaders.Builder().build());
        Glide.with(ctx)
                .load(glideUrl)
                .listener(glideRequestListener)
                .dontTransform()
                .error(R.drawable.ic_error)
                .into(imageView);
    }

    /**
     * Method used to determine if a given date is "TODAY", "YESTERDAY" or anything else
     *
     * @param date -
     * @return - "TODAY", "YESTERDAY" or DATE
     * @throws ParseException
     */
    public static String isDayToday(String date) throws ParseException {
        Log.d(TAG, "Date to faormat::" + date);
        if (date != null) {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
            SimpleDateFormat inputFormatLocal = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z");
            DateTime currentDay = new DateTime().withTimeAtStartOfDay();
            Date formatedDate = null;
            try {
                formatedDate = inputFormat.parse(date);
            } catch (Exception e) {
                formatedDate = inputFormatLocal.parse(date);
            }
            DateTime msgDate = new DateTime(formatedDate);
            if (msgDate.withTimeAtStartOfDay().isEqual(currentDay.minusDays(1))) {
                return "yesterday";
            }
            if (msgDate.withTimeAtStartOfDay().isEqual(currentDay.withTimeAtStartOfDay())) {
                return "today";
            }
            return msgDate.getDayOfMonth() + "/" + msgDate.getMonthOfYear() + "/" + msgDate.getYear();
        }
        return new String("");
    }

    public static SharedPreferences getSharedPref(Context context) {
        if (sharedpreferences == null) {
            sharedpreferences = context.getSharedPreferences(AppUtils.CMO_SHARED_PREF, Context.MODE_PRIVATE);
        }
        return sharedpreferences;
    }

    public static ProgressDialog showLoadingDialog(Context context) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.show();
        if (progressDialog.getWindow() != null) {
            progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        progressDialog.setContentView(R.layout.progress_dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(true);
        progressDialog.setCanceledOnTouchOutside(false);
        return progressDialog;
    }

}
