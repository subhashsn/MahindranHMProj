package com.damac.cmochat.model;

import java.util.ArrayList;

/**
 * Created by Barun.Gupta on 1/10/2017.
 *
 */

public class CMORosterGroup {

    private ArrayList<CMOGroup> group;

    private CMOGroupMembers members;

    public CMOGroupMembers getMembers() {
        return members;
    }

    public void setMembers(CMOGroupMembers members) {
        this.members = members;
    }

    public ArrayList<CMOGroup> getCmoGroup() {
        return group;
    }

    public void setCmoGroup(ArrayList<CMOGroup> cmoGroup) {
        this.group = cmoGroup;
    }
}
