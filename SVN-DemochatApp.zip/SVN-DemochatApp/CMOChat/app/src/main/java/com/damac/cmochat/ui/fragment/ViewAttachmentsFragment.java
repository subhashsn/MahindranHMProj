package com.damac.cmochat.ui.fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.damac.cmochat.R;
import com.damac.cmochat.adapter.AttachmentsListAdapter;
import com.damac.cmochat.model.XMPPBody;
import com.damac.cmochat.realm.CMORepositoryService;
import com.damac.cmochat.ui.activity.ShowAttachmentActivity;
import com.damac.cmochat.ui.listener.RecyclerItemClickListener;
import com.damac.cmochat.util.AppUtils;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmResults;

import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_ATTACHMENTS;
import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_Members;
import static com.damac.cmochat.util.AppUtils.log;

/**
 * A simple {@link Fragment} subclass.
 * Fragment to show UI for images/docs
 */
public class ViewAttachmentsFragment extends Fragment {
    private static final int NO_OF_GRID_COLUMNS = 2;
    private AttachmentsListAdapter mListAdapter;
    private RecyclerView mRecyclerView;
    private Realm mRealm;
    private String mRoomName;
    private ArrayList<XMPPBody> chatRoomAttachments;

    public enum LIST_TYPE {IMAGES, DOCS}

    private static final String CURRENT_TYPE = "CURRENT_TYPE";

    private LIST_TYPE mCurrentType;

    public ViewAttachmentsFragment() {
        // Required empty public constructor
    }

    public static ViewAttachmentsFragment newInstance(LIST_TYPE currentType, String roomName) {
        ViewAttachmentsFragment fragment = new ViewAttachmentsFragment();
        Bundle args = new Bundle();
        args.putSerializable(CURRENT_TYPE, currentType);
        args.putString(AppUtils.CHAT_ROOM_NAME, roomName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mRealm = Realm.getDefaultInstance();
        View view = inflater.inflate(R.layout.fragment_view_attachments, container, false);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.attachments_list);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        /*String chatRoomName = getActivity().getIntent().getStringExtra(AppUtils.CHAT_ROOM_NAME);
        if (chatRoomName != null)//For Handling activity
            mRoomName = chatRoomName;*/

        if (savedInstanceState != null) //For handling restarts
            mRoomName = savedInstanceState.getString(AppUtils.CHAT_ROOM_NAME);


        if (getArguments() != null) {
            //For Fragment newInstance
            mCurrentType = (LIST_TYPE) getArguments().getSerializable(CURRENT_TYPE);
            chatRoomAttachments = getActivity().getIntent().getParcelableArrayListExtra(CHAT_ROOM_ATTACHMENTS);
            String chatRoomName = getArguments().getString(AppUtils.CHAT_ROOM_NAME);
            if (chatRoomName != null)
                mRoomName = chatRoomName;
        }

       // if (mCurrentType == null || mCurrentType == LIST_TYPE.IMAGES) {
            showImages();
       // } else {
            //showDocs();
       // }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(AppUtils.CHAT_ROOM_NAME, mRoomName);
    }

    /**
     * Show the images associated with the chat room
     */
    private void showImages() {
//        RealmResults<XMPPBody> realmResults = CMORepositoryService.getInstance().getRoomImages(mRealm, mRoomName);
//        if (realmResults == null) {
//            log("No Images to show!!");
//            return;
//        }

        mListAdapter = new AttachmentsListAdapter(getActivity(), chatRoomAttachments);

        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), NO_OF_GRID_COLUMNS);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mListAdapter);


        mRecyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), mRecyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                XMPPBody message = chatRoomAttachments.get(position);

                if (message == null) {
                    return;
                }else {
                    Intent intent = new Intent(getActivity(), ShowAttachmentActivity.class);
                    intent.putExtra(AppUtils.ATTACHMENT_URL, message.getBody());
                    intent.putParcelableArrayListExtra(AppUtils.CHAT_ROOM_ATTACHMENTS, chatRoomAttachments);
                    intent.putExtra("Index", position);
                    startActivity(intent);
                }

            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));
    }

    /**
     * Show the Documents associated with the chat room
     */
    private void showDocs() {
        RealmResults<XMPPBody> realmResults = CMORepositoryService.getInstance().getRoomDocs(mRealm, mRoomName);
        if (realmResults == null) {
            log("No Docs to show!!");
            return;
        }

        mListAdapter = new AttachmentsListAdapter(getActivity(), chatRoomAttachments);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mListAdapter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mRealm != null) {
            mRealm.close();
        }
    }
}
