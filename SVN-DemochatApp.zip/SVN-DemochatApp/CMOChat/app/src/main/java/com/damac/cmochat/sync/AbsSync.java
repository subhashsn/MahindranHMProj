package com.damac.cmochat.sync;

import android.content.Context;
import android.support.annotation.NonNull;

import io.realm.Realm;

/**
 * Created by Barun.Gupta on 1/28/2017.
 *
 */

abstract class AbsSync {

    private Context context;

    public AbsSync(@NonNull Context context) {
        this.context = context.getApplicationContext();
    }

    protected abstract void doSync();
    //protected abstract void get();
}
