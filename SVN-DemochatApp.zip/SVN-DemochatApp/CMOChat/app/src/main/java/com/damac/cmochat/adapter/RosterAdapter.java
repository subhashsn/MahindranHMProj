package com.damac.cmochat.adapter;

import android.databinding.BindingAdapter;
import android.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.damac.cmochat.R;
import com.damac.cmochat.databinding.ContactListItemBinding;
import com.damac.cmochat.model.User;

import java.util.Arrays;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Barun.Gupta on 12/30/2016.
 *
 */

public class RosterAdapter extends RecyclerView.Adapter<RosterAdapter.ViewHolder> {
    private User[] mUserList;
    private FragmentManager mFragmentManager;

    public RosterAdapter(User[] myDataset, FragmentManager manager) {
        this.mUserList = myDataset;
        this.mFragmentManager = manager;
    }

    @BindingAdapter("bind:imageBitmap")
    public static void loadImage(CircleImageView iv, byte[] bitmap) {
        if (bitmap != null) {
            int len = bitmap.length;
            Bitmap img = BitmapFactory.decodeByteArray(bitmap, 0, len);
           // iv.setImageBitmap(AppUtils.getCircleBitmap(img));
            iv.setImageBitmap(img);
        }
    }

    @BindingAdapter("bind:loadColor")
    public static void loadColor(ImageView iv, int drawableId) {
        iv.setBackgroundResource(drawableId);
    }

    @Override
    public RosterAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_list_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final RosterAdapter.ViewHolder holder, int position) {
        final User user = (mUserList[position]);
        holder.bind(user);
    }

    @Override
    public int getItemCount() {
        return Arrays.asList(mUserList).size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ContactListItemBinding binding;

        public ViewHolder(View view) {
            super(view);
            binding = DataBindingUtil.bind(view);
        }

        public void bind(User user) {
            binding.setCmoUser(user);
        }
    }
}
