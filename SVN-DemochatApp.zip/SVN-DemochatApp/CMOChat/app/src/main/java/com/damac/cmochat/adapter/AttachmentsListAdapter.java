package com.damac.cmochat.adapter;

import android.content.Context;
import android.support.annotation.IdRes;
import android.support.v7.widget.RecyclerView;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.damac.cmochat.R;
import com.damac.cmochat.model.XMPPBody;
import com.damac.cmochat.util.AppUtils;

import java.util.ArrayList;

import io.realm.RealmResults;

import static com.damac.cmochat.util.AppUtils.log;

/**
 * Created by Narasimha.HS on 2/9/2017.
 * <p>
 * Recylerview Adapter for showing attachments of a chatroom
 */

public class AttachmentsListAdapter extends RecyclerView.Adapter<AttachmentsListAdapter.AttachmentViewHolder> {
    private static final String TAG = AttachmentsListAdapter.class.getSimpleName();

    private static final int TYPE_IMAGE = 1;
    private static final int TYPE_DOC = 2;
    private static final int TYPE_PDF = 3;
    private static final int TYPE_XLS = 4;

    private SparseIntArray containerLayoutRes = new SparseIntArray() {
        {
            put(TYPE_IMAGE, R.layout.list_attach_item_image);
            put(TYPE_DOC, R.layout.list_attach_item_doc);
            put(TYPE_PDF, R.layout.list_attach_item_doc);
            put(TYPE_XLS, R.layout.list_attach_item_doc);
        }
    };

    private Context mContext;
    private ArrayList<XMPPBody> attachmentList;
    private LayoutInflater inflater;
    private AttachmentViewHolder mucViewHolder;
    private RequestListener glideRequestListener;

    public AttachmentsListAdapter(Context context, ArrayList<XMPPBody> attachmentList) {
        this.attachmentList = attachmentList;
        this.inflater = LayoutInflater.from(context);
        this.mContext = context;
    }

    @Override
    public AttachmentViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case TYPE_IMAGE:
                mucViewHolder = new AttachmentsListAdapter.ImageAttachHolder(inflater.inflate(containerLayoutRes.get(viewType), parent, false),
                        R.id.attachment_image);
                return mucViewHolder;
            case TYPE_DOC:
            case TYPE_PDF:
            case TYPE_XLS:
                mucViewHolder = new AttachmentsListAdapter.DocumentAttachHolder(inflater.inflate(containerLayoutRes.get(viewType), parent, false),
                        R.id.list_item_doc_title);
                return mucViewHolder;

            default:
                log(TAG, "onCreateViewHolder case default");
                // resource must be set manually by creating custom adapter
                return null;
        }
    }

    @Override
    public void onBindViewHolder(AttachmentViewHolder holder, int position) {
        XMPPBody chatMessage = getItem(position);
        int valueType = getItemViewType(position);
        switch (valueType) {
            case TYPE_IMAGE:
                onBindImageAttachmentHolder((AttachmentsListAdapter.ImageAttachHolder) holder, chatMessage, position);
                break;
            case TYPE_DOC:
            case TYPE_PDF:
            case TYPE_XLS:
                onBindDocAttachmentHolder((AttachmentsListAdapter.DocumentAttachHolder) holder, chatMessage, position, valueType);
                break;
            default:
                //TODO - Handle this
                //onBindDocAttachmentHolder(holder, chatMessage, position);
                log(TAG, "onBindViewHolder TYPE_ATTACHMENT_CUSTOM");
                break;
        }
    }

    private void onBindDocAttachmentHolder(DocumentAttachHolder holder, XMPPBody chatMessage, int position, int valueType) {
        String messageText = chatMessage.getBody();
        holder.messageTextView.setText(messageText.substring(0, messageText.lastIndexOf('.')));
        //TODO - Show corresponding icons
    }

    private void initGlideRequestListener(final AttachmentsListAdapter.ImageAttachHolder holder) {
        glideRequestListener = new RequestListener() {
            @Override
            public boolean onException(Exception e, Object model, Target target, boolean isFirstResource) {
                e.printStackTrace();
                holder.attachImageView.setScaleType(ImageView.ScaleType.FIT_XY);
                //holder.attachmentProgressBar.setVisibility(View.GONE);
                return false;
            }

            @Override
            public boolean onResourceReady(Object resource, Object model, Target target, boolean isFromMemoryCache, boolean isFirstResource) {
                holder.attachImageView.setScaleType(ImageView.ScaleType.FIT_XY);
                //holder.attachmentProgressBar.setVisibility(View.GONE);
                return false;
            }
        };
    }

    private void onBindImageAttachmentHolder(ImageAttachHolder holder, XMPPBody chatMessage, int position) {
        initGlideRequestListener(holder);
        AppUtils.loadBitmapFromWebDAV(chatMessage.getBody(), mContext, glideRequestListener, holder.attachImageView);
    }

    @Override
    public int getItemViewType(int position) {
        XMPPBody chatMessage = getItem(position);
        if (chatMessage == null)
            return TYPE_IMAGE;
        String url = chatMessage.getBody();
        if (url.endsWith(".png") || url.endsWith(".jpg")) {
            return TYPE_IMAGE;
        } else if (url.endsWith(".doc") || url.endsWith(".docx")) {
            return TYPE_DOC;
        } else if (url.endsWith(".pdf")) {
            return TYPE_PDF;
        } else if (url.endsWith(".xls") || url.endsWith(".xlsx")) {
            return TYPE_XLS;
        }

        return TYPE_DOC;
    }

    @Override
    public int getItemCount() {
        return attachmentList == null ? 0 : attachmentList.size();
    }

    private XMPPBody getItem(int position) {
        return attachmentList.get(position);
    }

    private static class DocumentAttachHolder extends AttachmentViewHolder {
        TextView messageTextView;

        DocumentAttachHolder(View itemView, @IdRes int msgId) {
            super(itemView);
            messageTextView = (TextView) itemView.findViewById(msgId);
        }
    }

    private static class ImageAttachHolder extends AttachmentViewHolder {
        ImageView attachImageView;

        ImageAttachHolder(View itemView, @IdRes int attachId) {
            super(itemView);
            attachImageView = (ImageView) itemView.findViewById(attachId);
        }
    }

    abstract static class AttachmentViewHolder extends RecyclerView.ViewHolder {
        AttachmentViewHolder(View itemView) {
            super(itemView);
        }
    }
}
