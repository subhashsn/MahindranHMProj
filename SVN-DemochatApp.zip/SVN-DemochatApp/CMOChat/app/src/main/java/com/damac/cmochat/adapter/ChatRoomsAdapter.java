package com.damac.cmochat.adapter;

import android.databinding.DataBindingUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import com.damac.cmochat.BR;
import com.damac.cmochat.R;
import com.damac.cmochat.databinding.ChatroomListItemBinding;
import com.damac.cmochat.model.ChatRoom;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gautam.honavar on 1/11/2017.
 */

public class ChatRoomsAdapter extends RecyclerView.Adapter<ChatRoomsAdapter.ViewHolder> implements Filterable {
    private List<ChatRoom> chatRoomList;
    private List<ChatRoom> searchChatRoomList;

    public ChatRoomsAdapter(List<ChatRoom> chatroomDataset) {
        this.chatRoomList = chatroomDataset;
        searchChatRoomList = chatroomDataset;
    }

    @Override
    public ChatRoomsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chatroom_list_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final ChatRoomsAdapter.ViewHolder holder, int position) {
        final ChatRoom chatroom = chatRoomList.get(position);
        holder.getBinding().setVariable(BR.cmoUser, chatroom);
        holder.getBinding().executePendingBindings();
        holder.bind(chatroom);
    }

    @Override
    public int getItemCount() {
        return chatRoomList.size();
    }

    @Override
    public Filter getFilter() {
        Filter filter = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                List<ChatRoom> list = searchChatRoomList;
                if (!charSequence.toString().isEmpty()) {
                    List<ChatRoom> mlist = new ArrayList<>();
                    for (ChatRoom user : list) {
                        if (user.getSubject().toLowerCase().contains(charSequence.toString().toLowerCase())) {
                            mlist.add(user);
                        }
                    }
                    filterResults.values = mlist;
                } else {
                    filterResults.values = list;
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                chatRoomList = (List<ChatRoom>) filterResults.values;
                notifyDataSetChanged();
            }
        };
        return filter;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private ChatroomListItemBinding binding;

        public ViewHolder(View view) {
            super(view);
            binding = DataBindingUtil.bind(view);
        }

        public void bind(ChatRoom chatroom) {
            binding.setCmoChatRoom(chatroom);
        }

        public ChatroomListItemBinding getBinding() {
            return binding;
        }
    }
}
