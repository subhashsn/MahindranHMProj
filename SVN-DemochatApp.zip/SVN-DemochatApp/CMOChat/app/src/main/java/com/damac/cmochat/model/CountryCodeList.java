package com.damac.cmochat.model;

import java.util.ArrayList;

/**
 * Created by gautam.honavar on 2/8/2017.
 *
 */

public class CountryCodeList {
    private ArrayList<CountryCode> countries;

    public ArrayList<CountryCode> getCountries() {
        return this.countries;
    }

    public void setCountries(ArrayList<CountryCode> countries) {
        this.countries = countries;
    }
}
