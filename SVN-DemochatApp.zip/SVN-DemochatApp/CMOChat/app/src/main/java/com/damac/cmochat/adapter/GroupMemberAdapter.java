package com.damac.cmochat.adapter;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.damac.cmochat.R;
import com.damac.cmochat.databinding.CmogrpMemberListItemBinding;
import com.damac.cmochat.model.User;

import java.util.List;

/**
 * Created by Barun.Gupta on 1/18/2017.
 *
 */

public class GroupMemberAdapter extends RecyclerView.Adapter<GroupMemberAdapter.ViewHolder> {
    private List<User> mGroupMembersList;

    public GroupMemberAdapter(List<User> groupMembersList) {
        mGroupMembersList = groupMembersList;
    }

    @Override
    public GroupMemberAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cmogrp_member_list_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final User cmoGroupMembers = (mGroupMembersList.get(position));
        holder.bind(cmoGroupMembers);
        holder.getBinding().executePendingBindings();
    }

    @Override
    public int getItemCount() {
        if (mGroupMembersList != null) {
            return mGroupMembersList.size();
        }
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private CmogrpMemberListItemBinding binding;

        public ViewHolder(View view) {
            super(view);
            binding = DataBindingUtil.bind(view);
        }

        public void bind(User cmoGroupMembers) {
            binding.setCmoUser(cmoGroupMembers);
            if(cmoGroupMembers.isSelected()){
                binding.selected.setVisibility(View.VISIBLE);
            }else {
                binding.selected.setVisibility(View.INVISIBLE);
            }
        }

        public ViewDataBinding getBinding() {
            return binding;
        }
    }
}
