package com.damac.cmochat.ui.fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.damac.cmochat.R;
import com.damac.cmochat.adapter.CMOGroupRoasterAdapter;
import com.damac.cmochat.adapter.CMOUserRosterAdapter;
import com.damac.cmochat.adapter.SelectedUserAdapter;
import com.damac.cmochat.api.APIManager;
import com.damac.cmochat.api.RetrofitAPIInterface;
import com.damac.cmochat.databinding.ContactListFragmentBinding;
import com.damac.cmochat.model.CMOGroup;
import com.damac.cmochat.model.CMOGroupMembers;
import com.damac.cmochat.model.CMORosterGroup;
import com.damac.cmochat.model.CMOUser;
import com.damac.cmochat.model.User;
import com.damac.cmochat.realm.CMORepositoryService;
import com.damac.cmochat.ui.activity.CMOContactsListActivity;
import com.damac.cmochat.ui.activity.ChatActivity;
import com.damac.cmochat.ui.listener.CMOItemClickListener;
import com.damac.cmochat.ui.listener.SearchListener;
import com.damac.cmochat.util.AppURLs;
import com.damac.cmochat.util.AppUtils;
import com.damac.cmochat.util.RealmString;
import com.damac.cmochat.xmpp.XMPPManager;
import com.viethoa.models.AlphabetItem;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smackx.vcardtemp.packet.VCard;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmResults;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import rx.Observable;
import rx.Observer;
import rx.schedulers.Schedulers;

import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_NAME;
import static com.damac.cmochat.util.AppUtils.IS_GROUP_CHAT;
import static com.damac.cmochat.util.AppUtils.RIGHT_CONTAINER_FRAGMENT_TAG;
import static com.damac.cmochat.util.AppUtils.USER_IDS;
import static com.damac.cmochat.util.AppUtils.USER_IDS_RESULT_CODE;
import static com.damac.cmochat.util.AppUtils.log;
import static com.damac.cmochat.util.AppUtils.logError;

/**
 * Created by Barun.Gupta on 12/30/2016.
 */

public class CMOContactsListFragment extends Fragment implements View.OnClickListener, SearchListener {

    private Realm mRealm;
    private List<User> userList;
    private final String TAG = CMOContactsListFragment.class.getSimpleName();
    private RetrofitAPIInterface retrofitAPIService;
    private CMOUserRosterAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private Call<CMOUser> getCMOUser = null;
    private ContactListFragmentBinding mDataBinder;
    private Call<CMORosterGroup> getCMORoasterGroup = null;
    private CMOGroupRoasterAdapter cmoGroupRoasterAdapter;
    private Call<CMORosterGroup> getGroupDetailes = null;
    private RealmResults<CMOGroup> mCMOGroupsRealmResults;
    private RealmResults<User> mCMORosterUsersResults;
    private SelectedUserAdapter mSelectedUserAdapter;
    private List<User> userSet;
    private boolean GROUP_CHAT;
    private ProgressDialog mProgressDialog;
    private FloatingActionButton createGroupbtn;


    public static CMOContactsListFragment newInstance() {
        return new CMOContactsListFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mRealm = Realm.getDefaultInstance();
        setHasOptionsMenu(true);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        mDataBinder = DataBindingUtil.inflate(inflater, R.layout.contact_list_fragment, container, false);
        mDataBinder.contacts.setOnClickListener(this);
        mDataBinder.group.setOnClickListener(this);
        mDataBinder.createGroupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createGroup(view);
            }
        });
        mDataBinder.cmoGroupListRecyclerview.setVisibility(View.GONE);
        mDataBinder.userListRecyclerview.setVisibility(View.VISIBLE);
        retrofitAPIService = APIManager.getRetrofitServiceInstance(getContext());
        userSet = new ArrayList<>();
        mDataBinder.contacts.setBackground(getResources().getDrawable(R.drawable.btn_selector, getResources().newTheme()));
        return mDataBinder.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //Todo handle Tablet
        if (getActivity() != null && getActivity() instanceof CMOContactsListActivity) {
            setUserVisibleHint(true);
            GROUP_CHAT = getActivity().getIntent().getBooleanExtra(IS_GROUP_CHAT, false);
        }



    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.menu_add_participants, menu);
        SearchView searchView =
                (SearchView) menu.findItem(R.id.roaster_search).getActionView();
        MenuItem createMenu = menu.findItem(R.id.participants_selected);
        createMenu.setVisible(false);
        searchView.setFocusable(false);
        searchView.setQueryHint("Search");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                Toast.makeText(getContext(), "onQueryTextSubmit::" + s, Toast.LENGTH_LONG).show();
                return false;

            }

            @Override
            public boolean onQueryTextChange(String search) {
                if (mAdapter != null)
                    mAdapter.getFilter().filter(search);
                return false;
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.participants_selected:
               // participantsSelected();
                break;
            case R.id.menu_search:
                Toast.makeText(getActivity(), "menu_search", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void createGroup(View v) {
        if (userSet == null || userSet.size() == 0) {
            Toast.makeText(getActivity(), "Select atleast 1 Participant", Toast.LENGTH_SHORT).show();
            return;
        }

        FragmentManager fm = getFragmentManager();
        SearchDialogFragment dialogFragment = new SearchDialogFragment();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(fm, SearchDialogFragment.class.getSimpleName());
    }

    @Override
    public void onSearch(String recepient, String content) {

    }

    @Override
    public void getRoomName(String roomName) {
        if (roomName != null && roomName.length() > 0) {
            getActivity().getIntent().putExtra(CHAT_ROOM_NAME , roomName);
            participantsSelected();
        }
    }

    private void participantsSelected() {

        if (userSet == null || userSet.size() == 0) {
            Toast.makeText(getActivity(), "Select atleast 1 Participant", Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayList<String> userIds = new ArrayList<>();
        for (int i = 0, length = userSet.size(); i < length; i++) {
            userIds.add(userSet.get(i).getUsername() + "@" + AppURLs.DOMAIN);
        }
        getActivity().getIntent().putStringArrayListExtra(USER_IDS, userIds);
        getActivity().setResult(USER_IDS_RESULT_CODE, getActivity().getIntent());
        getActivity().finish();

    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        XMPPManager.getInstance(getContext()).addRosterListner(getContext());
        mDataBinder.cmoGroupListRecyclerview.addOnItemTouchListener(new CMOItemClickListener(getActivity(), new CMOItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position, float x, float y) {
                if (mCMOGroupsRealmResults != null && mCMOGroupsRealmResults.size() > 0) {
                    CMOGroup cmoGroup = mCMOGroupsRealmResults.get(position);
                    if (cmoGroup != null && cmoGroup.getMemberCount() != null && !cmoGroup.getMemberCount().equals("0")) {
                        if (getActivity().getResources().getBoolean(R.bool.twoPaneMode)) {
                            loadGroupUserFragment(cmoGroup.getName());
                        } else {
                            Bundle arg = new Bundle();
                            arg.putString("GrpName", cmoGroup.getName());
                            FragmentManager fm = getFragmentManager();
                            CMOGroupMemberDialogFragment dialogFragment = new CMOGroupMemberDialogFragment();
                            dialogFragment.setArguments(arg);
                            dialogFragment.show(fm, CMOGroupMemberDialogFragment.class.getSimpleName());
                        }
                    }
                }
            }
        }));

        mDataBinder.userListRecyclerview.addOnItemTouchListener(new CMOItemClickListener(getActivity(), new CMOItemClickListener.OnItemClickListener() {

            @Override
            public void onItemClick(View view, int position, float x, float y) {
                if (GROUP_CHAT) {
                    if (userList != null && userList.size() > 0) {
                        User user = userList.get(position);
                        if (!userSet.contains(user)) {
                            userSet.add(user);
                        }
                        mDataBinder.userSelectedListRecyclerview.setHasFixedSize(true);
                        LinearLayoutManager horizontalLayoutManagaer
                                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
                        mDataBinder.userSelectedListRecyclerview.setLayoutManager(horizontalLayoutManagaer);
                        mSelectedUserAdapter = new SelectedUserAdapter(userSet);
                        mDataBinder.userSelectedListRecyclerview.setAdapter(mSelectedUserAdapter);
                        if (userList.get(position).isSelected()) {
                            userList.get(position).setSelected(false);
                        } else {
                            userList.get(position).setSelected(true);
                        }
                        mAdapter.notifyDataSetChanged();
                        if (getActivity() != null) {
                            if (getActivity().getResources().getBoolean(R.bool.twoPaneMode)) {
                                User userJid = userList.get(position);
                                loadProfileDisplayFragment(userJid.getUsername() + "@" + AppURLs.DOMAIN);
                            }
                        }
                    }
                } else {
                    if (userList != null && userList.size() > 0) {
                        User user = userList.get(position);
                        Intent intent = new Intent(getActivity(), ChatActivity.class);
                        intent.putExtra("JID", user.getjID());
                        getContext().startActivity(intent);
                    }

                }

            }

        }));

        mDataBinder.userSelectedListRecyclerview.addOnItemTouchListener(new CMOItemClickListener(getActivity(), new CMOItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position, float x, float y) {

                if (userSet != null && userSet.size() != 0) {
                    for (int i = 0; i < userList.size(); i++) {
                        if (userList.get(i).getUsername().equals(userSet.get(position).getUsername())) {
                            userList.get(i).setSelected(false);
                            break;
                        }
                    }
                    userSet.remove(position);
                    mSelectedUserAdapter.notifyDataSetChanged();
                    mAdapter.notifyDataSetChanged();
                }

            }
        }));


    }

    @Override
    public void onPause() {
        super.onPause();
       // XMPPManager.getInstance(getContext()).removeRosterListner(getContext());
    }

    @Override
    public boolean getUserVisibleHint() {
        return super.getUserVisibleHint();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser) {
            mDataBinder.userListRecyclerview.setVisibility(View.VISIBLE);
            mDataBinder.cmoGroupListRecyclerview.setVisibility(View.GONE);
            mCMORosterUsersResults = CMORepositoryService.getInstance().getCMORosterUsers(mRealm);
            if (mCMORosterUsersResults != null && mCMORosterUsersResults.size() > 0) {
                if (userList != null && userList.size() > 0) {
                    userList.clear();
                    userList = mRealm.copyFromRealm(mCMORosterUsersResults);
                } else
                    userList = mRealm.copyFromRealm(mCMORosterUsersResults);
                mDataBinder.userListRecyclerview.setHasFixedSize(true);
                mLayoutManager = new LinearLayoutManager(getActivity());
                mDataBinder.userListRecyclerview.setLayoutManager(mLayoutManager);
                mAdapter = new CMOUserRosterAdapter(userList);
                mDataBinder.userListRecyclerview.setAdapter(mAdapter);
                initAlphabetScroll();
                if (getActivity() != null) {
                    if (getActivity().getResources().getBoolean(R.bool.twoPaneMode)) {
                        if (userList != null && userList.size() > 0) {
                            User userJid = userList.get(0);
                            loadProfileDisplayFragment(userJid.getUsername() + "@" + AppURLs.DOMAIN);
                        }
                    }
                }

            } else {
                mDataBinder.cmoGroupListRecyclerview.setVisibility(View.GONE);
                mDataBinder.userListRecyclerview.setVisibility(View.VISIBLE);
                if (retrofitAPIService == null)
                    retrofitAPIService = APIManager.getRetrofitServiceInstance(getContext());
                getCMOUsers();
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onClick(View v) {

        mDataBinder.fastScroller.setVisibility(View.VISIBLE);
        mDataBinder.contacts.setBackgroundResource(0);
        mDataBinder.group.setBackgroundResource(0);
        switch (v.getId()) {
            case R.id.contacts:
                mDataBinder.contacts.setBackground(getResources().getDrawable(R.drawable.btn_selector, getResources().newTheme()));
                mDataBinder.group.setBackground(getResources().getDrawable(R.drawable.btn_deselector, getResources().newTheme()));
                if (mSelectedUserAdapter != null && userSet != null) {
                    userSet.clear();
                    mSelectedUserAdapter.notifyDataSetChanged();
                }
                mDataBinder.userListRecyclerview.setVisibility(View.VISIBLE);
                mDataBinder.cmoGroupListRecyclerview.setVisibility(View.GONE);
                mCMORosterUsersResults = CMORepositoryService.getInstance().getCMORosterUsers(mRealm);
                if (mCMORosterUsersResults != null && mCMORosterUsersResults.size() > 0) {
                    if (userList != null && userList.size() > 0) {
                        userList.clear();
                        userList = mRealm.copyFromRealm(mCMORosterUsersResults);
                    } else
                        userList = mRealm.copyFromRealm(mCMORosterUsersResults);
                    mDataBinder.userListRecyclerview.setHasFixedSize(true);
                    mLayoutManager = new LinearLayoutManager(getActivity());
                    mDataBinder.userListRecyclerview.setLayoutManager(mLayoutManager);
                    mAdapter = new CMOUserRosterAdapter(userList);
                    mDataBinder.userListRecyclerview.setAdapter(mAdapter);
                    if (getActivity() != null) {
                        if (getActivity().getResources().getBoolean(R.bool.twoPaneMode)) {
                            if (userList != null && userList.size() > 0) {
                                User userJid = userList.get(0);
                                loadProfileDisplayFragment(userJid.getUsername() + "@" + AppURLs.DOMAIN);
                            }
                        }
                    }
                    //TODO: check server again for new data
                } else {
                    if (retrofitAPIService == null)
                        retrofitAPIService = APIManager.getRetrofitServiceInstance(getContext());
                    getCMOUsers();
                }
                break;

            case R.id.group:
                mDataBinder.group.setBackground(getResources().getDrawable(R.drawable.btn_selector, getResources().newTheme()));
                mDataBinder.contacts.setBackground(getResources().getDrawable(R.drawable.btn_deselector, getResources().newTheme()));
                if (mSelectedUserAdapter != null && userSet != null) {
                    userSet.clear();
                    mSelectedUserAdapter.notifyDataSetChanged();
                }
                mDataBinder.fastScroller.setVisibility(View.GONE);
                mDataBinder.userListRecyclerview.setVisibility(View.GONE);
                mDataBinder.cmoGroupListRecyclerview.setVisibility(View.VISIBLE);
                mCMOGroupsRealmResults = CMORepositoryService.getInstance().getAllCMOGroupsFromDB(mRealm);
                if (mCMOGroupsRealmResults != null && mCMOGroupsRealmResults.size() > 0) {
                    List<CMOGroup> membergrp = mRealm.copyFromRealm(mCMOGroupsRealmResults);
                    Toast.makeText(getContext(), "Fetching group ::" + mCMOGroupsRealmResults.size(), Toast.LENGTH_LONG).show();
                    mDataBinder.cmoGroupListRecyclerview.setHasFixedSize(true);
                    mLayoutManager = new LinearLayoutManager(getActivity());
                    mDataBinder.cmoGroupListRecyclerview.setLayoutManager(mLayoutManager);
                    cmoGroupRoasterAdapter = new CMOGroupRoasterAdapter(membergrp, retrofitAPIService);
                    mDataBinder.cmoGroupListRecyclerview.setAdapter(cmoGroupRoasterAdapter);
                    if (getActivity().getResources().getBoolean(R.bool.twoPaneMode)) {
                        if (membergrp != null && membergrp.size() > 0) {
                            CMOGroup cmGrp = membergrp.get(0);
                            loadGroupUserFragment(cmGrp.getName());
                        }
                    }
                } else {
                    if (retrofitAPIService == null)
                        retrofitAPIService = APIManager.getRetrofitServiceInstance(getContext());
                    getCMOGroups();
                }
                break;
        }
    }

    /**
     * Method to get all the users groups from xmpp server
     */
    public void getCMOGroups() {

        if (retrofitAPIService != null) {
            retrofitAPIService = APIManager.getRealmCMOGroupInstance(getContext());
            getCMORoasterGroup = retrofitAPIService.getCMORoasterGroup();
            getCMORoasterGroup.enqueue(new Callback<CMORosterGroup>() {
                @Override
                public void onResponse(Call<CMORosterGroup> call, Response<CMORosterGroup> response) {
                    if (response != null && response.isSuccessful()) {
                        mDataBinder.cmoGroupListRecyclerview.setHasFixedSize(true);
                        mLayoutManager = new LinearLayoutManager(getActivity());
                        mDataBinder.cmoGroupListRecyclerview.setLayoutManager(mLayoutManager);
                        final CMORosterGroup cmoRosterGroup = response.body();
                        final ArrayList<CMOGroup> groupArray = cmoRosterGroup.getCmoGroup();
                        if (groupArray != null) {
                            cmoGroupRoasterAdapter = new CMOGroupRoasterAdapter(groupArray, retrofitAPIService);
                            mDataBinder.cmoGroupListRecyclerview.setAdapter(cmoGroupRoasterAdapter);
                            for (final CMOGroup cmoGroup : groupArray) {
                                if (cmoGroup != null && cmoGroup.getName() != null) {
                                    final int i = cmoGroupRoasterAdapter.mGroupMembersList.indexOf(cmoGroup);
                                    retrofitAPIService = APIManager.getRealmServiceInstance(getContext());
                                    getGroupDetailes = retrofitAPIService.getGroupDetailes(cmoGroup.getName());
                                    getGroupDetailes.enqueue(new Callback<CMORosterGroup>() {
                                        @Override
                                        public void onResponse(Call<CMORosterGroup> call, Response<CMORosterGroup> response) {
                                            final CMORosterGroup cmoRosterGroup = response.body();
                                            CMOGroup cmoGroupResponse;
                                            CMOGroupMembers cmoGroupMembers;
                                            if (cmoRosterGroup != null && cmoRosterGroup.getMembers() != null && cmoRosterGroup.getMembers().getMember() != null) {
                                                cmoGroupResponse = cmoGroupRoasterAdapter.mGroupMembersList.get(i);
                                                cmoGroupResponse.setMemberCount(String.valueOf(cmoRosterGroup.getMembers().getMember().size()));
                                            } else {
                                                cmoGroupResponse = cmoGroupRoasterAdapter.mGroupMembersList.get(i);
                                                cmoGroupResponse.setMemberCount(String.valueOf(0));
                                            }
                                            CMORepositoryService.getInstance().saveCMOGroup(mRealm, cmoGroupResponse);
                                            if (cmoRosterGroup.getMembers() != null && cmoRosterGroup.getMembers().getMember() != null
                                                    && cmoRosterGroup.getMembers().getMember().size() > 0) {
                                                for (RealmString memberRealmString : cmoRosterGroup.getMembers().getMember()) {
                                                    cmoGroupMembers = cmoRosterGroup.getMembers();
                                                    cmoGroupMembers.setmMembersStr(memberRealmString.toString());
                                                    cmoGroupMembers.setmGroupName(cmoGroupResponse.getName());
                                                    //CMORepositoryService.getInstance().saveCMOGroupMember(mRealm, cmoGroupMembers);
                                                }
                                            }

                                            if (getActivity().getResources().getBoolean(R.bool.twoPaneMode)) {
                                                if (groupArray != null && groupArray.size() > 0) {
                                                    CMOGroup cmGrp = groupArray.get(0);
                                                    loadGroupUserFragment(cmGrp.getName());
                                                }
                                            }
                                        }

                                        @Override
                                        public void onFailure(Call<CMORosterGroup> call, Throwable t) {
                                            log(TAG, "onFailure::" + t.getMessage());
                                        }
                                    });
                                }
                            }
                        }
                    }
                }

                @Override
                public void onFailure(Call<CMORosterGroup> call, Throwable t) {
                    log(TAG, "onFailure::");
                }
            });
        }
    }

    /**
     * Method to get all the users from xmpp server also add the same to roster
     */
    public void getCMOUsers() {
        if (getContext() == null)
            return;
        mProgressDialog = AppUtils.showLoadingDialog(getContext());
        getCMOUser = retrofitAPIService.getCMOUser();
        getCMOUser.enqueue(new Callback<CMOUser>() {
            @Override
            public void onResponse(Call<CMOUser> call, Response<CMOUser> response) {
                if (response != null && response.isSuccessful()) {
                    if (mProgressDialog != null) {
                        mProgressDialog.cancel();
                    }
                    mDataBinder.userListRecyclerview.setHasFixedSize(true);
                    mLayoutManager = new LinearLayoutManager(getActivity());
                    mDataBinder.userListRecyclerview.setLayoutManager(mLayoutManager);
                    final CMOUser cmoUser = response.body();
                    userList = cmoUser.getUser();
                    mAdapter = new CMOUserRosterAdapter(userList);
                    mDataBinder.userListRecyclerview.setAdapter(mAdapter);
                    if (getActivity() != null) {
                        if (getActivity().getResources().getBoolean(R.bool.twoPaneMode)) {
                            if (userList != null && userList.size() > 0) {
                                User user = userList.get(0);
                                loadProfileDisplayFragment(user.getUsername() + "@" + AppURLs.DOMAIN);
                            }
                        }
                    }
                    Observable<User> userObserable = Observable.from(userList).subscribeOn(Schedulers.io()).observeOn(Schedulers.io());
                    userObserable.subscribe(new Observer<User>() {
                        @Override
                        public void onCompleted() {

                        }

                        @Override
                        public void onError(Throwable e) {

                        }

                        @Override
                        public void onNext(User cmouser) {
                            if (cmouser != null && cmouser.getUsername() != null) {
                                Presence availability = XMPPManager.getInstance(getContext()).getmRoster().getPresence(
                                        cmouser.getUsername() + "@" + AppURLs.DOMAIN);
                                if (availability.isAvailable()) {
                                    cmouser.setDrawbleId(R.drawable.round_green_circle);
                                } else {
                                    cmouser.setDrawbleId(R.drawable.round_gray_circle);
                                }
                                try {
                                    VCard card = XMPPManager.getInstance(getContext()).getVCard(cmouser.getUsername() + "@" + AppURLs.DOMAIN);
                                    byte[] imgs = card.getAvatar();
                                    if (imgs != null) {
                                        cmouser.setImgBitmap(imgs);
                                    } else {
                                        Bitmap bMap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
                                        cmouser.setImgBitmap(AppUtils.getBytesFromBitmap(bMap));
                                    }
                                } catch (XMPPException.XMPPErrorException | SmackException.NoResponseException | SmackException.NotConnectedException e) {
                                    logError(TAG, e.getMessage(), e);
                                }
                            }
                            try {
                                XMPPManager.getInstance(getContext()).addRosterEntries(cmouser.getUsername() + "@" + AppURLs.DOMAIN);
                            } catch (SmackException.NotLoggedInException | XMPPException.XMPPErrorException | SmackException.NoResponseException
                                    | SmackException.NotConnectedException e) {
                                logError(TAG, e.getMessage(), e);
                            }
                            cmouser.setjID(cmouser.getUsername() + "@" + AppURLs.DOMAIN);
                        }
                    });
                    initAlphabetScroll();
                }
            }

            @Override
            public void onFailure(Call<CMOUser> call, Throwable t) {
                if (call != null) {
                    log(TAG, "Error  occured::" + t.getMessage());
                }
            }
        });
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onPresenceEvent(Presence presence) {
        String jid = presence.getFrom().toString();
        String userName = jid.substring(0, jid.indexOf("@"));
        log(TAG, "jid called:" + jid);
        if (!jid.isEmpty() && userList != null) {
            User cmoUserDetails = null;
            for (User cmouser : userList) {
                if (cmouser.getUsername() != null && cmouser.getUsername().equals(userName)) {
                    cmoUserDetails = cmouser;
                }
                if (cmoUserDetails != null)
                    break;
            }
            if (userList != null && cmoUserDetails != null) {
                if (presence.isAvailable())
                    cmoUserDetails.setDrawbleId(R.drawable.round_green_circle);
                else
                    cmoUserDetails.setDrawbleId(R.drawable.round_gray_circle);

                CMORepositoryService.getInstance().updateCMORosterUsers(mRealm, cmoUserDetails);
            }
        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mRealm != null) {
            mRealm.close();
        }
    }

    public void initAlphabetScroll() {

        mDataBinder.fastScroller.setRecyclerView(mDataBinder.userListRecyclerview);
        ArrayList<AlphabetItem> mAlphabetItems = new ArrayList<>();
        List<String> strAlphabets = new ArrayList<>();
        for (int i = 0; i < userList.size(); i++) {
            String name = userList.get(i).getUsername();
            log(TAG, "name::" + name);
            if (name == null || name.trim().isEmpty())
                continue;
            String word = name.substring(0, 1);
            log(TAG, "word::" + word);
            if (!strAlphabets.contains(word)) {
                strAlphabets.add(word);
                mAlphabetItems.add(new AlphabetItem(i, word, false));
            }
        }
        mDataBinder.fastScroller.setUpAlphabet(mAlphabetItems);
    }

    /**
     * Method to display the ProfileFragment.
     */
    private void loadProfileDisplayFragment(String jid) {
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.right_container, ProfileDisplayFragment.newInstance(jid), RIGHT_CONTAINER_FRAGMENT_TAG);
        ft.commit();
    }

    /**
     * Method to display the GroupFragment on right side of tablet screen.
     */
    private void loadGroupUserFragment(String groupName) {
        Bundle arg = new Bundle();
        arg.putString("GrpName", groupName);
        FragmentManager fm = getFragmentManager();
        CMOGroupMemberFragment dialogFragment = new CMOGroupMemberFragment();
        dialogFragment.setArguments(arg);
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.right_container, dialogFragment, RIGHT_CONTAINER_FRAGMENT_TAG);
        ft.commit();
    }
}
