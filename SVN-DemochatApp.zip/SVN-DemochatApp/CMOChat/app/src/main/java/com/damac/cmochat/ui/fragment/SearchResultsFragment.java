package com.damac.cmochat.ui.fragment;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.damac.cmochat.R;
import com.damac.cmochat.adapter.SearchResultsAdapter;
import com.damac.cmochat.databinding.SearchResultsFragmentBinding;
import com.damac.cmochat.model.ChatRoom;
import com.damac.cmochat.model.XMPPBody;
import com.damac.cmochat.ui.activity.ChatActivity;
import com.damac.cmochat.ui.listener.CMOItemClickListener;
import com.damac.cmochat.util.AppUtils;

import java.util.List;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmResults;

import static com.damac.cmochat.util.AppUtils.RIGHT_CONTAINER_FRAGMENT_TAG;
import static com.damac.cmochat.util.AppUtils.log;

/**
 * Created by Barun.Gupta on 2/13/2017.
 *
 */

public class SearchResultsFragment extends Fragment {

    private String mRecepient;
    private String mContent;
    private RealmList<ChatRoom> mSearchChatRoomList;
    private Realm mRealm;
    private RecyclerView.LayoutManager mLayoutManager;
    private RecyclerView.Adapter mAdapter;
    private String TAG = SearchResultsFragment.class.getSimpleName();
    private SearchResultsFragmentBinding mDataChatroomBinder;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mRealm = Realm.getDefaultInstance();
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mDataChatroomBinder = DataBindingUtil.inflate(inflater, R.layout.search_results_fragment, container, false);
        Bundle bundle = getArguments();
        if (bundle != null) {
            mRecepient = bundle.getString("recepient");
            mContent = bundle.getString("content");
        }
        /*Intent intent = getActivity().getIntent();
        if (intent != null) {
            mRecepient = intent.getStringExtra("recepient");
            mContent = intent.getStringExtra("content");

        }*/
        log(TAG, "mRecepient::" + mRecepient);
        log(TAG, "mContent::" + mContent);
        RealmResults<XMPPBody> result = mRealm.where(XMPPBody.class)
                .equalTo("body", mContent)
                .findAll();
        log(TAG, "result::" + result.size());
        mSearchChatRoomList = new RealmList<>();
        if (result.size() > 0) {
            for (XMPPBody xmppBody : result) {
                log(TAG, "xmppbody::" + xmppBody.getBody());
                log(TAG, "xmppbody::" + xmppBody.getRoomName());
                ChatRoom chatRoom = mRealm.where(ChatRoom.class).equalTo("roomName", xmppBody.getRoomName()).findFirst();
                if (!mSearchChatRoomList.contains(chatRoom)) {
                    mSearchChatRoomList.add(chatRoom);
                }
            }
        }
        if (mSearchChatRoomList != null) {
            renderUI(mSearchChatRoomList);
        }
        return mDataChatroomBinder.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        mDataChatroomBinder.chatroomSearchlistRecyclerview.addOnItemTouchListener(new CMOItemClickListener(getActivity(), new CMOItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position, float x, float y) {
                if (getActivity() == null)
                    return;
                ChatRoom chatRoom = null;
                if (mSearchChatRoomList != null && mSearchChatRoomList.size() > 0) {
                    chatRoom = mSearchChatRoomList.get(position);
                }
                if (getResources().getBoolean(R.bool.twoPaneMode)) {
                    //Load the fragment on the right
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.right_container, ChatFragment.newInstance(chatRoom.getRoomName()), RIGHT_CONTAINER_FRAGMENT_TAG);
                    ft.commit();
                } else {
                    //Start a new activity
                    Intent intent = new Intent(getActivity(), ChatActivity.class);
                    intent.putExtra(AppUtils.CHAT_ROOM_NAME, chatRoom.getRoomName());
                    getContext().startActivity(intent);
                }
            }
        }));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mRealm != null) {
            mRealm.close();
        }
    }

    public void renderUI(RealmList<ChatRoom> searchList) {
        List<ChatRoom> chatRoomList = mRealm.copyFromRealm(searchList);
        mDataChatroomBinder.chatroomSearchlistRecyclerview.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mDataChatroomBinder.chatroomSearchlistRecyclerview.setLayoutManager(mLayoutManager);
        mAdapter = new SearchResultsAdapter(chatRoomList);
        mDataChatroomBinder.chatroomSearchlistRecyclerview.setAdapter(mAdapter);
    }

}
