package com.damac.cmochat.api;

import android.content.Context;

import com.damac.cmochat.model.CMOGroup;
import com.damac.cmochat.model.CMOGroupMembers;
import com.damac.cmochat.model.ChatRoom;
import com.damac.cmochat.util.AppUtils;
import com.damac.cmochat.util.CMOChatRoomConverter;
import com.damac.cmochat.util.CMOGroupConverter;
import com.damac.cmochat.util.CMOMemberRealmListConverter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Barun.Gupta on 1/6/2017.
 */

public class APIManager {
    private static int READ_TIMEOUT = 120;
    private static RetrofitAPIInterface service = null;

    private APIManager() {
    }

    public static RetrofitAPIInterface getRetrofitServiceInstance(Context context) {
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(RetrofitInterceptor.getInterceptor(context))
                .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .connectTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .build();

        Retrofit retrofit = new Retrofit.Builder().client(client)
                .baseUrl(AppUtils.BASE_URL).addConverterFactory(GsonConverterFactory.create())
                .build();

        service = retrofit.create(RetrofitAPIInterface.class);
        return service;
    }

    public static void resetService() {
        APIManager.service = null;
    }

    public static RetrofitAPIInterface getRealmServiceInstance(Context context) {
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(RetrofitInterceptor.getInterceptor(context))
                .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .connectTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .build();
        Gson gson = new GsonBuilder()
                .registerTypeAdapter(new TypeToken<CMOGroupMembers>() {
                        }.getType(),
                        new CMOMemberRealmListConverter())
                .create();
        Retrofit retrofit = new Retrofit.Builder().client(client)
                .baseUrl(AppUtils.BASE_URL).addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        service = retrofit.create(RetrofitAPIInterface.class);
        return service;
    }

    public static RetrofitAPIInterface getRealmCMOGroupInstance(Context context) {
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(RetrofitInterceptor.getInterceptor(context))
                .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .connectTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .build();
        Gson gson = new GsonBuilder()
                .registerTypeAdapter(new TypeToken<ArrayList<CMOGroup>>() {
                        }.getType(),
                        new CMOGroupConverter())
                .create();
        Retrofit retrofit = new Retrofit.Builder().client(client)
                .baseUrl(AppUtils.BASE_URL).addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        service = retrofit.create(RetrofitAPIInterface.class);
        return service;
    }

    public static RetrofitAPIInterface getRealmCMOChatRoomInstance(Context context) {
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(RetrofitInterceptor.getInterceptor(context))
                .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .connectTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .build();
        Gson gson = new GsonBuilder()
                .registerTypeAdapter(new TypeToken<ArrayList<ChatRoom>>() {
                        }.getType(),
                        new CMOChatRoomConverter(context))
                .create();
        Retrofit retrofit = new Retrofit.Builder().client(client)
                .baseUrl(AppUtils.BASE_URL).addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        service = retrofit.create(RetrofitAPIInterface.class);
        return service;
    }


    public static RetrofitAPIInterface getRxJavaAPIService(Context context) {
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(RetrofitInterceptor.getInterceptor(context))
                .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .connectTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .build();
        Gson gson = new GsonBuilder()
                .excludeFieldsWithoutExposeAnnotation()
                .create();
        Retrofit retrofit = new Retrofit.Builder().client(client)
                .baseUrl(AppUtils.BASE_URL).addConverterFactory(GsonConverterFactory.create(gson)).addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
        service = retrofit.create(RetrofitAPIInterface.class);
        //}
        return service;
    }
}
