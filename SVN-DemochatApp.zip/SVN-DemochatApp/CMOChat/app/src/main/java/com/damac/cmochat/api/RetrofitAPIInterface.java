package com.damac.cmochat.api;

import com.damac.cmochat.model.CMOChatRooms;
import com.damac.cmochat.model.CMORosterGroup;
import com.damac.cmochat.model.CMOUser;
import com.damac.cmochat.model.NewChatRoom;
import com.damac.cmochat.model.User;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Url;
import rx.Observable;

/**
 * Created by Barun.Gupta on 1/6/2017.
 *
 */

public interface RetrofitAPIInterface {

    @GET("users")
    Call<CMOUser> getCMOUser();

    @GET("chatrooms")
    Call<CMOChatRooms> getChatRooms();

    @GET("chatrooms/of/{userName}")
    Call<CMOChatRooms> getChatRooms(@Path("userName") String userName);

    @GET("groups")
    Call<CMORosterGroup> getCMORoasterGroup();

    @GET("groups/{groupName}")
    Call<CMORosterGroup> getGroupDetailes(@Path("groupName") String groupName);

    @POST
    Call<ResponseBody> createChatRoom(@Body NewChatRoom body, @Url String url);

    @GET("users/{username}")
    Observable<User> getUser(@Path("username") String username);
}
