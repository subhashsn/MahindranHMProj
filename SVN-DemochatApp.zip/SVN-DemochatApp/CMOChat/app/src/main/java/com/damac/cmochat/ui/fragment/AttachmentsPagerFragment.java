package com.damac.cmochat.ui.fragment;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.damac.cmochat.R;
import com.damac.cmochat.util.AppUtils;

/**
 * A simple {@link Fragment} subclass.
 * Fragment to show the view pager for attachments within a chat room
 */
public class AttachmentsPagerFragment extends Fragment {
    private static String mRoomName;

    public AttachmentsPagerFragment() {
        // Required empty public constructor
    }

    public static AttachmentsPagerFragment newInstance(String roomName) {
        AttachmentsPagerFragment fragment = new AttachmentsPagerFragment();
        Bundle args = new Bundle();
        args.putString(AppUtils.CHAT_ROOM_NAME, roomName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_attachments_pager, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        TabLayout tabLayout = (TabLayout) getActivity().findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Images"));
        tabLayout.addTab(tabLayout.newTab().setText("Documents"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ViewPager viewPager = (ViewPager) getActivity().findViewById(R.id.view_pager);
        AttachmentsPagerAdapter adapterViewPager = new AttachmentsPagerAdapter(getChildFragmentManager());
        viewPager.setAdapter(adapterViewPager);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        String chatRoomName = getActivity().getIntent().getStringExtra(AppUtils.CHAT_ROOM_NAME);
        if (chatRoomName != null)//For Handling activity
            mRoomName = chatRoomName;

        if (savedInstanceState != null) //For handling restarts
            mRoomName = savedInstanceState.getString(AppUtils.CHAT_ROOM_NAME);

        if (getArguments() != null) {
            //For Fragment newInstance
            chatRoomName = getArguments().getString(AppUtils.CHAT_ROOM_NAME);
            if (chatRoomName != null)
                mRoomName = chatRoomName;
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(AppUtils.CHAT_ROOM_NAME, mRoomName);
    }

    /**
     * Adapter for showing Images and other attachments
     */
    public static class AttachmentsPagerAdapter extends FragmentPagerAdapter {
        private static int NUM_ITEMS = 2;

        AttachmentsPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        // Returns total number of pages
        @Override
        public int getCount() {
            return NUM_ITEMS;
        }

        // Returns the fragment to display for that page
        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return ViewAttachmentsFragment.newInstance(ViewAttachmentsFragment.LIST_TYPE.IMAGES, mRoomName);
                case 1:
                    return ViewAttachmentsFragment.newInstance(ViewAttachmentsFragment.LIST_TYPE.DOCS, mRoomName);
                default:
                    return null;
            }
        }

        // Returns the page title for the top indicator
        @Override
        public CharSequence getPageTitle(int position) {
            return position == 0 ? "Images" : "Documents";
        }
    }
}
