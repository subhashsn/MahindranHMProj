package com.damac.cmochat.model;

import android.os.Parcel;
import android.os.Parcelable;

import io.realm.RealmObject;

/**
 * Created by gautam.honavar on 1/27/2017.
 * <p>
 * Body of the message to be sent. It follows the Builder pattern
 */

public class XMPPBody extends RealmObject implements Parcelable{

    private String body;
    private String mediaItem;
    private String slaTime;
    private String slaFlag;
    private String isConfidential;
    private String date;
    private String roomName;
    private String from;
    private String to;
    private String messageId;
    private boolean toDisplayed;
    private boolean isConcluded;
    private boolean mediaType;

    public boolean isMediaType() {
        return mediaType;
    }

    public XMPPBody setMediaType(boolean mediaType) {
        this.mediaType = mediaType;
        return this;
    }



    public String getMessageId() {
        return messageId;
    }

    public XMPPBody setMessageId(String messageId) {
        this.messageId = messageId;
        return this;
    }



    public boolean isConcluded() {
        return isConcluded;
    }

    public XMPPBody setConcluded(boolean concluded) {
        this.isConcluded = concluded;
        return this;
    }


    public String getDateDisplay() {
        return dateDisplay;
    }

    public void setDateDisplay(String dateDisplay) {
        this.dateDisplay = dateDisplay;
    }

    private String dateDisplay;

    public boolean isToDisplayed() {
        return toDisplayed;
    }

    public void setToDisplayed(boolean toDisplayed) {
        this.toDisplayed = toDisplayed;
    }


    public XMPPBody() {
        //Required Default constructor
    }

    public String getBody() {
        return body;
    }

    public XMPPBody setBody(String body) {
        this.body = body;
        return this;
    }

    public String getMediaItem() {
        return mediaItem;
    }

    public XMPPBody setMediaItem(String mediaItem) {
        this.mediaItem = mediaItem;
        return this;
    }

    public String getSlaTime() {
        return slaTime;
    }

    public XMPPBody setSlaTime(String slaTime) {
        this.slaTime = slaTime;
        return this;
    }

    public String getSlaFlag() {
        return slaFlag;
    }

    public XMPPBody setSlaFlag(String slaFlag) {
        this.slaFlag = slaFlag;
        return this;
    }

    public String getDate() {
        return date;
    }

    public XMPPBody setDate(String date) {
        this.date = date;
        return this;
    }

    public String getIsConfidential() {
        return isConfidential;
    }

    public XMPPBody setIsConfidential(String isConfidential) {
        this.isConfidential = isConfidential;
        return this;
    }

    public String getRoomName() {
        return roomName;
    }

    public XMPPBody setRoomName(String roomName) {
        this.roomName = roomName;
        return this;
    }

    public String getFrom() {
        return from;
    }

    public XMPPBody setFrom(String from) {
        this.from = from;
        return this;
    }

    public String getTo() {
        return to;
    }

    public XMPPBody setTo(String to) {
        this.to = to;
        return this;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.body);
        dest.writeString(this.mediaItem);
        dest.writeString(this.slaTime);
        dest.writeString(this.slaFlag);
        dest.writeString(this.isConfidential);
        dest.writeString(this.date);
        dest.writeString(this.roomName);
        dest.writeString(this.from);
        dest.writeString(this.to);
        dest.writeString(this.messageId);
        dest.writeByte(this.toDisplayed ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isConcluded ? (byte) 1 : (byte) 0);
        dest.writeByte(this.mediaType ? (byte) 1 : (byte) 0);
        dest.writeString(this.dateDisplay);
    }

    protected XMPPBody(Parcel in) {
        this.body = in.readString();
        this.mediaItem = in.readString();
        this.slaTime = in.readString();
        this.slaFlag = in.readString();
        this.isConfidential = in.readString();
        this.date = in.readString();
        this.roomName = in.readString();
        this.from = in.readString();
        this.to = in.readString();
        this.messageId = in.readString();
        this.toDisplayed = in.readByte() != 0;
        this.isConcluded = in.readByte() != 0;
        this.mediaType = in.readByte() != 0;
        this.dateDisplay = in.readString();
    }

    public static final Creator<XMPPBody> CREATOR = new Creator<XMPPBody>() {
        @Override
        public XMPPBody createFromParcel(Parcel source) {
            return new XMPPBody(source);
        }

        @Override
        public XMPPBody[] newArray(int size) {
            return new XMPPBody[size];
        }
    };
}


