package com.damac.cmochat.model;

/**
 * Created by gautam.honavar on 2/7/2017.
 *
 */


public class CountryCode {
    private String code;

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    private String name;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}