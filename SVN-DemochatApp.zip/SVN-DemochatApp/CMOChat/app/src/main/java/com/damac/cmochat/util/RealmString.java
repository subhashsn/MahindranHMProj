package com.damac.cmochat.util;

import io.realm.RealmObject;

/**
 * Created by Barun.Gupta on 1/16/2017.
 *
 */

public class RealmString extends RealmObject {

    private String val;

    public String getValue() {
        return val;
    }

    public void setValue(String value) {
        this.val = value;
    }

    @Override
    public String toString() {
        return val;
    }
}
