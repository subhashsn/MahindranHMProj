package com.damac.cmochat.ui.fragment;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.damac.cmochat.R;
import com.damac.cmochat.adapter.MUCAdapter;
import com.damac.cmochat.api.APIManager;
import com.damac.cmochat.api.RetrofitAPIInterface;
import com.damac.cmochat.events.ImageDownloadedEvent;
import com.damac.cmochat.model.CMOGroupMembers;
import com.damac.cmochat.model.NewChatRoom;
import com.damac.cmochat.model.XMPPBody;
import com.damac.cmochat.realm.CMORepositoryService;
import com.damac.cmochat.ui.activity.AttachmentsPagerActivity;
import com.damac.cmochat.ui.activity.CMOContactsListActivity;
import com.damac.cmochat.ui.activity.ParticipantsActivity;
import com.damac.cmochat.ui.activity.ShowAttachmentActivity;
import com.damac.cmochat.ui.custom.TextWatchingEditText;
import com.damac.cmochat.ui.listener.RecyclerItemClickListener;
import com.damac.cmochat.util.AppURLs;
import com.damac.cmochat.util.AppUtils;
import com.damac.cmochat.util.ImageManager;
import com.damac.cmochat.util.RealmString;
import com.damac.cmochat.xmpp.XMPPManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smackx.chatstates.ChatState;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import io.realm.Realm;
import io.realm.RealmResults;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;
import static android.widget.LinearLayout.VERTICAL;
import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_Members;
import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_NAME;
import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_PARTICIPANTS;
import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_SUBJECT;
import static com.damac.cmochat.util.AppUtils.CREATE_CHAT_ROOM;
import static com.damac.cmochat.util.AppUtils.IS_GROUP_CHAT;
import static com.damac.cmochat.util.AppUtils.PARTICIPANTS_ID;
import static com.damac.cmochat.util.AppUtils.USER_IDS_REQUEST_CODE;
import static com.damac.cmochat.util.AppUtils.log;
import static com.damac.cmochat.util.AppUtils.logError;

/**
 * A simple {@link Fragment} subclass.
 * <p>
 * Use the {@link ChatFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ChatFragment extends Fragment implements View.OnClickListener {

    private static final String JOINED_ROOM_NAME = "JOINED_ROOM_NAME";
    private static final int MY_PERMISSIONS_REQUEST_WRITE_STORAGE = 4005;
    private static final int RESULT_LOAD_IMAGE = 4004;
    private final String TAG = ChatFragment.class.getSimpleName();
    private TextWatchingEditText messageET;
    private ArrayList<XMPPBody> chatHistory = new ArrayList<>();
    private ArrayList<XMPPBody> filterChatHistory = new ArrayList<>();
    private AlertDialog alertDialog;
    private RecyclerView messagesListView;
    private String roomName;
    private boolean createChatRoom;
    private MUCAdapter chatAdapter;
    private ArrayList<String> chatRoomParticipants;
    private Call<ResponseBody> createChatAPI;
    private RetrofitAPIInterface retrofitAPIService;
    private String jid;
    private LinearLayout topView;
    private Realm mRealm;
    private ArrayList<String> chatRoomMembers;
    private ArrayList<XMPPBody> attachments;

    public ChatFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment ChatFragment.
     */
    public static ChatFragment newInstance(String chatRoomName) {
        ChatFragment chatFragment = new ChatFragment();
        Bundle args = new Bundle();
        args.putString(CHAT_ROOM_NAME, chatRoomName);
        chatFragment.setArguments(args);
        return chatFragment;
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment ChatFragment.
     */
    public static ChatFragment newInstance() {
        ChatFragment chatFragment = new ChatFragment();
        Bundle args = new Bundle();
        args.putBoolean(CREATE_CHAT_ROOM, true);
        chatFragment.setArguments(args);
        return chatFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View fragmentView = inflater.inflate(R.layout.fragment_chat, container, false);
        Button sendButton = (Button) fragmentView.findViewById(R.id.button_chat_send);
        ImageButton attachButton = (ImageButton) fragmentView.findViewById(R.id.button_chat_attachment);
        LinearLayout toLayout = (LinearLayout) fragmentView.findViewById(R.id.add_participants_layout);
        final ToggleButton conclusionBtn = (ToggleButton) fragmentView.findViewById(R.id.conclusion_btn);
        boolean isToDisplay = AppUtils.getSharedPref(getContext()).getBoolean(AppUtils.IS_TO_DISPLAY, true);
        if (isToDisplay) {
            conclusionBtn.setBackgroundDrawable(ResourcesCompat.getDrawable(getResources(), android.R.drawable.btn_star_big_on, null));
            conclusionBtn.setChecked(isToDisplay);
        } else {
            conclusionBtn.setBackgroundDrawable(ResourcesCompat.getDrawable(getResources(), android.R.drawable.btn_star_big_off, null));
            conclusionBtn.setChecked(isToDisplay);
        }
        conclusionBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (conclusionBtn.isChecked()) {
                    conclusionBtn.setBackgroundDrawable(ResourcesCompat.getDrawable(getResources(), android.R.drawable.btn_star_big_on, null));
                    Toast.makeText(getContext(), "isChecked::" + conclusionBtn.isChecked(), Toast.LENGTH_LONG).show();
                    SharedPreferences.Editor editor = AppUtils.getSharedPref(getContext()).edit();
                    editor.putBoolean(AppUtils.IS_TO_DISPLAY, conclusionBtn.isChecked());
                    editor.commit();
                    chatHistory = new ArrayList<>();
                    filterChatHistory = new ArrayList<>();
                    initControls();
                } else {
                    conclusionBtn.setBackgroundDrawable(ResourcesCompat.getDrawable(getResources(), android.R.drawable.btn_star_big_off, null));
                    Toast.makeText(getContext(), "isChecked::" + conclusionBtn.isChecked(), Toast.LENGTH_LONG).show();
                    SharedPreferences.Editor editor = AppUtils.getSharedPref(getContext()).edit();
                    editor.putBoolean(AppUtils.IS_TO_DISPLAY, conclusionBtn.isChecked());
                    editor.commit();
                    chatHistory = new ArrayList<XMPPBody>();
                    filterChatHistory = new ArrayList<XMPPBody>();
                    initControls();
                }
            }
        });
        sendButton.setOnClickListener(this);
        attachButton.setOnClickListener(this);
        toLayout.setOnClickListener(this);
        return fragmentView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);
        String chatRoomName = getActivity().getIntent().getStringExtra(CHAT_ROOM_NAME);
        String chatRoomSubject = getActivity().getIntent().getStringExtra(CHAT_ROOM_SUBJECT);
        createChatRoom = getActivity().getIntent().getBooleanExtra(CREATE_CHAT_ROOM, false);

        chatRoomMembers = getActivity().getIntent().getStringArrayListExtra(CHAT_ROOM_Members);
        attachments = new ArrayList<XMPPBody>();

//        ArrayList<String> members = (ArrayList<String>) getActivity().getIntent().getSerializableExtra(CHAT_ROOM_Members);

        if (chatRoomName != null)//For Handling activity
            roomName = chatRoomName;
        if (savedInstanceState != null) { //For handling restarts
            roomName = savedInstanceState.getString(JOINED_ROOM_NAME);
            createChatRoom = savedInstanceState.getBoolean(CREATE_CHAT_ROOM, false);
            chatRoomParticipants = savedInstanceState.getStringArrayList(CHAT_ROOM_PARTICIPANTS);
            showNumberOfParticipants();
        }
        if (getArguments() != null) {
            //For Fragment newInstance
            chatRoomName = getArguments().getString(CHAT_ROOM_NAME);
            if (chatRoomName != null)
                roomName = chatRoomName;
            createChatRoom = getArguments().getBoolean(CREATE_CHAT_ROOM, false);
        }

        if (chatRoomSubject != null)
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(chatRoomSubject);

        jid = getActivity().getIntent().getStringExtra("JID");
        log("jid::" + jid);
        initControls();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.menu_chat, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            /*case R.id.createGrp:
                createConference();
                break;
            case R.id.inviteOtherUser:
                inviteUser();
                break;*/
            case R.id.showAttachments:
                showAttachments();
                break;
            case R.id.showParticipants:
                showParticipants();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            final String picturePath = getPathFromUri(data.getData());
            if (picturePath == null) {
                //TODO - Handle error
                Toast.makeText(getActivity(), "Unable to load the file!! Error!!", Toast.LENGTH_SHORT).show();
                return;
            }
            //TODO: calculate with server time
            String currentDate = AppUtils.dateFormat.format(Calendar.getInstance().getTime());
            String jid = AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext());
            /**** Upload the file to WebDAV server****/
            uploadFileToWebDAV(data.getData(), currentDate, jid);
        } else {
            //TODO - Handle error
            log("Error!!", "Should Not Come here!!");
        }
    }

    /**
     * Method to upload a file to WebDAV
     *
     * @param file - File to be uploaded
     */


    private void uploadFileToWebDAV(Uri imageuri, final String currentDate, final String from) {

        try {
            final InputStream imageStream = getContext().getContentResolver().openInputStream(imageuri);
            final int imageLength = imageStream.available();

            final Handler handler = new Handler();
            Thread th = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String imageName = UUID.randomUUID().toString();
                        final String imageStr = imageName + ".png";
                        imageName = "thumb_" + imageName + ".png";
                        final long timeStarted = System.currentTimeMillis();
                        final String imagePath = ImageManager.UploadImage(imageStream, imageLength, imageName);

                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                              //  Toast.makeText(getActivity(), "Upload Success!!", Toast.LENGTH_SHORT).show();
                                log("Upload", "success");
                                log("Time Taken", "" + ((System.currentTimeMillis() - timeStarted) / 1000) + " seconds.");
                                if (jid != null) {
                                    sendChatRoaster(getContext(), imagePath, jid);
                                } else {
                                    String curentDate = AppUtils.dateFormat.format(Calendar.getInstance().getTime());
                                    String messageId = UUID.randomUUID().toString();
                                    XMPPBody chatMessages = new XMPPBody().setBody(imageStr).setDate(curentDate).setFrom(from).setRoomName(roomName).setMessageId(messageId).setMediaType(true);
                                    XMPPManager.getInstance(getActivity()).sendGroupMessage(roomName, chatMessages);
                                }
                            }
                        });


                    }
                    catch (Exception ex) {
                        Toast.makeText(getActivity(), "Upload Failue!!", Toast.LENGTH_SHORT).show();
                        log("Upload", "Failure");
                        log("UP_FAIL", ex.getMessage() + "     " + " " + "   " + " ");
                    }


                }
            });

            th.start();


        }
        catch (Exception ex) {
            Toast.makeText(getActivity(), ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
       /* WebDAVService uploadService = WebDAVServiceGenerator.createService(WebDAVService.class, "admin@dotcms.com", "admin");
        // create RequestBody instance from file
        RequestBody requestFile = RequestBody.create(MediaType.parse("file/*"), file);
        // finally, execute the request
        final String fileName = getUniqueNameForFile(file.getName().substring(file.getName().lastIndexOf('.')));
        final String url = WebDAVServiceGenerator.API_BASE_URL + "photos/" + fileName;
        Call<ResponseBody> call = uploadService.uploadFile(requestFile, url);
        final long timeStarted = System.currentTimeMillis();
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call,
                                   Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(getActivity(), "Upload Success!!", Toast.LENGTH_SHORT).show();
                    log("Upload", "success");
                    log("Time Taken", "" + ((System.currentTimeMillis() - timeStarted) / 1000) + " seconds.");
                    if (jid != null) {
                        sendChatRoaster(getContext(), url, jid);
                    } else {
                        String curentDate = AppUtils.dateFormat.format(Calendar.getInstance().getTime());
                        XMPPBody chatMessages = new XMPPBody().setBody(url).setDate(curentDate).setFrom(from).setRoomName(roomName);
                        XMPPManager.getInstance(getActivity()).sendGroupMessage(roomName, chatMessages);
                    }
                } else {
                    Toast.makeText(getActivity(), "Upload Failue!!", Toast.LENGTH_SHORT).show();
                    log("Upload", "Failure");
                    log("UP_FAIL", response.message() + "     " + response.errorBody() + "   " + response.code());
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(getActivity(), "Upload failure!!", Toast.LENGTH_SHORT).show();
                log("Upload error:", t.getMessage());
            }
        }); */
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(JOINED_ROOM_NAME, roomName);
        outState.putBoolean(CREATE_CHAT_ROOM, createChatRoom);
        outState.putStringArrayList(CHAT_ROOM_PARTICIPANTS, chatRoomParticipants);
    }

    /**
     * Method to get unique file name while uploading a file
     */
    private String getUniqueNameForFile(String fileExt) {
        return (AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext(), "") + "_" + System.currentTimeMillis() + fileExt);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_WRITE_STORAGE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                    onAttachmentsClick();
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(getActivity(), "Please give permission to access file before trying again!!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    /**
     * Method to get the complete path from an uri
     *
     * @param uri - uri
     * @return - Complete path of the file
     */
    private String getPathFromUri(Uri uri) {
        if (uri == null)
            return null;
        String[] filePathColumn = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContext().getContentResolver().query(uri, filePathColumn, null, null, null);
        if (cursor == null)
            return null;
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
        String path = cursor.getString(columnIndex);
        cursor.close();
        return path;
    }

    /**
     * Method to create a chatroom
     */
    private void createConference() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(R.layout.dialog_create_conference);
        builder.create();
        // Add the buttons
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked OK button
                assert (alertDialog).findViewById(R.id.to_username) != null;
                String toUserName = ((EditText) alertDialog.findViewById(R.id.to_username)).getText().toString();
                assert (alertDialog).findViewById(R.id.room_name) != null;
                String roomName = ((EditText) alertDialog.findViewById(R.id.room_name)).getText().toString();
                ChatFragment.this.roomName = roomName;
                String jid = AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext());
                XMPPManager.getInstance(getContext()).createConference(roomName, jid, toUserName);
            }
        });
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the alertDialog
            }
        });

        alertDialog = builder.show();
    }

    /**
     * Method to invite users to an existing chatroom
     */
    private void inviteUser() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(R.layout.dialog_invite_user);
        builder.create();
        // Add the buttons
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked OK button
                assert (alertDialog).findViewById(R.id.to_username) != null;
                String toUserName = ((EditText) alertDialog.findViewById(R.id.to_username)).getText().toString();
                XMPPManager.getInstance(getContext()).inviteUser(toUserName);
            }
        });

        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the alertDialog
            }
        });

        alertDialog = builder.show();
    }

    /**
     * Method to join an existing chatroom
     *
     * @param mContext - Context
     */
    public void joinChat(Context mContext, boolean getAllMessages, Date since) {
        XMPPManager xmppManager = XMPPManager.getInstance(mContext);
        xmppManager.joinChatRoom(roomName, getAllMessages, since);
    }

    /**
     * Method to send text to Roaster
     *
     * @param context - Context
     */
    public void sendChatRoaster(Context context, String messageText, String toJid) {
        XMPPManager xmppManager = XMPPManager.getInstance(context);
        XMPPBody chatMessages;
        chatMessages = new XMPPBody().setBody(messageText).setFrom(AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext()).split("@")[0]).setDate(null).setRoomName(null).setConcluded(false);
        xmppManager.sendSingleMessage(chatMessages, toJid);
        messageET.setText("");
        chatAdapter.add(chatMessages);
        scrollListToEnd();
    }

    /**
     * Method to show the attachments associated with the chat room
     */
    private void showAttachments() {
        Intent intent = new Intent(getActivity(), AttachmentsPagerActivity.class);
        intent.putExtra(CHAT_ROOM_NAME, roomName);
        intent.putParcelableArrayListExtra(AppUtils.CHAT_ROOM_ATTACHMENTS, attachments);
        startActivity(intent);
    }

    private void showParticipants() {
        Intent intent = new Intent(getActivity(), ParticipantsActivity.class);
        intent.putStringArrayListExtra(AppUtils.PARTICIPANTS_ID, chatRoomParticipants);
        intent.putExtra("RoomName", roomName);
        intent.putExtra(AppUtils.CHAT_ROOM_Members, chatRoomMembers);
        startActivity(intent);
    }

    /**
     * Method to initiate the UI
     */
    private void initControls() {
        messagesListView = (RecyclerView) getView().findViewById(R.id.list_chat_messages);
        messageET = (TextWatchingEditText) getView().findViewById(R.id.edit_chat_message);
        topView = (LinearLayout) getView().findViewById(R.id.top_container);
        handleClickEvents(messagesListView);
        messageET.setOnTypingModifiedListener(new TextWatchingEditText.OnTypingModified() {
            @Override
            public void onIsTypingModified(EditText view, boolean isTyping) {
                XMPPManager xmppManager = XMPPManager.getInstance(getContext());
                if (xmppManager == null)
                    return;
                try {
                    xmppManager.sendComposingStatus(isTyping, AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext()));
                } catch (SmackException.NotConnectedException e) {
                    logError(TAG, e.getMessage(), e);
                }
            }
        });
        if (jid != null) {
            topView.setVisibility(View.GONE);
        } else {
            topView.setVisibility(View.VISIBLE);
        }
        mRealm = Realm.getDefaultInstance();
        boolean isToDisplay = AppUtils.getSharedPref(getContext()).getBoolean(AppUtils.IS_TO_DISPLAY, true);
        RealmResults<XMPPBody> realmResults = CMORepositoryService.getInstance().getRoomMessage(mRealm, roomName);
        List<XMPPBody> chatRoomMessages = mRealm.copyFromRealm(realmResults);
        if (roomName != null && !roomName.isEmpty()) {
            if (chatRoomMessages.size() > 0) {
                mRealm.beginTransaction();
                XMPPBody chatMessage = chatRoomMessages.get(chatRoomMessages.size() - 1);
                try {
                    long addMilSec = 1000;
                    for (XMPPBody xmppBody : chatRoomMessages) {
                        String dateDisplay = null;
                        try {
                            dateDisplay = AppUtils.isDayToday(xmppBody.getDate());
                        } catch (ParseException e) {
                            logError(TAG, e.getMessage(), e);
                        }
                        if (chatHistory != null && chatHistory.size() == 0) {
                            xmppBody.setToDisplayed(true);
                            xmppBody.setDateDisplay(dateDisplay);
                        }
                        if (chatHistory != null && chatHistory.size() > 0) {
                            XMPPBody xchatMessages = chatHistory.get(chatHistory.size() - 1);
                            try {
                                dateDisplay = AppUtils.isDayToday(xmppBody.getDate());
                                xmppBody.setDateDisplay(dateDisplay);
                            } catch (ParseException e) {
                                logError(TAG, e.getMessage(), e);
                            }
                            if (xchatMessages.getDateDisplay().equals(xmppBody.getDateDisplay())) {
                                xmppBody.setToDisplayed(false);
                            } else {
                                xmppBody.setToDisplayed(true);
                            }
                        }
                        if (xmppBody.isConcluded()) {
                            filterChatHistory.add(xmppBody);
                        }
                        chatHistory.add(xmppBody);
                    }
                    if (chatMessage.getDate() != null) {
                        Date sinceDate = new Date(AppUtils.dateFormat.parse(chatMessage.getDate()).getTime() + addMilSec);
                        displayMessage(isToDisplay);
                        scrollListToEnd();
                        joinChat(getContext(), false, sinceDate);
                    } else {
                        //For handling null date if any
                        Date sinceDate = new Date(System.currentTimeMillis() + addMilSec);
                        displayMessage(isToDisplay);
                        scrollListToEnd();
                        joinChat(getContext(), false, sinceDate);
                    }
                } catch (Exception e) {
                    displayMessage(isToDisplay);
                    joinChat(getContext(), true, null);
                }
                mRealm.cancelTransaction();
            } else {
                displayMessage(isToDisplay);
                joinChat(getContext(), false, null);
            }
        } else {
            displayMessage(isToDisplay);
        }
    }

    /**
     * Method to handle onclick events for chat messages
     *
     * @param recyclerView - recyclerview
     */
    private void handleClickEvents(RecyclerView recyclerView) {
        if (recyclerView == null)
            return;

        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(getActivity(), recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        if (chatAdapter == null || chatAdapter.getItemCount() < position)
                            return;

                        XMPPBody message = chatAdapter.getItem(position);
                        int viewType = chatAdapter.getItemViewType(position);
                        int arrayIndex = attachments.indexOf(message);

                        if (viewType == MUCAdapter.TYPE_IMAGE_LEFT || viewType == MUCAdapter.TYPE_IMAGE_RIGHT) {
                            Intent intent = new Intent(getActivity(), ShowAttachmentActivity.class);
                            intent.putExtra(AppUtils.ATTACHMENT_URL, message.getBody());
                            intent.putExtra("Index", arrayIndex);
                            intent.putParcelableArrayListExtra(AppUtils.CHAT_ROOM_ATTACHMENTS, attachments);

                            startActivity(intent);
                        }
                    }

                    @Override
                    public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );
    }

    /*** Event to Handle Incoming Message ***/

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(XMPPBody message) {
        if (null == message.getBody()) {
            return;
        }

        if (message.isMediaType())
            attachments.add(message);

        chatAdapter.add(message);
        scrollListToEnd();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(Message message) {
        if (null == message.getBody()) {
            handleChatState(message);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(ImageDownloadedEvent message) {
        if (chatAdapter != null) {
            chatAdapter.notifyDataSetChanged();
        }
    }

    /**
     * Method to handle the typing status of a user
     *
     * @param message - Message received
     */
    private void handleChatState(Message message) {
        if (message == null || message.getFrom() == null || message.getFrom().isEmpty())
            return;

        String msg_xml = message.toXML().toString();
        String fromUser = message.getFrom().substring(message.getFrom().lastIndexOf('/') + 1);
        String loggedInUser = AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext());
        //TODO - Refine this logic. Think of all the cases.
        if (fromUser.equals(loggedInUser) || loggedInUser.startsWith(fromUser)) {
            //Status from the logged in User. Ignore
            if (loggedInUser.indexOf('@') < 0)
                return;
            else if (fromUser.equals(loggedInUser.substring(0, loggedInUser.indexOf('@'))))
                return;
        }

        if (msg_xml.contains(ChatState.composing.toString())) {
            //handle is-typing, probably some indication on screen
            Toast.makeText(getActivity(), fromUser + " is typing!!", Toast.LENGTH_SHORT).show();
        } else if (msg_xml.contains(ChatState.inactive.toString())) {
            // handle "stopped typing"
            Toast.makeText(getActivity(), fromUser + " stopped typing!!", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Initiating chat messages recycler view
     */
    private void displayMessage(boolean isTodispaly) {

        chatAdapter = new MUCAdapter(getActivity(), chatHistory, AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext()));
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), VERTICAL, false);
        messagesListView.setLayoutManager(layoutManager);
        messagesListView.setAdapter(chatAdapter);
    }

    /**
     * Method to handle adding attachments
     */
    public void onAttachmentsClick() {
        Toast.makeText(getActivity(), "Add Attachments", Toast.LENGTH_SHORT).show();
        if (ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST_WRITE_STORAGE);
        } else {
            Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(i, RESULT_LOAD_IMAGE);
        }
    }

    /**
     * User has clicked send button. Send the message to MUC chat room
     *
     * @param view - View
     */
    public void onSendClick(View view) {
        String messageText = messageET.getText().toString();
        if (TextUtils.isEmpty(messageText)) {
            return;
        }
        if (roomName != null) {
            createAndSendMessage(messageText);
        }
        if (jid != null) {
            sendChatRoaster(getContext(), messageText, jid);
        }
    }

    /**
     * Method to create the message(XMPPBody) and send it to the cjat room
     */
    private void createAndSendMessage(String messageText) {
        try {
            String currentDate = AppUtils.dateFormat.format(Calendar.getInstance().getTime());
            String jid = AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext());
            XMPPBody chatMessages;
            String messageId = UUID.randomUUID().toString();
            chatMessages = new XMPPBody().setBody(messageText).setFrom(jid).setDate(currentDate).setRoomName(roomName).setConcluded(true).setMessageId(messageId).setMediaType(false);
            XMPPManager.getInstance(getContext()).sendGroupMessage(roomName, chatMessages);
            messageET.setText("");
        } catch (Exception e) {
            logError(TAG, e.getMessage(), e);
        }
    }

    /**
     * Method to create a new chat room
     */
    private void createNewChatRoom() {
        //Chatroom should have atleast 1 participant
        if (chatRoomParticipants == null || chatRoomParticipants.size() == 0) {
            Toast.makeText(getContext(), "Add atleast 1 participant!!", Toast.LENGTH_SHORT).show();
            return;
        }
        NewChatRoom.Members members = new NewChatRoom.Members(chatRoomParticipants);
        NewChatRoom.Owners owners = new NewChatRoom.Owners(AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getActivity()));
        NewChatRoom newChatRoom = new NewChatRoom.Builder().setRoomName(roomName)
                .setNaturalName(roomName)
                .setDescription(roomName)
                .setPublicRoom(Boolean.TRUE.toString())
                .setSubject(roomName)
                .setCanOccupantsInvite(Boolean.TRUE.toString())
                .setMaxUsers("50")
                .setMembersOnly(Boolean.TRUE.toString())
                .setMembers(members)
                .setOwners(owners)
                .setPersistent(Boolean.TRUE.toString())
                .createNewChatRoom();
        Gson gson = new Gson();
        Type type = new TypeToken<NewChatRoom>() {
        }.getType();
        String json = gson.toJson(newChatRoom, type);
        System.out.println(json);
        final String url = AppUtils.BASE_URL + "chatrooms";
        retrofitAPIService = APIManager.getRetrofitServiceInstance(getContext());
        createChatAPI = retrofitAPIService.createChatRoom(newChatRoom, url);
        createChatAPI.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    createChatRoom = false;
                   /* Join the created room*/
                    XMPPManager xmppManager = XMPPManager.getInstance(getActivity());
                    xmppManager.joinChatRoom(roomName, true, null);
                   /* Invite participants*/
                    for (String jid : chatRoomParticipants)
                        xmppManager.inviteUser(jid);
                   /* Send the first message*/
                    //createAndSendMessage(roomName);
                    //getActivity().startService(new Intent(getActivity(), SyncService.class));
                    Toast.makeText(getActivity(), "Room created successfully!!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                //TODO - Handle Error
                Toast.makeText(getActivity(), "Room creation Failed!!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Scroll to the end of chat messages and show the most recent message
     */
    private void scrollListToEnd() {
        int itemCount = chatAdapter.getItemCount();
        if (itemCount > 0) {
            messagesListView.smoothScrollToPosition(chatAdapter.getItemCount() - 1);
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.button_chat_send) {
            onSendClick(view);
        } else if (view.getId() == R.id.button_chat_attachment) {
            onAttachmentsClick();
        } else if (view.getId() == R.id.add_participants_layout) {
            if (messageET.getText() != null && messageET.getText().length() > 0) {
                addParticipants();
            } else {
                Toast.makeText(getContext(), "Please add Subject of Chat Room", Toast.LENGTH_LONG).show();
            }

        }
    }

    /**
     * Method to add participants to this chatroom
     */
    private void addParticipants() {
        //Start the activity
        Intent intent = new Intent(getActivity(), CMOContactsListActivity.class);
        intent.putExtra(IS_GROUP_CHAT, true);
        startActivityForResult(intent, USER_IDS_REQUEST_CODE);
    }

    /**
     * Method to append domain name to userIDs
     */
    private void appendDomain() {
        if (chatRoomParticipants == null || chatRoomParticipants.size() == 0)
            return;
        for (int i = 0, length = chatRoomParticipants.size(); i < length; i++) {
            String jid = chatRoomParticipants.get(i);
            jid = jid + "@" + AppURLs.DOMAIN;
            chatRoomParticipants.remove(i);
            chatRoomParticipants.add(i, jid);
        }
    }

    /**
     * Show the number of participants in the textview
     */
    private void showNumberOfParticipants() {
        if (getView() == null || chatRoomParticipants == null || chatRoomParticipants.size() == 0)
            return;
        getView().findViewById(R.id.chat_fragment_add_icon).setVisibility(View.GONE);
        TextView textView = (TextView) getView().findViewById(R.id.chat_fragment_participants);
        String text = chatRoomParticipants.size() + " Participants";
        textView.setText(text);
        textView.setVisibility(View.VISIBLE);
    }

    /**
     * Callback for handling selected participants
     *
     * @param userIds - Selected userIds
     */
    public void participantsSelected(ArrayList<String> userIds) {
        chatRoomParticipants = userIds;
        appendDomain();
        showNumberOfParticipants();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//        if (mRealm != null)
//            CMORepositoryService.getInstance().deleteGroupMembers(mRealm);

    }

    @Override
    public void onResume() {
        super.onResume();
        chatRoomParticipants = getActivity().getIntent().getStringArrayListExtra(PARTICIPANTS_ID);
        if (createChatRoom) {
            createNewChatRoom();
        }
        showNumberOfParticipants();
    }
}
