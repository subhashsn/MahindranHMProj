package com.damac.cmochat.xmpp;

import org.jivesoftware.smack.packet.ExtensionElement;
import org.jivesoftware.smack.provider.EmbeddedExtensionProvider;
import org.jivesoftware.smack.util.XmlStringBuilder;

import java.util.List;
import java.util.Map;

/**
 * Created by Narasimha.HS on 2/1/2017.
 * Custom Message Extension to handle data required by the server
 */

class CustomMessageExtension implements ExtensionElement {
    static final String NAMESPACE = "urn:xmpp:receipts";
    static final String ELEMENT = "customdata";

    private static final String ATTRIBUTE_ROOM_NAME = "roomName";
    private static final String ATTRIBUTE_SLA_FLAG = "slaFlag";
    private static final String ATTRIBUTE_SLA_TIME = "slaTime";

    private String roomName;
    private String slaFlag;
    private String slaTime;

    CustomMessageExtension(String roomName, String slaFlag, String slaTime) {
        this.roomName = roomName;
        this.slaFlag = slaFlag;
        this.slaTime = slaTime;
    }

    @Override
    public String getNamespace() {
        return NAMESPACE;
    }

    @Override
    public String getElementName() {
        return ELEMENT;
    }

    @Override
    public CharSequence toXML() {
        XmlStringBuilder xml = new XmlStringBuilder(this);
        xml.attribute(ATTRIBUTE_ROOM_NAME, roomName);
        xml.attribute(ATTRIBUTE_SLA_FLAG, slaFlag);
        xml.attribute(ATTRIBUTE_SLA_TIME, slaTime);
        xml.closeEmptyElement();
        return xml;
    }

    static class CustomMessageExtensionProvider extends EmbeddedExtensionProvider<CustomMessageExtension> {
        @Override
        protected CustomMessageExtension createReturnExtension(String currentElement, String currentNamespace, Map<String, String> attributeMap,
                                                               List<? extends ExtensionElement> content) {
            return new CustomMessageExtension(attributeMap.get(ATTRIBUTE_ROOM_NAME), attributeMap.get(ATTRIBUTE_SLA_FLAG), attributeMap.get(ATTRIBUTE_SLA_TIME));
        }
    }
}
