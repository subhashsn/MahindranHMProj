package com.damac.cmochat.sync;

/**
 * Created by Barun.Gupta on 1/28/2017.
 *
 */

public enum SyncType {
    CMO_CHATROOM_SYNC,
    CMO_GROUP_SYNC,
    CMO_GROUP_MEMBER_SYNC
}
