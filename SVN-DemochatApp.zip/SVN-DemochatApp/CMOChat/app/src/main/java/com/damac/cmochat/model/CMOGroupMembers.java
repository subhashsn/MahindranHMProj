package com.damac.cmochat.model;

import android.databinding.Bindable;
import android.databinding.Observable;
import android.databinding.PropertyChangeRegistry;

import com.damac.cmochat.BR;
import com.damac.cmochat.util.RealmString;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.Ignore;

/**
 * Created by Barun.Gupta on 1/12/2017.
 *
 */


public class CMOGroupMembers extends RealmObject implements Observable {
    public String mMembersStr;
    public String mGroupName;
    private RealmList<RealmString> member;

    @Ignore
    private transient PropertyChangeRegistry mCallbacks;

    public RealmList<RealmString> getMember() {
        return member;
    }

    public void setMember(RealmList<RealmString> member) {
        this.member = member;
    }

    public String getmGroupName() {
        return mGroupName;
    }

    public void setmGroupName(String mGroupName) {
        this.mGroupName = mGroupName;
    }

    @Bindable
    public String getmMembersStr() {
        return mMembersStr;
    }

    public void setmMembersStr(String mMembersStr) {
        this.mMembersStr = mMembersStr;
        notifyPropertyChanged(BR.mMembersStr);
    }

    @Override
    public void addOnPropertyChangedCallback(OnPropertyChangedCallback onPropertyChangedCallback) {
        if (mCallbacks == null) {
            mCallbacks = new PropertyChangeRegistry();
        }
        mCallbacks.add(onPropertyChangedCallback);
    }

    @Override
    public void removeOnPropertyChangedCallback(OnPropertyChangedCallback onPropertyChangedCallback) {
        if (mCallbacks != null) {
            mCallbacks.remove(onPropertyChangedCallback);
        }
    }

    /**
     * Notifies listeners that a specific property has changed. The getter for the property
     * that changes should be marked with {@link Bindable} to generate a field in
     * <code>BR</code> to be used as <code>fieldId</code>.
     *
     * @param fieldId The generated BR id for the Bindable field.
     */
    public void notifyPropertyChanged(int fieldId) {
        if (mCallbacks != null) {
            mCallbacks.notifyCallbacks(this, fieldId, null);
        }
    }
}
