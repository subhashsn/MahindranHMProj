package com.damac.cmochat.sync;

import android.content.Context;

import com.damac.cmochat.api.APIManager;
import com.damac.cmochat.api.RetrofitAPIInterface;
import com.damac.cmochat.events.SyncRequestEvent;
import com.damac.cmochat.model.CMOGroup;
import com.damac.cmochat.model.CMOGroupMembers;
import com.damac.cmochat.model.CMORosterGroup;
import com.damac.cmochat.realm.CMORepositoryService;

import org.greenrobot.eventbus.EventBus;

import io.realm.Realm;
import io.realm.RealmResults;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.damac.cmochat.util.AppUtils.log;

/**
 * Created by Barun.Gupta on 1/31/2017.
 *
 */

public class GroupMemberSync extends AbsSync {

    private Context mContext;
    private Call<CMORosterGroup> getGroupDetailes = null;
    private RetrofitAPIInterface retrofitAPIService = null;
    private final String TAG = GroupMemberSync.class.getSimpleName();


    public GroupMemberSync(Context context, Realm realm) {
        super(context);
        mContext = context;
        retrofitAPIService = APIManager.getRealmServiceInstance(mContext);

    }


    @Override
    protected void doSync() {
       final Realm realm = Realm.getDefaultInstance();
        RealmResults<CMOGroup> mCMOGroupsRealmResults = CMORepositoryService.getInstance().getAllCMOGroupsFromDB(realm);
        if (mCMOGroupsRealmResults != null && mCMOGroupsRealmResults.size() > 0) {
            for (final CMOGroup cmoGroup : mCMOGroupsRealmResults) {
                log(TAG, "GRP name:" + cmoGroup.getName());
                getGroupDetailes = retrofitAPIService.getGroupDetailes(cmoGroup.getName());
                getGroupDetailes.enqueue(new Callback<CMORosterGroup>() {
                    @Override
                    public void onResponse(Call<CMORosterGroup> call, Response<CMORosterGroup> response) {
                        final CMORosterGroup cmoRosterGroup = response.body();
                        CMOGroupMembers cmoGroupMembers;
                        if (cmoRosterGroup != null && cmoRosterGroup.getMembers() != null && cmoRosterGroup.getMembers().getMember() != null) {
                            log(TAG, "Size::" + cmoRosterGroup.getMembers().getMember());
                            Realm realmUpdate = Realm.getDefaultInstance();
                            cmoGroup.setMemberCount(String.valueOf(cmoRosterGroup.getMembers().getMember()));
                            CMORepositoryService.getInstance().updateCMOGroup(realmUpdate, cmoGroup);
                            if (realmUpdate != null) {
                                realmUpdate.close();
                            }
                            if (realm != null) {
                                realm.close();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<CMORosterGroup> call, Throwable t) {

                    }
                });
            }
            EventBus.getDefault().post(new SyncRequestEvent(SyncType.CMO_GROUP_MEMBER_SYNC));
        }

    }
}
