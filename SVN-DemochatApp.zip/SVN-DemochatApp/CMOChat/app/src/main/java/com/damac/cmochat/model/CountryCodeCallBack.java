package com.damac.cmochat.model;

/**
 * Created by gautam.honavar on 2/9/2017.
 *
 */

public interface CountryCodeCallBack {
    void onCountryCodeCallBack(String countryCode);
}
