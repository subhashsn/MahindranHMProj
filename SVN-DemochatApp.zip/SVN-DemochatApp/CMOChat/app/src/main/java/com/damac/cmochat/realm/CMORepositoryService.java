package com.damac.cmochat.realm;

import android.content.Context;

import com.damac.cmochat.model.CMOGroup;
import com.damac.cmochat.model.CMOGroupMembers;
import com.damac.cmochat.model.ChatRoom;
import com.damac.cmochat.model.User;
import com.damac.cmochat.model.XMPPBody;
import com.damac.cmochat.util.AppUtils;

import java.util.List;

import io.realm.Realm;
import io.realm.RealmResults;
import io.realm.Sort;

import static com.damac.cmochat.util.AppUtils.log;

/**
 * Created by Barun.Gupta on 1/12/2017.
 */

public class CMORepositoryService {

    private static final String TAG = CMORepositoryService.class.getSimpleName();
    private static CMORepositoryService cmoRepositoryService = null;

    public static CMORepositoryService getInstance() {
        if (cmoRepositoryService == null) {
            synchronized (CMORepositoryService.class) {
                cmoRepositoryService = new CMORepositoryService();
                return cmoRepositoryService;
            }
        }
        return cmoRepositoryService;
    }

    public boolean saveCMOGroup(Realm mRealm, CMOGroup cmoGroup) {
        try {
            if (readCMOGroup(cmoGroup.getName(), mRealm)) {
                updateCMOGroup(mRealm, cmoGroup);
            } else {
                log(TAG, "saveCMOGroup");
                mRealm.beginTransaction();
                CMOGroup realmCMOGroup = mRealm.createObject(CMOGroup.class);
                realmCMOGroup.setDescription(cmoGroup.getDescription());
                realmCMOGroup.setName(cmoGroup.getName());
                realmCMOGroup.setMemberCount(cmoGroup.getMemberCount());
                mRealm.commitTransaction();
            }
        } catch (Exception e) {
            mRealm.cancelTransaction();
            return false;
        }
        return true;
    }

    public RealmResults<CMOGroup> getAllCMOGroupsFromDB(Realm mRealm) {
        RealmResults<CMOGroup> cmoGroupsResults;
        cmoGroupsResults = mRealm.where(CMOGroup.class).findAll();
        return cmoGroupsResults;

    }


    /* Save Chat Room @param Realm, ChatRoom

     */

    public boolean saveGroupMembers(Realm mRealm, CMOGroupMembers cmoGroupMembers) {
        try {
            mRealm.beginTransaction();
            CMOGroupMembers cmoGroupMembers1 = mRealm.createObject(CMOGroupMembers.class);
            cmoGroupMembers1.setmMembersStr(cmoGroupMembers.getmMembersStr());
            mRealm.commitTransaction();
        } catch (Exception e){
            mRealm.cancelTransaction();
            return false;
        }
        return true;
    }

    public RealmResults<CMOGroupMembers> getGroupMembers(Realm mRealm) {
        RealmResults<CMOGroupMembers> cmoGroupMembers;
        cmoGroupMembers = mRealm.where(CMOGroupMembers.class).findAll();
        return cmoGroupMembers;
    }


    public void deleteGroupMembers(Realm realm) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                RealmResults<CMOGroupMembers> result = realm.where(CMOGroupMembers.class).findAll();
                result.deleteAllFromRealm();
            }
        });

        //.equalTo("roomName", chatRoom.getRoomName())
    }



    /*
    Save CMOGroup Members
    @param Realm, CMOGroupMembers
     */
    public boolean saveCMOGroupMember(Realm mRealm, CMOGroupMembers cmoGroupMembers) {
        try {
            mRealm.beginTransaction();
            CMOGroupMembers mRealmCMOGroupMembers = mRealm.createObject(CMOGroupMembers.class);
            mRealmCMOGroupMembers.setmGroupName(cmoGroupMembers.getmGroupName());
            mRealmCMOGroupMembers.setmMembersStr(cmoGroupMembers.getmMembersStr());
            mRealm.commitTransaction();
        } catch (Exception e) {
            mRealm.cancelTransaction();
            return false;
        }
        return true;
    }

    public RealmResults<CMOGroupMembers> getCMOGroupMemberByGrpname(Realm mRealm, final String grpName) {
        RealmResults<CMOGroupMembers> cmoGroupMembersResults;
        cmoGroupMembersResults = mRealm.where(CMOGroupMembers.class).equalTo("mGroupName", grpName).findAll();
        return cmoGroupMembersResults;
    }

    /*
  Save CMORoster user Members
  @param Realm, CMOUser
   */
    public boolean saveCMORosterUsers(Realm mRealm, List<User> cmoRosterUsers) {
        try {
            for (User user : cmoRosterUsers) {
                if (readUserName(user.getUsername(), mRealm)) {
                    log(TAG, "saveUsersList: try updateRecord");
                    updateCMORosterUsers(mRealm, user);
                } else {
                    log(TAG, "saveUsersList: try createRecord");
                    createCMORosterUsers(mRealm, user);
                }
            }
        } catch (Exception e) {
            mRealm.cancelTransaction();
            return false;
        }
        return true;
    }

    /*
     Retrive CMORoster user Members
     @param Realm, CMOUser
      */
    public RealmResults<User> getCMORosterUsers(Realm mRealm) {
        RealmResults<User> cmoRosterUsers;
        cmoRosterUsers = mRealm.where(User.class).findAll();
        return cmoRosterUsers;
    }

    /*
 create CMORoster user Members
 @param Realm, CMOUser
  */
    public boolean createCMORosterUsers(Realm mRealm, User cmoRosterUsers) {
        try {
            log(TAG, "createCMORosterUsers: ");
            mRealm.beginTransaction();
            User mRealmUser = mRealm.createObject(User.class);
            mRealmUser.setDrawbleId(cmoRosterUsers.getDrawbleId());
            mRealmUser.setImgBitmap(cmoRosterUsers.getImgBitmap());
            mRealmUser.username = cmoRosterUsers.getUsername();
            mRealmUser.email = cmoRosterUsers.getEmail();
            mRealmUser.name = cmoRosterUsers.getName();
            mRealm.commitTransaction();
        } catch (Exception e) {
            mRealm.cancelTransaction();
            return false;
        }
        return true;
    }

    /**
     * This would updated a record in Realm DataBase
     */
    public boolean updateCMORosterUsers(Realm mRealm, User cmoRosterUsers) {
        log(TAG, "CMORosterUsers: ");
        try {
            User currentUserRealm = mRealm
                    .where(User.class)
                    .equalTo("username", cmoRosterUsers.getUsername())
                    .findFirst();
            if (currentUserRealm != null) {
                log(TAG, "updateRecord: user exists so update it:");
                mRealm.beginTransaction();
                currentUserRealm.setDrawbleId(cmoRosterUsers.getDrawbleId());
                currentUserRealm.setImgBitmap(cmoRosterUsers.getImgBitmap());
                currentUserRealm.username = cmoRosterUsers.getUsername();
                currentUserRealm.email = cmoRosterUsers.getEmail();
                currentUserRealm.name = cmoRosterUsers.getName();
                mRealm.commitTransaction();
            } else {
                log(TAG, "updateRecord: Record does not exist:");
                return false;
            }
        } catch (Exception e) {
            mRealm.cancelTransaction();
            return false;
        }
        return true;
    }


    public boolean updateCMOGroup(Realm mRealm, CMOGroup cmoGroup) {
        log(TAG, "updateCMOGroup: ");
        try {
            CMOGroup currentcmoGroup = mRealm
                    .where(CMOGroup.class)
                    .equalTo("name", cmoGroup.getName())
                    .findFirst();
            if (currentcmoGroup != null) {
                log(TAG, "updateRecord: user exists so update it:");
                mRealm.beginTransaction();
                currentcmoGroup.setMemberCount(cmoGroup.getMemberCount());
                currentcmoGroup.setName(cmoGroup.getName());
                currentcmoGroup.setDescription(cmoGroup.getDescription());
                mRealm.commitTransaction();
            } else {
                log(TAG, "updateRecord: Record does not exist:");
                return false;
            }
        } catch (Exception e) {
            mRealm.cancelTransaction();
            return false;
        }
        return true;
    }

    /**
     * This methods tries to read a User and notifies if it exist in RealmDatabase of not.
     */

    private boolean readUserName(String username, Realm mRealm) {
        log(TAG, "readUserName: :" + username);
        User userRealm = mRealm
                .where(User.class)
                .equalTo("username", username)
                .findFirst();
        return userRealm != null;
    }


    /*public boolean saveCMOChatRoom(Realm mRealm, ChatRoom cmoChatRooms) {
        if (readChatRoom(cmoChatRooms.getRoomName(), mRealm)) {
            updateChatRoom(mRealm, cmoChatRooms);
        } else {
            try {
                mRealm.beginTransaction();
                ChatRoom mRealcmoChatRooms = mRealm.createObject(ChatRoom.class);
                mRealcmoChatRooms.setSubject(cmoChatRooms.getSubject());
                mRealcmoChatRooms.setRoomName(cmoChatRooms.getRoomName());
                mRealcmoChatRooms.setNaturalName(cmoChatRooms.getNaturalName());
                RealmList<RealmString> memberList = cmoChatRooms.getMembers();
                if (memberList != null) {
                    mRealcmoChatRooms.members = new RealmList<>();
                    for (RealmString memberString : memberList)
                        mRealcmoChatRooms.members.add(memberString);
                }
                mRealcmoChatRooms.setModificationDate(cmoChatRooms.getModificationDate());
                mRealcmoChatRooms.setMemberCount(cmoChatRooms.getMemberCount());
                mRealm.commitTransaction();
                log(TAG, "save ChatRoom::" + mRealcmoChatRooms.getRoomName());
            } catch (Exception e) {
                log(TAG, "Exception::" + e.getMessage() + "for chat room::" + cmoChatRooms.getRoomName());
                mRealm.cancelTransaction();
                return false;
            }
        }

        return true;
    }*/


    public RealmResults<ChatRoom> getAllChatRoom(Realm mRealm) {
        RealmResults<ChatRoom> chatRoomResults;
        chatRoomResults = mRealm.where(ChatRoom.class).findAllSorted(AppUtils.CONVERSATION_MOD_DATE, Sort.DESCENDING);
        return chatRoomResults;
    }

   /* public boolean updateChatRoom(Realm mRealm, ChatRoom chatRoom) {
        try {
            ChatRoom currentUserRealm = mRealm
                    .where(ChatRoom.class)
                    .equalTo("roomName", chatRoom.getRoomName())
                    .findFirst();
            if (currentUserRealm != null) {
                log(TAG, "updateRecord::" + currentUserRealm.getRoomName());
                mRealm.beginTransaction();
                currentUserRealm.setSubject(chatRoom.getSubject());
                currentUserRealm.setRoomName(chatRoom.getRoomName());
                currentUserRealm.setNaturalName(chatRoom.getNaturalName());
                RealmList<RealmString> memberList = chatRoom.getMembers();
                currentUserRealm.members = new RealmList<RealmString>();
                for (RealmString memberString : memberList)
                    currentUserRealm.members.add(memberString);
                currentUserRealm.setModificationDate(chatRoom.getModificationDate());
                currentUserRealm.setMemberCount(chatRoom.getMemberCount());
                mRealm.commitTransaction();
            } else {
                log(TAG, "updateRecord: Record does not exist:");
                return false;
            }
        } catch (Exception e) {
            mRealm.cancelTransaction();
            return false;
        }
        return true;
    }*/

    private boolean readChatRoom(String roomName, Realm mRealm) {
        ChatRoom chatroom = mRealm
                .where(ChatRoom.class)
                .equalTo("roomName", roomName)
                .findFirst();
        return chatroom != null;
    }

    private boolean readCMOGroup(String name, Realm mRealm) {
        CMOGroup cmoGroup = mRealm
                .where(CMOGroup.class)
                .equalTo("name", name)
                .findFirst();
        return cmoGroup != null;
    }


    public boolean saveChatRoomMessage(Realm mRealm, XMPPBody chatMessage, Context context) {
        try {
            mRealm.beginTransaction();
            XMPPBody mRealcmoXMPPBody = mRealm.createObject(XMPPBody.class);
            mRealcmoXMPPBody.setBody(chatMessage.getBody());
            mRealcmoXMPPBody.setMediaItem(chatMessage.getMediaItem());
            mRealcmoXMPPBody.setSlaTime(chatMessage.getSlaTime());
            mRealcmoXMPPBody.setSlaFlag(chatMessage.getSlaFlag());
            mRealcmoXMPPBody.setDate(chatMessage.getDate());
            mRealcmoXMPPBody.setIsConfidential(chatMessage.getIsConfidential());
            mRealcmoXMPPBody.setRoomName(chatMessage.getRoomName());
            mRealcmoXMPPBody.setFrom(chatMessage.getFrom());
            mRealcmoXMPPBody.setTo(chatMessage.getTo());
            mRealm.copyToRealm(chatMessage);
            mRealm.commitTransaction();
        } catch (Exception e) {
            mRealm.cancelTransaction();
            return false;
        }
        return true;
    }

    public RealmResults<XMPPBody> getAllRoomMessages(Realm mRealm) {
        RealmResults<XMPPBody> chatRoomMessages;
        chatRoomMessages = mRealm.where(XMPPBody.class).findAll();
        return chatRoomMessages;
    }

    public RealmResults<XMPPBody> getRoomMessage(Realm mRealm, String roomName) {
        RealmResults<XMPPBody> chatRoomMessages;
        chatRoomMessages = mRealm.where(XMPPBody.class).equalTo(AppUtils.ROOM_NAME, roomName).findAllSorted(AppUtils.DATE, Sort.ASCENDING);
        // chatRoomMessages = mRealm.where(XMPPBody.class).equalTo(AppUtils.ROOM_NAME,roomName).findAll();
        return chatRoomMessages;
    }

    public RealmResults<XMPPBody> getRoomImages(Realm mRealm, String roomName) {
        RealmResults<XMPPBody> chatRoomMessages;
        chatRoomMessages = mRealm.where(XMPPBody.class).
                endsWith(AppUtils.BODY, ".png").
                or().endsWith(AppUtils.BODY, ".jpg").
                equalTo(AppUtils.ROOM_NAME, roomName).
                findAllSorted(AppUtils.DATE, Sort.ASCENDING);
        return chatRoomMessages;
    }

    public RealmResults<XMPPBody> getRoomDocs(Realm mRealm, String roomName) {
        RealmResults<XMPPBody> chatRoomMessages;
        chatRoomMessages = mRealm.where(XMPPBody.class).
                endsWith(AppUtils.BODY, ".doc").
                or().endsWith(AppUtils.BODY, ".pdf").
                or().endsWith(AppUtils.BODY, ".xls").
                equalTo(AppUtils.ROOM_NAME, roomName).
                findAllSorted(AppUtils.DATE, Sort.ASCENDING);
        return chatRoomMessages;
    }

    public User getCMOUserByUsername(Realm mRealm, String userName) {
        User user;
        user = mRealm.where(User.class).equalTo("username", userName).findFirst();
        return user;
    }

    public void deleteChatRoom(Realm realm, final ChatRoom chatRoom) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                RealmResults<ChatRoom> result = realm.where(ChatRoom.class).equalTo("roomName", chatRoom.getRoomName()).findAll();
                result.deleteAllFromRealm();
            }
        });

        //.equalTo("roomName", chatRoom.getRoomName())
    }
}
