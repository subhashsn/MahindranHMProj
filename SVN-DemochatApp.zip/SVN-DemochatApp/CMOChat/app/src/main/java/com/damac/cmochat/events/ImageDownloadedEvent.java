package com.damac.cmochat.events;

/**
 * Created by Narasimha.HS on 2/2/2017.
 *
 * Class which is used to notify that an images has been downloaded
 */

public class ImageDownloadedEvent {

}
