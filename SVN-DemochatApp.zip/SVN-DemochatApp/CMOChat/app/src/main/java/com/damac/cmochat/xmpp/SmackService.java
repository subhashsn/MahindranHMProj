package com.damac.cmochat.xmpp;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import com.damac.cmochat.events.XMPPAuthenticationEvent;
import com.damac.cmochat.util.AppUtils;

import org.greenrobot.eventbus.EventBus;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;

import java.io.IOException;

import static com.damac.cmochat.util.AppUtils.logError;

public class SmackService extends Service {

    public static XMPPManager.ConnectionState sConnectionState;
    static String sConnectionMsg;
    private boolean mActive;
    private Thread mThread;
    private Handler mHandler;
    private XMPPManager mConnection;
    private String mUsername;
    private String mPassword;


    public static XMPPManager.ConnectionState getState() {
        if (sConnectionState == null) {
            return XMPPManager.ConnectionState.DISCONNECTED;
        }
        return sConnectionState;
    }

    public void setConnState(XMPPManager.ConnectionState state, String statusMsg) {
        sConnectionState = state;
        sConnectionMsg = statusMsg;
        notifyActivity(sConnectionState, sConnectionMsg);
    }

    @Override
    public void onCreate() {
        super.onCreate();

    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Bundle bundle = intent.getExtras();
        if(bundle != null) {
            mUsername = bundle.getString("UserName");
            mPassword = bundle.getString("Password");
        }
        start();
        return Service.START_STICKY;
    }

    public XMPPManager getConnection() {
        return mConnection;
    }

    public void setConnection(XMPPManager mConnection) {
        this.mConnection = mConnection;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.mConnection.disconnect();
        this.mConnection = null;

    //    AppUtils.clearData(getApplicationContext());
    }

    public void start() {
        if (!mActive) {
            // Create ConnectionThread Loop
            if (mThread == null || !mThread.isAlive()) {
                mThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Looper.prepare();
                        mHandler = new Handler();
                        initConnection();
                        Looper.loop();
                    }
                });
                mThread.start();
            }
        }
    }



    private void initConnection() {
        if (mConnection == null) {
            mConnection = XMPPManager.getInstance(this);
        }
        try {
            mConnection.connect(mUsername, mPassword);
        } catch (IOException | SmackException | XMPPException e) {
            logError(SmackService.class.getSimpleName(), e.getMessage(), e);
            sConnectionState = XMPPManager.ConnectionState.DISCONNECTED;
            stopSelf();
        }
    }

    private void notifyActivity(XMPPManager.ConnectionState state, String message) {
        EventBus.getDefault().post(new XMPPAuthenticationEvent(state, message));
    }
}
