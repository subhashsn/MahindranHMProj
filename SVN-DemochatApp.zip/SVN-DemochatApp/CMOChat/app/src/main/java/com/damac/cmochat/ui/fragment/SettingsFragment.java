package com.damac.cmochat.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.damac.cmochat.R;
import com.damac.cmochat.ui.activity.ProfileActivity;
import com.damac.cmochat.util.AppUtils;
import com.damac.cmochat.xmpp.SmackService;

import static com.damac.cmochat.util.AppUtils.RIGHT_CONTAINER_FRAGMENT_TAG;

/**
 * A simple {@link Fragment} subclass.
 * <p>
 * Use the {@link SettingsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SettingsFragment extends Fragment implements View.OnClickListener {
    private String jID;
    private boolean isTwoPaneMode;

    public SettingsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment SettingsFragment.
     */
    public static SettingsFragment newInstance(String jid, boolean isTwopaneMode) {
        SettingsFragment settingsFragment = new SettingsFragment();
        Bundle args = new Bundle();
        args.putString(AppUtils.XMPP_JID, jid);
        args.putBoolean("isTowPaneMode", isTwopaneMode);
        settingsFragment.setArguments(args);
        return settingsFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View fragmentView = inflater.inflate(R.layout.fragment_settings, container, false);
        TextView profileClick = (TextView) fragmentView.findViewById(R.id.my_profile);
        TextView logoutClick = (TextView) fragmentView.findViewById(R.id.logout);
        profileClick.setOnClickListener(this);
        logoutClick.setOnClickListener(this);
        return fragmentView;
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (getArguments().getBoolean("isTowPaneMode"))
                loadProfileDisplayFragment();
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getArguments() != null) {
            jID = getArguments().getString(AppUtils.XMPP_JID);
            isTwoPaneMode = getArguments().getBoolean("isTowPaneMode");
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.my_profile:
                if (getResources().getBoolean(R.bool.twoPaneMode)) {
                    //Load the fragment on the right
                    loadProfileDisplayFragment();
                } else {
                    Intent startIntent = new Intent(getActivity(), ProfileActivity.class);
                    startActivity(startIntent);
                }
                break;
            case R.id.logout:
                getActivity().stopService(new Intent(getActivity(),SmackService.class));
                break;

        }

    }

    /**
     * Method to display the ProfileFragment.
     */
    private void loadProfileDisplayFragment() {
        FragmentManager fm = getFragmentManager();
        /*if (fm.findFragmentByTag(RIGHT_CONTAINER_FRAGMENT_TAG) instanceof ProfileDisplayFragment)
            return;*/
        FragmentTransaction ft = fm.beginTransaction();
        jID = getArguments().getString(AppUtils.XMPP_JID);
        // String jid = AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext());
        ft.replace(R.id.right_container, ProfileDisplayFragment.newInstance(jID), RIGHT_CONTAINER_FRAGMENT_TAG);
        ft.commit();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(AppUtils.XMPP_JID, jID);
        outState.putBoolean("isTowPaneMode", isTwoPaneMode);
    }


}
