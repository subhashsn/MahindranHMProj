package com.damac.cmochat.ui.fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.databinding.DataBindingUtil;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.damac.cmochat.R;
import com.damac.cmochat.adapter.ChatRoomsAdapter;
import com.damac.cmochat.api.APIManager;
import com.damac.cmochat.api.RetrofitAPIInterface;
import com.damac.cmochat.databinding.ChatroomsFragmentBinding;
import com.damac.cmochat.model.CMOChatRoomMember;
import com.damac.cmochat.model.CMOChatRooms;
import com.damac.cmochat.model.CMOGroupMembers;
import com.damac.cmochat.model.ChatRoom;
import com.damac.cmochat.model.User;
import com.damac.cmochat.realm.CMORepositoryService;
import com.damac.cmochat.ui.activity.CMOContactsListActivity;
import com.damac.cmochat.ui.activity.ChatActivity;
import com.damac.cmochat.ui.listener.CMOItemClickListener;
import com.damac.cmochat.ui.listener.SearchListener;
import com.damac.cmochat.util.AppUtils;
import com.damac.cmochat.util.RealmString;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmResults;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import rx.Observer;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_Members;
import static com.damac.cmochat.util.AppUtils.CHAT_ROOM_NAME;
import static com.damac.cmochat.util.AppUtils.IS_GROUP_CHAT;
import static com.damac.cmochat.util.AppUtils.RIGHT_CONTAINER_FRAGMENT_TAG;
import static com.damac.cmochat.util.AppUtils.USER_IDS_REQUEST_CODE;
import static com.damac.cmochat.util.AppUtils.log;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link ConversationsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ConversationsFragment extends Fragment implements SearchListener {

    private Realm mRealm;
    private Call<CMOChatRooms> getCMOChatRooms = null;
    private ChatroomsFragmentBinding mDataChatroomBinder;
    private ChatRoomsAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private RealmResults<ChatRoom> chatRoomResults;
    private RealmChangeListener realmChangeListener;
    private String TAG = ConversationsFragment.class.getSimpleName();
    private Parcelable recyclerViewState;
    private List<ChatRoom> chatRoomList;
    private boolean isVisibletoUser = false;
    private Subscription subscription;
    private ArrayList<String> participantIds;


    public ConversationsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment ConversationsFragment.
     */

    public static ConversationsFragment newInstance() {
        return new ConversationsFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mRealm = Realm.getDefaultInstance();
        // Inflate the layout for this fragment
        mDataChatroomBinder = DataBindingUtil.inflate(inflater, R.layout.chatrooms_fragment, container, false);

        mDataChatroomBinder.createConversationbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createConversation(view);
            }
        });
        realmChangeListener = new RealmChangeListener() {
            @Override
            public void onChange(Object element) {
                chatRoomResults = (RealmResults<ChatRoom>) element;
                chatRoomList = mRealm.copyFromRealm(chatRoomResults);
                if (chatRoomList != null && chatRoomList.size() > 0) {
                    renderUI();
                    if (isVisibletoUser) {
                        loadRightFragment(chatRoomList, false);
                    }
                }
            }
        };

        chatRoomResults = CMORepositoryService.getInstance().getAllChatRoom(mRealm);
        if (chatRoomResults != null && chatRoomResults.size() > 0) {
            chatRoomList = mRealm.copyFromRealm(chatRoomResults);
            if (chatRoomList != null && chatRoomList.size() > 0) {
                renderUI();
            }
        } else {
            getChatRoom();
        }
        return mDataChatroomBinder.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        mDataChatroomBinder.chatroomListRecyclerview.addOnItemTouchListener(new CMOItemClickListener(getActivity(), new CMOItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position, float x, float y) {
                if (getActivity() == null)
                    return;

              final ChatRoom chatRoom = chatRoomList.get(position);

                ArrayList<String> participants = new ArrayList<String>();

                for (RealmString member : chatRoom.getMembers()) {
                    participants.add(member.getValue());
                }

                loadChatFragment(false, chatRoom.getRoomName(), chatRoom.getSubject(), participants);
            }
        }));
        chatRoomResults.addChangeListener(realmChangeListener);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (isVisibletoUser) {
            FragmentManager fm = getFragmentManager();
            if (!(fm.findFragmentByTag(RIGHT_CONTAINER_FRAGMENT_TAG) instanceof ChatFragment)) {
                loadRightFragment(chatRoomList, false);
            }
        }
        participantIds = getActivity().getIntent().getStringArrayListExtra(AppUtils.PARTICIPANTS_ID);
    }


    @Override
    public void onPause() {
        super.onPause();
        chatRoomResults.removeChangeListener(realmChangeListener);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mRealm != null) {
            mRealm.close();
        }
        if (subscription != null) {
            subscription.unsubscribe();
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        isVisibletoUser = isVisibleToUser;
        if (isVisibleToUser) {
            if (mRealm == null) {
                return;
            }
            if (chatRoomResults == null)
                return;
            if (chatRoomResults != null && chatRoomResults.size() > 0) {
                List<ChatRoom> chatRoomList = mRealm.copyFromRealm(chatRoomResults);
                loadRightFragment(chatRoomList, true);
            }
        }
    }

    public void getChatRoom() {
        RetrofitAPIInterface retrofitAPIService = APIManager.getRealmCMOChatRoomInstance(getContext());
        String jid = AppUtils.getFromAppPrefs(AppUtils.XMPP_JID, getContext());
        if (jid == null)
            return;
        String userName = jid.substring(0, jid.indexOf('@'));
        //getCMOChatRooms = retrofitAPIService.getChatRooms();// ths is for POC
        getUserDisplayName(userName);
        getCMOChatRooms = retrofitAPIService.getChatRooms(userName);// this is for real project openfire plugin API
        getCMOChatRooms.enqueue(new Callback<CMOChatRooms>() {
            @Override
            public void onResponse(Call<CMOChatRooms> call, Response<CMOChatRooms> response) {
                if (response != null && response.isSuccessful()) {
                    final CMOChatRooms cmoChatRooms = response.body();
                    chatRoomList = cmoChatRooms.getChatRoom();
//                    for (ChatRoom chatRoom : chatRoomList) {
//                        String roomName = chatRoom.getRoomName();
//                        CMOGroupMembers cmoGroupMembers = new CMOGroupMembers();
//                        cmoGroupMembers.setMember(chatRoom.getMembers());
//                        cmoGroupMembers.setmGroupName(roomName);
//                        CMORepositoryService.getInstance().saveGroupMembers(mRealm,cmoGroupMembers);
//                    }

                    if (chatRoomList != null && chatRoomList.size() > 0) {
                        renderUI();
                        SharedPreferences.Editor editor = AppUtils.getSharedPref(getContext()).edit();
                        if (cmoChatRooms.getMeta() != null && cmoChatRooms.getMeta().getRequestTime() != null) {
                            editor.putString(AppUtils.RESPONSE_TIME, cmoChatRooms.getMeta().getResponseTime());
                            editor.commit();
                        }
                    } else if (chatRoomList != null && chatRoomList.size() == 0) {
                        Toast.makeText(getContext(), "1 Chat Room Found", Toast.LENGTH_LONG).show();
                        chatRoomList.add(cmoChatRooms.getChatRoomResponse());
                        renderUI();
                        SharedPreferences.Editor editor = AppUtils.getSharedPref(getContext()).edit();
                        if (cmoChatRooms.getMeta() != null && cmoChatRooms.getMeta().getRequestTime() != null) {
                            editor.putString(AppUtils.RESPONSE_TIME, cmoChatRooms.getMeta().getResponseTime());
                            editor.commit();
                        }
                    }
                } else {
                    Toast.makeText(getContext(), "No Chat Room Found", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<CMOChatRooms> call, Throwable t) {
                if (call != null) {
                    log("Chat", "Error  occured::" + t.getMessage());
                }
            }
        });
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        inflater.inflate(R.menu.menu_conversations, menu);
        SearchView searchView =
                (SearchView) menu.findItem(R.id.menu_search).getActionView();
        MenuItem createMenu = menu.findItem(R.id.createroom);
        createMenu.setVisible(false);
        searchView.setFocusable(false);
        searchView.setQueryHint("Search");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                Toast.makeText(getContext(), "onQueryTextSubmit::" + s, Toast.LENGTH_LONG).show();
                return false;

            }

            @Override
            public boolean onQueryTextChange(String search) {
                if (mAdapter != null)
                    mAdapter.getFilter().filter(search);
                return false;
            }
        });


    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.createroom:
//                FragmentManager fm = getFragmentManager();
//                SearchDialogFragment dialogFragment = new SearchDialogFragment();
//                dialogFragment.setTargetFragment(this, 0);
//                dialogFragment.show(fm, SearchDialogFragment.class.getSimpleName());
                Intent intent = new Intent(getActivity(), CMOContactsListActivity.class);
                intent.putExtra(IS_GROUP_CHAT, true);
                startActivityForResult(intent, USER_IDS_REQUEST_CODE);
                break;
            case R.id.menu_search:
                loadChatFragment(true, null, null, null);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    public void createConversation(View v) {
        Intent intent = new Intent(getActivity(), CMOContactsListActivity.class);
        intent.putExtra(IS_GROUP_CHAT, true);
        startActivityForResult(intent, USER_IDS_REQUEST_CODE);
    }

    public void renderUI() {
        mDataChatroomBinder.chatroomListRecyclerview.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mDataChatroomBinder.chatroomListRecyclerview.setLayoutManager(mLayoutManager);
        mAdapter = new ChatRoomsAdapter(chatRoomList);
        recyclerViewState = mDataChatroomBinder.chatroomListRecyclerview.getLayoutManager().onSaveInstanceState();
        if (recyclerViewState != null) {
            mDataChatroomBinder.chatroomListRecyclerview.getLayoutManager().onRestoreInstanceState(recyclerViewState);
        }
        mDataChatroomBinder.chatroomListRecyclerview.setAdapter(mAdapter);
    }

    //RealmList<RealmString> memberList = new RealmList<>();

    /**
     * Method to load Chatroom Fragment by Joining a chatroom/creating a new chatroom
     *
     * @param creatChatRoom -
     * @param chatRoomName  -
     */
    private void loadChatFragment(boolean creatChatRoom, String chatRoomName, String chatRoomSubject, ArrayList<String> member) {
        if (getResources().getBoolean(R.bool.twoPaneMode)) {
            //Load the fragment on the right
            FragmentManager fm = getFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            if (creatChatRoom)
                ft.replace(R.id.right_container, ChatFragment.newInstance(), RIGHT_CONTAINER_FRAGMENT_TAG);
            else
                ft.replace(R.id.right_container, ChatFragment.newInstance(chatRoomName), RIGHT_CONTAINER_FRAGMENT_TAG);
            ft.commit();
        } else {

            //Start a new activity
            Intent intent = new Intent(getActivity(), ChatActivity.class);
            if (creatChatRoom)
                intent.putExtra(AppUtils.CREATE_CHAT_ROOM, true);
            else
                intent.putExtra(AppUtils.CHAT_ROOM_NAME, chatRoomName);
                intent.putExtra(AppUtils.CHAT_ROOM_SUBJECT, chatRoomSubject);
                intent.putExtra(AppUtils.CHAT_ROOM_Members, member);


            intent.putStringArrayListExtra(AppUtils.PARTICIPANTS_ID, participantIds);
            getContext().startActivity(intent);
        }
    }


    @Override
    public void onSearch(String recepient, String content) {
        Bundle bundle = new Bundle();
        bundle.putString("recepient", recepient);
        bundle.putString("content", content);
        SearchResultsFragment searchResultsFragment = new SearchResultsFragment();
        searchResultsFragment.setArguments(bundle);
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.main_container, searchResultsFragment, RIGHT_CONTAINER_FRAGMENT_TAG);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.addToBackStack(SearchResultsFragment.class.getSimpleName());
        ft.commit();
    }

    @Override
    public void getRoomName(String roomName) {

    }

    private void loadRightFragment(List<ChatRoom> chatRoomLst, boolean isCommitNow) {
        if (chatRoomLst != null && chatRoomLst.size() > 0) {
            ChatRoom chatRoom;
            chatRoom = chatRoomLst.get(0);
            if (getActivity() != null) {
                if (getActivity().getResources().getBoolean(R.bool.twoPaneMode)) {
                    //Load the fragment on the right
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.right_container, ChatFragment.newInstance(chatRoom.getRoomName()), RIGHT_CONTAINER_FRAGMENT_TAG);
                    if (isCommitNow)
                        ft.commitNow();
                    else
                        ft.commit();
                }
            }
        }
    }


    private void getUserDisplayName(String username) {

        subscription = APIManager.getRxJavaAPIService(getContext())
                .getUser(username)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<User>() {
                    @Override
                    public void onCompleted() {
                        log(TAG + "onCompleted:::::");
                    }

                    @Override
                    public void onError(Throwable e) {
                        log(TAG + "onError::" + e.getMessage());
                    }

                    @Override
                    public void onNext(User user) {
                        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(user.getUsername());
                    }
                });

    }

}
