package com.damac.cmochat.ui.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.damac.cmochat.R;

/**
 * Created by Narasimha on 1/9/2017.
 * <p>
 * Class for showing MUC chat
 */

public class ChatActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode == USER_IDS_RESULT_CODE) {
            ArrayList<String> userIds = data.getStringArrayListExtra(USER_IDS);
            ChatFragment fragment = (ChatFragment) getSupportFragmentManager().findFragmentById(R.id.chat_fragment);
            if (fragment != null) {
                fragment.participantsSelected(userIds);
            }
        }
    }*/
}
