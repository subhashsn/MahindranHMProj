package com.damac.cmochat.events;

import com.damac.cmochat.xmpp.XMPPManager;

/**
 * Created by Narasimha.HS on 1/6/2017.
 * <p>
 * Class to encapsulate XMPP authentication event
 */

public class XMPPAuthenticationEvent {
    private XMPPManager.ConnectionState state;
    private String message;

    public XMPPAuthenticationEvent(XMPPManager.ConnectionState state, String message) {
        this.state = state;
        this.message = message;
    }

    public XMPPManager.ConnectionState getState() {
        return state;
    }

    public void setState(XMPPManager.ConnectionState state) {
        this.state = state;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
