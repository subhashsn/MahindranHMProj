package com.damac.cmochat.ui.listener;

/**
 * Created by Barun.Gupta on 2/10/2017.
 *
 */

public interface SearchListener {
    void onSearch(String param1, String param2);
    void getRoomName(String roomName);
}
