//
//  CMOUserPresence.h
//  CMOChat
//
//  Created by Administrator on 11/9/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
 <presence xmlns="jabber:client" to="subash@hmecmac000094.local/CMOCHATIPHONE" from="hmgroup@conference.hmecmac000094.local/subash"><c xmlns="http://jabber.org/protocol/caps" hash="sha-1" node="https://github.com/robbiehanson/XMPPFramework" ver="VyOFcFX6+YNmKssVXSBKGFP0BS4="/><x xmlns="http://jabber.org/protocol/muc#user"><item jid="subash@hmecmac000094.local/CMOCHATIPHONE" affiliation="member" role="participant"/><status code="110"/><status code="100"/></x></presence>
 */


@interface CMOOccupant : NSObject

@property (nonatomic,strong)NSString *username;

@property (nonatomic,strong)NSString *jid;

@property (nonatomic,strong)NSString *affiliation;

@property (nonatomic,strong)NSString *role;

@end

@interface CMOVCard : NSObject

@property (nonatomic, strong)NSString *photoSHA;

@end

@interface CMOUserPresence : NSObject
@property (nonatomic, strong)NSString *from;
@property (nonatomic, strong)NSString *to;
@property (nonatomic, strong)NSString *type;
@property (nonatomic, assign)BOOL isMUC;
@property (nonatomic, strong)CMOVCard *vCard;
@property (nonatomic, strong)CMOOccupant *user;
@property (nonatomic, assign)BOOL ownPresence;
@end
