//
//  CMORosterPresentation.h
//  CMOChat
//
//  Created by Administrator on 10/24/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CMOCoreComponents;
@class CMORoster;

@interface CMORosterPresentation : NSObject

@property (nonatomic, strong)CMOCoreComponents *coreComponents;

- (NSArray *)getRostersWithCompletionHandler:(void (^)(id users))onSuccess
                                     failure:(void (^)(NSError  *error))onFailure;

- (NSArray *)getUsersWithCompletionHandler:(void (^)(id users))onSuccess
                              failure:(void (^)(NSError  *error))onFailure;

- (NSArray *)getGroupsWithCompletionHandler:(void (^)(id users))onSuccess
                                   failure:(void (^)(NSError  *error))onFailure;

//- (NSArray *)getCurrentUserInfoWithCompletionHandler:(void (^)(id users))onSuccess
  //                                    failure:(void (^)(NSError  *error))onFailure;

- (CMORoster *)getCurrentUserInfoWithCompletionHandler:(void (^)(id users))onSuccess
                                               failure:(void (^)(NSError  *error))onFailure;

- (void)getAllUsersWithCompletionHandler:(void (^)(NSArray *items,NSError *error))handler;

- (NSArray *)fetchAllUsers;

- (NSArray *)getNonBuddyListWithCompletionHandler:(void (^)(id users))onSuccess
                                          failure:(void (^)(NSError  *error))onFailure;

- (void) savePhoneContactRosters;

- (NSArray *)getExchangeUsersWithCompletionHandler:(void (^)(id users))onSuccess
                                           failure:(void (^)(NSError  *error))onFailure;

- (NSMutableArray *)fetchPhoneNumbersFromSMSUsers:(NSMutableArray *)users;

- (NSArray *)eligibleParticipants:(NSMutableDictionary *)participants sent:(BOOL)messageSent;

- (NSArray *)hasSMSUsers:(NSMutableDictionary *)participants;

- (void)fetchAllUsersAndGroupsWithCompletionHandler:(void (^)(id users))onSuccess
                                            failure:(void (^)(NSError  *error))onFailure;

@end
