//
//  CMOArchivedRooms+CoreDataClass.m
//  CMOChat
//
//  Created by Administrator on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOArchivedRooms+CoreDataClass.h"

@implementation CMOArchivedRooms

@end
