//
//  CMOMessage.m
//  CMOChat
//
//  Created by Anish on 10/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOMessage.h"


//#import <CocoaLumberjack/CocoaLumberjack.h>


@implementation CMOMessageBody


@end

@interface CMOMessage(){
   
}
@end



@implementation CMOMessage


@end
