//
//  CMOMessageCount.h
//  CMOChat
//
//  Created by Administrator on 1/15/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <JSONModel/JSONModel.h>

@protocol CMOMessageCount <NSObject>

@end

@interface CMOUserMessageCount : JSONModel
@property (nonatomic, strong)NSMutableArray *mucusermessage;
@end


@interface CMOMessageCount : JSONModel
@property (nonatomic, assign)NSInteger messageCount;
@property (nonatomic, strong)NSString<Optional> *room;
@property (nonatomic, strong)NSObject<Optional> *firstMessage;
@property (nonatomic, assign)NSInteger SLAClosed;
@property (nullable, nonatomic, copy)NSDate *lastModifiedDate;
@end
