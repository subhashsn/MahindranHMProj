//
//  XMPPRoomCoreDataStorage+CMORoomCoreDataStorage.h
//  CMOChat
//
//  Created by Administrator on 11/26/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <XMPPFramework/XMPPFramework.h>
#import "XMPPHeader.h"

@interface XMPPRoomCoreDataStorage (CMORoomCoreDataStorage)


@end
