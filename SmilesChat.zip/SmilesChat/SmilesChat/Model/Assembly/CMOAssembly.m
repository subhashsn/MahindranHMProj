//
//  CMOAssembly.m
//  CMOChat
//
//  Created by Administrator on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOAssembly.h"
#import "CMOLoginViewController.h"


static NSString *loginvc = @"loginvc";

@implementation CMOAssembly

/**
 Make sure that this storyboard identifier is added for both iPhone and iPad viewcontrollers of  storyboard
 */

+ (UIViewController *)controller:(NSString *)identifier{
    NSString *storyboardName = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"UIMainStoryboardFile"];
 
   UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
   return  [storyboard instantiateViewControllerWithIdentifier:identifier];


}

+ (CMOLoginViewController *)loginviewcontroller{
    return (CMOLoginViewController *)[CMOAssembly controller:loginvc];
}

@end
