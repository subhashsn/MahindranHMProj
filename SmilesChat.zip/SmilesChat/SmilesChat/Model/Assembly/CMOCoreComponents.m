//
//  CoreComponents.m
//  CMOChat
//
//  Created by Administrator on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOCoreComponents.h"
#import "CMOXMPPManager.h"


static id <CMOXMPPDelegate> _xmppManager;

@implementation CMOCoreComponents

+ (id<CMOXMPPDelegate>)xmppManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _xmppManager = [[CMOXMPPManager alloc] init];
    });
    return _xmppManager;
}
    
@end
