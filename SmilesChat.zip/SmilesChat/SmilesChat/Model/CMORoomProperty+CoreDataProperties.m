//
//  CMORoomProperty+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 2/10/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMORoomProperty+CoreDataProperties.h"

@implementation CMORoomProperty (CoreDataProperties)

+ (NSFetchRequest<CMORoomProperty *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMORoomProperty"];
}

@dynamic isChatHidden;
@dynamic isAnyMessageOffline;
@dynamic isOffline;
@dynamic roomDetails;
@dynamic isEligibleToJoin;
@dynamic smsUsers;
@dynamic groups;
@dynamic isUploadProgress;

@end
