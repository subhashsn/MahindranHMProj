//
//  CMOLoginPresentation.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOLoginPresentation.h"
#import "CMOChatClient.h"
#import "CMOCoreComponents.h"
#import "CMOVersionInfo.h"
#import "CMOUtils.h"

@interface CMOLoginPresentation(){
}

@end

@implementation CMOLoginPresentation

- (instancetype)initWithUser:(NSString *)userName clientId:(NSString *)clientId{
    self = [super init];
    if (!self) return nil;
    
    //loginUser = user;
    if (userName.length > 0){
        _userName = userName;
    }
    
    if (clientId.length > 0){
        _clientId = clientId;
    }
    
    return self;
}

#pragma mark XMPP Connect

- (void)connect:(CMOUser *)user andPassword:(NSString *)password completionHandler:(void (^)(id success, NSError *error))handler{
    
    id <CMOChatClient>chatService = [_coreComponents chatService];
    
    //The following function handles connect and authentication functionality with XMPP. If connection is failed (i.e)Username is not registered with XMPP Server, it will return immediately in `connected` variable. If the user is registered, but the authentication fails (Password is wrong), then it will be returned in the following completion handler.
    
    //Refer connectWithJID:password:completionHandler in XMPPManager.m for more details.
    BOOL connected = [chatService connect:user andPassword:password completionHandler:^(BOOL success) {
        if (!success){
            //Print Error, Unable to connect. Authentication Error or
            //Already connected.
            NSError *error = [NSError errorWithDomain:@"Authentication" code:111 userInfo:nil];
            handler(nil,error);
        }
        else{
            id <CMOUserClient>userClient = [_coreComponents userService];
            [userClient saveUser:user];
            handler(user,nil);
        }
        return;
    }];
    
    if (!connected){
        //Connection Failed before Authentication. Show Alert. Above completion handled will not get called.
        NSError *error = [NSError errorWithDomain:@"Connection Failed" code:112 userInfo:nil];
        handler(nil,error);
    }
}

- (BOOL)disconnect{
    id <CMOChatClient>chatService = [_coreComponents chatService];
    return [chatService disconnect];
}


#pragma mark --
#pragma mark App version updates

- (void)updateAppVersionWithUser:(NSString *)userName  onSuccess:(void (^)(CMOVersionInfo *versioninfo))success onFailure:(void (^)(NSError *error))failure
{
    id <CMOLoginClient>loginService = [_coreComponents loginService];
    [loginService updateAppVersionWithUser:userName onSuccess:^(id result) {
        CMOVersionInfo *versioninfo = [self getVersionInfoWithData:result];
        if (versioninfo) {
            success(versioninfo);
        }
        else{
            success(nil);
        }
    } onFailure:^(NSError *error) {
        failure(error);
    }];
}

- (CMOVersionInfo *) getVersionInfoWithData:(id)data{
    CMOVersionInfo *versionInfo = [[CMOVersionInfo alloc]init];
    NSDictionary *appResponseDetails = (NSDictionary *)data;
    
    versionInfo.appVersion = [appResponseDetails objectForKey:@"appVersion"];
    versionInfo.downloadUrl = [appResponseDetails objectForKey:@"downloadUrl"];
    versionInfo.lastSupportedVersionCode = [appResponseDetails objectForKey:@"lastSupportedVersionCode"];
    versionInfo.forceUpdate = [[appResponseDetails objectForKey:@"forceUpdate"] boolValue];
    versionInfo.forceUpdateBy = [[appResponseDetails objectForKey:@"forceUpdateBy"] integerValue];
    versionInfo.releaseDate = [[appResponseDetails objectForKey:@"releaseDate"] integerValue];
    
    return versionInfo;
}



@end
