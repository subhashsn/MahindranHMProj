//
//  CMOUserRoles+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 11/28/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOUserRoles+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOUserRoles (CoreDataProperties)

+ (NSFetchRequest<CMOUserRoles *> *)fetchRequest;

@property (nonatomic) int16_t roleId;
@property (nullable, nonatomic, copy) NSString *roleName;
@property (nullable, nonatomic, retain) CMORoster *users;

@end

NS_ASSUME_NONNULL_END
