//
//  CMOAdmins+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 11/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOAdmins+CoreDataProperties.h"

@implementation CMOAdmins (CoreDataProperties)

+ (NSFetchRequest<CMOAdmins *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMOAdmins"];
}

@dynamic admins;
@dynamic roomInfo;

@end
