//
//  CMOUser.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <JSONModel/JSONModel.h>

@protocol CMOUser <NSObject>
@end

// Note: Please don't change the key. It should match the JSON Response.

@interface Users : JSONModel
@property (nonatomic, strong)NSArray<CMOUser> *user;
@end

// Note: Please don't change the key. It should match the JSON Response.

@interface CMOUser : JSONModel

@property (nonatomic, strong)NSString *username;
@property (nonatomic, strong)NSString *name;
@property (nonatomic, strong)NSString<Optional> *nickname;
@property (nonatomic, strong)NSString<Optional> *email;
@property (nonatomic, strong)UIImage<Optional> *userAvatar;
@property (nonatomic, strong)NSString<Optional> *orgTitle;
@property (nonatomic, strong)NSString<Optional> *orgRole;
@property (nonatomic, strong)NSString<Optional> *orgName;
@property (nonatomic, strong)NSString<Optional> *phoneNumber;
@property (nonatomic, strong)NSString<Optional> *street;
@property (nonatomic, strong)NSDictionary<Optional> *properties;

@end
