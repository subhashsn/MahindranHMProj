//
//  CMOGroup.h
//  CMOChat
//
//  Created by Administrator on 11/30/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <JSONModel/JSONModel.h>

@interface CMOGroup : JSONModel

@property (nonatomic, strong)NSString *username;
@property (nonatomic, strong)NSString *name;
@property (nonatomic, strong)NSString *grpDescription;
@property (nonatomic, strong)NSString<Optional> *nickname;
@property (nonatomic, strong)NSString<Optional> *email;
@property (nonatomic, strong)UIImage<Optional> *userAvatar;
@property (nonatomic, strong)NSString<Optional> *orgTitle;
@property (nonatomic, strong)NSString<Optional> *orgRole;
@property (nonatomic, strong)NSString<Optional> *orgName;
@property (nonatomic, strong)NSDictionary<Optional> *properties;

@end
