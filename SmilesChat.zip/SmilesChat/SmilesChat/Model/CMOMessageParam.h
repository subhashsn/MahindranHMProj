//
//  CMOMessageParam.h
//  CMOChat
//
//  Created by Administrator on 4/5/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CMOMessageParam : NSObject


@property (nonatomic, strong)NSString *body;
@property (nonatomic, strong)NSString *roomSubject;
@property (nonatomic, strong)NSString *senderId;
@property (nonatomic, strong)NSString *senderDisplayName;
@property (nonatomic, strong)NSString *roomId;
@property (nonatomic, strong)NSDate *date;
@property (nonatomic, strong)NSString *uuid;
@property (nonatomic, strong)id media;
@property (nonatomic, strong)NSString *mediaName;
@property (nonatomic, strong)NSString *fileName;
@property (nonatomic, strong)NSString *messageDateString;
@property (nonatomic, assign)BOOL isMedia;
@property (nonatomic, assign)NSInteger slaTime;
@property (nonatomic, assign)BOOL isConfidential;
@property (nonatomic) DocumentType documentType;
@property (nonatomic, assign)BOOL show; //For Hide/UnHide Message
@property (nonatomic, assign)MessageDeliveryStatus status;
@property (nonatomic, strong)NSString *smsUsers;
@property (nonatomic, strong)NSString *messageId;
@property (nonatomic, assign)BOOL upload;
@property (nonatomic, assign)BOOL smsSent;
@property (nonatomic, assign)BOOL isFirstMessage; //First successful message

@end
/*
 message.localTimeStamp = msg.localTimestamp;
 message.remoteTimeStamp = msg.remoteTimestamp;

*/
