//
//  CMORoomInfo.h
//  CMOChat
//
//  Created by Administrator on 10/30/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <JSONModel/JSONModel.h>


@interface Owners : JSONModel
/**
 * Prpoperty name: owner
 * Description: The value may be string or array depending on number of objects. So be careful while parsing.
 */

@property (nonatomic, strong)id <Optional> owner; //Value can be string or array;
@end

@interface Admins : JSONModel
@property (nonatomic, strong)id <Optional> admin; //Value can be string or array;
@end

@interface Members : JSONModel
@property (nonatomic, strong)id <Optional> member; //Value can be string or array;
@end

@interface CMORoomInfo : JSONModel

@property (nonatomic, strong)NSString *roomName;
@property (nonatomic, strong)NSString<Optional> *naturalName;
@property (nonatomic, strong)NSString<Optional> *roomDesc;
@property (nonatomic, strong)NSString<Optional> *subject;
@property (nonatomic, strong)NSString *creationDate;
@property (nonatomic, strong)NSString *modificationDate;
@property (nonatomic, strong)NSString *maxUsers;
@property (nonatomic, strong)NSString *persistent;
@property (nonatomic, strong)NSString *publicRoom;
@property (nonatomic, strong)NSString *registrationEnabled;
@property (nonatomic, strong)NSString *canAnyoneDiscoverJID;
@property (nonatomic, strong)NSString *canOccupantsChangeSubject;
@property (nonatomic, strong)NSString *canOccupantsInvite;
@property (nonatomic, strong)NSString *canChangeNickname;
@property (nonatomic, strong)NSString *logEnabled;
@property (nonatomic, strong)NSString *loginRestrictedToNickname;
@property (nonatomic, strong)NSString *membersOnly;
@property (nonatomic, strong)NSString *moderated;
@property (nonatomic, strong)NSDictionary<Optional> *outcasts;
@property (nonatomic, strong)NSDictionary<Optional> *ownerGroups;
@property (nonatomic, strong)NSDictionary<Optional> *adminGroups;
@property (nonatomic, strong)NSDictionary<Optional> *memberGroups;
@property (nonatomic, strong)NSDictionary<Optional> *outcastGroups;
@property (nonatomic, strong)NSDictionary<Optional> *broadcastPresenceRoles;
@property (nonatomic, strong)Owners<Optional> *owners;
@property (nonatomic, strong)Admins<Optional> *admins;
@property (nonatomic, strong)Members<Optional> *members;

@end

