//
//  CMOBroadcastPresenceRoles+CoreDataClass.m
//  CMOChat
//
//  Created by Administrator on 11/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOBroadcastPresenceRoles+CoreDataClass.h"
#import "CMORoomDetails+CoreDataProperties.h"
@implementation CMOBroadcastPresenceRoles

@end
