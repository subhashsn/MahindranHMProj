//
//  CMOUserRoles+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 11/28/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOUserRoles+CoreDataProperties.h"

@implementation CMOUserRoles (CoreDataProperties)

+ (NSFetchRequest<CMOUserRoles *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMOUserRoles"];
}

@dynamic roleId;
@dynamic roleName;
@dynamic users;

@end
