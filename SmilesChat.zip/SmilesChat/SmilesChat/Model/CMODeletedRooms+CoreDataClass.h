//
//  CMODeletedRooms+CoreDataClass.h
//  CMOChat
//
//  Created by Administrator on 3/16/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface CMODeletedRooms : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "CMODeletedRooms+CoreDataProperties.h"
