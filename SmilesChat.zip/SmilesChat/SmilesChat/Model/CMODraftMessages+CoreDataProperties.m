//
//  CMODraftMessages+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 11/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMODraftMessages+CoreDataProperties.h"

@implementation CMODraftMessages (CoreDataProperties)

+ (NSFetchRequest<CMODraftMessages *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMODraftMessages"];
}

@dynamic body;
@dynamic roomName;

@end
