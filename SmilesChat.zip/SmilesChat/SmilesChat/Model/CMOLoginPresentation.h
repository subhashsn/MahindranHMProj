//
//  CMOLoginPresentation.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CMOUser.h"

@class CMOCoreComponents;
@class CMOVersionInfo;

@interface CMOLoginPresentation : NSObject

@property (nonatomic, strong)NSString *userName;
/**
 *  Active directory client id. Your app should register with Active directory and get the client id in order to fetch the user information
 */
@property (nonatomic, strong)NSString *clientId;

@property (strong, nonatomic) CMOCoreComponents *coreComponents;

- (instancetype)initWithUser:(NSString *)userName clientId:(NSString *)clientId;

- (void)connect:(CMOUser *)user andPassword:(NSString *)password completionHandler:(void (^)(id success, NSError *error))handler;

- (BOOL)disconnect;

- (void)updateAppVersionWithUser:(NSString *)userName  onSuccess:(void (^)(CMOVersionInfo *versioninfo))success onFailure:(void (^)(NSError *error))failur;

@end
