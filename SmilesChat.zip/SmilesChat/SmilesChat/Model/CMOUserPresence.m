//
//  CMOUserPresence.m
//  CMOChat
//
//  Created by Administrator on 11/9/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOUserPresence.h"

@implementation CMOVCard



@end

@implementation CMOOccupant



@end


@implementation CMOUserPresence

@end
