//
//  CMOMembers+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 11/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOMembers+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOMembers (CoreDataProperties)

+ (NSFetchRequest<CMOMembers *> *)fetchRequest;

@property (nullable, nonatomic, retain) NSObject *members;
@property (nullable, nonatomic, retain) CMORoomDetails *roomInfo;

@end

NS_ASSUME_NONNULL_END
