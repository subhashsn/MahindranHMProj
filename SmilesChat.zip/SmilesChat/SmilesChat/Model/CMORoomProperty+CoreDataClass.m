//
//  CMORoomProperty+CoreDataClass.m
//  CMOChat
//
//  Created by Administrator on 2/10/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMORoomProperty+CoreDataClass.h"

@implementation CMORoomProperty

@end
