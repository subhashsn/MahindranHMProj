//
//  CMODeletedRooms+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 3/16/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "CMODeletedRooms+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMODeletedRooms (CoreDataProperties)

+ (NSFetchRequest<CMODeletedRooms *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *roomName;

@end

NS_ASSUME_NONNULL_END
