//
//  CMORosterGroup+CoreDataProperties.h
//  CMOChat
//
//  Created by Amit Kumar on 10/12/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMORosterGroup+CoreDataClass.h"
#import "CMOGroupMembers+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMORosterGroup (CoreDataProperties)

+ (NSFetchRequest<CMORosterGroup *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *grpDescription;
@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, retain) CMOGroupMembers *grpMembers;

@end

NS_ASSUME_NONNULL_END
