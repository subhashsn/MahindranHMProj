//
//  CMOOwnersGroup+CoreDataClass.h
//  CMOChat
//
//  Created by Administrator on 12/7/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class CMORoomDetails, NSObject;

NS_ASSUME_NONNULL_BEGIN

@interface CMOOwnersGroup : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "CMOOwnersGroup+CoreDataProperties.h"
