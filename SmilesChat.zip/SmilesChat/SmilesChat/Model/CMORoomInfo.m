//
//  CMORoomInfo.m
//  CMOChat
//
//  Created by Administrator on 10/30/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMORoomInfo.h"




@implementation Members

+(JSONKeyMapper*)keyMapper
{
    
    return [[JSONKeyMapper alloc]initWithModelToJSONDictionary:@{
                                                                 @"member": @"member",
                                                                 }];
}

@end

@implementation Admins


+(JSONKeyMapper*)keyMapper
{
    
    return [[JSONKeyMapper alloc]initWithModelToJSONDictionary:@{
                                                                 @"admin": @"admin",
                                                                 }];
}

@end

@implementation Owners
+(JSONKeyMapper*)keyMapper
{
    
    return [[JSONKeyMapper alloc]initWithModelToJSONDictionary:@{
                                                                 @"owner": @"owner",
                                                                 }];
}


@end

@implementation CMORoomInfo


+(JSONKeyMapper*)keyMapper
{
    
    return [[JSONKeyMapper alloc]initWithModelToJSONDictionary:@{
                                                                 @"roomDesc": @"description",
                                                                 
                                                                 }];
    
}

@end
