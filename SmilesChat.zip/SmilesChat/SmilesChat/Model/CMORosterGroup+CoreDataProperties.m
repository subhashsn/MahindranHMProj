//
//  CMORosterGroup+CoreDataProperties.m
//  CMOChat
//
//  Created by Amit Kumar on 10/12/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMORosterGroup+CoreDataProperties.h"

@implementation CMORosterGroup (CoreDataProperties)

+ (NSFetchRequest<CMORosterGroup *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMORosterGroup"];
}

@dynamic grpDescription;
@dynamic name;
@dynamic grpMembers;

@end
