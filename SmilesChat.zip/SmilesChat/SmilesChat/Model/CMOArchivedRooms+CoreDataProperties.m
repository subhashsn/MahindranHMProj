//
//  CMOArchivedRooms+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOArchivedRooms+CoreDataProperties.h"

@implementation CMOArchivedRooms (CoreDataProperties)

+ (NSFetchRequest<CMOArchivedRooms *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMOArchivedRooms"];
}

@dynamic messageCount;
@dynamic roomName;

@end
