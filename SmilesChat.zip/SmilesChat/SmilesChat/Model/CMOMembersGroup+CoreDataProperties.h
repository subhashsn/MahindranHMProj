//
//  CMOMembersGroup+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 12/7/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOMembersGroup+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOMembersGroup (CoreDataProperties)

+ (NSFetchRequest<CMOMembersGroup *> *)fetchRequest;

@property (nullable, nonatomic, retain) NSObject *memberGroup;
@property (nullable, nonatomic, retain) CMORoomDetails *roomInfo;

@end

NS_ASSUME_NONNULL_END
