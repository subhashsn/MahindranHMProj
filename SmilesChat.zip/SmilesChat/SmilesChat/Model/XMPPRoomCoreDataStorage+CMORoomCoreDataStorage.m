//
//  XMPPRoomCoreDataStorage+CMORoomCoreDataStorage.m
//  CMOChat
//
//  Created by Administrator on 11/26/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "XMPPRoomCoreDataStorage+CMORoomCoreDataStorage.h"
#import "CMOChatService.h"
#import "CMOMessage.h"

@implementation XMPPRoomCoreDataStorage (CMORoomCoreDataStorage)


- (void)didInsertMessage:(XMPPRoomMessageCoreDataStorageObject *)message
{
    
   // ////DDLogInfo(@"Message DID inserted");
    // Override me if you're extending the XMPPRoomMessageCoreDataStorageObject class to add additional properties.
    // You can update your additional properties here.
    //
    // At this point the standard properties have already been set.
    // So you can, for example, access the XMPPMessage via message.message.
    //XMPPMessage *xmppMessage = message.message;
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter]postNotificationName:DID_RECEIVED_MESSAGE_NOTIFICATION object:nil userInfo:@{@"message":message}];
    });
}


- (void)didInsertOccupant:(XMPPRoomOccupantCoreDataStorageObject *)occupant
{
    // Override me if you're extending the XMPPRoomOccupantCoreDataStorageObject class to add additional properties.
    // You can update your additional properties here.
    //
    // At this point the standard XMPPRoomOccupantCDSO properties have already been set.
    // So you can, for example, access the XMPPPresence via occupant.presence.
}

/**
 * Optional override hook for general extensions.
 *
 * @see updateOccupant:withPresence:room:stream:
 **/
- (void)didUpdateOccupant:(XMPPRoomOccupantCoreDataStorageObject *)occupant
{
    // Override me if you're extending the XMPPRoomOccupantCoreDataStorageObject class to add additional properties.
    // You can update your additional properties here.
    //
    // At this point the standard XMPPRoomOccupantCDSO properties have already been updated.
    // So you can, for example, access the XMPPPresence via occupant.presence.
}



@end
