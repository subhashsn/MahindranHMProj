//
//  CMODeletedRooms+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 3/16/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "CMODeletedRooms+CoreDataProperties.h"

@implementation CMODeletedRooms (CoreDataProperties)

+ (NSFetchRequest<CMODeletedRooms *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMODeletedRooms"];
}

@dynamic roomName;

@end
