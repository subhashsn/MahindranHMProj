//
//  CMORoster+CoreDataClass.m
//  CMOChat
//
//  Created by Administrator on 11/19/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMORoster+CoreDataClass.h"

@implementation CMORoster

@end
