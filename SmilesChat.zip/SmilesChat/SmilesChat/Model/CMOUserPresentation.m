//
//  CMOUserPresentation.m
//  CMOChat
//
//  Created by Administrator on 11/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOUserPresentation.h"
#import "CMOUser.h"
#import "CMOUtils.h"

@implementation CMOUserPresentation


- (CMOUser *)user{
    return [_userClient user];
}

- (void)saveUser:(CMOUser *)user{
    [_userClient saveUser:user];
}
- (void)setUserInformation:(CMOUser *)user{
    [_userClient updateUserInformation:user];
}

- (CMOUser *)fetchUservCardInformation:(NSString *)username{
    return [_userClient fetchUservCard:username];
}

- (void)updateLogsToServer{
    NSDate *serverTime = [CMOUtils toDate:[CMOUtils getServerTime]];
    NSDate *lastUploadTime = [CMOUtils getLogUploadTime];
    
    BOOL uploadLog = NO;
    if (!lastUploadTime) {
        uploadLog = YES;
    } else {
        NSTimeInterval diff = [serverTime timeIntervalSinceDate:lastUploadTime]/(60*60); //In hours
        if (diff > 20) { //If time difference is more than 20 hours then sync it to server.
            uploadLog = YES;
        }
    }
    if (uploadLog){
        [_userClient uploadLogFileonSuccess:^(id result) {
            //DDLogInfo(@"Logs Update Success");
            [CMOUtils saveLogUploadTime:serverTime];
        } onFailure:^(NSError *error) {
            //DDLogInfo(@"Logs Update failed");
        }];
    }
}



@end
