//
//  CMOGroupMembers+CoreDataProperties.m
//  CMOChat
//
//  Created by Amit Kumar on 10/12/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOGroupMembers+CoreDataProperties.h"

@implementation CMOGroupMembers (CoreDataProperties)

+ (NSFetchRequest<CMOGroupMembers *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMOGroupMembers"];
}

@dynamic members;
@dynamic rosterGroup;

@end
