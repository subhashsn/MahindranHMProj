//
//  CMORoster+CoreDataProperties.m
//  CMOChat
//
//  Created by Amit Kumar on 12/05/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMORoster+CoreDataProperties.h"

@implementation CMORoster (CoreDataProperties)

+ (NSFetchRequest<CMORoster *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMORoster"];
}

@dynamic companyName;
@dynamic email;
@dynamic exchangeID;
@dynamic isFromExchange;
@dynamic isPhoneContact;
@dynamic isSMSUser;
@dynamic name;
@dynamic phoneNumber;
@dynamic properties;
@dynamic subscription;
@dynamic username;
@dynamic nicname;
@dynamic userType;
@dynamic smsGroupType;
@dynamic userPermission;
@dynamic userRoles;

@end
