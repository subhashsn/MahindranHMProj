//
//  CMOMessageCount.m
//  CMOChat
//
//  Created by Administrator on 1/15/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMOMessageCount.h"

@implementation CMOUserMessageCount

@end

@implementation CMOMessageCount

@end
