//
//  CMORoomDetails+CoreDataProperties.m
//  CMOChat
//
//  Created by Amit Kumar on 13/04/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMORoomDetails+CoreDataProperties.h"

@implementation CMORoomDetails (CoreDataProperties)

+ (NSFetchRequest<CMORoomDetails *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMORoomDetails"];
}

//@dynamic archived;
@dynamic canAnyoneDiscoverJID;
@dynamic canChangeNickname;
@dynamic canOccupantsChangeSubject;
@dynamic canOccupantsInvite;
//@dynamic confidential;
@dynamic creationDate;
//@dynamic deleted;
//@dynamic isJoined;
//@dynamic isRoomDeleted;
//@dynamic lastMsgDate;
@dynamic logEnabled;
@dynamic loginRestrictedToNickname;
@dynamic maxUsers;
@dynamic membersOnly;
@dynamic moderated;
@dynamic modificationDate;
@dynamic naturalName;
@dynamic persistent;
@dynamic publicRoom;
//@dynamic readMessageCount;
@dynamic registrationEnabled;
@dynamic roomDescription;
@dynamic roomName;
@dynamic roomSubject;
//@dynamic slaClosed;
//@dynamic slaEnabled;
//@dynamic slaRemainingTime;
//@dynamic slaTime;
//@dynamic totalMessageCount;
@dynamic roomOwner;
@dynamic admins;
@dynamic broadcastPresence;
@dynamic members;
@dynamic membersGroup;
@dynamic outcastsGroup;
@dynamic owners;
@dynamic ownersGroup;
@dynamic roomProperty;

@end
