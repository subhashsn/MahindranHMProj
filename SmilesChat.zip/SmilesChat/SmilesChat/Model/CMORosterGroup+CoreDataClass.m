//
//  CMORosterGroup+CoreDataClass.m
//  CMOChat
//
//  Created by Amit Kumar on 28/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMORosterGroup+CoreDataClass.h"

@implementation CMORosterGroup

@end
