//
//  CMOMessageReadStatus+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 12/27/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOMessageReadStatus+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOMessageReadStatus (CoreDataProperties)

+ (NSFetchRequest<CMOMessageReadStatus *> *)fetchRequest;

@property (nonatomic) BOOL didReadMessage;
@property (nullable, nonatomic, copy) NSString *roomId;
@property (nonatomic) int32_t unReadCount;
@end

NS_ASSUME_NONNULL_END
