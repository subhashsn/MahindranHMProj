//
//  CMOAdminsGroup+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 12/7/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOAdminsGroup+CoreDataProperties.h"

@implementation CMOAdminsGroup (CoreDataProperties)

+ (NSFetchRequest<CMOAdminsGroup *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMOAdminsGroup"];
}


@end
