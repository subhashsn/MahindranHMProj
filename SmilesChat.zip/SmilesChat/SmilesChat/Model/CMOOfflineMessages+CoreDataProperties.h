//
//  CMOOfflineMessages+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 11/12/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOOfflineMessages+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOOfflineMessages (CoreDataProperties)

+ (NSFetchRequest<CMOOfflineMessages *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *body;
@property (nullable, nonatomic, copy) NSString *elementId;
@property (nullable, nonatomic, copy) NSString *smsUsers;
@property (nullable, nonatomic, copy) NSNumber *fromMe;
@property (nullable, nonatomic, copy) NSDate *messageDate;
@property (nullable, nonatomic, copy) NSString *messageDateString;
@property (nullable, nonatomic, copy) NSString *messageId;
@property (nullable, nonatomic, copy) NSDate *localTimestamp;
@property (nullable, nonatomic, retain) NSObject *message;
@property (nullable, nonatomic, copy) NSString *messageStr;
@property (nullable, nonatomic, copy) NSString *nickname;
@property (nullable, nonatomic, copy) NSDate *remoteTimestamp;
@property (nullable, nonatomic, copy) NSString *roomJIDStr;
@property (nullable, nonatomic, copy) NSString *sender;
@property (nullable, nonatomic, copy) NSString *senderjidStr;
@property (nullable, nonatomic, copy) NSString *streamBareJidStr;
@property (nullable, nonatomic, copy) NSString *fileName;
@property (nullable, nonatomic, copy) NSNumber *status;
@property (nonatomic, assign)BOOL slaFlag;
@property (nonatomic, assign)int16_t slaTime;
@property (nonatomic, assign)BOOL isConfidential;
@property (nonatomic, assign)BOOL show; //For Hide/Show
@property (nonatomic) BOOL upload;
@property (nonatomic) BOOL isOffline;
@property (nullable, nonatomic, copy) NSString *roomID;
@property (nonatomic) BOOL isMediaMessage;

@end

NS_ASSUME_NONNULL_END
