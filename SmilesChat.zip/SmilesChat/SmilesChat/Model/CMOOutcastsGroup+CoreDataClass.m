//
//  CMOOutcastsGroup+CoreDataClass.m
//  CMOChat
//
//  Created by Administrator on 12/7/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOOutcastsGroup+CoreDataClass.h"
#import "CMORoomDetails+CoreDataClass.h"
@implementation CMOOutcastsGroup

@end
