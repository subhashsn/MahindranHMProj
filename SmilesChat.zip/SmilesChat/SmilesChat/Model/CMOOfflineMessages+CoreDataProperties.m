//
//  CMOOfflineMessages+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 11/12/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOOfflineMessages+CoreDataProperties.h"

@implementation CMOOfflineMessages (CoreDataProperties)

+ (NSFetchRequest<CMOOfflineMessages *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMOOfflineMessages"];
}

@dynamic body;
@dynamic elementId;
@dynamic smsUsers;
@dynamic fromMe;
@dynamic localTimestamp;
@dynamic message;
@dynamic messageStr;
@dynamic nickname;
@dynamic messageDate;
@dynamic messageDateString;
@dynamic remoteTimestamp;
@dynamic roomJIDStr;
@dynamic sender;
@dynamic senderjidStr;
@dynamic streamBareJidStr;
@dynamic upload;
@dynamic roomID;
@dynamic status;
@dynamic isOffline;
@dynamic fileName;
@dynamic isMediaMessage;
@dynamic slaFlag;
@dynamic show;
@dynamic slaTime;
@dynamic isConfidential;
@end
