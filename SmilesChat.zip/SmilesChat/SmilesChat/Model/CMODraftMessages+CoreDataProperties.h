//
//  CMODraftMessages+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 11/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMODraftMessages+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMODraftMessages (CoreDataProperties)

+ (NSFetchRequest<CMODraftMessages *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *body;
@property (nullable, nonatomic, copy) NSString *roomName;

@end

NS_ASSUME_NONNULL_END
