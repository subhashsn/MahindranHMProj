//
//  CMOVisitedRooms+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 3/16/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "CMOVisitedRooms+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOVisitedRooms (CoreDataProperties)

+ (NSFetchRequest<CMOVisitedRooms *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *roomName;
@property (nonatomic) int32_t readCount;

@end

NS_ASSUME_NONNULL_END
