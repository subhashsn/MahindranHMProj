//
//  CMOUserPresentation.h
//  CMOChat
//
//  Created by Administrator on 11/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CMOUserClient.h"

@class CMOUser;

@interface CMOUserPresentation : NSObject

@property (nonatomic,strong)id<CMOUserClient> userClient;


- (CMOUser *)user;

- (void)saveUser:(CMOUser *)user;

- (void)setUserInformation:(CMOUser *)user;

- (CMOUser *)fetchUservCardInformation:(NSString *)username;

- (void)updateLogsToServer;

@end
