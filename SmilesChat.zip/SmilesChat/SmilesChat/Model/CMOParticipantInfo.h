//
//  CMOParticipantInfo.h
//  CMOChat
//
//  Created by Administrator on 10/30/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CMOParticipantInfo : NSObject

@property (nonatomic, strong)NSString *jid;
@property (nonatomic, strong)NSString *participantName;
@property (nonatomic, strong)NSString *partcipantDesc;
@property (nonatomic) BOOL isGroup;
@end
