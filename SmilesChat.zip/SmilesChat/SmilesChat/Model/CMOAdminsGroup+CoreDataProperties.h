//
//  CMOAdminsGroup+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 12/7/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOAdminsGroup+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOAdminsGroup (CoreDataProperties)

+ (NSFetchRequest<CMOAdminsGroup *> *)fetchRequest;


@end

NS_ASSUME_NONNULL_END
