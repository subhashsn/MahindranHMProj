//
//  CMOGroupMembers+CoreDataClass.m
//  CMOChat
//
//  Created by Amit Kumar on 10/12/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOGroupMembers+CoreDataClass.h"
//#import "CMORosterGroup.h"
@implementation CMOGroupMembers

@end
