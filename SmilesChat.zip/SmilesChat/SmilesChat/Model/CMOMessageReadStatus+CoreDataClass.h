//
//  CMOMessageReadStatus+CoreDataClass.h
//  CMOChat
//
//  Created by Administrator on 12/27/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface CMOMessageReadStatus : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "CMOMessageReadStatus+CoreDataProperties.h"
