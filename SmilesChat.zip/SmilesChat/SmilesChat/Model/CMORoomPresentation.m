//
//  CMORoomPresentation.m
//  CMOChat
//
//  Created by Administrator on 4/5/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMORoomPresentation.h"
#import "CMORoomInfo.h"
#import "CMOUserService.h"
#import "CMOCoreComponents.h"
#import "CMOUser.h"
#import "CMORoster+CoreDataProperties.h"
#import "CMOMessageParam.h"
#import "CMOUtils.h"
#import "CMOChatPresentation.h"
#import "CMORoomDetails+CoreDataProperties.h"
#import "CMORosterGroup+CoreDataProperties.h"

#define MAX_ALLOWED_CHARS 50
#define MAX_ALLOWED_CHARS_ROOM_SUBJECT 150
#define MAX_ALLOWED_CHARS_TEXT_MESSAGE 3000


@implementation CMORoomPresentation



- (void)createRoomWithMessage:(CMOMessage *)message
                 participants:(NSMutableDictionary *)roomParticipants
                    onSuccess:(void (^)(id result, CMOMessage *message))success
                    onFailure:(void (^)(NSError *error))failure{

    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    CMOUser *appUser = [[_coreComponents userService]user];
    NSString *roomSubject = [message.messageBody.mediaItem integerValue] ? @"Document" : message.messageBody.body;
    roomSubject = [message.messageBody.mediaType integerValue] ? @"Document" : message.messageBody.body;
    
    CMORoomInfo *roomInfo = [[CMORoomInfo alloc]init];
    NSString *subject = (roomSubject.length > MAX_ALLOWED_CHARS_ROOM_SUBJECT)?[roomSubject substringToIndex:MAX_ALLOWED_CHARS_ROOM_SUBJECT-1]:roomSubject;
    roomInfo.subject = subject;
    roomInfo.roomName = message.roomIDStr;
    roomInfo.naturalName = message.roomIDStr;
    roomInfo.roomDesc = subject;
    roomInfo.membersOnly = @"true";
    roomInfo.publicRoom = @"true";
    //roomInfo.maxUsers = 0;
    roomInfo.persistent = @"true";
    roomInfo.membersOnly = @"true";
    roomInfo.logEnabled = @"true";
    roomInfo.canOccupantsInvite = @"true";
    //roomInfo.canAnyoneDiscoverJID = @"false";
    
    //CMOGroupName
    Owners *roomOwner = [[Owners alloc]init];
    NSString *owner = [NSString stringWithFormat:@"%@@%@",appUser.username,[CMOUtils domainName]];
    roomOwner.owner = owner;//[NSDictionary dictionaryWithObjectsAndKeys:owner,@"owners", nil]; // Add user jid
    roomInfo.owners = roomOwner;
    
    id<CMORoomClient> roomClient = [_coreComponents roomService];
    
    Members *members = [[Members alloc]init];
    NSMutableArray *array = [self userNameList:roomParticipants];
    if (array.count > 0){
        members.member = array;
    }
    
    roomInfo.members = members;
    id<CMORoomBuilderDelegate>roomBuilder = [_coreComponents roomBuilder:roomInfo];
    NSDictionary *roomParams = [roomBuilder build];
    //Check this for group members
    [self saveRoomLocal:roomParams offline:true];
    id <CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    [repoClient updateSLATime:[message.messageBody.slaTime integerValue] confidential:[message.messageBody.isConfidential boolValue] roomId:message.roomIDStr];
    
    
    // Save Selected Groups & CMO Group if non-confidential to `CMORoomProperty` field (new field has to be created). When Add group members API is success, then update the `CMORoomDetails` with the group members & remove the group members in `CMORoomProperty` table.
    
    NSMutableArray *groups = [[NSMutableArray alloc]init];
    if (![message.messageBody.isConfidential boolValue]){
        [groups addObject:CMOGroupName];
    }
    NSMutableArray *groupParticipants = [roomParticipants objectForKey:MACROS_GROUPS];
    if (groupParticipants.count > 0){
        for (CMORosterGroup *rosterGroup in groupParticipants){
            [groups addObject:rosterGroup.name];
            //[groups addObjectsFromArray:groupParticipants];
        }
    }
    
    //Groups should be added offline before calling create room api.
    if (groups.count > 0){
        ////DDLogInfo(@"%@ %@ 2 %@",THIS_METHOD,THIS_FILE,groups);
        [self saveTempGroupsToChatRoom:groups roomId:message.roomIDStr];
    }
    
    //SMS can be send before creating a room. So it is better to save the sms users in the room table. So that user can search for participants based on the SMS sent status.
    if ([message.messageBody.smsUsers length] > 0){
        ////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
        [self saveSmsusersToChatRoom:message.messageBody.smsUsers roomId:message.roomIDStr];
    }
    
    //Whenever room is created, the first message will be saved offline.
    CMOChatPresentation *chatModel = [_coreComponents chatPresentation];
    [chatModel saveMessageOffline:message];
    
    //Save document if the message is media.
    if (message.isMediaMessage){
        ////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
        id document = [chatModel mediaItemFromMessage:message];
        [chatModel saveDocument:message.messageBody.body docData:document roomID:message.roomIDStr];
    
    }
    ////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
    [roomClient createRoom:roomParams onSuccess:^(id result) {
        ////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
        [self saveRoomLocal:roomParams offline:false];
        if (groups && groups.count > 0){
            ////DDLogInfo(@"%@ %@ 7",THIS_METHOD,THIS_FILE);
            [self addGroups:groups toChatRoom:message.roomIDStr onSuccess:^(id response) {
                ////DDLogInfo(@"%@ %@ 8",THIS_METHOD,THIS_FILE);
               // ////DDLogInfo(@"Groups added to chatroom");
            } onFailure:^(NSError *error) {
                ////DDLogInfo(@"%@ %@ 9",THIS_METHOD,THIS_FILE);
                //DDLogError(@"Add Groups to Chatroom - Failed");
            }];
        }
        success(result,message);
    } onFailure:^(NSError *error) {
        ////DDLogInfo(@"%@ %@ %@ 10",THIS_METHOD,THIS_FILE,error);
        message.status = MessageDeliveryFailed;
        [chatModel saveMessageOffline:message];
        failure(error);
    }];
    ////DDLogInfo(@"%@ %@ 99",THIS_METHOD,THIS_FILE);
}


- (void)getAllRooms:(NSString *)user
          onSuccess:(void (^)(id result))success
          onFailure:(void (^)(NSError *error))failure{
    id<CMORoomClient> roomClient = [_coreComponents roomService];
    [roomClient getAllRooms:user onSuccess:^(id result) {
        success(result);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
}


- (void)inviteUsersToJoinTheRoom:(id)user forRoom:(NSString *)roomName withAffiliation:(Affiliation)affiliation{
    id<CMORoomClient> roomClient = [_coreComponents roomService];
    [roomClient inviteUsersToJoinTheRoom:user forRoom:roomName withAffiliation:affiliation];
}

- (void)joinToRoom:(CMORoomDetails *)roomId
           history:(NSDate *)date
         onSuccess:(void (^)(BOOL result))success
         onFailure:(void (^)(NSError *error))failure{
    [[_coreComponents roomService]joinToRoom:roomId history:date onSuccess:^(BOOL result) {
        success(result);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
}


- (void)addGroups:(NSMutableArray *)groups
       toChatRoom:(NSString *)roomId
        onSuccess:(void (^)(id response))success
        onFailure:(void (^)(NSError *error))failure{
    
    //__weak typeof(self) weakSelf = self;
    //id <CMORepositoryClient>client = [_coreComponents repositoryService];

    id<CMORoomClient> roomClient = [_coreComponents roomService];
    [roomClient addGroups:groups toChatRoom:roomId onSuccess:^(id response) {
        //DDLogInfo(@"Add Group to chatroom sucess");
        /*for (NSString *groupId in groups){
            NSArray *members = [client fetchMembersForGroup:groupId];
            NSMutableArray *membersList = [[NSMutableArray alloc]init];
            for (NSString *member in members){
                [membersList addObject:[NSString stringWithFormat:@"%@@%@",member,[CMOUtils domainName]]];
            }
            [self inviteUsersToJoinTheRoom:membersList forRoom:roomId withAffiliation:AffiliationNone];
        }*/
        
        success(response);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
}


- (void)saveRoomLocal:(NSDictionary *)params offline:(BOOL)isOffline{
    id<CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    [repoClient saveRoomInfo:params offline:isOffline];
    
}

- (void)updateTotalMessageCount:(int64_t)count ofRoom:(NSString *)roomId{
    id<CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    [repoClient updateTotalMessageCount:count ofRoom:roomId];
}

- (void)updateRoomInfo:(NSString *)roomId withLastMessageDate:(NSDate *)date{
     id<CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    [repoClient updateRoomInfo:roomId withLastMessageDate:date];
}

- (void)saveTempGroupsToChatRoom:(NSMutableArray *)groups roomId:(NSString *)roomId{
    if (groups && groups.count > 0){
        id<CMORepositoryClient>repoClient = [_coreComponents repositoryService];
        [repoClient saveTempGroupsToRoomProperty:groups roomId:roomId];
    }
}



- (void)inviteUsersToJoinTheRoom:(NSString *)roomId users:(id)user withAffiliation:(Affiliation)affiliation{
    id <CMORoomClient>roomClient = [_coreComponents roomService];
    [roomClient inviteUsersToJoinTheRoom:user forRoom:roomId withAffiliation:affiliation];
}

- (CMORoomDetails *)retreiveChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure{
    id<CMORoomClient> roomClient = [_coreComponents roomService];
    CMORoomDetails *roomDetails = [roomClient retreiveChatRoom:roomId onSuccess:^(id result) {
        success(result);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
    return roomDetails;
}

- (void)saveSmsusersToChatRoom:(NSString *)participants roomId:(NSString *)roomId{
    if ([participants length] > 0){
        id <CMORepositoryClient>client = [_coreComponents repositoryService];
        [client saveSmsusersToChatRoom:participants roomId:roomId];
        [CMOUtils saveSMSInfo:participants roomId:roomId];
    }
}


- (BOOL)shouldRoomToBeCreated:(NSString *)roomId{
    BOOL shouldCreate = false;
    id <CMORepositoryClient>client = [_coreComponents repositoryService];
    CMORoomDetails *roomDetails = [client fetchRoomInfo:roomId];
    if (roomDetails && roomDetails.roomProperty.isOffline){
        shouldCreate = true;
    }
    return shouldCreate;
}

- (BOOL)isJoinedInRoom:(NSString *)roomId{
    id<CMORoomClient> roomClient = [_coreComponents roomService];
    return [roomClient isJoinedInRoom:roomId];
}


- (NSString *)smsusersFromParticipants:(NSMutableArray *)participants{
    NSString *smsUsers = @"";
    NSPredicate *ADExchangePredicate = [NSPredicate predicateWithFormat:@"isFromExchange==true OR isSMSUser==true"];
    NSArray *users = [participants filteredArrayUsingPredicate:ADExchangePredicate];
    NSMutableArray *usersNamesList = [NSMutableArray new];
    for (CMORoster *roster in users){
        [usersNamesList addObject:roster.name ? roster.name : roster.username];
    }
    if (usersNamesList.count > 0){
        smsUsers = [usersNamesList componentsJoinedByString:@", "];
    }
    return smsUsers;
}

- (NSMutableArray *)userNameList:(NSMutableDictionary *)users{
    NSMutableArray *userNameArray = [[NSMutableArray alloc]init];
    if (users.allKeys.count > 0){
        for (NSString *key in users.allKeys){
            NSMutableArray *array = [users valueForKey:key];
            if (array){
                for (id roster in array){
                    if ([roster isKindOfClass:[CMORoster class]]){
                        CMORoster *userRoster = (CMORoster *)roster;
                        [userNameArray addObject:[NSString stringWithFormat:@"%@@%@",userRoster.username,[CMOUtils domainName]]];
                    }
                }
            }
        }
    }
    return userNameArray;
}

@end
