//
//  CMOAdmins+CoreDataClass.m
//  CMOChat
//
//  Created by Administrator on 11/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOAdmins+CoreDataClass.h"
#import "CMORoomDetails+CoreDataProperties.h"
@implementation CMOAdmins

@end
