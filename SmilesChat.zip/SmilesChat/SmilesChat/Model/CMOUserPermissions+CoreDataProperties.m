//
//  CMOUserPermissions+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 11/28/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOUserPermissions+CoreDataProperties.h"

@implementation CMOUserPermissions (CoreDataProperties)

+ (NSFetchRequest<CMOUserPermissions *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMOUserPermissions"];
}

@dynamic addRecipientInAnOngoingChat;
@dynamic canBlockAndProvideAccessToUsers;
@dynamic canConfigureReminderTimeAndFrequency;
@dynamic canCreateGroups;
@dynamic canDeleteRecipients;
@dynamic canDeleteUsers;
@dynamic canSetConfidentiality;
@dynamic canSetSlaTime;
@dynamic chatInitiation;
@dynamic conversationHistoryAvailable;
@dynamic permissionId;
@dynamic users;

@end
