//
//  CMOChatPresentation.m
//  CMOChat
//
//  Created by Anish Kumar on 10/24/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOChatPresentation.h"
#import "CMOChatClient.h"
#import "CMOChatService.h"
#import "CMORoomInfo.h"
#import "CMOParticipantInfo.h"
#import "CMORepositoryClient.h"
#import "CMOCoreComponents.h"
#import "CMOUser.h"
#import "CMOOfflineMessages+CoreDataProperties.h"
#import <JSQMessagesViewController/JSQMessages.h>
#import "CMOPhotoMediaItem.h"
#import "CMORoomDetails+CoreDataClass.h"
#import "CMOOwners+CoreDataClass.h"
#import "CMOMembers+CoreDataClass.h"
#import "CMOAdmins+CoreDataClass.h"
#import "CMOArchivedRooms+CoreDataClass.h"
#import "CMODraftMessages+CoreDataClass.h"
#import "CMOMessageReadStatus+CoreDataClass.h"
#import "CMOUtils.h"
#import "CMOVideoMediaItem.h"
#import "CMOMessageCount.h"
#import "CMOAudioMediaItem.h"
#import "CMODocumentItem.h"
#import "CMORoster+CoreDataClass.h"
#import "CMOVisitedRooms+CoreDataClass.h"
#import "CMORosterGroup+CoreDataProperties.h"

#import "CMOMessageParam.h"

@interface CMOChatPresentation() <CMOChatResponseDelegate>{
    
    id<CMOChatClient> chatClient;
}
@end


@implementation CMOChatPresentation

- (instancetype)init
{
    self = [super init];
    if (self) {
//        chatClient = [_coreComponents chatService];
//        chatService = (CMOChatService *)chatClient;
//        chatService.chatResponseDelegate = self;
    }
    return self;
}

- (instancetype)initWithService:(id<CMOChatClient>)service{
    self = [super init];
    if (self) {
        chatClient = service;
        CMOChatService *chatService = (CMOChatService *)service;
        chatService.chatResponseDelegate = self;
    }
    return self;
}

/*- (NSArray *)getMessagesOfCurrentRoom:(id)target{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [self getCMOMessages:[client fetchMessages] delegate:target];//[client fetchMessages];
}*/

- (NSMutableArray *)getMessagesForRoom:(NSString *)roomId delegate:(id)target messagesDict:(NSMutableDictionary *)dict{
    NSMutableArray *allMessages = nil;
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    NSArray *messages = [client fetchMessageForRoom:roomId];
    if (messages.count > 0){
        allMessages = [[NSMutableArray alloc]init];
        for (XMPPRoomMessageCoreDataStorageObject *roomMessage in messages){
            //DDLogError(@"\n\n\n ROOM MESSAGE %@ \n\n\n",roomMessage.message);
            XMPPMessage *xmppRoomMessage = roomMessage.message;
            if (![xmppRoomMessage isErrorMessage]){
                CMOMessageParam *param = [self constructMessageParamFromXMPP:roomMessage];
                ////DDLogError(@"\n\n\n PARAM ID IS %@ \n\n\n",param.senderId);
                if (param){
                    CMOMessage *cmoMessage = [self constructMessage:param target:target messagesDict:dict];
                    [allMessages addObject:cmoMessage];
                }
            }
        }
    }
    return allMessages;
   
}

/*- (NSMutableArray *)getMessagesForRoom:(NSString *)roomId delegate:(id)target{
id<CMORepositoryClient>client = [_coreComponents repositoryService];
 NSArray *cmoMessages = [self getCMOMessages:[client fetchMessageForRoom:roomId] delegate:target];
 return [self sortCMOMessages:cmoMessages ascending:true];
}*/
//New


- (NSArray *)getArchivedRooms {
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [self getArchivedRooms:[client fetchAllArchivedRooms]];
}

- (CMOArchivedRooms *)getArchivedRoom:(NSString *)roomId {
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    CMOArchivedRooms *room = [client fetchArchivedRoom:roomId];
    return room;
}

- (NSArray *)getArchivedRooms:(NSArray *)coreDataRooms {
    NSMutableArray *roomIds = nil;
    if (coreDataRooms.count) {
        roomIds = [[NSMutableArray alloc] init];
    }
    
    for (CMOArchivedRooms *room  in coreDataRooms) {
        [roomIds addObject:[room roomName]];
    }
    
    return roomIds;
}

- (void)markRoomArchived:(NSString*)roomId unreadCount:(NSInteger)msgCount {
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    [client makeRoomArchived:roomId unreadCount:msgCount];
}

- (void)markRoomUnarchived:(NSString*)roomId {
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    [client makeRoomUnarchived:roomId];
}

- (BOOL)isRoomArchived:(NSString*)roomId {
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client isRoomArchived:roomId];
}

- (void)saveVisitedRoom:(NSString *)roomName count:(int32_t)count{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    [client saveVisitedRoom:roomName readCount:count];
    [client saveReadMessageCountToRoom:roomName count:count];
    [CMOUtils saveVisitedRoomInfo:roomName count:count];
}

- (NSInteger)getRoomCountFromVisitedRoom:(NSString *)roomName{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    CMOVisitedRooms *vRoom = [client fetchVisitedRoom:roomName];
    if (vRoom){
        return vRoom.readCount;
    }
    return 0;
}

- (BOOL)isConnectedToXMPP{
    return [chatClient isConnectedToXMPP];
}

- (void)saveRoomMessageHiddenStatus:(NSString *)roomId shouldHide:(BOOL)shouldHide{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    [client saveHideStatusOfRoom:roomId shouldHide:shouldHide];
}

- (BOOL)isRoomMessageHidden:(NSString *)roomId{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client isRoomMessageHidden:roomId];
}

/* To Get the selected index of the room. 
 Retain selected index of room even if objects get sorted. Only for iPad
 */

- (NSInteger)indexOfSelectedRoomList:(NSArray *)roomList name:(NSString *)roomName{
    NSInteger selectedIndex = -1;
    if (roomList.count > 0 && roomName){
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomName == %@",roomName];
        NSArray *roomDetails = [roomList filteredArrayUsingPredicate:predicate];
        CMORoomDetails *roomDetail = roomDetails.count > 0 ? [roomDetails lastObject] : nil;
        if (roomDetail){
            selectedIndex = [roomList indexOfObject:roomDetail];
        }
    }
    return selectedIndex;
}

#pragma mark Document Upload Status

- (void)saveDocumentUploadStatusForRoom:(NSString *)roomId inprogress:(BOOL)status{
     id<CMORepositoryClient>client = [_coreComponents repositoryService];
     [client saveDocumentUploadStatusForRoom:roomId inprogress:status];
}

- (BOOL)documentUploadStatusOfRoom:(NSString *)roomId{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client documentUploadStatusOfRoom:roomId];
}

- (void)updateDocumentUploadStatusOfAllRooms{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    [client updateDocumentUploadStatusOfAllRooms];
}



#pragma mark Adding SMS Users in Body - (i.e) SMS Sent to: ABC, XYZ etc

- (NSString *)getFormattedMessageBody:(CMOMessageBody *)messageBody fromMe:(BOOL)fromMe{
    id <CMOChatClient>client = [_coreComponents chatService];
    return [client getFormattedMessageBody:messageBody fromMe:fromMe];
}


#pragma mark Filter Messages - Based on Role - Only Applicable for Chairman

- (NSArray *)filterMessagesByVisiblity:(BOOL)show message:(NSArray *)messages{
    if (messages.count > 0){
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messageBody.shouldVisible == %@",(show ? @"true" : @"false")];
        NSArray *filteredArray = [messages filteredArrayUsingPredicate:predicate];
        return filteredArray.count > 0 ? filteredArray : nil;
    }
    return nil;
}

//This function will decide whether to display Hide/UnHide option to user. Usually this comes to the user who can initiate the chat. For other users, Summary button will come if this condition fails
- (BOOL)shouldProvideHideShowOption{
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    id <CMORosterClient>rosterClient = [_coreComponents rosterService];
    CMORoster *roster = [rosterClient fetchRoster:owner.username];
    return [roster.userPermission.chatInitiation integerValue] == 1;
}


#pragma mark Sort CMO Message using message body date
//This will be helpful when you fetch the first message to get the SLA Time.
- (NSMutableArray *)sortCMOMessages:(NSArray *)messages ascending:(BOOL)ascending{
    NSSortDescriptor *descriptor = [[NSSortDescriptor alloc] initWithKey:@"messageBody.messageDate" ascending:ascending];
    return [NSMutableArray arrayWithArray:[messages sortedArrayUsingDescriptors:@[descriptor]]];
}

#pragma mark **** SLA Calculation Logic ****
/*- (NSTimeInterval)calculateSLATime:(CMOMessage *)message forRoom:(NSString *)roomId{
    NSTimeInterval mins = [chatClient calculateSLATime:message];
    return mins;
}*/

- (BOOL)isMessageAvailableOtherThanOwnerOfRoom:(NSString *)roomId{
      id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
      return [repositoryClient isMessageAvailableOtherThanOwnerOfRoom:roomId];
}


#pragma mark Room Count

- (NSInteger)getMessageCountForRoom:(NSString *)roomId{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    return [repositoryClient fetchMessageCountForRooms:roomId];
}

- (void)getUnReadMessagesCountOfAllRoomsonSuccess:(void (^)(id result))success
                                        onFailure:(void (^)(NSError *error))failure {
    //getUnReadMessagesCountOfAllRoomsonSuccess
    [chatClient getUnReadMessagesCountOfAllRoomsonSuccess:^(id result) {
       // NSLog(@"Result is %@",result);
        success(result);
    } onFailure:^(NSError *error) {
        //NSLog(@"Error is %@",error);
        failure(error);
    }];
}



- (CMOMessageCount *)getMessageInfoForRoom:(NSString *)roomId messagesInfoArray:(NSArray *)messagesInfo{
    if (messagesInfo.count > 0){
        NSString *roomName = [NSString stringWithFormat:@"%@@%@", roomId,self.conferenceURL];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"room == %@",roomName];
        NSArray *array = [messagesInfo filteredArrayUsingPredicate:predicate];
        return array.count > 0 ? [array lastObject] : nil;
    }
    return nil;
}


- (NSData *)mediaItemFromMessage:(CMOMessage *)message{
    DocumentType docType = [CMOUtils documentType:message.messageBody.body];
    id docData = nil;
    switch (docType) {
        case DocumentTypeImage:
            docData = UIImageJPEGRepresentation(((CMOPhotoMediaItem *)message.media).image, 0);
            break;
        case DocumentTypeAudio:
        case DocumentTypeVideo:
        case DocumentTypeMedia:
            docData = [NSData dataWithContentsOfFile:[self getFilePath:message.messageBody.body roomId:message.roomIDStr]];
            break;
        default:
            break;
    }
    return docData;
}


#pragma mark Prepare CMOMessageParam from CMOOfflineMessages
#warning - IMPORTANT: Validate this function.

- (CMOMessageParam *)constructMessageParamFromOffline:(CMOOfflineMessages *)offlineMessage{
    @autoreleasepool{
        NSString *user = offlineMessage.sender;
        if (!user && [user length] <= 0){
            id <CMOUserClient>userClient = [_coreComponents userService];
            user = [[userClient user]username];
        }
        CMOMessageParam *param = [[CMOMessageParam alloc]init];
        param.body = offlineMessage.body;
        param.senderId = user;
        id <CMORosterClient>rosterClient = [_coreComponents rosterService];
        CMORoster *roster = [rosterClient fetchRoster:user];
        if (roster && roster.name) {
            param.senderDisplayName = roster.name;
        } else {
            param.senderDisplayName = user;
        }
        param.upload = offlineMessage.upload;
        param.roomId = offlineMessage.roomID;
        param.date = offlineMessage.messageDate;
        param.uuid = offlineMessage.elementId;
        param.isMedia = offlineMessage.isMediaMessage;
        param.slaTime = offlineMessage.slaTime;
        param.isConfidential = offlineMessage.isConfidential;
        param.fileName = offlineMessage.fileName;
        param.documentType = [CMOUtils documentType:offlineMessage.body];
        param.smsUsers = offlineMessage.smsUsers;
        param.smsSent = [offlineMessage.smsUsers length] > 0 ? true : false;
        param.show = offlineMessage.show;
        param.media = param.isMedia ? [self getDocument:offlineMessage.body roomID:param.roomId] : nil;
        
        param.messageId = offlineMessage.messageId;
        param.messageDateString = offlineMessage.messageDateString;
//#warning check this condition
        param.status = [offlineMessage.status integerValue];
        return param;
    }

}


#pragma mark Prepare CMOMessageParam from XMPPMessages
//#warning - IMPORTANT: validate this function.

- (CMOMessageParam *)constructMessageParamFromXMPP:(XMPPRoomMessageCoreDataStorageObject *)xmppMessage{
    /*if ([xmppMessage isKindOfClass:[DDXMLElement class]]){
        xmppMessage = [XMPPMessage messageFromElement:xmppMessage];
    }*/
    if (![xmppMessage.message isErrorMessage]){
        ////DDLogError(@"\n\n\n GOT ERROR MESSAGE %@ \n\n\n",xmppMessage.message);
        @autoreleasepool{
            id <CMOChatClient>chatService = [_coreComponents chatService];
            //xmppMessage.body is a JSON String
            CMOMessageBody *messageBody = [chatService messageBody:xmppMessage.body];
            CMOMessageParam *param = [[CMOMessageParam alloc]init];
            param.body = messageBody.body;
            //DDLogError(@"\n\n\n ******* JID IS %@ ******\n\n\n",xmppMessage.jid);
            param.senderId = [xmppMessage.jid resource];
            id <CMORosterClient>rosterClient = [_coreComponents rosterService];
            CMORoster *roster = [rosterClient fetchRoster:[xmppMessage.jid resource]];
            if (roster && roster.name) {
                param.senderDisplayName = roster.name;
            } else {
                param.senderDisplayName = [xmppMessage.jid resource];
            }
            param.roomId = [xmppMessage.roomJID user]; //Room Id
            param.date = messageBody.messageDate ? messageBody.messageDate : [NSDate date];
            param.isMedia = [messageBody.mediaItem boolValue];
            param.isMedia = [messageBody.mediaType boolValue];
            param.slaTime = [messageBody.slaTime integerValue];
            param.isConfidential = [messageBody.isConfidential boolValue];
            param.documentType = [CMOUtils documentType:messageBody.body];
            param.smsUsers = messageBody.smsUsers;
            param.smsSent = [messageBody.smsUsers length] > 0 ? true : false;
            param.show = [messageBody.shouldVisible boolValue];
            param.fileName = messageBody.fileName;
            param.status = xmppMessage.deliveryStatus;
            param.upload = false; //Upload will be false,
            param.messageId = messageBody.messageId;
            param.messageDateString = messageBody.messageDateString;
            param.media = param.isMedia ? [self getDocument:messageBody.body roomID:param.roomId] : nil;
            return param;
        }
    }
    return nil;
    
    /*
     cmoMessage.localTimeStamp = remoteTimeStamp ? remoteTimeStamp : [NSDate date];
     cmoMessage.remoteTimeStamp = [message delayedDeliveryDate];
     */
}


#pragma mark Prepare CMOMessage

- (CMOMessage *)constructMessage:(CMOMessageParam *)param target:(id)target messagesDict:(NSMutableDictionary *)dict{
    
    if ([[dict allKeys]count] > 0){
        NSString *messageId = param.messageId;
        NSMutableArray *values = [dict valueForKey:param.roomId];
        NSArray *messages = [values filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"messageBody.messageId == %@",messageId]];
        if (messages.count > 0){
            return messages[0];
        }
    }
    
    @autoreleasepool{
        id <CMOUserClient>userClient = [_coreComponents userService];
        CMOUser *owner = [userClient user];
        
        CMOMessage *cmoMessage = nil;
        CMOMessageBody *messageBody = [self messageBody:param];
        if (param.isMedia){
            JSQMediaItem *mediaItem = nil;
            switch (param.documentType) {
                case DocumentTypeImage:
                    {
                        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
                        UIImage *image = param.media ? [UIImage imageWithData:param.media] : nil;
                        mediaItem = [[CMOPhotoMediaItem alloc] initWithUIImage:image target:target];
                    }
                    break;
                case DocumentTypeVideo:
                        ////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
                        mediaItem = [[CMOVideoMediaItem alloc]initWithFileURL:nil isReadyToPlay:false delegate:target];
                    break;
                case DocumentTypeAudio:
                {
                        ////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
                        //NSString *filePath = [self getFilePath:messageBody.body roomId:param.roomId];
                        //NSURL *fileUrl = [NSURL URLWithString:filePath];
                        mediaItem = [[CMOAudioMediaItem alloc] initWithData:param.media target:target];
                }
                    break;
                case DocumentTypeMedia:
                        ////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
                        mediaItem = [[CMODocumentItem alloc] initWithData:param.media target:target];
                    break;
                default:
                    break;
            }
            ////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
            //DDLogError(@"\n\n\n ******* SENDER ID IS %@ ******\n\n\n",param.senderId);
            cmoMessage = [[CMOMessage alloc]initWithSenderId:param.senderId senderDisplayName:param.senderDisplayName date:param.date media:mediaItem];
        }
        else{
            ////DDLogInfo(@"%@ %@ 7",THIS_METHOD,THIS_FILE);
            //DDLogError(@"\n\n\n ******* SENDER ID 2 IS %@ ******\n\n\n",param.senderId);

            cmoMessage = [[CMOMessage alloc]initWithSenderId:param.senderId senderDisplayName:param.senderDisplayName date:param.date text:[self getFormattedMessageBody:messageBody fromMe:[owner.username isEqualToString:param.senderId]]];
        }
        //NSString *uuid = [CMOUtils getUniqueString];
        cmoMessage.elementID = param.uuid ? param.uuid : [CMOUtils getUniqueString];
        cmoMessage.userName = param.senderId;
        cmoMessage.roomIDStr = param.roomId;
        //cmoMessage.from
        cmoMessage.mediaItem = param.isMedia ? @"1" : @"0";
        cmoMessage.mediaType = param.isMedia ? @"1" : @"0";
        cmoMessage.status = param.status;
        cmoMessage.upload = param.upload;
        cmoMessage.fromMe = true;
        cmoMessage.messageDate = param.date;
        cmoMessage.slaFlag = param.slaTime > 0 ? true : false;
        cmoMessage.slaTime = param.slaTime;
        cmoMessage.isFirstMessage = param.isFirstMessage;
        cmoMessage.messageBody = messageBody;

        ////DDLogInfo(@"%@ %@ 99",THIS_METHOD,THIS_FILE);
        return cmoMessage;
    }
}

- (CMOMessageBody *)messageBody:(CMOMessageParam *)param{
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    CMOMessageBody *messageBody = [[CMOMessageBody alloc]init];
    messageBody.body = param.body ? param.body : @"";
    messageBody.mediaItem = param.isMedia ? @"1" : @"0";
    messageBody.mediaType = param.isMedia ? @"1" : @"0";
    messageBody.isConfidential = [NSString stringWithFormat:@"%d",param.isConfidential];
    messageBody.messageDate = param.date;
    messageBody.fileName = param.fileName;
    messageBody.slaTime = [NSString stringWithFormat:@"%ld",(long)param.slaTime];
    messageBody.slaFlag = param.slaTime > 0 ? @"true" : @"false" ;
    messageBody.messageDateString = param.messageDateString;
    messageBody.messageId = param.messageId;
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    id <CMORosterClient>rosterClient = [_coreComponents rosterService];
    CMORoster *roster = [rosterClient fetchRoster:owner.username];
    if ([roster.userPermission.chatInitiation integerValue] == 1){
        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        messageBody.shouldVisible = @"true";
    }
    else{
        ////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
        messageBody.shouldVisible = param.show ? @"true" : @"false";
    }
    messageBody.smsUsers = param.smsSent ? param.smsUsers : @"";
    ////DDLogInfo(@"%@ %@ 99",THIS_METHOD,THIS_FILE);
    return messageBody;
}

- (CMOMessageBody *)messageBodyFromJson:(NSString *)messageString{
    return [[_coreComponents chatService]messageBody:messageString];
}

#pragma mark - Is User Allowed to Join
//This case will come when a user was removed from the chat and he/she is trying to join the chatroom.

- (BOOL)isUserAllowedToJoin:(NSString *)userName roomInfo:(CMORoomDetails *)roomInfo isConfidential:(BOOL)isConfidential{
    if (!roomInfo)return true;
    
    BOOL isAllowed = false;
    
    NSString *userJid = [NSString stringWithFormat:@"%@@%@",userName,self.domainName];

    id owner = roomInfo.owners.owner;
    if ([owner isKindOfClass:[NSMutableArray class]]){
        if ([owner containsObject:userJid]){
            return true;
        }
    }
    
    id members = roomInfo.members.members;
    
    id <CMORepositoryClient>repositoryClient = [self.coreComponents repositoryService];
    if ([roomInfo.membersGroup.memberGroup isKindOfClass:[NSArray class]]) {
        NSArray *allGroups = (NSArray *)roomInfo.membersGroup.memberGroup;
        for (NSString *groupName in allGroups){
            NSArray *groupMembers = [repositoryClient fetchMembersForGroup:groupName];
            if ([groupMembers containsObject:userName]){
                isAllowed = true;
                break;
            }
        }
    } else if ([roomInfo.membersGroup.memberGroup isKindOfClass:[NSString class]]) {
        NSString *groupName = (NSString*)roomInfo.membersGroup.memberGroup;
        NSArray *groupMembers = [repositoryClient fetchMembersForGroup:groupName];
        if ([groupMembers containsObject:userName]){
            isAllowed = true;
        }
    }
    
    NSMutableArray *membersList = nil;
    if (members){
        membersList = [[NSMutableArray alloc]init];
        if ([members isKindOfClass:[NSString class]]){
            [membersList addObject:members];
        }
        else{
            [membersList addObjectsFromArray:members];
        }
    }
    
    if (membersList){
        if ([membersList containsObject:userJid]){
            isAllowed = true;
        }
    }
    
    return isAllowed;
}

- (void)updateArchiveStatus:(BOOL)isArchived toRoom:(CMORoomDetails *)roomDetail{
    id <CMORepositoryClient>client = [_coreComponents repositoryService];
    [client updateArchiveStatus:isArchived toRoom:roomDetail];
}

#pragma mark Upload and Download Documents
#pragma mark

- (void)uploadDocumentWithMessage:(CMOMessage *)message
                             data:(id)documentData
                       OnProgress:(void (^)(id progress))onProgress
                        onSuccess:(void (^)(id result))success
                        onFailure:(void (^)(NSError *error))failure{

    [chatClient uploadDocumentWithMessage:message data:documentData OnProgress:^(id progress) {
        onProgress(progress);
    } onSuccess:^(id result) {
        success(result);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
    
}

- (void)downloadDocument:(NSString *)documentName
              OnProgress:(void (^)(id progress))onProgress
             onSuccess:(void (^)(id result))success
             onFailure:(void (^)(NSError *error))failure{
    
    [chatClient downloadDocument:documentName OnProgress:^(id progress)
     {
         onProgress(progress);
     }onSuccess:^(id result) {
        success(result);
     } onFailure:^(NSError *error) {
         failure(error);
     }];
}


//Old Upload and Download functions
/*- (void)uploadDocument:(NSString *)docName
               documentData:(id)docData
               message:(CMOMessage *)message
     completionHandler:(void (^)(id success, NSError *error))handler{
    
    [chatClient uploadDocument:docName documentData:docData message:message completionHandler:^(id success, NSError *error) {
        if (error){
            handler(nil,error);
        }
        else{
            handler(success,nil);
        }
    }];
}

- (void)downloadDocument:(NSString *)docName
                 message:(CMOMessage *)message
       completionHandler:(void (^)(id success, NSError *error))handler{
    
    [chatClient downloadDocument:docName message:message completionHandler:^(id success, NSError *error) {
        if (error){
            handler(nil,error);
        }
        else{
            handler(success,nil);
        }
    }];
}*/


- (NSString *)getDocumentFilePath:(NSString *)roomId fileName:(NSString *)fileName{
    return [chatClient getFilePath:fileName roomName:roomId];
}

#pragma mark Save Documents

- (void)saveDocument:(NSString *)documentName docData:(id)docData roomID:(NSString *)roomID{
    [chatClient saveDocument:documentName docData:docData forRoom:roomID];
}

- (id)getDocument:(NSString *)documentName roomID:(NSString *)roomID{
    return [chatClient getDocument:documentName forRoom:roomID];
}

- (BOOL)deleteDocument:(NSString *)documentName roomID:(NSString *)roomID{
    return [chatClient deleteDocument:documentName forRoom:roomID];
}

- (NSString *)getFilePath:(NSString *)fileName roomId:(NSString *)roomId{
    return [chatClient getFilePath:fileName roomName:roomId];
}

- (void)sendMessage:(CMOMessage *)message roomId:(NSString *)roomID
  completionHandler:(void (^)(XMPPMessage *message,NSError *error))handler{
    [chatClient sendMessage:message roomId:roomID completionHandler:^(XMPPMessage *message, NSError *error) {
        handler(message,error);
    }];
}

- (NSArray *)getRooms:(NSString *)user completionHandler:(void (^)(NSArray *items,NSError *error))handler{
    return [chatClient fetchRooms:user completionHandler:^(NSArray *items,NSError *error) {
        if (error){
            handler(nil,error);
        }
        else{
            handler(items,nil);
        }
    }];
}

- (NSArray *)fetchAllRooms{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    return [repositoryClient fetchChatRooms];
}

- (NSArray *)fetchRoomsForArchivedStatus:(BOOL)archived {
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    return [repositoryClient fetchChatRoomsForArchivedStatus:archived];
}

- (NSArray *)getActiveChatRooms{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    return [repositoryClient getActiveRooms];
}


- (void)updateSyncDataonSuccess:(void (^)(id result))success
                      onFailure:(void (^)(NSError *error))failure{
    [chatClient updateSyncDataonSuccess:^(id result) {
        success(result);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
}

#pragma mark Room Subject

- (void)setSubject:(NSString *)roomSubject forRoom:(NSString *)roomJID{
    [chatClient setRoomSubject:roomSubject forRoom:roomJID];
}

- (NSArray *)filterRoomsbySMSUser:(NSString *)userName{
    id <CMORepositoryClient>client = [_coreComponents repositoryService];
    NSArray *rooms = [client filterRoomsbySMSUser:userName];
    /*NSMutableArray *messagesArray = [NSMutableArray new];
    for (XMPPRoomMessageCoreDataStorageObject *message in messages){
        if (![messagesArray containsObject:[message.roomJID user]]){
            [messagesArray addObject:[message.roomJID user]];
        }
    }
    NSMutableArray *roomDetailsArray = [NSMutableArray new];
    for (NSString *roomId in messagesArray){
        CMORoomDetails *roomDetail = [self fetchRoomInfo:roomId];
        if (roomDetail){
            [roomDetailsArray addObject:roomDetail];
        }
    }*/
    return rooms;
}


#pragma mark Send Chat Status

- (void)sendChatStatus:(NSString *)roomID status:(ChatTypStatus)status{
    [chatClient sendChatStatus:roomID status:status];
}

- (void)removeUser:(NSString *)userId fromChatRoom:(NSString *)roomId onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure {
    [chatClient removeUser:userId fromChatRoom:roomId onSuccess:^(id result) {
        success(result);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
}

- (void)addUser:(NSString *)userName toChatRoom:(NSString *)roomId onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure {
    [chatClient addUser:userName toChatRoom:roomId onSuccess:^(id result) {
        success(result);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
}


- (void)addGroup:(NSString *)groupId toChatRoom:(NSString *)roomId onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure {
    __weak typeof(self) weakSelf = self;
    [chatClient addGroup:groupId toChatRoom:roomId onSuccess:^(id result) {
        id <CMORepositoryClient>client = [weakSelf.coreComponents repositoryService];
        NSArray *members = [client fetchMembersForGroup:groupId];
        NSMutableArray *membersList = [[NSMutableArray alloc]init];
        for (NSString *member in members){
            [membersList addObject:[NSString stringWithFormat:@"%@@%@",member,[CMOUtils domainName]]];
        }
        [weakSelf inviteUsersToJoinTheRoom:membersList forRoom:roomId withAffiliation:AffiliationNone];

        success(result);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
}

- (CMORoomDetails *)retreiveChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure{
    CMORoomDetails *roomDetails = [chatClient retreiveChatRoom:roomId onSuccess:^(id result) {
        success(result);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
    return roomDetails;
}

- (CMORoomDetails *)fetchRoomInfo:(NSString *)roomID{
    id <CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client fetchRoomInfo:roomID];
}


- (NSMutableArray *)clubOwnersAndMembers:(CMORoomDetails *)roomInfo {
    if (roomInfo != nil){
        NSMutableArray *participants = [[NSMutableArray alloc]init];
        
        id owners =  roomInfo.owners.owner;//roomInfo.owners.owner;
        id members = roomInfo.members.members;//[roomInfo.members.member valueForKey:@"member"];
        
        id admins = roomInfo.admins.admins;//[roomInfo.admins valueForKey:@"admin"];
        
        id memberGroups = roomInfo.membersGroup.memberGroup;
        
        if (members){
            if ([members isKindOfClass:[NSString class]]){
                NSMutableDictionary *membersdict = [[NSMutableDictionary alloc]init];
                [membersdict setObject:members forKey:@"Participant"];
                [membersdict setObject:@"Member" forKey:@"ParticipantDesc"];
                [participants addObject:membersdict];
                
              // [participants addObject:members];
            }
            else{
                NSMutableDictionary *membersdict = [[NSMutableDictionary alloc]init];
                [membersdict setObject:members forKey:@"Participant"];
                [membersdict setObject:@"Member" forKey:@"ParticipantDesc"];
                [participants addObject:membersdict];
                
       //         participants = [NSMutableArray arrayWithArray:[participants arrayByAddingObjectsFromArray:members]];
            }
        }
        
        if (owners){
            if ([owners isKindOfClass:[NSString class]]){
        //        [participants addObject:owners];
                
                NSMutableDictionary *ownersdict = [[NSMutableDictionary alloc]init];
                [ownersdict setObject:owners forKey:@"Participant"];
                [ownersdict setObject:@"Owner" forKey:@"ParticipantDesc"];
                [participants addObject:ownersdict];
            }
            else{
                
                NSMutableDictionary *ownersdict = [[NSMutableDictionary alloc]init];
                [ownersdict setObject:owners forKey:@"Participant"];
                [ownersdict setObject:@"Owner" forKey:@"ParticipantDesc"];
                [participants addObject:ownersdict];
                
           //    participants = [NSMutableArray arrayWithArray:[participants arrayByAddingObjectsFromArray:owners]];
            }
        }
        
        if (admins){
            if ([admins isKindOfClass:[NSString class]]){
            //    [participants addObject:admins];
                
                NSMutableDictionary *admindict = [[NSMutableDictionary alloc]init];
                [admindict setObject:admins forKey:@"Participant"];
                [admindict setObject:@"Admin" forKey:@"ParticipantDesc"];
                [participants addObject:admindict];
            }
            else{
                
                NSMutableDictionary *admindict = [[NSMutableDictionary alloc]init];
                [admindict setObject:admins forKey:@"Participant"];
                [admindict setObject:@"Admin" forKey:@"ParticipantDesc"];
                [participants addObject:admindict];
                
//                participants = [NSMutableArray arrayWithArray:[participants arrayByAddingObjectsFromArray:admins]];
            }
        }
        
        if (memberGroups){
            if ([memberGroups isKindOfClass:[NSString class]]) {
               // [participants addObject:memberGroups];
                NSMutableDictionary *membersdict = [[NSMutableDictionary alloc]init];
                [membersdict setObject:memberGroups forKey:@"Participant"];
                [membersdict setObject:@"Member" forKey:@"ParticipantDesc"];
                [participants addObject:membersdict];
            } else {
//                participants = [NSMutableArray arrayWithArray:[participants arrayByAddingObjectsFromArray:memberGroups]];
                
                NSMutableDictionary *membersdict = [[NSMutableDictionary alloc]init];
                [membersdict setObject:memberGroups forKey:@"Participant"];
                [membersdict setObject:@"Member" forKey:@"ParticipantDesc"];
                [participants addObject:membersdict];
            }
        }
        return [self occupantsForItems:participants];
    }
    return nil;
}


- (NSMutableArray *)occupantsForItems:(NSArray *)items {
    NSMutableArray *itemsArray = nil;
    NSArray *rosters = nil;
    if (items.count > 0){
        itemsArray = [[NSMutableArray alloc]init];
        id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
        rosters =  [repositoryClient fetchAllRostersIncludingLoggedInUser];
    }
    
    if (rosters == nil){
        DDLogInfo(@"WARNING: Rosters are not loaded. Please check the api call");
    }
    
    
    for (NSDictionary *item in items){
         NSArray *list = [item objectForKey:@"Participant"];
        for (NSString *partici in list) {
            CMOParticipantInfo *participantInfo = [[CMOParticipantInfo alloc]init];
            participantInfo.jid = partici;
            participantInfo.partcipantDesc = [item objectForKey:@"ParticipantDesc"];
            NSString* bareId = [partici componentsSeparatedByString:@"@"][0];
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"username == %@",bareId];
            NSArray *searchresult = [rosters filteredArrayUsingPredicate:predicate];
            if (searchresult.count) {
                participantInfo.participantName = [searchresult[0] name];
                participantInfo.isGroup = false;
            }
            else{ //If roster is not available then it is a group name. Add the group name to `participantName`
                participantInfo.participantName = bareId;
                participantInfo.isGroup = true;
            }
            [itemsArray addObject:participantInfo];
        }
    
    }
    return itemsArray;
}


- (NSMutableArray *)clubMembersOnly:(CMORoomDetails *)roomInfo{
    if (roomInfo != nil){
        NSMutableArray *participants = [[NSMutableArray alloc]init];
        id members = roomInfo.members.members;//
        if (members){
            if ([members isKindOfClass:[NSString class]]){
                [participants addObject:members];
            }
            else{
                participants = [NSMutableArray arrayWithArray:[participants arrayByAddingObjectsFromArray:members]];
            }
            return [self occupantsForItems:participants];
        }
    }
    return nil;
}


//This will return the participant dictionary from room object. This will be applicable for exsisting chat.
- (NSMutableDictionary *)getRoomParticipants:(CMORoomDetails *)roominfo{
    NSMutableArray *participants = [self clubOwnersAndMembers:roominfo];//[self clubMembersOnly:roominfo];
    id <CMOUserClient>userService = [_coreComponents userService];
    CMOUser *owner = [userService user];
    id<CMORepositoryClient> repoClient = [_coreComponents repositoryService];
    if (participants.count > 0){
        NSMutableDictionary *dict = [NSMutableDictionary new];
        for (CMOParticipantInfo *participantInfo in participants){
            if (participantInfo.isGroup){
                NSMutableArray *participantList = [self arrayForDict:dict key:MACROS_GROUPS];
                CMORosterGroup *rosterGroup = [repoClient fetchGroupRoster:participantInfo.jid];
                if (rosterGroup){
                    [participantList addObject:rosterGroup];
                }
            }
            else{
                XMPPJID *jid = [XMPPJID jidWithString:participantInfo.jid];
                NSMutableArray *participantList = [self arrayForDict:dict key:MACROS_CONTACTS];
                CMORoster *roster = [repoClient fetchRoster:[jid user]];
                //Don't add owner as a member in participant list.
                if (roster && ![roster.username isEqualToString:owner.username]){
                    [participantList addObject:roster];
                }
            }
        }
        return dict;
    }
    return nil;
}

- (NSMutableArray *)arrayForDict:(NSMutableDictionary *)dict key:(NSString *)key{
    id value = [dict valueForKey:key];
    if (!value){
        value = [[NSMutableArray alloc]init];
        [dict setObject:value forKey:key];
    }
    return value;
}

- (BOOL)isAppUserExist:(CMORoomDetails *)roomDetail{
    
    NSMutableArray *participants = [self clubOwnersAndMembers:roomDetail];
    NSMutableArray *roomRosters = [NSMutableArray new];
    for (CMOParticipantInfo *participant in participants){
        id <CMORosterClient>rosterClient = [_coreComponents rosterService];
        NSArray *userJid = [participant.jid componentsSeparatedByString:@"@"];
        if (userJid.count > 1){
            CMORoster *roster = [rosterClient fetchRoster:[participant.jid componentsSeparatedByString:@"@"][0]];
            if (!roster.isSMSUser && !roster.isFromExchange){
                [roomRosters addObject:roster];
            }
        }
        else{
            CMORosterGroup *rosterGroup = [rosterClient fetchGroupRoster:participant.participantName];
            if (![[rosterGroup name] isEqualToString:CMONonAppUsersGroup]){
                [roomRosters addObject:rosterGroup];
            }
        }
        
    }
    return roomRosters.count > 1;
    
}


- (void)createOrJoinRoom:(CMORoomDetails *)roomJID userstoInvite:(id)users  history:(NSString *)date completionHandler:(void (^)(BOOL result, NSError *error))handler{
    
    [chatClient createOrJoinRoom:roomJID userstoInvite:users history:date completionHandler:^(BOOL result, NSError *error) {
        if (error){
            handler(false,error);
        }
        else{
            handler(true,nil);
        }
    }];
}

- (void)leaveRoom{
    [chatClient leaveRoom];
}


/*- (void)createRoom:(CMORoomInfo *)roomInfo participants:(id)pariticipants onSuccess:(void (^)(id result))success
         onFailure:(void (^)(NSError *error))failure {
    [chatClient createRoom:roomInfo participants:pariticipants onSuccess:^(id result) {
        success(result);
    } onFailure:^(NSError *error) {
        failure(error);
    }];
}*/

- (void)saveSmsusersToChatRoom:(NSMutableArray *)participants roomId:(NSString *)roomId{
    NSString *users = [self smsusersFromParticipants:participants];
    if ([users length] > 0){
        id <CMORepositoryClient>client = [_coreComponents repositoryService];
        [client saveSmsusersToChatRoom:users roomId:roomId];
        [CMOUtils saveSMSInfo:users roomId:roomId];
    }
}

- (NSString *)smsusersFromParticipants:(NSMutableArray *)participants{
    NSString *smsUsers = @"";
    NSPredicate *ADExchangePredicate = [NSPredicate predicateWithFormat:@"isFromExchange==true OR isSMSUser==true"];
    NSArray *users = [participants filteredArrayUsingPredicate:ADExchangePredicate];
    NSMutableArray *usersNamesList = [NSMutableArray new];
    for (CMORoster *roster in users){
        [usersNamesList addObject:roster.name ? roster.name : roster.username];
    }
    if (usersNamesList.count > 0){
        smsUsers = [usersNamesList componentsJoinedByString:@", "];
    }
    return smsUsers;
}


- (void)inviteUsersToJoinTheRoom:(id)user forRoom:(NSString *)roomName withAffiliation:(Affiliation)affiliation{
    [chatClient inviteUsersToJoinTheRoom:user forRoom:roomName withAffiliation:affiliation];
}

- (void)addGroupsToRoom:(NSArray *)groups forRoom:(NSString *)roomId{
    for (NSString *group in groups){
      [self addGroup:group toChatRoom:roomId onSuccess:^(id result) {
          ////DDLogInfo(@"Groups Added to ChatRoom: %@",group);
      } onFailure:^(NSError *error) {
          ////DDLogInfo(@"Groups Added Failed: %@",groups);
      }];
    }
}

#pragma mark Draft Message

- (void)saveDraftMessage:(NSString *)message forRoom:(NSString *)roomId{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    [client saveDraftMessage:message forRoom:roomId];
}


- (NSString *)fetchDraftMessagesForRoom:(NSString *)roomId{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    CMODraftMessages *draftMessages = [client fetchDraftMessageForRoom:roomId];
    return draftMessages == nil ? @"" : draftMessages.body;
}

#pragma mark Save Message Offline

- (CMOMessage *)getUpdatedDateMessage:(CMOMessage *)message delegate:(id)target {
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    CMOOfflineMessages *offlineMessage1 = [client updateOfflineMessage:message];
    message.messageBody.messageDateString = offlineMessage1.messageDateString;
    //CMOOfflineMessages *offlineMessage2 = [client fetchOfflineMessage:offlineMessage1.messageDateString];
    //CMOMessageParam *param = [self constructMessageParamFromOffline:offlineMessage2];
    return message;//[self constructMessage:param target:target messagesDict:nil];
}

- (void)updateMessageOfflineDate:(CMOMessage *)message{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    [client updateOfflineMessage:message];
}

- (void)saveMessageOffline:(CMOMessage *)message{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    [client saveMessageOffline:message];
}

- (NSArray *)getOfflineMessageOfRoom:(NSString *)roomID delegate:(id)target messagesDict:(NSMutableDictionary *)dict{
    NSMutableArray *allMessages = nil;
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    NSArray *messages = [client fetchOfflineMessageOfRoom:roomID];
    if (messages.count > 0){
        allMessages = [[NSMutableArray alloc]init];
        for (CMOOfflineMessages *offlineMessage in messages){
            CMOMessageParam *param = [self constructMessageParamFromOffline:offlineMessage];
            CMOMessage *cmoMessage = [self constructMessage:param target:target messagesDict:dict];
            [allMessages addObject:cmoMessage];
        }
    }
    return allMessages;
}

/* - (NSArray *)getOfflineMessageOfRoom:(NSString *)roomID delegate:(id)target{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [self getOfflineCMOMessages:[client fetchOfflineMessageOfRoom:roomID] delegate:target];
}*/

- (NSArray *)getOfflineMessagesOfRoom:(NSString *)roomId{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    NSArray *messages = [client fetchOfflineMessageOfRoom:roomId];
    NSMutableArray *offlineMessages = [NSMutableArray new];
    for (CMOOfflineMessages *offlineMessage in messages){
        CMOMessageParam *param = [self constructMessageParamFromOffline:offlineMessage];
        CMOMessage *message = [self constructMessage:param target:self messagesDict:nil];
        [offlineMessages addObject:message];
    }
    return offlineMessages;
}


- (NSInteger)getOfflineMessageCountOfRoom:(NSString *)roomId{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client fetchOfflineMessageCountOfRoom:roomId];
}



- (NSArray *)getAllOfflineMessages{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client fetchAllOfflineMessages];
}

/*- (NSArray *)getOfflineCMOMessages:(NSArray *)coreDataMessages delegate:(id)target{
    NSMutableArray *messages = nil;
    if (coreDataMessages.count > 0){
        messages = [[NSMutableArray alloc]init];
    }
    for (CMOOfflineMessages *msg in coreDataMessages){
        //msg.messageStr contains raw message (i.e)JSON
        
        CMOMessageBody *messageBody = [chatClient messageBody:msg.messageStr];
        CMOMessage *message = nil;
        NSString *userName = msg.nickname;
        
        //NSString *userName = xmppMessage.wasDelayed ? [xmppMessage attributeStringValueForName:@"delay"] :
        XMPPJID *jid = [XMPPJID jidWithString:msg.roomJIDStr];
        if ([messageBody.mediaItem integerValue] == 1){
            //Note: Image name should be local url. Not image name
            //If image is deleted then handle case
            UIImage *image = [UIImage imageWithData:[chatClient getDocument:messageBody.body forRoom:[jid user]]];
            if (!image){
                DDLogWarn(@"Image is deleted from local folder. Handle error condition here");
                image = [UIImage imageNamed:@"imagePlaceholder.png"];
            }
            
            DocumentType docType = [CMOUtils documentType:messageBody.body];
            
            if (docType == DocumentTypeImage){
                CMOPhotoMediaItem *photoItem = [[CMOPhotoMediaItem alloc] initWithUIImage:image target:target];
                message = [[CMOMessage alloc]initWithSenderId:userName senderDisplayName:userName date:msg.localTimestamp media:photoItem];
            }
            else if (docType == DocumentTypeVideo){
                NSString *videoPath = [chatClient getFilePath:messageBody.body roomName:msg.roomJIDStr];
                BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:videoPath];
                CMOVideoMediaItem *videoItem = [[CMOVideoMediaItem alloc]initWithFileURL:isFileExist ? [NSURL fileURLWithPath:videoPath] : nil isReadyToPlay:isFileExist ? true : false delegate:target];
                message = [[CMOMessage alloc]initWithSenderId:userName senderDisplayName:userName date:msg.localTimestamp media:videoItem];
            } else if (docType == DocumentTypeAudio) {
                NSString *audioPath = [chatClient getFilePath:messageBody.body roomName:msg.roomJIDStr];
                BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:audioPath];
                CMOAudioMediaItem *audioItem = [[CMOAudioMediaItem alloc] initWithUrl:(isFileExist?[NSURL fileURLWithPath:audioPath]:nil) target:target];
                message = [[CMOMessage alloc] initWithSenderId:userName senderDisplayName:userName date:msg.localTimestamp media:audioItem];
            } else if (docType == DocumentTypeMedia) {
                NSString *docPath = [chatClient getFilePath:messageBody.body roomName:msg.roomJIDStr];
                BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:docPath];
                CMODocumentItem *docItem = [[CMODocumentItem alloc] initWithUrl:(isFileExist?[NSURL fileURLWithPath:docPath]:nil) target:target];
                docItem.fileName = messageBody.fileName;
                message = [[CMOMessage alloc] initWithSenderId:userName senderDisplayName:userName date:msg.localTimestamp media:docItem];
                message.messageBody.fileName = messageBody.fileName;
            }
            else{
                //handle other error conditions
            }
        }
        else{
            //[xmppMessage.from user] - Occupant Name in the room
            message = [[CMOMessage alloc]initWithSenderId:userName senderDisplayName:userName date:msg.localTimestamp text:[self getFormattedMessageBody:messageBody fromMe:msg.fromMe]];
        }
       // message.from = xmppMessage.from;
        message.isOffline = msg.isOffline;
        message.userName = userName;
        message.status = MessageDeliveryFailed;
        message.roomIDStr = msg.roomID;
        message.fromMe = [msg.fromMe boolValue];
        message.messageBody = messageBody;
        message.upload = msg.upload;
        message.elementID = msg.elementId;
        message.localTimeStamp = msg.localTimestamp;
        message.remoteTimeStamp = msg.remoteTimestamp;
        message.slaFlag = msg.slaFlag;
        message.slaTime = msg.slaTime;
        message.isErrorMessage = false; //CMO Offline storage doesn't keep track of error messages.
        if(message){
            [messages addObject:message];
        }
    }
    return messages;
}*/

- (BOOL)isOfflineMessage:(CMOMessage *)message{
    //fetchMessage
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client fetchOfflineMessage:message.messageBody.messageDateString] != nil;
}


#pragma mark - Remove Offline Messages
- (void)removeOfflineMessage:(CMOMessage *)message{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    [client deleteOfflineMessage:message];
}

#pragma mark - Remove XMPP Messages
- (void)removeXMPPMessages:(NSArray *)messages{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    if (messages.count > 0){
        for (CMOMessage *msg in messages){
            XMPPRoomMessageCoreDataStorageObject *xmppObject = [client fetchMessage:msg ofRoom:msg.roomIDStr];
            if (xmppObject){
                [client deleteXMPPMessage:xmppObject];
            }
        }
    }
}

#pragma mark - Save Message Read Status
- (void)saveMessageReadStatus:(BOOL)didReadMessage unReadCount:(int)count forRoom:(NSString *)roomId{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    //CMOMessageReadStatus *messageReadStatus = [client fetchMessageReadStatusForRoom:roomId];
   // if (messageReadStatus.didReadMessage != didReadMessage){
        [client messageRead:didReadMessage unreadCount:count forRoom:roomId];
    //}
}

- (BOOL)isMessageReadForRoom:(NSString *)roomId{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    CMOMessageReadStatus *messageReadStatus = [client fetchMessageReadStatusForRoom:roomId];
    return messageReadStatus.didReadMessage;
}

- (CMOMessageReadStatus *)getUnReadMessageForRoom:(NSString *)roomId{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client fetchMessageReadStatusForRoom:roomId];
}

- (int)unReadMessageCountForRoom:(NSString *)roomId{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    CMOMessageReadStatus *messageReadStatus = [client fetchMessageReadStatusForRoom:roomId];
    return messageReadStatus.unReadCount;
}

- (NSArray *)unReadMessagesOfAllRooms{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client fetchAllUnReadMessagesOfAllRooms];
}

- (BOOL)isMessageAlreadyExist:(XMPPRoomMessageCoreDataStorageObject *)message{
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client isMessageAlreadyExist:message];
}


#pragma Did Receive Message
- (void)didReceiveMessage:(CMOMessage *)message{
//#warning This becomes nil
    //[self.chatPresentationDelegate didReceiveMessage:message];
}


- (CMOMessage *)getMessage:(CMOMessage *)message sender:(NSString *)user messages:(NSMutableArray *)messages{
    
    NSDate *remoteTimeStamp = message.remoteTimeStamp;
    //    if (remoteTimeStamp == nil){
    //        return nil;
    //    }
    //NSString *streamBareJidStr = [NSString stringWithFormat:@"%@@%@",user,self.serverName];
    // XMPPJID *messageJid = message.from;
    NSString *messageBody = message.messageBody.body;
    NSDate *minLocalTimestamp = [message.remoteTimeStamp dateByAddingTimeInterval:-60];
    NSDate *maxLocalTimestamp = [message.remoteTimeStamp dateByAddingTimeInterval: 60];
    //@"AND from == %@ "
    NSString *predicateFormat = @"messageBody.body == %@ "
    @"AND userName == %@ "
    @"AND "
    @"("
    @"     (remoteTimeStamp == %@) "
    @"  OR (remoteTimeStamp == NIL && localTimeStamp BETWEEN {%@, %@})"
    @")";
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:predicateFormat,
                              messageBody, user,
                              remoteTimeStamp, minLocalTimestamp, maxLocalTimestamp];
    
    
    //Issue with time(last time between condition)
    
    NSArray *filteredArray = [messages filteredArrayUsingPredicate:predicate];
    
    return filteredArray.count > 0 ? [filteredArray lastObject] : nil;
}

- (NSArray *)getRoomDetailsAndMessages:(NSString *)user completionHandler:(void (^)(NSArray *items,NSError *error))handler{
    return [chatClient fetchRoomDetailsAndMessage:user completionHandler:^(NSArray *items,NSError *error) {
        if (error){
            handler(nil,error);
        }
        else{
            handler(items,nil);
        }
    }];
}

- (NSString*_Nullable)getUsernameForNicname:(NSString *_Nonnull)nicname
{
    id <CMORosterClient>rosterClient = [_coreComponents rosterService];
    return [rosterClient getUsernameForNicname:nicname];
}

@end


