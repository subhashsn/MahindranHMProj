//
//  CMORosterGroup+CoreDataClass.h
//  CMOChat
//
//  Created by Amit Kumar on 28/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface CMORosterGroup : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "CMORosterGroup+CoreDataProperties.h"
