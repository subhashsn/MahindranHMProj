//
//  CMORosterPresentation.m
//  CMOChat
//
//  Created by Administrator on 10/24/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMORosterPresentation.h"
#import "CMORosterClient.h"
#import "CMORepositoryClient.h"
#import "CMOCoreComponents.h"
#import "CMOUser.h"
#import "CMORoster+CoreDataProperties.h"
#import "XMPPRosterCoreDataStorage.h"
#import <AddressBook/AddressBook.h>

@interface CMORosterPresentation(){
    id<CMORosterClient> rosterClient;
}

@end

@implementation CMORosterPresentation


// This fill return the user list that are not part of logged in user roster list
- (NSArray *)getRostersWithCompletionHandler:(void (^)(id users))onSuccess
                                          failure:(void (^)(NSError  *error))onFailure{
    
    rosterClient = [_coreComponents rosterService];
    __block BOOL buddyRequestSent = false;
    
    NSArray *users = [rosterClient getUsers:nil onSuccess:^(id list) {
        if (((NSArray *)list).count > 0 && !buddyRequestSent){
            buddyRequestSent = true;
            [self sendBuddyRequestOrPresence:list];
           // [self fetchvCardOfUsers:list];
        }
    } onFailure:^(NSError *error) {
        NSLog(@"Unable to get users %@",error);
        onFailure(error);
    }];
    
 
    if (users.count > 0 && !buddyRequestSent){
        buddyRequestSent = true;
        [self sendBuddyRequestOrPresence:users];
        //[self fetchvCardOfUsers:users];
    }
    return users;
}


- (NSArray *)getUsersWithCompletionHandler:(void (^)(id users))onSuccess
                                   failure:(void (^)(NSError  *error))onFailure{
    rosterClient = [_coreComponents rosterService];
    
    NSArray *users = [rosterClient getUsers:nil onSuccess:^(id list) {
        onSuccess(list);
    } onFailure:^(NSError *error) {
        NSLog(@"Unable to get users %@",error);
        onFailure(error);
    }];
    
   
    return users;

}

//Required
- (void)fetchAllUsersAndGroupsWithCompletionHandler:(void (^)(id))onSuccess failure:(void (^)(NSError *))onFailure
{
    rosterClient = [_coreComponents rosterService];
    
    [rosterClient fetchAllUsersAndGroups:nil onSuccess:^(id users) {
        
        id <CMOUserClient>userClient = [_coreComponents userService];
        CMOUser *owner = [userClient user];
        CMORoster *roster = [rosterClient fetchRoster:owner.username];
        if ([roster.userPermission.chatInitiation integerValue] == 1) {
            [self getExchangeUsersWithCompletionHandler:^(id users) {
                //Map vCard to Users
               // [repoClient updatevCardDetailsToRoster:[repoClient fetchAllRosters]];
            } failure:^(NSError *error) {
                //Map vCard to Users
               // [repoClient updatevCardDetailsToRoster:[repoClient fetchAllRosters]];
            }];
        }
        onSuccess(users);
    } onFailure:^(NSError *error) {
        onFailure(error);
    }];
}


//Not Required
- (NSArray *)getGroupsWithCompletionHandler:(void (^)(id groups))onSuccess
                                    failure:(void (^)(NSError  *error))onFailure {
    rosterClient = [_coreComponents rosterService];
    NSArray *groups = [rosterClient getGroups:nil onSuccess:^(id list) {
        onSuccess(list);
    } onFailure:^(NSError *error) {
        NSLog(@"Unable to get groups %@",error);
        onFailure(error);
    }];
    return groups;
}

- (CMORoster *)getCurrentUserInfoWithCompletionHandler:(void (^)(id users))onSuccess
                                             failure:(void (^)(NSError  *error))onFailure{
    rosterClient = [_coreComponents rosterService];
    
    CMORoster *users = [rosterClient getCurrentUserInfo:nil onSuccess:^(id list) {
        onSuccess(list);
    } onFailure:^(NSError *error) {
        NSLog(@"Unable to get users %@",error);
        onFailure(error);
    }];
    
    
    return users;
    
}

/*
- (NSArray *)getCurrentUserInfoWithCompletionHandler:(void (^)(id users))onSuccess
                                   failure:(void (^)(NSError  *error))onFailure{
    rosterClient = [_coreComponents rosterService];
    
    NSArray *users = [rosterClient getCurrentUserInfo:nil onSuccess:^(id list) {
        onSuccess(list);
    } onFailure:^(NSError *error) {
        NSLog(@"Unable to get users %@",error);
        onFailure(error);
    }];
    
    
    return users;
    
}
*/

#pragma mark - Fetch vCard Coredata/Network
- (void)fetchvCardOfUsers:(NSArray *)users{
    id <CMOUserClient>client = [_coreComponents userService];
    for (CMORoster *roster in users){
        [client fetchUservCard:roster.username];
    }
}


#pragma mark - Fetch Roster from Coredata
//Note: Rosters will be saved in db once we logged in. We always fetch from XMPPUserCoreDataStorageObject DB.

- (void)sendBuddyRequestOrPresence:(NSArray *)users{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    
    if (!rosterClient){
        rosterClient = [_coreComponents rosterService];
    }
    
    //Condition: Fetch all XMPPRoster and addToBuddyList if the subscription type of fetched user is none, else sendPresence to the user. If subscription type is 'both', then the user is already subscribed to each other. so do nothing.
    NSArray *rosters = [repositoryClient filterRostersFromXMPPRoster];
    for (XMPPUserCoreDataStorageObject *roster in rosters){
        /*if ([roster.subscription isEqualToString:@"none"]) {
            [rosterClient addBuddyOrSendPresence:[roster.jid user] toAdd:false];
        }*/
        if ([roster.subscription isEqualToString:@"from"] || [roster.subscription isEqualToString:@"to"]){
            [rosterClient addBuddyOrSendPresence:[roster.jid user] toAdd:false]; //Send Subscription
        }
        else{
            //DO Nothing
            //////DDLogInfo(@"User has subscription type 'both'");
        }
    }
    
    // Compare Users List and XMPP Rosters List for new set of users. If any, then send addBuddy Request to add it to your roster
    NSArray *nonRosters = [repositoryClient filterNonRostersfromAllUser];
    for (CMORoster *roster in nonRosters){
        [rosterClient addBuddyOrSendPresence:roster.username toAdd:true];
       // [rosterClient addBuddyOrSendPresence:roster.username toAdd:false];
    }
}

- (void)addBuddy:(NSString *)newBuddy{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    
    if (!rosterClient){
        rosterClient = [_coreComponents rosterService];
    }
    NSArray *nonRosters = [repositoryClient filterRostersFromXMPPRoster];
    for (XMPPUserCoreDataStorageObject *roster in nonRosters){
        NSLog(@"Non rosters %@",roster.subscription);
        if ([roster.subscription isEqualToString:@"none"]) {
            [rosterClient addBuddyOrSendPresence:newBuddy toAdd:true];
        }
        else if ([roster.subscription isEqualToString:@"from"] || [roster.subscription isEqualToString:@"to"]){
            [rosterClient addBuddyOrSendPresence:newBuddy toAdd:false]; //Send Subscription
        }
        else{
            //DO Nothing
            //////DDLogInfo(@"User has subscription type 'both'");
        }
    }
    
}

/*- (NSArray *)getUsersWithCompletionHandler:(void (^)(id users))onSuccess
                              failure:(void (^)(NSError  *error))onFailure{
    rosterClient = [_coreComponents rosterService];
    NSArray *users = [rosterClient getUsers:nil onSuccess:^(id  _Nullable users) {
        onSuccess(users);
    } onFailure:^(NSError * _Nonnull error) {
        NSLog(@"Error %@",error);
        onFailure(error);
    }];
    return users;

}*/

- (void)getAllUsersWithCompletionHandler:(void (^)(NSArray *items,NSError *error))handler{
    rosterClient = [_coreComponents rosterService];
    [rosterClient fetchRosterswithCompletionHandler:^(NSArray *items,NSError *error) {
        if (error){
            handler(nil,error);
        }
        else{
            handler([self usersFromRosters:items],nil);
        }
    }];
}




//This will return the phone numbers of AD + Exchange users
//eligible users (i.e)participants
- (NSMutableArray *)fetchPhoneNumbersFromSMSUsers:(NSMutableArray *)users{
    NSMutableArray *phoneNumbers = [[NSMutableArray alloc]init];
    if (users.count > 0){
        ////DDLogInfo(@"%@ 1",THIS_METHOD);
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(isSMSUser == true OR isFromExchange == true)"];
        NSArray *rosters = [users filteredArrayUsingPredicate:predicate];
        if (rosters.count > 0){
            ////DDLogInfo(@"%@ 2",THIS_METHOD);
            
            for (CMORoster *roster in rosters){
                if (roster.phoneNumber) {
                    [phoneNumbers addObject:roster.phoneNumber];
                }
            }
            ////DDLogInfo(@"%@ 98",THIS_METHOD);
        }
    }
    ////DDLogInfo(@"%@ 99",THIS_METHOD);
    return phoneNumbers;
}

//This function will return the eligible participants (i.e) App + AD if any, to create a chat.
- (NSArray *)eligibleParticipants:(NSMutableDictionary *)participants sent:(BOOL)messageSent{
    NSMutableArray *contacts = [participants objectForKey:MACROS_CONTACTS];
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (contacts.count > 0){
        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        NSPredicate *predicate = nil;
        if (messageSent){
            ////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
            predicate = [NSPredicate predicateWithFormat:@"isFromExchange != true"];
        }
        else{
            ////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
            predicate = [NSPredicate predicateWithFormat:@"isSMSUser != true AND isFromExchange != true"];
        }
       NSArray *rosters = [contacts filteredArrayUsingPredicate:predicate];
       ////DDLogInfo(@"%@ %@ 98",THIS_METHOD,THIS_FILE);
       return rosters;
    }
    ////DDLogInfo(@"%@ %@ 99",THIS_METHOD,THIS_FILE);
    return nil;
}

- (NSArray *)hasSMSUsers:(NSMutableDictionary *)participants{
    NSMutableArray *contacts = [participants objectForKey:MACROS_CONTACTS];
    if (contacts.count > 0){
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"isSMSUser == true OR isFromExchange == true"];
        NSArray *rosters = [contacts filteredArrayUsingPredicate:predicate];
        return rosters;
    }
    return nil;
}


- (NSArray *)fetchAllUsers{
    id <CMORepositoryClient>client = [_coreComponents repositoryService];
    return [client fetchAllRosters];
}

- (CMORoster *)fetchRoster:(NSString *)name{
    rosterClient = [_coreComponents rosterService];
    return [rosterClient fetchRoster:name];
}

- (CMORosterGroup *)fetchGroupRoster:(NSString *)name{
    rosterClient = [_coreComponents rosterService];
    return [rosterClient fetchGroupRoster:name];
}

- (NSMutableArray *)usersFromRosters:(NSArray *)items{
    NSMutableArray *usersList = nil;
    if(items.count > 0){
        usersList = [[NSMutableArray alloc]init];
    }
    //[item attributeStringValueForName:@"name"];

    for (NSXMLElement *item in items){
        CMOUser *user = [[CMOUser alloc]init];
        if ([item attributeStringValueForName:@"name"] != nil){
            user.name = [item attributeStringValueForName:@"name"];
        }
        if ([item attributeStringValueForName:@"jid"] != nil){
            user.username = [item attributeStringValueForName:@"jid"];
        }
        [usersList addObject:user];
    }
    return usersList;
}

- (void)savePhoneContactRosters
{
    CFErrorRef error = NULL;
    __block ABAddressBookRef addressBook = ABAddressBookCreateWithOptions(NULL, &error);
    
    if (!addressBook) {
        NSLog(@"ABAddressBookCreateWithOptions error: %@", CFBridgingRelease(error));
        [[NSNotificationCenter defaultCenter]postNotificationName:RELOAD_CONTACT_NOTIFICATION object:nil];
        return;
    }
    
    id <CMORepositoryClient> repositoryClient = [_coreComponents repositoryService];
    ABAddressBookRequestAccessWithCompletion(addressBook, ^(bool granted, CFErrorRef error) {
        if (error) {
            NSLog(@"ABAddressBookRequestAccessWithCompletion error: %@", CFBridgingRelease(error));
        }
        
        if (granted) {
            // if they gave you permission, then just carry on
            dispatch_async(dispatch_get_main_queue(), ^{
                //id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
                [repositoryClient savePeopleInAddressBook:addressBook];
                CFRelease(addressBook);
            });
        }
        else{
            [[NSNotificationCenter defaultCenter]postNotificationName:RELOAD_CONTACT_NOTIFICATION object:nil];
        }
        
    });
}



- (NSArray *)getExchangeUsersWithCompletionHandler:(void (^)(id users))onSuccess
                                   failure:(void (^)(NSError  *error))onFailure{
    rosterClient = [_coreComponents rosterService];
    
    NSArray *users = [rosterClient getExchangeServerUsers:nil onSuccess:^(id list) {
        onSuccess(list);
    } onFailure:^(NSError *error) {
        NSLog(@"Unable to get Exchange users %@",error);
        onFailure(error);
    }];
    return users;
}


@end
