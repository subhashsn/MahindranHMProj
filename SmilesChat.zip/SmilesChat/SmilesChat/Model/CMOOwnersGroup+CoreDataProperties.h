//
//  CMOOwnersGroup+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 12/7/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOOwnersGroup+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOOwnersGroup (CoreDataProperties)

+ (NSFetchRequest<CMOOwnersGroup *> *)fetchRequest;

@property (nullable, nonatomic, retain) NSObject *ownerGroup;
@property (nullable, nonatomic, retain) CMORoomDetails *roomInfo;

@end

NS_ASSUME_NONNULL_END
