//
//  CMOMessage.h
//  CMOChat
//
//  Created by Anish on 10/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMPPHeader.h"
#import <JSQMessagesViewController/JSQMessage.h>

/*typedef NS_ENUM(NSInteger, MessageStatus) {
    MessagePending,
    MessageFailed,
    MessageSuccess
};*/
/*
 MessageDelivered,
 MessageRead,
 MessageReceived
 */
@interface CMOMessageBody : NSObject
@property (nonatomic, strong)NSString *body;
@property (nonatomic, strong)NSString *fileName;
@property (nonatomic, strong)NSDate *messageDate;
@property (nonatomic, strong)NSString *messageDateString; //Local Purpose
@property (nonatomic, strong)NSString *messageId;
@property (nonatomic, strong)NSString *mediaItem;
@property (nonatomic, strong)NSString *mediaType;
@property (nonatomic, strong)NSString *slaTime;
@property (nonatomic, strong)NSString *slaFlag;
@property (nonatomic, strong)NSString *isConfidential;
@property (nonatomic, strong)NSString *shouldVisible; //Should Visible to Chairman
@property (nonatomic, strong)NSString *smsUsers;
@end

@interface CMOMessage : JSQMessage


//@property (nonatomic, strong)NSString *attachment;
//@property (nonatomic, strong)NSString *from;
//@property (nonatomic, strong)NSString *to;
@property (nonatomic, strong)NSDate *messageDate;
@property (nonatomic, strong)NSDate *localTimeStamp;
@property (nonatomic, strong)NSDate *remoteTimeStamp;
@property (nonatomic, assign)BOOL isPlaceHolder;
//@property (nonatomic, strong)NSString *fileName;
@property (nonatomic, strong)NSString *elementID;
//@property (nonatomic, strong)NSString *messageTitle;
//@property (nonatomic, strong)NSString *senderImageUrl;
@property (nonatomic, strong)CMOMessageBody *messageBody;
@property (nonatomic, strong)NSString *rawMessage;//handled during did received message
@property (nonatomic, strong)NSString *mediaItem;
@property (nonatomic, strong)NSString *mediaType;

//@property (nonatomic, strong)NSDate *messageDate;
//@property (nonatomic, strong)NSString *targetBareId;
@property (nonatomic, strong)XMPPJID *from;
@property (nonatomic, strong)NSString *userName;
@property (nonatomic, strong)NSString *roomIDStr;
@property (nonatomic, assign)BOOL upload;
@property (nonatomic, assign)BOOL fromMe;
@property (nonatomic, assign)BOOL isOffline;
@property (nonatomic, strong)NSString *statusInString;
@property (nonatomic, assign)BOOL slaFlag;
@property (nonatomic, assign)NSInteger slaTime;
//@property (nonatomic, assign)BOOL isConfidential;
@property (nonatomic, assign)BOOL isErrorMessage;
@property (nonatomic, assign)BOOL isFirstMessage;
@property (nonatomic, assign)MessageDeliveryStatus status;

//@property (nonatomic, strong)NSString *senderType;
//@property (nonatomic, strong)NSString *chatType;
//@property (nonatomic, strong)NSNumber *unreadMessage;
//@property (nonatomic, strong)NSString *senderName;

//- (DDXMLElement *)asXMLElement;

@end
