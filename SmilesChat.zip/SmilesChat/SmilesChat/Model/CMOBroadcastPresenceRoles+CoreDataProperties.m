//
//  CMOBroadcastPresenceRoles+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 11/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOBroadcastPresenceRoles+CoreDataProperties.h"

@implementation CMOBroadcastPresenceRoles (CoreDataProperties)

+ (NSFetchRequest<CMOBroadcastPresenceRoles *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMOBroadcastPresenceRoles"];
}

@dynamic broadcastPresenceRole;
@dynamic roomInfo;

@end
