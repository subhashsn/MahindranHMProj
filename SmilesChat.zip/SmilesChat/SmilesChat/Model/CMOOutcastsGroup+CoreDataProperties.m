//
//  CMOOutcastsGroup+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 12/7/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOOutcastsGroup+CoreDataProperties.h"

@implementation CMOOutcastsGroup (CoreDataProperties)

+ (NSFetchRequest<CMOOutcastsGroup *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMOOutcastsGroup"];
}

@dynamic outcastGroup;
@dynamic roomInfo;

@end
