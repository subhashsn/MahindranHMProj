//
//  CMORoster+CoreDataProperties.h
//  CMOChat
//
//  Created by Amit Kumar on 12/05/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMORoster+CoreDataClass.h"
#import "CMOUserRoles+CoreDataClass.h"
#import "CMOUserPermissions+CoreDataClass.h"

NS_ASSUME_NONNULL_BEGIN

@interface CMORoster (CoreDataProperties)

+ (NSFetchRequest<CMORoster *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *companyName;
@property (nullable, nonatomic, copy) NSString *email;
@property (nullable, nonatomic, copy) NSString *exchangeID;
@property (nonatomic) BOOL isFromExchange;
@property (nonatomic) BOOL isPhoneContact;
@property (nonatomic) BOOL isSMSUser;
@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *phoneNumber;
@property (nullable, nonatomic, retain) NSObject *properties;
@property (nullable, nonatomic, copy) NSString *subscription;
@property (nullable, nonatomic, copy) NSString *username;
@property (nullable, nonatomic, copy) NSString *nicname;
@property (nullable, nonatomic, copy) NSString *userType;
@property (nullable, nonatomic, copy) NSNumber *smsGroupType;
@property (nullable, nonatomic, retain) CMOUserPermissions *userPermission;
@property (nullable, nonatomic, retain) CMOUserRoles *userRoles;

@end

NS_ASSUME_NONNULL_END
