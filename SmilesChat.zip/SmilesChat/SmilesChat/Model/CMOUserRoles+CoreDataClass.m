//
//  CMOUserRoles+CoreDataClass.m
//  CMOChat
//
//  Created by Administrator on 11/24/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOUserRoles+CoreDataClass.h"
#import "CMORoster+CoreDataClass.h"

@implementation CMOUserRoles

@end
