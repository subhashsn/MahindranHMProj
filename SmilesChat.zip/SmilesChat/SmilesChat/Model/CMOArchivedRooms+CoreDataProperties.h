//
//  CMOArchivedRooms+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOArchivedRooms+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOArchivedRooms (CoreDataProperties)

+ (NSFetchRequest<CMOArchivedRooms *> *)fetchRequest;

@property (nonatomic) int32_t messageCount;
@property (nullable, nonatomic, copy) NSString *roomName;

@end

NS_ASSUME_NONNULL_END
