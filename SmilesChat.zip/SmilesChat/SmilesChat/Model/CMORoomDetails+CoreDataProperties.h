//
//  CMORoomDetails+CoreDataProperties.h
//  CMOChat
//
//  Created by Amit Kumar on 13/04/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMORoomDetails+CoreDataClass.h"
#import "CMOMembersGroup+CoreDataClass.h"
#import "CMOOwnersGroup+CoreDataClass.h"
#import "CMOOutcastsGroup+CoreDataClass.h"
#import "CMORoomProperty+CoreDataClass.h"

NS_ASSUME_NONNULL_BEGIN

@interface CMORoomDetails (CoreDataProperties)

+ (NSFetchRequest<CMORoomDetails *> *)fetchRequest;

//@property (nonatomic) BOOL archived;
@property (nullable, nonatomic, copy) NSString *canAnyoneDiscoverJID;
@property (nullable, nonatomic, copy) NSString *canChangeNickname;
@property (nullable, nonatomic, copy) NSString *canOccupantsChangeSubject;
@property (nullable, nonatomic, copy) NSString *canOccupantsInvite;
//@property (nonatomic) BOOL confidential;
@property (nullable, nonatomic, copy) NSDate *creationDate;
//@property (nonatomic) BOOL deleted;
//@property (nonatomic) BOOL isJoined;
//@property (nonatomic) BOOL isRoomDeleted;
//@property (nullable, nonatomic, copy) NSDate *lastMsgDate;
@property (nullable, nonatomic, copy) NSString *logEnabled;
@property (nullable, nonatomic, copy) NSString *loginRestrictedToNickname;
@property (nullable, nonatomic, copy) NSString *maxUsers;
@property (nullable, nonatomic, copy) NSString *membersOnly;
@property (nullable, nonatomic, copy) NSString *moderated;
@property (nullable, nonatomic, copy) NSDate *modificationDate;
@property (nullable, nonatomic, copy) NSString *naturalName;
@property (nullable, nonatomic, copy) NSString *persistent;
@property (nullable, nonatomic, copy) NSString *publicRoom;
//@property (nonatomic) int64_t readMessageCount;
@property (nullable, nonatomic, copy) NSString *registrationEnabled;
@property (nullable, nonatomic, copy) NSString *roomDescription;
@property (nullable, nonatomic, copy) NSString *roomName;
@property (nullable, nonatomic, copy) NSString *roomSubject;
//@property (nonatomic) BOOL slaClosed;
//@property (nonatomic) BOOL slaEnabled;
//@property (nonatomic) int64_t slaRemainingTime;
//@property (nonatomic) int64_t slaTime;
//@property (nonatomic) int64_t totalMessageCount;
@property (nullable, nonatomic, copy) NSString *roomOwner;
@property (nullable, nonatomic, retain) CMOAdmins *admins;
@property (nullable, nonatomic, retain) CMOBroadcastPresenceRoles *broadcastPresence;
@property (nullable, nonatomic, retain) CMOMembers *members;
@property (nullable, nonatomic, retain) CMOMembersGroup *membersGroup;
@property (nullable, nonatomic, retain) CMOOutcastsGroup *outcastsGroup;
@property (nullable, nonatomic, retain) CMOOwners *owners;
@property (nullable, nonatomic, retain) CMOOwnersGroup *ownersGroup;
@property (nullable, nonatomic, retain) CMORoomProperty *roomProperty;

@end

NS_ASSUME_NONNULL_END
