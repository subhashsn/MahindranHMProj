//
//  CMOVersionInfo.h
//  CMOChat
//
//  Created by Raju on 4/18/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CMOVersionInfo : NSObject

@property (nonatomic, strong)NSString *appVersion;
@property (nonatomic, strong)NSString *downloadUrl;
@property (nonatomic, assign)BOOL forceUpdate;
@property (nonatomic, assign)NSInteger releaseDate;
@property (nonatomic, assign)NSInteger forceUpdateBy;
@property (nonatomic, strong)NSString *lastSupportedVersionCode;

@end
