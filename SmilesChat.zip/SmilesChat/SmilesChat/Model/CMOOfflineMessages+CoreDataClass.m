//
//  CMOOfflineMessages+CoreDataClass.m
//  CMOChat
//
//  Created by Administrator on 11/10/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOOfflineMessages+CoreDataClass.h"

@implementation CMOOfflineMessages

@end
