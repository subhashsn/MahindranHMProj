//
//  CMOOwners+CoreDataProperties.m
//  CMOChat
//
//  Created by Administrator on 11/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOOwners+CoreDataProperties.h"

@implementation CMOOwners (CoreDataProperties)

+ (NSFetchRequest<CMOOwners *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CMOOwners"];
}

@dynamic owner;
@dynamic roomInfo;

@end
