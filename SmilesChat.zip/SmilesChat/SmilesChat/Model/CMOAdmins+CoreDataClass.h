//
//  CMOAdmins+CoreDataClass.h
//  CMOChat
//
//  Created by Administrator on 11/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class CMORoomDetails, NSObject;

NS_ASSUME_NONNULL_BEGIN

@interface CMOAdmins : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "CMOAdmins+CoreDataProperties.h"
