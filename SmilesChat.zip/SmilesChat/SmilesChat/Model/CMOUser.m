//
//  CMOUser.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOUser.h"

@implementation Users

@end

@implementation CMOUser

@end
