//
//  CMORoomPresentation.h
//  CMOChat
//
//  Created by Administrator on 4/5/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CMOCoreComponents;
@class CMOMessageParam;
@class CMOMessage;
@class CMORoomDetails;

@interface CMORoomPresentation : NSObject

@property (nonatomic, strong)CMOCoreComponents *coreComponents;

- (void)createRoomWithMessage:(CMOMessage *)message
                 participants:(NSMutableDictionary *)roomParticipants
                    onSuccess:(void (^)(id result, CMOMessage *message))success
                    onFailure:(void (^)(NSError *error))failure;

- (void)inviteUsersToJoinTheRoom:(id)user
                         forRoom:(NSString *)roomName
                 withAffiliation:(Affiliation)affiliation;


- (void)addGroups:(NSMutableArray *)groups
       toChatRoom:(NSString *)roomId
        onSuccess:(void (^)(id response))success
        onFailure:(void (^)(NSError *error))failure;

- (void)joinToRoom:(CMORoomDetails *)roomId
           history:(NSDate *)date
         onSuccess:(void (^)(BOOL result))success
         onFailure:(void (^)(NSError *error))failure;

- (CMORoomDetails *)retreiveChatRoom:(NSString *)roomId
                           onSuccess:(void (^)(id result))success
                           onFailure:(void (^)(NSError *error))failure;


- (void)getAllRooms:(NSString *)user
          onSuccess:(void (^)(id result))success
          onFailure:(void (^)(NSError *error))failure;

- (BOOL)shouldRoomToBeCreated:(NSString *)roomId;

- (BOOL)isJoinedInRoom:(NSString *)roomId;

- (void)updateRoomInfo:(NSString *)roomId withLastMessageDate:(NSDate *)date;

@end
