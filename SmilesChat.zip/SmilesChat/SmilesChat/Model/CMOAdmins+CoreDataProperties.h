//
//  CMOAdmins+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 11/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOAdmins+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOAdmins (CoreDataProperties)

+ (NSFetchRequest<CMOAdmins *> *)fetchRequest;

@property (nullable, nonatomic, retain) NSObject *admins;
@property (nullable, nonatomic, retain) CMORoomDetails *roomInfo;

@end

NS_ASSUME_NONNULL_END
