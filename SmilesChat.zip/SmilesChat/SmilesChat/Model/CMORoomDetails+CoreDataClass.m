//
//  CMORoomDetails+CoreDataClass.m
//  CMOChat
//
//  Created by Administrator on 11/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMORoomDetails+CoreDataClass.h"
#import "CMOAdmins+CoreDataProperties.h"
#import "CMOBroadcastPresenceRoles+CoreDataProperties.h"
#import "CMOMembers+CoreDataProperties.h"
#import "CMOOwners+CoreDataProperties.h"


@implementation CMORoomDetails

@end
