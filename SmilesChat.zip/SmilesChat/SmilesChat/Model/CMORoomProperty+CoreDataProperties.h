//
//  CMORoomProperty+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 2/10/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMORoomProperty+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMORoomProperty (CoreDataProperties)

+ (NSFetchRequest<CMORoomProperty *> *)fetchRequest;

@property (nonatomic) BOOL isChatHidden;
@property (nonatomic) BOOL isOffline;
@property (nonatomic) BOOL isAnyMessageOffline;
@property (nonatomic) BOOL isUploadProgress;
@property (nonatomic) BOOL isEligibleToJoin;
@property (nonatomic) NSString *smsUsers;
@property (nonatomic) NSDate *firstMessageDate;
@property (nonatomic) id groups;
@property (nullable, nonatomic, retain) CMORoomProperty *roomDetails;

@end

NS_ASSUME_NONNULL_END
