//
//  CMOGroupMembers+CoreDataProperties.h
//  CMOChat
//
//  Created by Amit Kumar on 10/12/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOGroupMembers+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOGroupMembers (CoreDataProperties)

+ (NSFetchRequest<CMOGroupMembers *> *)fetchRequest;

@property (nullable, nonatomic, retain) NSObject *members;
@property (nullable, nonatomic, retain) CMORosterGroup *rosterGroup;

@end

NS_ASSUME_NONNULL_END
