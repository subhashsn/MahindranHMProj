//
//  CMOGroupMembers+CoreDataClass.h
//  CMOChat
//
//  Created by Amit Kumar on 10/12/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class CMORosterGroup, NSObject;

NS_ASSUME_NONNULL_BEGIN

@interface CMOGroupMembers : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "CMOGroupMembers+CoreDataProperties.h"
