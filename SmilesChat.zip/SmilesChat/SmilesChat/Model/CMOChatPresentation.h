//
//  CMOChatPresentation.h
//  CMOChat
//
//  Created by Administrator on 10/24/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CMOChatClient.h"

@class CMOMessage;
@class CMORoomInfo;
@class CMOCoreComponents;
@class CMORoomDetails;
@class CMOMessageReadStatus;
@class XMPPRoomMessageCoreDataStorageObject;
@class CMOMessageCount;
@class CMOArchivedRooms;
@class CMOMessageParam;
@class CMOOfflineMessages;

@protocol ChatPresentationDelegate <NSObject>

- (void)didReceiveMessage:(CMOMessage *)message;

@end

@interface CMOChatPresentation : NSObject <ChatPresentationDelegate>

//If message is not received, check this property as it is a weak reference. Usually typhoon should take care of this reference.
@property (nonatomic, strong) id <ChatPresentationDelegate>chatPresentationDelegate;

@property (nonatomic, strong)CMOCoreComponents *coreComponents;

@property (nonatomic, strong)NSString *domainName;

@property (nonatomic, strong)NSString *conferenceURL;

- (instancetype)initWithService:(id<CMOChatClient>)service;

- (void)sendMessage:(CMOMessage *)message roomId:(NSString *)roomID
  completionHandler:(void (^)(XMPPMessage *message,NSError *error))handler;

//- (void)startRoom;

- (void)createOrJoinRoom:(CMORoomDetails *)roomJID userstoInvite:(id)users history:(NSString *)date completionHandler:(void (^)(BOOL result, NSError *error))handler;

//- (void)createRoom:(CMORoomInfo *)roomInfo participants:(id)pariticipants onSuccess:(void (^)(id result))success
//         onFailure:(void (^)(NSError *error))failure;

- (void)inviteUsersToJoinTheRoom:(id)user forRoom:(NSString *)roomName withAffiliation:(Affiliation)affiliation;

- (void)leaveRoom;

//- (void)addGroupsToRoom:(NSArray *)groups forRoom:(NSString *)roomId;

- (void)addUser:(NSString *)userName toChatRoom:(NSString *)roomId onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;

- (CMORoomDetails *)retreiveChatRoom:(NSString *)roomId onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;

- (void)removeUser:(NSString *)userId fromChatRoom:(NSString *)roomId onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;

//- (void)addGroup:(NSString *)groupId toChatRoom:(NSString *)roomId onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;

- (NSArray *)getRooms:(NSString *)user completionHandler:(void (^)(NSArray *items,NSError *error))handler;

- (NSArray *)getRoomDetailsAndMessages:(NSString *)user completionHandler:(void (^)(NSArray *items,NSError *error))handler;

- (NSArray *)fetchAllRooms;

- (NSArray *)fetchRoomsForArchivedStatus:(BOOL)archived;

- (NSArray *)getActiveChatRooms;

- (CMORoomDetails *)fetchRoomInfo:(NSString *)roomID;

- (void)setSubject:(NSString *)roomSubject forRoom:(NSString *)roomJID;

- (void)sendChatStatus:(NSString *)roomID status:(ChatTypStatus)status;


- (BOOL)isAppUserExist:(CMORoomDetails *)roomDetail;

- (NSMutableArray *)clubOwnersAndMembers:(CMORoomDetails *)roomInfo;

- (NSArray *)getMessagesOfCurrentRoom:(id)target;

- (NSMutableArray *)getMessagesForRoom:(NSString *)roomId delegate:(id)target messagesDict:(NSMutableDictionary *)dict;

- (BOOL)isUserAllowedToJoin:(NSString *)userName roomInfo:(CMORoomDetails *)roomInfo isConfidential:(BOOL)isConfidential;

- (NSArray *)getArchivedRooms;

- (CMOArchivedRooms *)getArchivedRoom:(NSString *)roomId;

- (void)markRoomArchived:(NSString*)roomId unreadCount:(NSInteger)msgCount;

- (void)markRoomUnarchived:(NSString*)roomId;

- (BOOL)isRoomArchived:(NSString*)roomId;

- (void)saveVisitedRoom:(NSString *)roomName count:(int32_t)count;

- (NSInteger)getRoomCountFromVisitedRoom:(NSString *)roomName;

- (void)saveRoomMessageHiddenStatus:(NSString *)roomId shouldHide:(BOOL)shouldHide;

- (void)saveSmsusersToChatRoom:(NSMutableArray *)participants roomId:(NSString *)roomId;

- (BOOL)isRoomMessageHidden:(NSString *)roomId;

- (NSArray *)filterRoomsbySMSUser:(NSString *)userName;

- (void)saveDocumentUploadStatusForRoom:(NSString *)roomId inprogress:(BOOL)status;

- (BOOL)documentUploadStatusOfRoom:(NSString *)roomId;

- (void)updateArchiveStatus:(BOOL)isArchived toRoom:(CMORoomDetails *)roomDetail;

- (void)updateDocumentUploadStatusOfAllRooms;

- (NSInteger)indexOfSelectedRoomList:(NSArray *)roomList name:(NSString *)roomName;

- (void)uploadDocumentWithMessage:(CMOMessage *)message
                             data:(id)documentData
                       OnProgress:(void (^)(id progress))onProgress
                        onSuccess:(void (^)(id result))success
                        onFailure:(void (^)(NSError *error))failure;

- (void)downloadDocument:(NSString *)documentName
              OnProgress:(void (^)(id progress))onProgress
               onSuccess:(void (^)(id result))success
               onFailure:(void (^)(NSError *error))failure;



- (void)updateSyncDataonSuccess:(void (^)(id result))success
                      onFailure:(void (^)(NSError *error))failure;

- (NSString *)getDocumentFilePath:(NSString *)roomId fileName:(NSString *)fileName;

- (void)saveDocument:(NSString *)documentName docData:(id)docData roomID:(NSString *)roomID;

- (id)getDocument:(NSString *)documentName roomID:(NSString *)roomID;

- (BOOL) deleteDocument:(NSString *)documentName roomID:(NSString *)roomID;

- (CMOMessage *)getUpdatedDateMessage:(CMOMessage *)message delegate:(id)target;

- (void)updateMessageOfflineDate:(CMOMessage *)message;

- (void)saveMessageOffline:(CMOMessage *)message;

- (NSArray *)getOfflineCMOMessages:(NSArray *)coreDataMessages delegate:(id)target;

- (NSArray *)getOfflineMessageOfRoom:(NSString *)roomID delegate:(id)target messagesDict:(NSMutableDictionary *)dict;

- (NSArray *)getOfflineMessagesOfRoom:(NSString *)roomId;

- (NSInteger)getOfflineMessageCountOfRoom:(NSString *)roomId;


- (BOOL)isOfflineMessage:(CMOMessage *)message;

- (void)removeOfflineMessage:(CMOMessage *)message;

- (void)removeXMPPMessages:(NSArray *)messages;

- (CMOMessage *)getMessage:(CMOMessage *)message sender:(NSString *)user messages:(NSMutableArray *)messages;

//- (NSTimeInterval)calculateSLATime:(CMOMessage *)message forRoom:(NSString *)roomId;

- (BOOL)isMessageAvailableOtherThanOwnerOfRoom:(NSString *)roomId;

- (NSMutableArray *)sortCMOMessages:(NSArray *)messages ascending:(BOOL)ascending;

//- (NSArray *)getCMOMessages:(NSArray *)coreDataMessages delegate:(id)target;

- (NSString *)getFormattedMessageBody:(CMOMessageBody *)messageBody fromMe:(BOOL)fromMe;

- (NSInteger)getMessageCountForRoom:(NSString *)roomId;

- (NSArray *)filterMessagesByVisiblity:(BOOL)show message:(NSArray *)messages;

- (BOOL)shouldProvideHideShowOption;

- (void)getUnReadMessagesCountOfAllRoomsonSuccess:(void (^)(id result))success
                                        onFailure:(void (^)(NSError *error))failure;

- (CMOMessageCount *)getMessageInfoForRoom:(NSString *)roomId messagesInfoArray:(NSArray *)messagesInfo;

- (NSString *)getFilePath:(NSString *)fileName roomId:(NSString *)roomId;

#pragma mark Draft Messages
- (void)saveDraftMessage:(NSString *)message forRoom:(NSString *)roomId;

- (NSString *)fetchDraftMessagesForRoom:(NSString *)roomId;

#pragma mark Construct CMOMessage - New Methods

- (CMOMessageParam *)constructMessageParamFromOffline:(CMOOfflineMessages *)offlineMessage;

- (CMOMessageParam *)constructMessageParamFromXMPP:(XMPPRoomMessageCoreDataStorageObject *)xmppMessage;

- (CMOMessage *)constructMessage:(CMOMessageParam *)param target:(id)target messagesDict:(NSMutableDictionary *)dict;

- (CMOMessageBody *)messageBodyFromJson:(NSString *)messageString;

- (NSData *)mediaItemFromMessage:(CMOMessage *)message;

- (BOOL)isConnectedToXMPP;

#pragma mark Save Message Read Status
- (void)saveMessageReadStatus:(BOOL)didReadMessage unReadCount:(int)count forRoom:(NSString *)roomId;

- (BOOL)isMessageReadForRoom:(NSString *)roomId;

- (int)unReadMessageCountForRoom:(NSString *)roomId;

- (NSArray *)unReadMessagesOfAllRooms;

- (CMOMessageReadStatus *)getUnReadMessageForRoom:(NSString *)roomId;

- (BOOL)isMessageAlreadyExist:(XMPPRoomMessageCoreDataStorageObject *)message;

- (NSMutableDictionary *)getRoomParticipants:(CMORoomDetails *)roominfo;

- (NSString *)smsusersFromParticipants:(NSMutableArray *)participants;

- (NSString*_Nullable)getUsernameForNicname:(NSString *_Nonnull)nicname;

@end
