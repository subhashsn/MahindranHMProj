//
//  CMOUserPermissions+CoreDataProperties.h
//  CMOChat
//
//  Created by Administrator on 11/28/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOUserPermissions+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMOUserPermissions (CoreDataProperties)

+ (NSFetchRequest<CMOUserPermissions *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *addRecipientInAnOngoingChat;
@property (nullable, nonatomic, copy) NSString *canBlockAndProvideAccessToUsers;
@property (nullable, nonatomic, copy) NSString *canConfigureReminderTimeAndFrequency;
@property (nullable, nonatomic, copy) NSString *canCreateGroups;
@property (nullable, nonatomic, copy) NSString *canDeleteRecipients;
@property (nullable, nonatomic, copy) NSString *canDeleteUsers;
@property (nullable, nonatomic, copy) NSString *canSetConfidentiality;
@property (nullable, nonatomic, copy) NSString *canSetSlaTime;
@property (nullable, nonatomic, copy) NSString *chatInitiation;
@property (nullable, nonatomic, copy) NSString *conversationHistoryAvailable;
@property (nonatomic) int16_t permissionId;
@property (nullable, nonatomic, retain) CMORoster *users;

@end

NS_ASSUME_NONNULL_END
