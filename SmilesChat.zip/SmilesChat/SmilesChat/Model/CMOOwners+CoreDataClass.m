//
//  CMOOwners+CoreDataClass.m
//  CMOChat
//
//  Created by Administrator on 11/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOOwners+CoreDataClass.h"
#import "CMORoomDetails+CoreDataProperties.h"
@implementation CMOOwners

@end
