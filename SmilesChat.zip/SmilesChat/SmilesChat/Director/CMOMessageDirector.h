//
//  CMOMessageDirector.h
//  CMOChat
//
//  Created by Administrator on 10/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CMOMessageBuilder.h"

@interface CMOMessageDirector : NSObject

- (instancetype)initWithMessageBuilder:(CMOMessageBuilder *)builder;

@end
