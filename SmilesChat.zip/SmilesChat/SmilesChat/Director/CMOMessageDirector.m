//
//  CMOMessageDirector.m
//  CMOChat
//
//  Created by Administrator on 10/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOMessageDirector.h"
#import "CMOMessage.h"

@interface CMOMessageDirector(){
    CMOMessageBuilder *messageBuilder;
}

@end

@implementation CMOMessageDirector

- (instancetype)initWithMessageBuilder:(CMOMessageBuilder *)builder
{
    self = [super init];
    if (self) {
        messageBuilder = builder;
    }
    return self;
}


- (CMOMessage *)getMessage{
    return [messageBuilder getMessage];
}

- (XMPPMessage *)build{
    return [messageBuilder build];
}


@end
