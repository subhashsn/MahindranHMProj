//
//  CMOInitilize.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOInitilize.h"

@implementation CMOInitilize


+ (void)initialize {
    
}

@end
