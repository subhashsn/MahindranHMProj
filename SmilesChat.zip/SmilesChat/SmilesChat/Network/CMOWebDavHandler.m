//
//  CMOWebDavHandler.m
//  CMOChat
//
//  Created by Amit Kumar on 14/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOWebDavHandler.h"
#import "CMOConstant.h"
#import "CMOCoreComponents.h"
#import "CMOUtils.h"
#import <AZSClient/AZSClient.h>

typedef enum {
    CMOWebDAVPropertyCreationDate = 1,
    CMOWebDAVPropertyLastModifiedDate = 2,
    CMOWebDAVPropertyDisplayName = 4,
    CMOWebDAVPropertyContentLength = 8,
    CMOWebDAVPropertyContentType = 16,
    CMOWebDAVPropertyCommonProperties = 31,
    CMOWebDAVPropertyETag = 32,
    CMOWebDAVPropertySupportedLock = 64,
    CMOWebDAVPropertyLockDiscovery = 128,
    CMOWebDAVPropertyAllProperties = 4095
} CMOWebDAVProperties;

static const NSUInteger kWebDAVProperty =   4095;

@implementation CMOWebDavHandler

- (instancetype)init
{
    self = [self initWithSessionConfiguration:nil];
    if (self) {
        
    }
    return self;
}

- (instancetype)initWithSessionConfiguration:(NSURLSessionConfiguration *)configuration
{
    if (!configuration){
        configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
        configuration.timeoutIntervalForRequest = 600.0;
    }
    self = [super initWithSessionConfiguration:configuration];
    if (self) {
        
//        [[self requestSerializer] setAuthorizationHeaderFieldWithUsername:DOTCMS_USER password:[CMOUtils getCMSPassword]];
        [[self requestSerializer] setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        //[[self requestSerializer] setValue:@"application/json" forHTTPHeaderField:@"content-type"];
         self.responseSerializer = [AFHTTPResponseSerializer serializer];
        
        
    }
    return self;
}

- (NSString *)baseURL{
//    NSDictionary *dict = [CMOUtils appConfigurations];
//    return [NSString stringWithFormat:@"%@%@/",dict[@"ofbaseurl"],dict[@"apiversion"]];
  //  return DOTCMS_BASEURL;
    return DOMAIN_URL;
}

#pragma mark PUT

- (void)putPath:(NSString * _Nonnull )path
     parameters:( nullable id )parameters
           data:(NSData * _Nonnull )data
       mimeType:(NSString * _Nonnull )mimeType
     OnProgress:(APIProgress _Nullable )progress
      OnSuccess:(APIResponseSuccess _Nullable )responseBlock
      onFailure:(APIResponseFailed _Nonnull )failureBlock {
    
    NSError *accountCreationError;
    
    // Create a storage account object from a connection string.
    AZSCloudStorageAccount *account = [AZSCloudStorageAccount accountFromConnectionString:@"DefaultEndpointsProtocol=https;AccountName=smileschat;AccountKey=9DqlpTXHrQD5ASJieP64J91VQXibBLvIynB1DEg8Mh1HjXCd1k32X+jjHRySsSTePezGqJQSOC1uabk4vl7KnA==" error:&accountCreationError];
    
    if(accountCreationError){
        NSLog(@"Error in creating account.");
    }
    
    // Create a blob service client object.
    AZSCloudBlobClient *blobClient = [account getBlobClient];
    
    // Create a local container object.
    AZSCloudBlobContainer *blobContainer = [blobClient containerReferenceFromName:CONTAINER_NAME];
    
    NSRange range = NSMakeRange(0,1);
    
    NSString *newPath = [path stringByReplacingCharactersInRange:range withString:@""];
    
   // NSString *blobname = [NSString stringWithFormat:@"%@",newPath];
    NSString *thumbimageblobname = [NSString stringWithFormat:@"thumb_%@",newPath];
    
    [blobContainer createContainerIfNotExistsWithAccessType:AZSContainerPublicAccessTypeContainer requestOptions:nil operationContext:nil completionHandler:^(NSError *error, BOOL exists)
     {
         if (error){
             NSLog(@"Error in creating container.");
         }
         else{
             // Create a local blob object
             AZSCloudBlockBlob *blockBlob = [blobContainer blockBlobReferenceFromName:thumbimageblobname];
             
             // Upload blob to Storage
             [blockBlob uploadFromData:data completionHandler:^(NSError *error) {
                 if (error){
                     NSLog(@"Error in creating blob.");
                     if (failureBlock) {
                         failureBlock(error);
                     }
                 }else {
                     if (responseBlock) {
                         responseBlock(@"Success");
                     }
                 }
             }];
         }
     }];
    
    
    
//    NSString *containerStr = [NSString stringWithFormat:@"%@%@?%@",DOMAIN_URL,CONTAINER_NAME,SAS_URL];
//    NSURL *containerurl = [NSURL URLWithString:containerStr];
//    NSError *error = nil;
//    AZSCloudBlobContainer *container = [[AZSCloudBlobContainer alloc] initWithUrl:containerurl error:&error];
//    if(error != nil) {
//        NSLog(@"Connection failed for the reason %@", error.description);
//    }
//
//
//
//    AZSCloudBlockBlob *blob = [container blockBlobReferenceFromName:blobname];
//
//    [blob uploadFromData:data completionHandler:^(NSError * error) {
//        if (error != nil) {
//            NSLog(@"Error While Uploading %@",error.description);
//            if (failureBlock) {
//                failureBlock(error);
//            }
//        }else {
//
//            UIImage * thumbImage = [UIImage imageWithData:data];
//            UIImage *scaledImage = [self imageWithImage:thumbImage scaledToSize:thumbImage.size];
//            NSData *scaledData = UIImageJPEGRepresentation(scaledImage, 0.3);
//
//            AZSCloudBlockBlob *thumbblob = [container blockBlobReferenceFromName:thumbimageblobname];
//
//            [thumbblob uploadFromData:scaledData completionHandler:^(NSError * error) {
//                if (error != nil) {
//                    NSLog(@"Error While Uploading %@",error.description);
//                    if (failureBlock) {
//                        failureBlock(error);
//                    }
//                }else {
//                    if (responseBlock) {
//                        responseBlock(@"Success");
//                    }
//                }
//            }];
//        }
//    }];
    
//    [[self requestSerializer] setAuthorizationHeaderFieldWithUsername:DOTCMS_USER password:[CMOUtils getCMSPassword]];
//    
//    NSString *apiURL = [[NSString stringWithFormat:@"%@%@",[self baseURL],path] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    NSURLRequest *request = [self requestWithMethod:@"PUT" URLString:apiURL parameters:parameters data:data mimeType:mimeType];
//    NSURLSessionDataTask *dataTask = [self dataTaskWithRequest:request uploadProgress:progress downloadProgress:nil completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
//        if (error) {
//            NSDictionary *errorInfo = error.userInfo;
//            NSInteger statusCode = [[errorInfo objectForKey:AFNetworkingOperationFailingURLResponseErrorKey] statusCode];
//            NSLog(@"Error code = %ld",(long)statusCode);
//            if (statusCode == 401 ) {
//                //password changed. get new password
//                [CMOUtils getCMSPasswordFromServer:[_coreComponents appServerAPIHandler]];
//            }
//            if (failureBlock) {
//                failureBlock(error);
//            }
//        } else {
//            NSString *date = ((NSHTTPURLResponse *)response).allHeaderFields[@"Date"];
//            [CMOUtils saveServerTime:date];
//
//            if (responseBlock) {
//                responseBlock(responseObject);
//            }
//        }
//        
//    }];
//    [dataTask resume];
}


- (UIImage*)imageWithImage:(UIImage*)image
              scaledToSize:(CGSize)newSize;
{
    UIGraphicsBeginImageContext( newSize );
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}


-(NSMutableURLRequest*)requestWithMethod:(NSString *)method
                               URLString:( NSString * _Nonnull )URLString
                              parameters:(NSDictionary *)parameters
                                    data:(NSData*)data
                                mimeType:(NSString*)dataMimeType
{
    NSMutableURLRequest* request = [self.requestSerializer requestWithMethod:method URLString:URLString parameters:parameters error:nil];
    NSString *len = [NSString stringWithFormat:@"%d", [data length]];
    [request setValue:len forHTTPHeaderField:@"Content-Length"];
    [request setValue:dataMimeType forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"keep-alive" forHTTPHeaderField:@"Connection"];
    [request setHTTPBody:data];
    
    return request;
}

#pragma mark MKCOL
- (void)makeCollection:(NSString * _Nonnull )path
     parameters:( nullable id )parameters
      onSuccess:(APIResponseSuccess _Nullable )responseBlock
      onFailure:(APIResponseFailed _Nonnull )failureBlock {
    [[self requestSerializer] setAuthorizationHeaderFieldWithUsername:DOTCMS_USER password:[CMOUtils getCMSPassword]];

    NSString *apiURL = [NSString stringWithFormat:@"%@%@",[self baseURL],path];
    NSMutableURLRequest* request = [self.requestSerializer requestWithMethod:@"MKCOL" URLString:apiURL parameters:parameters error:nil];
    [request setValue:@"text/xml" forHTTPHeaderField:@"Content-Type"];

    NSURLSessionDataTask *dataTask = [self dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        if (error) {
            if (failureBlock) {
                failureBlock(error);
            }
        } else {
            if (responseBlock) {
                responseBlock(responseObject);
            }
        }
        
    }];
    [dataTask resume];
}

#pragma mark PROPFIND
- (void)getProperty:(NSString * _Nonnull )path
         parameters:( nullable id )parameters
          onSuccess:(APIResponseSuccess _Nullable )responseBlock
          onFailure:(APIResponseFailed _Nonnull )failureBlock {
    [[self requestSerializer] setAuthorizationHeaderFieldWithUsername:DOTCMS_USER password:[CMOUtils getCMSPassword]];

    NSString *apiURL = [NSString stringWithFormat:@"%@%@",[self baseURL],path];
    NSMutableURLRequest* request = [self.requestSerializer requestWithMethod:@"PROPFIND" URLString:apiURL parameters:parameters error:nil];
    [request setValue:[NSString stringWithFormat:@"%d",1] forHTTPHeaderField:@"Depth"];
    [request setValue:@"application/xml" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"close" forHTTPHeaderField:@"Connection"];
    [request setHTTPBody:[self generateBody]];
    
    self.responseSerializer.acceptableContentTypes = [self.responseSerializer.acceptableContentTypes setByAddingObjectsFromSet:[NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"video/mpeg",@"application/xml", nil]];
    ;
    
    NSURLSessionDataTask *dataTask = [self dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        if (error) {
            if (failureBlock) {
                failureBlock(error);
            }
        } else {
            if (responseBlock) {
                responseBlock(responseObject);
            }
        }
        
    }];
    [dataTask resume];
    
    
}

#pragma mark GET
- (void)get:(NSString * _Nonnull )URLString parameters:( nullable id )parameters
 OnProgress:(APIProgress _Nonnull)progress
  OnSuccess:(APIResponseSuccess _Nullable)responseBlock
  onFailure:(APIResponseFailed _Nonnull)failureBlock {
    
   // [[self requestSerializer] setAuthorizationHeaderFieldWithUsername:DOTCMS_USER password:[CMOUtils getCMSPassword]];
    URLString = [NSString stringWithFormat:@"%@%@",IMAGE_PATH,URLString];
    NSString *apiURL = [NSString stringWithFormat:@"%@%@%@",[self baseURL],CONTAINER_NAME,URLString];
    
    [self setResponseSerializer:[AFHTTPResponseSerializer serializer]];
   //use downloadTask
    [self GET:apiURL parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        progress(downloadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        responseBlock(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSString* ErrorResponse = [[NSString alloc] initWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
        NSLog(@"%@",ErrorResponse);
        NSDictionary *errorInfo = error.userInfo;
        NSInteger statusCode = [[errorInfo objectForKey:AFNetworkingOperationFailingURLResponseErrorKey] statusCode];
        NSLog(@"Error code = %ld",(long)statusCode);
        if (statusCode == 401 ) {
            //password changed. get new password
            [CMOUtils getCMSPasswordFromServer:[_coreComponents appServerAPIHandler]];
        }
        failureBlock(error);
    }];
}


#pragma mark - Private method
-(NSData *)generateBody{
    NSMutableString* o = [NSMutableString string];
    [o appendString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
    [o appendString:@"<D:propfind xmlns:D=\"DAV:\">\n"];
    //    [o appendString:@"<D:propfind>\n"];
    [o appendString:@"	<D:prop>"];
    [o appendString:@"		<D:resourcetype/>\n"];
    
    if((kWebDAVProperty & CMOWebDAVPropertyCreationDate) == CMOWebDAVPropertyCreationDate) {
        [o appendString:@"		<D:creationdate/>\n"];
    }
    
    if((kWebDAVProperty & CMOWebDAVPropertyLastModifiedDate) == CMOWebDAVPropertyLastModifiedDate) {
        [o appendString:@"		<D:getlastmodified/>\n"];
    }
    
    if((kWebDAVProperty & CMOWebDAVPropertyDisplayName) == CMOWebDAVPropertyDisplayName) {
        [o appendString:@"		<D:displayname/>\n"];
    }
    
    if((kWebDAVProperty & CMOWebDAVPropertyContentLength) == CMOWebDAVPropertyContentLength) {
        [o appendString:@"		<D:getcontentlength/>\n"];
    }
    
    if((kWebDAVProperty & CMOWebDAVPropertyContentType) == CMOWebDAVPropertyContentType) {
        [o appendString:@"		<D:getcontenttype/>\n"];
    }
    
    if((kWebDAVProperty & CMOWebDAVPropertyLockDiscovery) == CMOWebDAVPropertyLockDiscovery) {
        [o appendString:@"		<D:lockdiscovery/>\n"];
    }
    
    if((kWebDAVProperty & CMOWebDAVPropertySupportedLock) == CMOWebDAVPropertySupportedLock) {
        [o appendString:@"		<D:supportedlock/>\n"];
    }
    
    [o appendString:@"	</D:prop>"];
    [o appendString:@"</D:propfind>"];
    
    return [o dataUsingEncoding:NSUTF8StringEncoding];
}


@end
