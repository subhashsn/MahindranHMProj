//
//  AFClient.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMONetworkHandler.h"
#import "CMOUtils.h"
#import "NSDictionary+Custom.h"

@implementation CMONetworkHandler

- (instancetype)init
{
    self = [self initWithSessionConfiguration:nil];
    if (self) {
        
    }
    return self;
}

- (instancetype)initWithSessionConfiguration:(NSURLSessionConfiguration *)configuration
{
    if (!configuration){
        configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    }
    self = [super initWithSessionConfiguration:configuration];
    if (self) {
        
        self.requestSerializer = [AFJSONRequestSerializer serializer];

        [[self requestSerializer] setValue:REST_SECRET_KEY forHTTPHeaderField:@"Authorization"];
        [[self requestSerializer] setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        [[self requestSerializer] setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
       // self.requestSerializer = [AFJSONRequestSerializer serializer];
        
        //   self.responseSerializer =[AFHTTPResponseSerializer serializer]
        //[manager.requestSerializer setValue:@"application/x-www-form-urlencoded; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];

        //[[self requestSerializer] setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
     //   self.responseSerializer =[AFHTTPResponseSerializer serializer];
       
        //self.securityPolicy.allowInvalidCertificates = YES;
        
        __unsafe_unretained typeof(self) weakSelf = self;

        [self setSessionDidReceiveAuthenticationChallengeBlock:^NSURLSessionAuthChallengeDisposition(NSURLSession * _Nonnull session, NSURLAuthenticationChallenge * _Nonnull challenge, NSURLCredential *__autoreleasing  _Nullable * _Nullable credential) {
            if([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]){
                if([challenge.protectionSpace.host isEqualToString:weakSelf.serverName]){
                    //                    SecTrustRef serverTrust = challenge.protectionSpace.serverTrust;
                    //                    SecCertificateRef certificate = SecTrustGetCertificateAtIndex(serverTrust, 0);
                    //                    NSData *remoteCertificateData = CFBridgingRelease(SecCertificateCopyData(certificate));
                    
                    *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
                    
                }
            }
            return NSURLSessionAuthChallengeUseCredential;
            
        }]; 

    }
    return self;
}

- (NSString *)baseURL{
    NSDictionary *dict = [CMOUtils appConfigurations];
    return [NSString stringWithFormat:@"%@%@/",dict[@"ofbaseurl"],dict[@"apiversion"]];
}

#pragma mark GET

//This connection is Insecure. Remove Arbitrary loads in info.plist

- (void)GET:( NSString * _Nonnull )URLString parameters:(nullable id)parameters
        OnProgress:(APIProgress _Nullable)progress
        OnSuccess:(APIResponseSuccess _Nullable)responseBlock
        onFailure:(APIResponseFailed _Nonnull)failureBlock{
    //http://devhomestaycare.southindia.cloudapp.azure.com/plugins/restapi/v1/chatrooms/of/anish.kumar_happiestminds.com
    
    //http://devhomestaycare.southindia.cloudapp.azure.com/plugins/restapiv1/chatrooms/of/anish
    NSString *apiURL = [[NSString stringWithFormat:@"%@%@",[self baseURL],URLString] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    //self.securityPolicy.allowInvalidCertificates = true;
//#warning API Call should be in seperate thread.
    
    [self GET:apiURL parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        progress(downloadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //Get Date
        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        NSString *date = ((NSHTTPURLResponse *)task.response).allHeaderFields[@"Date"];
        [CMOUtils saveServerTime:date];
        
        responseBlock(responseObject);
        [self invalidateSessionCancelingTasks:false];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        ////DDLogInfo(@"%@ %@ 3 error: %@",THIS_METHOD,THIS_FILE,error);
        NSString* ErrorResponse = [[NSString alloc] initWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
        NSLog(@"ErrorResponse %@",ErrorResponse);
        if (error.code == 3840){ //JSON Parsing Error
            ////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
            responseBlock(nil); //To delete outdated rooms
        }
        else{
            ////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
            NSDictionary *errorInfo = error.userInfo;
            NSInteger statusCode = [[errorInfo objectForKey:AFNetworkingOperationFailingURLResponseErrorKey] statusCode];
            NSLog(@"Error code = %ld",(long)statusCode);
            if (statusCode == 404 ) {
                ////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
                NSError *notFoundError = [NSError errorWithDomain:@"Resource Not Found Exception" code:statusCode userInfo:nil];
                failureBlock(notFoundError);
            }
            else{
                ////DDLogInfo(@"%@ %@ 7",THIS_METHOD,THIS_FILE);
                failureBlock(error);
            }
            
        }
        [self invalidateSessionCancelingTasks:false];
        ////DDLogInfo(@"%@ %@ 8",THIS_METHOD,THIS_FILE);
    }];
}

#pragma mark POST

- (void)POST:(NSString * _Nonnull)URLString parameters:(nullable id)parameters
       OnProgress:(APIProgress _Nullable)progress
       OnSuccess:(APIResponseSuccess _Nullable)responseBlock
       onFailure:(APIResponseFailed _Nonnull)failureBlock{
    
    
     ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    NSString *apiURL = [[NSString stringWithFormat:@"%@%@",[self baseURL],URLString] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [self POST:apiURL parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
         progress(uploadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
         ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        responseBlock(responseObject);
        [self invalidateSessionCancelingTasks:false];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        ////DDLogInfo(@"%@ %@ %@ 3",THIS_METHOD,THIS_FILE,error);
        failureBlock(error);
        [self invalidateSessionCancelingTasks:false];
    }];
}

#pragma mark Multipart POST

- (void)POSTMultipart:(NSString * _Nonnull)URLString parameters:(nullable id)parameters
           OnProgress:(APIProgress _Nullable)progress
            OnSuccess:(APIResponseSuccess _Nullable)responseBlock
            onFailure:(APIResponseFailed _Nonnull)failureBlock{
    
    NSString *apiURL = [[NSString stringWithFormat:@"%@%@",[self baseURL],URLString] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [self POST:apiURL parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        progress(uploadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        responseBlock(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(error);
    }];
}

#pragma mark DELETE


- (void)DELETE:( NSString * _Nonnull )URLString parameters:(nullable id)parameters
  OnSuccess:(APIResponseSuccess _Nullable)responseBlock
  onFailure:(APIResponseFailed _Nonnull)failureBlock{
    
    NSString *apiURL = [[NSString stringWithFormat:@"%@%@",[self baseURL],URLString]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [self DELETE:apiURL parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        responseBlock(responseObject);
        [self invalidateSessionCancelingTasks:false];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(error);
        [self invalidateSessionCancelingTasks:false];
    }];
}


#pragma mark Get Message Count

- (void)GETMessageCount:( NSString * _Nonnull )URLString parameters:(nullable id)parameters
 OnProgress:(APIProgress _Nullable)progress
  OnSuccess:(APIResponseSuccess _Nullable)responseBlock
  onFailure:(APIResponseFailed _Nonnull)failureBlock{
    
    //NSString *apiURL = [[NSString stringWithFormat:@"%@%@",[self baseURL],URLString] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    //self.securityPolicy.allowInvalidCertificates = true;
    [self GET:URLString parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        progress(downloadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //Get Date
        NSString *date = ((NSHTTPURLResponse *)task.response).allHeaderFields[@"Date"];
        [CMOUtils saveServerTime:date];
        
        responseBlock(responseObject);
        [self invalidateSessionCancelingTasks:false];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSString* ErrorResponse = [[NSString alloc] initWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
        NSLog(@"%@",ErrorResponse);
        if (error.code == 3840){ //JSON Parsing Error
            responseBlock(nil); //To delete outdated rooms
        }
        else{
            failureBlock(error);
        }
        [self invalidateSessionCancelingTasks:false];
    }];
}


@end
