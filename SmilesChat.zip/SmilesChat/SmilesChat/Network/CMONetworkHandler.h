//
//  AFClient.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>
#import "APIClient.h"

@interface CMONetworkHandler : AFHTTPSessionManager <APIClient>

@property (nonatomic, strong)NSString *serverName;

@end
