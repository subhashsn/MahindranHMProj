//
//  CMOAppServerAPIHandler.h
//  CMOChat
//
//  Created by Amit Kumar on 17/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>
#import "CMOAppServerAPIClient.h"

@interface CMOAppServerAPIHandler : AFHTTPSessionManager <CMOAppServerAPIClient>

@property (nonatomic,strong)NSString *serverName;
@property (nonatomic, assign)NSInteger serverPort;
@end
