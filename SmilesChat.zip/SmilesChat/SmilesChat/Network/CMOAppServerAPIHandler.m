//
//  CMOAppServerAPIHandler.m
//  CMOChat
//
//  Created by Amit Kumar on 17/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOAppServerAPIHandler.h"
#import "CMOUtils.h"

//#define RESTAPI_SECRET_KEY @"aqp0mptfbeiFC282"
//#define RESTAPI_BASE_URL @"http://10.20.22.88:8092/"
//#define RESTAPI_BASE_URL @"http://hmecd001128:8092/"

@implementation CMOAppServerAPIHandler

- (instancetype)init
{
    self = [self initWithSessionConfiguration:nil];
    if (self) {
        
    }
    return self;
}

- (instancetype)initWithSessionConfiguration:(NSURLSessionConfiguration *)configuration
{
    if (!configuration){
        configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    }
    self = [super initWithSessionConfiguration:configuration];
    if (self) {
       // self.requestSerializer = [AFJSONRequestSerializer serializer];
        self.requestSerializer = [AFJSONRequestSerializer serializer];
        [[self requestSerializer] setValue:REST_SECRET_KEY forHTTPHeaderField:@"Authorization"];
        [[self requestSerializer] setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        [[self requestSerializer] setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        __unsafe_unretained typeof(self) weakSelf = self;
        
        [self setSessionDidReceiveAuthenticationChallengeBlock:^NSURLSessionAuthChallengeDisposition(NSURLSession * _Nonnull session, NSURLAuthenticationChallenge * _Nonnull challenge, NSURLCredential *__autoreleasing  _Nullable * _Nullable credential) {
            if([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]){
                if([challenge.protectionSpace.host isEqualToString:weakSelf.serverName]){
                    //                    SecTrustRef serverTrust = challenge.protectionSpace.serverTrust;
                    //                    SecCertificateRef certificate = SecTrustGetCertificateAtIndex(serverTrust, 0);
                    //                    NSData *remoteCertificateData = CFBridgingRelease(SecCertificateCopyData(certificate));
                    
                    *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
                    
                }
            }
            return NSURLSessionAuthChallengeUseCredential;
            
        }];
    }
    return self;
}

- (NSString *)baseURL{
    NSString *protocol = ([CMOUtils isConnectionSecured]) ? @"https":@"http";
    return [NSString stringWithFormat:@"%@://%@:%ld",protocol,self.serverName,(long)self.serverPort];
}


#pragma mark GET

//This connection is Insecure. Remove Arbitrary loads in info.plist

- (void)GET:( NSString * _Nonnull )URLString parameters:(nullable id)parameters
 OnProgress:(APIProgress _Nullable)progress
  OnSuccess:(APIResponseSuccess _Nullable)responseBlock
  onFailure:(APIResponseFailed _Nonnull)failureBlock{
    
    NSString *apiURL = [[NSString stringWithFormat:@"%@/%@",[self baseURL],URLString] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [self GET:apiURL parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        if (progress) {
            progress(downloadProgress);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSString *date = ((NSHTTPURLResponse *)task.response).allHeaderFields[@"Date"];
        [CMOUtils saveServerTime:date];
        responseBlock(responseObject);
        [self invalidateSessionCancelingTasks:false];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (error.code == 3840){ //JSON Parsing Error
            responseBlock(nil); //send first push message
        }
        else{
            
            failureBlock(error);
        }
        [self invalidateSessionCancelingTasks:false];
    }];
}


#pragma mark POST

- (void)POST:(NSString * _Nonnull)URLString parameters:(nullable id)parameters
  OnProgress:(APIProgress _Nullable)progress
   OnSuccess:(APIResponseSuccess _Nullable)responseBlock
   onFailure:(APIResponseFailed _Nonnull)failureBlock{
    
    

    NSString *apiURL = [[NSString stringWithFormat:@"%@%@",[self baseURL],URLString] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [self POST:apiURL parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        progress(uploadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSString *date = ((NSHTTPURLResponse *)task.response).allHeaderFields[@"Date"];
        [CMOUtils saveServerTime:date];
        responseBlock(responseObject);
        [self invalidateSessionCancelingTasks:false];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (error.code == 3840){ //JSON Parsing Error
            responseBlock(nil); //send first push message
        }
        else{
            failureBlock(error);
        }
        [self invalidateSessionCancelingTasks:false];
    }];
}

@end
