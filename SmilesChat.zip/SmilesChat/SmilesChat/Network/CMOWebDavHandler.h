//
//  CMOWebDavHandler.h
//  CMOChat
//
//  Created by Amit Kumar on 14/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>
#import "CMOWebDavClient.h"

@class CMOCoreComponents;

@interface CMOWebDavHandler : AFHTTPSessionManager <CMOWebDavClient>

@property (nonatomic, strong)CMOCoreComponents *coreComponents;

@end
