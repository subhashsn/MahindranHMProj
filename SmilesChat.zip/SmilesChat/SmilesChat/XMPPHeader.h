//
//  XMPPHeader.h
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#ifndef XMPPHeader_h
#define XMPPHeader_h

#import "XMPPFramework/XMPPFramework.h"
#import "XMPPRoster.h"
#import "XMPPReconnect.h"
#import "XMPPMUC.h"
#import "XMPPMUCLight.h"
#import "XMPPRoom.h"
#import "XMPPRoomLight.h"
#import "XMPPRoomLightCoreDataStorage.h"
#import "XMPPRosterCoreDataStorage.h"
#import "XMPPCapabilitiesCoreDataStorage.h"
#import "XMPPRoomCoreDataStorage.h"
#import "XMPPMessageArchivingCoreDataStorage.h"
#import "XMPPMessageArchiving.h"
#import "XMPPMessage+XEP_0184.h"
#import "XMPPMessage+XEP0045.h"
#import "XMPPMessage+XEP_0085.h"
#import "XMPPMessage+XEP_0172.h" //nick
#import "XMPPMessage+XEP_0224.h" //Attention message
//#import "XMPPMessage+XEP_0280.h" //Message carbon
//#import "XMPPMessage+XEP_0308.h" //MEssage correction
//#import "XMPPMessage+XEP_0333.h" //Chat marker
#import "XMPPMessage+XEP_0334.h" //Message store
#import "XMPPMessageDeliveryReceipts.h"
#import "XMPPMessageArchiveManagement.h"
#import "NSXMLElement+XEP_0203.h"

#import "XMPPvCardTempModule.h"
#import "XMPPvCardCoreDataStorage.h"
#import "XMPPvCardTemp.h"
#import "XMPPvCardTempModule.h"
#import "XMPPPing.h"
#import "XMPPAutoPing.h"
#endif /* XMPPHeader_h */
