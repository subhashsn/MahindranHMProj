//
//  AppDelegate.m
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "AppDelegate.h"
#import "XMPPHeader.h"
#import "CMONavigationController.h"
#import "CMOLoginViewController.h"
#import "CMOChatViewController.h"
#import "CMOAssembly.h"
#import "CMOUtils.h"

#import <Fabric/Fabric.h>
#import <Crashlytics/Crashlytics.h>

//#import "CMOXMPPMUCLight.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    //#ifdef DEBUG
        [Fabric with:@[[Crashlytics class]]];
    //#endif
    //[[UIApplication sharedApplication]setMinimumBackgroundFetchInterval:UIApplicationBackgroundFetchIntervalMinimum];
    [DDLog addLogger:[DDASLLogger sharedInstance]];
    [DDLog addLogger:[DDTTYLogger sharedInstance]];
    
    
    NSSetUncaughtExceptionHandler(&appExceptionHandler);
   // [DDLog addLogger:[DDTTYLogger sharedInstance] withLogLevel:XMPP_LOG_FLAG_SEND_RECV];

    self.fileLogger = [[DDFileLogger alloc] init]; // File Logger
    self.fileLogger.rollingFrequency = 60 * 60 * 24; // 24 hour rolling
    self.fileLogger.logFileManager.maximumNumberOfLogFiles = 7;
    [DDLog addLogger:self.fileLogger];
    
    //DDLogFileInfo *fileInfo = [DDLogFileInfo new];
    
    DDLogInfo(@"log file at: %@", [[self.fileLogger currentLogFileInfo] filePath]);
    
    //NSMutableArray *array = [NSMutableArray new];
    //NSLog(@"%@",array[1]);
    
    [self applicationDocumentsDirectory];
    
    
    if (![CMOUtils getMuteNotificationUserDefaultValue]) {
        [application registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
        [application registerForRemoteNotifications];
    }
    
    
    [CMOUtils startReachabilityMonitoring];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
        self.window.rootViewController = self.rootViewController;
        //reload splitView on some condition
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        appDelegate.isReloadSplitView = YES;
        appDelegate.isPortrait = NO;
        appDelegate.isConversationReload = YES;
    }
    
    return YES;
}

void appExceptionHandler(NSException *exception)
{
    NSArray *stack = [exception callStackSymbols];
    DDLogError(@"***** CRASH *****: %@",stack);
    //NSLog(@"Stack trace: %@", stack);
}


- (NSURL *)applicationDocumentsDirectory
{
    ////DDLogInfo(@"%@",[[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory      inDomains:NSUserDomainMask] lastObject]);
    
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory     inDomains:NSUserDomainMask] lastObject];
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    ////DDLogInfo(@"Did Register for Remote Notifications with Device Token (%@)", deviceToken);
    NSString * deviceTokenString = [[[[deviceToken description] stringByReplacingOccurrencesOfString: @"<" withString: @""] stringByReplacingOccurrencesOfString: @">" withString: @""]   stringByReplacingOccurrencesOfString: @" " withString: @""];
    DDLogError(@"the generated device token string is : %@",deviceTokenString);
    NSString *oldDeviceToken = [[NSUserDefaults standardUserDefaults] valueForKey:@"APNSDeviceToken"];
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"APNSDeviceToken"] == nil || ![oldDeviceToken isEqualToString:deviceTokenString]) {
        [[NSUserDefaults standardUserDefaults] setValue:deviceTokenString forKey:@"APNSDeviceToken"];
        [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:@"APNSDeviceTokenChanged"];
        [[NSNotificationCenter defaultCenter] postNotificationName:DID_UPDATE_DEVICE_TOKEN_NOTIFICATION object:nil userInfo:nil];

    }
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    DDLogError(@"Did Fail to Register for Remote Notifications");
    DDLogError(@"%@, %@", error, error.localizedDescription);
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    [[NSNotificationCenter defaultCenter]postNotificationName:APP_WILL_RESIGN_ACTIVE_NOTIFICATION object:nil];
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        appDelegate.isPortrait = NO;
    }
    
    //set unread message count to zero once app enter foreground.
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    
    [[NSNotificationCenter defaultCenter]postNotificationName:APP_BACKGROUND_NOTIFICATION object:nil];
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    
    //set unread message count to zero once app enter foreground.
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];

    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad && appDelegate.isPortrait) {
        return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskPortrait;
    }
    else if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        return UIInterfaceOrientationMaskLandscape;
    }
    else{
        return UIInterfaceOrientationMaskPortrait;
    }
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))handler{
    
//    if (application.applicationState == UIApplicationStateBackground || application.applicationState == UIApplicationStateInactive)
    {
        DDLogError(@"************* didReceiveRemoteNotification ************");
        //increment unread message count +1 on every notification
        [[UIApplication sharedApplication] setApplicationIconBadgeNumber:[UIApplication sharedApplication].applicationIconBadgeNumber + 1];
    }
}


@end
