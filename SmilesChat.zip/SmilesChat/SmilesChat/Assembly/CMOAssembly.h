//
//  CMOAssembly.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Typhoon/Typhoon.h>
#import "CMOCoreComponents.h"

@class CMOTabBarController;

@interface CMOAssembly : TyphoonAssembly

@property (nonatomic, strong, readonly)CMOCoreComponents *coreComponents;

- (CMOTabBarController *)tabBarController;

- (id)loginviewcontroller;

- (id)chatviewcontroller;

- (id)rosterviewcontroller;

- (id)conversationsviewcontroller;

- (id)conversationsettingsviewcontroller:(id)info;

- (id)newconversationviewcontroller;

- (id)myinfoviewcontroller:(id)username;

- (id)otpviewcontroller:(id)mobileNumber userName:(id)username;

- (id)chatcontainerviewcontroller;

- (id)settingsviewcontroller;

- (id)countrycodeviewcontroller;

- (id)attachmentsviewcontroller;

- (id)fullimageviewcontroller;

- (id)myprofileviewcontroller;

- (id)editProfileviewcontroller;

- (id)groupMemberviewcontroller;

- (id)searchviewcontroller;

- (id)documentpreviewviewcontroller;

- (id)smsViewController:(id)delegate;

#pragma mark iPad methods
- (id) ipadsplitviewcontroller;

- (id) ipadtabbarcontroller;

- (id) ipaddetailviewcontroller;

- (id) ipadrosterviewcontroller;

- (id) slatimerpopover;

- (id) ipadEmptyViewcontroller;

@end
