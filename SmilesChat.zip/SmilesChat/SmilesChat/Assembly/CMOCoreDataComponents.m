//
//  CMOCoreDataComponents.m
//  CMOChat
//
//  Created by Administrator on 11/9/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOCoreDataComponents.h"
#import <CoreData/CoreData.h>

@implementation CMOCoreDataComponents


- (id)fileManager{
    return [TyphoonDefinition withClass:[NSFileManager class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(defaultManager)];
    }];
}

- (id)applicationDocumentDirectories{
    return [TyphoonDefinition withFactory:[self fileManager] selector:@selector(URLsForDirectory:inDomains:)parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:[NSNumber numberWithInt:NSDocumentDirectory]];
        [factoryMethod injectParameterWith:[NSNumber numberWithInt:NSUserDomainMask]];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        
    }];
}

- (id)applicationDocumentsDirectory{
    return [TyphoonDefinition withFactory:[self applicationDocumentDirectories] selector:@selector(lastObject)];
}

- (id)databasePath{
    return [TyphoonDefinition withFactory:[self applicationDocumentsDirectory] selector:@selector(stringByAppendingPathComponent:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:@"/esabataD"];//Name obfuscated. Reverse order
        
    }];
}

- (id)storeURL{
    return [TyphoonDefinition withFactory:[self applicationDocumentsDirectory] selector:@selector(URLByAppendingPathComponent:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:@"cmochat.sqlite"];
    }];
}

/*
 
 - (NSString *)imageFolderPath{
 NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
 NSString *documentsDirectory = [paths objectAtIndex:0]; // Get documents folder
 NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:@"/Images"];
 
 NSError *error = nil;
 if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath])//Check
 [[NSFileManager defaultManager] createDirectoryAtPath:dataPath withIntermediateDirectories:NO attributes:nil error:&error];
 
 return dataPath;
 }
 */

- (id)persistentStoreCoordinator{
    return [TyphoonDefinition withClass:[NSPersistentStoreCoordinator class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(initWithManagedObjectModel:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self managedObjectModel]];//self.managedObjectModel
        }];
        [definition injectMethod:@selector(addPersistentStoreWithType:configuration:URL:options:error:) parameters:^(TyphoonMethod *method) {
            
            NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
                                     [NSNumber numberWithBool:YES], NSMigratePersistentStoresAutomaticallyOption,
                                     [NSNumber numberWithBool:YES], NSInferMappingModelAutomaticallyOption, nil];
            
            [method injectParameterWith:NSSQLiteStoreType];
            [method injectParameterWith:nil];
            [method injectParameterWith:[self storeURL]];
            [method injectParameterWith:options];
            [method injectParameterWith:nil];
            
        }];
    }];
}


- (id)mainManagedObjectContext{
    return [TyphoonDefinition withClass:[NSManagedObjectContext class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(initWithConcurrencyType:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[NSNumber numberWithInt:NSMainQueueConcurrencyType]];
        }];
        [definition injectProperty:@selector(persistentStoreCoordinator) with:[self persistentStoreCoordinator]];
        definition.scope = TyphoonScopeLazySingleton;
    }];
}

- (id)managedObjectContext{
    return [TyphoonDefinition withClass:[NSManagedObjectContext class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(initWithConcurrencyType:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[NSNumber numberWithInt:NSPrivateQueueConcurrencyType]];
        }];
        [definition injectProperty:@selector(parentContext) with:[self mainManagedObjectContext]];
    }];
}

- (id)managedObjectModel{
    return [TyphoonDefinition withClass:[NSManagedObjectModel class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(initWithContentsOfURL:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self modelUrl]];
        }];
    }];
}

- (id)modelUrl{
    return [TyphoonDefinition withFactory:[self mainBundle] selector:@selector(URLForResource:withExtension:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:@"CMOChat"];
        [factoryMethod injectParameterWith:@"momd"];
    }];
}

- (id)mainBundle{
    return [TyphoonDefinition withClass:[NSBundle class] configuration:^(TyphoonDefinition *definition) {
       [definition useInitializer:@selector(mainBundle) parameters:^(TyphoonMethod *initializer) {
           
       }];
    }];
}



@end
