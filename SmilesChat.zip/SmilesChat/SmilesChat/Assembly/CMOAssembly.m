//
//  CMOAssembly.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOAssembly.h"
#import "CMOLoginViewController.h"
#import "CMOChatViewController.h"
#import "CMORosterViewController.h"
#import "CMOMyInfoViewController.h"
#import "CMOTabBarController.h"
#import "CMOOtpViewController.h"
#import "CMOSettingsViewController.h"
#import "CMOCountryCodeViewController.h"
#import "CMOAttachmentsViewController.h"
#import "CMOFullImageViewController.h"
#import "CMOGroupMemberViewController.h"
#import "AppDelegate.h"
#import "CMOSplitViewController.h"
#import "CMOiPadTabBarViewController.h"
#import "CMOiPadDetailViewController.h"
#import "CMOSMSViewController.h"

static NSString *loginvc = @"loginvc";
static NSString *chatvc = @"chatvc";
static NSString *chatcontainervc = @"chatcontainervc";
static NSString *rostervc = @"rosterlistvc";
static NSString *conversationsvc = @"conversationsvc";
static NSString *conversationsettingsvc = @"conversationsettingsvc";
static NSString *newconversationvc = @"newconversationvc";
static NSString *myinfovc = @"myinfovc";
static NSString *otpvc = @"otpvc";
static NSString *settingsvc = @"settingsvc";
static NSString *countrycodevc = @"countrycodevc";
static NSString *attachmentsvc = @"attachmentsvc";
static NSString *fullimagevc = @"fullimagevc";
static NSString *myProfilevc = @"myProfilevc";
static NSString *editProfilevc = @"editProfilevc";
static NSString *groupmembervc = @"groupmembervc";
static NSString *searchvc = @"searchvc";

static NSString *ipadsplitvc = @"ipadsplitvc";
static NSString *ipadtabbarvc = @"ipadtabbarvc";
static NSString *ipaddetailvc = @"ipaddetailvc";
static NSString *ipadrostervc = @"ipadrosterlistvc";
static NSString *slatimervc = @"slatimervc";
static NSString *emptyvc = @"emptyvc";
static NSString *documentpreviewvc = @"documentpreviewvc";

@implementation CMOAssembly


- (AppDelegate *)appDelegate
{
    return [TyphoonDefinition withClass:[AppDelegate class] configuration:^(TyphoonDefinition *definition)
            {
                [definition injectProperty:@selector(window) with:[self mainWindow]];
                [definition injectProperty:@selector(rootViewController) with:[self tabBarController]];
               // [definition injectProperty:@selector(corecomponents) with:self.coreComponents];
            }];
}

/**
 * Set up the main window. We don't really need to use DI for this, but it shows an example of injecting a struct.
 */
- (UIWindow *)mainWindow
{
    return [TyphoonDefinition withClass:[UIWindow class] configuration:^(TyphoonDefinition *definition)
            {
                [definition useInitializer:@selector(initWithFrame:) parameters:^(TyphoonMethod *initializer)
                 {
                     [initializer injectParameterWith:[NSValue valueWithCGRect:[[UIScreen mainScreen] bounds]]];
                 }];
                [definition injectProperty:@selector(rootViewController) with:[self tabBarController]];
                [definition injectProperty:@selector(backgroundColor) with:[UIColor whiteColor]];
            }];
    
}

- (CMOTabBarController *)tabBarController
{
    return [TyphoonDefinition withClass:[CMOTabBarController class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(initWithAssembly:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:self];
        }];
        [definition injectProperty:@selector(viewControllers) with:[NSArray arrayWithObjects:[self firstNavViewController],[self secondNavViewController],[self thirdNavViewController], nil]];
       
        definition.scope = TyphoonScopeSingleton;
    }];
}

- (CMONavigationController *)firstNavViewController{
    return [TyphoonDefinition withClass:[CMONavigationController class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(initWithRootViewController:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self loginviewcontroller]];
        }];
        //definition.scope = TyphoonScopeSingleton;
    }];
}

- (CMONavigationController *)secondNavViewController{
    return [TyphoonDefinition withClass:[CMONavigationController class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(initWithRootViewController:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self rosterviewcontroller]];
        }];
        //definition.scope = TyphoonScopeSingleton;
    }];
}

- (CMONavigationController *)thirdNavViewController{
    return [TyphoonDefinition withClass:[CMONavigationController class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(initWithRootViewController:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self settingsviewcontroller]];
        }];
        //definition.scope = TyphoonScopeSingleton;
    }];
}

/**
 Make sure that this storyboard identifier is added for both iPhone and iPad viewcontrollers of  storyboard
 */


- (UIViewController *)storyboard{//controller:(NSString *)identifier{
    NSString *storyboardName = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"UIMainStoryboardFile"];
 
  // UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
  // return  [storyboard instantiateViewControllerWithIdentifier:identifier];
    
    return [TyphoonDefinition withClass:[TyphoonStoryboard class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(storyboardWithName:factory:bundle:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:storyboardName];
            [initializer injectParameterWith:self];
            [initializer injectParameterWith:[NSBundle mainBundle]];
        }];
    }];


}

- (id)loginviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:loginvc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
    }];
}

- (id)chatcontainerviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:chatcontainervc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
         [definition injectProperty:@selector(chatModel) with:[self.coreComponents chatPresentation]];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
    }];
}

- (id)chatviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:chatvc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(chatModel) with:[self.coreComponents chatPresentation]];
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
        //                definition.classOrProtocolForAutoInjection = [MYViewController class];
        definition.classOrProtocolForAutoInjection = [CMOChatViewController class];
    }];
}

- (id)conversationsviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:conversationsvc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
         [definition injectProperty:@selector(chatModel) with:[self.coreComponents chatPresentation]];//coreComponents
        [definition injectProperty:@selector(roomModel) with:[self.coreComponents roomPresentation]];
        [definition injectProperty:@selector(rosterModel) with:[self.coreComponents rosterPresentation]];
         [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
         [definition injectProperty:@selector(assembly) with:self];
        //[definition injectProperty:@selector(splitViewController) with:[self ipadsplitviewcontroller]];
    }];
}

- (id)rosterviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:rostervc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
        //[definition injectProperty:@selector(splitViewController) with:[self ipadsplitviewcontroller]];
    }];
}

- (id)myinfoviewcontroller:(id)username{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:myinfovc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(userName) with:username];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
    }];
}

- (id)countrycodeviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:countrycodevc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
    }];
}

- (id)otpviewcontroller:(id)mobileNumber userName:(id)username {
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:otpvc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(mobileNumber) with:mobileNumber];
        [definition injectProperty:@selector(userName) with:username];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
    }];
}

- (id)conversationsettingsviewcontroller:(id)info{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:conversationsettingsvc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
//        [definition injectProperty:@selector(roomInfo) with:info];
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(chatModel) with:[self.coreComponents chatPresentation]];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
    }];
}

- (id)newconversationviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:newconversationvc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(chatModel) with:[self.coreComponents chatPresentation]];
    }];
}

- (id)settingsviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:settingsvc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
        [definition injectProperty:@selector(splitViewController) with:[self ipadsplitviewcontroller]];
    }];
}

- (id)myprofileviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:myProfilevc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
    }];
}

- (id)editProfileviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:editProfilevc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
    }];
}

- (id)attachmentsviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod)
    {
        [factoryMethod injectParameterWith:attachmentsvc];
    }configuration:^(TyphoonFactoryDefinition *definition){
        [definition injectProperty:@selector(assembly) with:self];
    }];
}

- (id)fullimageviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod)
            {
                [factoryMethod injectParameterWith:fullimagevc];
            }configuration:^(TyphoonFactoryDefinition *definition){
                [definition injectProperty:@selector(assembly) with:self];
                [definition injectProperty:@selector(chatModel) with:[self.coreComponents chatPresentation]];
            }];
}

- (id)groupMemberviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:groupmembervc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];        
    }];
}

- (id)searchviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:searchvc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
    }];
}

- (id)smsViewController:(id)delegate{
    return [TyphoonDefinition withClass:[CMOSMSViewController class] configuration:^(TyphoonDefinition *definition){
        [definition useInitializer:@selector(initWithDelegate:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:delegate];
        }];
    }];
}

#pragma mark iPad methods

- (id)ipadsplitviewcontroller{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
            [factoryMethod injectParameterWith:ipadsplitvc];
        } configuration:^(TyphoonFactoryDefinition *definition) {
            [definition injectProperty:@selector(assembly) with:self];
            
            [definition injectProperty:@selector(viewControllers) with:[NSArray arrayWithObjects:[self ipadtabbarcontroller],[self ipaddetailNavViewcontroller], nil]];
        }];
    } else {
        return nil;
    }
}

- (id) ipadtabbarcontroller
{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod)
            {
                [factoryMethod injectParameterWith:ipadtabbarvc];
            }configuration:^(TyphoonFactoryDefinition *definition){
                [definition injectProperty:@selector(assembly) with:self];
                
                [definition injectProperty:@selector(viewControllers) with:[NSArray arrayWithObjects:[self ipadFirstNavViewController],[self secondNavViewController],[self thirdNavViewController], nil]];
            }];
}

- (id) ipaddetailviewcontroller
{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod)
            {
                [factoryMethod injectParameterWith:ipaddetailvc];
            }configuration:^(TyphoonFactoryDefinition *definition){
                [definition injectProperty:@selector(assembly) with:self];
                //                [definition injectProperty:@selector(chatModel) with:[self.coreComponents chatPresentation]];
            }];
}

- (id)ipadrosterviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:ipadrostervc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
        [definition injectProperty:@selector(coreComponents) with:self.coreComponents];
        [definition injectProperty:@selector(splitViewController) with:[self ipadsplitviewcontroller]];
    }];
}

- (id) slatimerpopover{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:slatimervc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
    }];
}

- (id) ipaddetailNavViewcontroller
{
    return [TyphoonDefinition withClass:[CMONavigationController class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(initWithRootViewController:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self ipaddetailviewcontroller]];
        }];
        //definition.scope = TyphoonScopeSingleton;
    }];
}

- (CMONavigationController *)ipadFirstNavViewController{
    return [TyphoonDefinition withClass:[CMONavigationController class] configuration:^(TyphoonDefinition *definition) {
        [definition useInitializer:@selector(initWithRootViewController:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self conversationsviewcontroller]];
        }];
        //definition.scope = TyphoonScopeSingleton;
    }];
}

- (id) ipadEmptyViewcontroller
{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod) {
        [factoryMethod injectParameterWith:emptyvc];
    } configuration:^(TyphoonFactoryDefinition *definition) {
        [definition injectProperty:@selector(assembly) with:self];
    }];
}

- (id)documentpreviewviewcontroller{
    return [TyphoonDefinition withFactory:[self storyboard] selector:@selector(instantiateViewControllerWithIdentifier:) parameters:^(TyphoonMethod *factoryMethod)
            {
                [factoryMethod injectParameterWith:documentpreviewvc];
            }configuration:^(TyphoonFactoryDefinition *definition){
                [definition injectProperty:@selector(assembly) with:self];
                [definition injectProperty:@selector(chatModel) with:[self.coreComponents chatPresentation]];
            }];
}

@end
