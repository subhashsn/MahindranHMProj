//
//  CMOCoreDataComponents.h
//  CMOChat
//
//  Created by Administrator on 11/9/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Typhoon/Typhoon.h>

@interface CMOCoreDataComponents : TyphoonAssembly

- (id)mainManagedObjectContext;

- (id)managedObjectContext;

@end
