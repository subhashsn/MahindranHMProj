//
//  CMOCoreComponents.m
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOCoreComponents.h"
#import "CMOXMPPManager.h"
#import "CMONetworkHandler.h"
#import "CMORosterService.h"
#import "CMOUserService.h"
#import "CMOChatService.h"
#import "CMOLoginService.h"
#import "CMOChatPresentation.h"
#import "CMOLoginPresentation.h"
#import "CMORosterPresentation.h"
#import "CMOUserPresentation.h"
#import "CMOXMPPErrorHandler.h"
#import "CMORepositoryService.h"
#import "CMOWebDavHandler.h"
#import "CMOAppServerAPIHandler.h"
#import "CMORoomBuilder.h"
#import "CMORoomService.h"
#import "CMORoomPresentation.h"

@implementation CMOCoreComponents

- (id<CMOXMPPDelegate>)xmppManager{
    return [TyphoonDefinition withClass:[CMOXMPPManager class] configuration:^(TyphoonDefinition *definition){
       
        [definition injectProperty:@selector(serverName) with:TyphoonConfig(kOFServerNameKey)];
        [definition injectProperty:@selector(serverHost) with:TyphoonConfig(kOFServerPortKey)];
         [definition injectProperty:@selector(conferenceURL) with:TyphoonConfig(kOFConferenceName)];
        [definition injectProperty:@selector(domainName) with:TyphoonConfig(kOFDomainName)];
        [definition injectProperty:@selector(xmppErrorHandler) with:[self xmppErrorHandler]];
        [definition injectProperty:@selector(coreComponents) with:self];
            definition.scope = TyphoonScopeSingleton;
        }];
}

//- (CMOXMPPMUCLight *)xmppMUCLight{
//    return [TyphoonDefinition withParent:[self xmppManager] class:[CMOXMPPMUCLight class] configuration:^(TyphoonDefinition *definition) {
//      
//      //  [definition injectMethod:@selector(setupStream) parameters:nil];
//        definition.scope = TyphoonScopeWeakSingleton;
//        
//    }];
//   
//}

- (id)xmppErrorHandler{
    return [TyphoonDefinition withClass:[CMOXMPPErrorHandler class] configuration:^(TyphoonDefinition *definition){
       
    }];
}

- (id<CMOAppServerAPIClient>)appServerAPIHandler {
    return [TyphoonDefinition withClass:[CMOAppServerAPIHandler class] configuration:^(TyphoonDefinition *definition){
        
          [definition injectProperty:@selector(serverName) with:TyphoonConfig(kOFServerNameKey)];
        [definition injectProperty:@selector(serverPort) with:TyphoonConfig(kAppServerPort)];
    }];
}


- (id<APIClient>)networkHandler{
    return [TyphoonDefinition withClass:[CMONetworkHandler class] configuration:^(TyphoonDefinition *definition){
       [definition injectProperty:@selector(serverName) with:TyphoonConfig(kOFServerNameKey)];
    }];
}

- (id<CMOWebDavClient>)webDavHandler{
    return [TyphoonDefinition withClass:[CMOWebDavHandler class] configuration:^(TyphoonDefinition *definition){
          [definition injectProperty:@selector(coreComponents) with:self];
    }];
}

- (id<CMORosterClient>)rosterService{
    return [TyphoonDefinition withClass:[CMORosterService class] configuration:^(TyphoonDefinition *definition){
        [definition injectProperty:@selector(coreComponents) with:self];
    }];
}

- (id<CMOChatClient>)chatService{
    return [TyphoonDefinition withClass:[CMOChatService class] configuration:^(TyphoonDefinition *definition){
        [definition useInitializer:@selector(initWithManager:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self xmppManager]];
        }];
        [definition injectProperty:@selector(coreComponents) with:self];
        [definition injectProperty:@selector(domainName) with:TyphoonConfig(kOFDomainName)];
    }];
}

- (id<CMOUserClient>)userService{
    return [TyphoonDefinition withClass:[CMOUserService class] configuration:^(TyphoonDefinition *definition){
        [definition useInitializer:@selector(initWithManager:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self xmppManager]];
        }];
        [definition injectProperty:@selector(coreComponents) with:self];
    }];
}
- (id<CMORoomClient>)roomService{
    return [TyphoonDefinition withClass:[CMORoomService class] configuration:^(TyphoonDefinition *definition){
        [definition useInitializer:@selector(initWithManager:) parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self xmppManager]];
        }];
        [definition injectProperty:@selector(coreComponents) with:self];
        
    }];
}

- (id<CMOLoginClient>)loginService{
    return [TyphoonDefinition withClass:[CMOLoginService class] configuration:^(TyphoonDefinition *definition){
        [definition injectProperty:@selector(coreComponents) with:self];
        
    }];
}

- (id<CMORepositoryClient>)repositoryService{
    return [TyphoonDefinition withClass:[CMORepositoryService class] configuration:^(TyphoonDefinition *definition){
        [definition injectProperty:@selector(conferenceURL) with:TyphoonConfig(kOFConferenceName)];
        [definition injectProperty:@selector(domainName) with:TyphoonConfig(kOFDomainName)];
        [definition injectProperty:@selector(coreComponents) with:self];
        [definition injectProperty:@selector(managedObjectcontext) with:[_coreDataComponents mainManagedObjectContext]];
        [definition injectProperty:@selector(serverName) with:TyphoonConfig(kOFServerNameKey)];
        definition.scope = TyphoonScopeSingleton;
    }];
}

- (id <CMOMessageBuilderDelegate>)messageBuilder:(CMOMessage *)message{
    return [TyphoonDefinition withClass:[CMOMessageBuilder class] configuration:^(TyphoonDefinition *definition){
        [definition useInitializer:@selector(initWithMessage:)parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:message];
        }];
        [definition injectProperty:@selector(serverName) with:TyphoonConfig(kOFDomainName)];
    }];
}


- (id <CMORoomBuilderDelegate>)roomBuilder:(CMORoomInfo *)roomInfo{
    return [TyphoonDefinition withClass:[CMORoomBuilder class] configuration:^(TyphoonDefinition *definition){
        [definition useInitializer:@selector(initWithRoom:)parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:roomInfo];
        }];
        //[definition injectProperty:@selector(serverName) with:TyphoonConfig(kOFDomainName)];
    }];
}



- (id)loginPresentationWithUser:(NSString *)user clientId:(NSString *)clientId{
    return [TyphoonDefinition withClass:[CMOLoginPresentation class] configuration:^(TyphoonDefinition *definition){
        [definition useInitializer:@selector(initWithUser:clientId:)parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:user];
            [initializer injectParameterWith:clientId];
        }];
        [definition injectProperty:@selector(coreComponents) with:self];
    }];
}


- (id)chatPresentation{
    return [TyphoonDefinition withClass:[CMOChatPresentation class] configuration:^(TyphoonDefinition *definition){
        [definition useInitializer:@selector(initWithService:)parameters:^(TyphoonMethod *initializer) {
            [initializer injectParameterWith:[self chatService]];
        }];
        [definition injectProperty:@selector(coreComponents) with:self];
        [definition injectProperty:@selector(domainName) with:TyphoonConfig(kOFDomainName)];
         [definition injectProperty:@selector(conferenceURL) with:TyphoonConfig(kOFConferenceName)];
    }];
}

- (id)rosterPresentation{
    return [TyphoonDefinition withClass:[CMORosterPresentation class] configuration:^(TyphoonDefinition *definition){
        [definition injectProperty:@selector(coreComponents) with:self];
    }];
}

- (id)roomPresentation{
    return [TyphoonDefinition withClass:[CMORoomPresentation class] configuration:^(TyphoonDefinition *definition){
        [definition injectProperty:@selector(coreComponents) with:self];
    }];
}

- (id)userPresentation{
    return [TyphoonDefinition withClass:[CMOUserPresentation class] configuration:^(TyphoonDefinition *definition){
        [definition injectProperty:@selector(userClient) with:[self userService]];
    }];
}

#pragma mark - App Configurations
- (id)config
{
    id definition;
    //#ifdef DEBUG
        definition = [TyphoonDefinition withConfigName:@"Configuration_UAT.plist"];
    //#else
      //  definition = [TyphoonDefinition withConfigName:@"Configuration_Prod.plist"];
    //#endif
    
    return definition;
}


@end
