//
//  CoreComponents.h
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Typhoon/Typhoon.h>
#import "CMOXMPPClient.h"
#import "APIClient.h"
#import "CMORosterClient.h"
#import "CMOUserClient.h"
#import "CMOChatClient.h"
#import "CMOLoginClient.h"
#import "CMORoomClient.h"
#import "CMOMessageBuilder.h"
#import "CMORoomBuilder.h"
#import "CMORepositoryClient.h"

#import "CMOWebDavClient.h"


#import "CMOCoreDataComponents.h"
#import "CMOWebDavClient.h"
#import "CMOAppServerAPIClient.h"

@class CMOChatPresentation;
@class CMOLoginPresentation;
@class CMORosterPresentation;
@class CMORoomPresentation;


@interface CMOCoreComponents : TyphoonAssembly

@property (nonatomic, strong)CMOCoreDataComponents *coreDataComponents;

- (id<CMOXMPPDelegate>)xmppManager;

//- (CMOXMPPMUCLight *)xmppMUCLight;

- (id <CMOMessageBuilderDelegate>)messageBuilder:(CMOMessage *)message;

- (id <CMORoomBuilderDelegate>)roomBuilder:(CMORoomInfo *)roomInfo;

- (id<CMORosterClient>)rosterService;

- (id<CMOAppServerAPIClient>)appServerAPIHandler;

- (id<APIClient>)networkHandler;

- (id<CMOWebDavClient>)webDavHandler;

- (id<CMOUserClient>)userService;

- (id<CMOChatClient>)chatService;

- (id<CMOLoginClient>)loginService;

- (id<CMORepositoryClient>)repositoryService;

- (id<CMORoomClient>)roomService;

- (id)chatPresentation;

- (id)loginPresentationWithUser:(NSString *)user clientId:(NSString *)clientId;

- (id)rosterPresentation;

- (id)userPresentation;

- (id)roomPresentation;

@end
