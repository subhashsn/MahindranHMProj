//
//  CMOXMPPRoomPool.h
//  CMOChat
//
//  Created by Administrator on 11/5/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMPPHeader.h"

@interface CMOXMPPRoomPool : NSObject

- (void)setRoom:(XMPPRoom *)room forJid:(NSString *)jid;

- (XMPPRoom *)roomForKey:(NSString *)jid;

- (void)removeAllRooms;

@end
