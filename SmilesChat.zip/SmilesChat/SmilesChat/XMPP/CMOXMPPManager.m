//
//  XMPPManager.m
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOXMPPManager.h"
#import "CMOCoreComponents.h"
#import "CMOUser.h"
#import "CMOUtils.h"
#import "CMORoomDetails+CoreDataProperties.h"
#import "CMOOwners+CoreDataProperties.h"

typedef NS_ENUM(NSInteger, XMPPQuery) {
    XMPPDISCOITEMS,
    XMPPDISCOINFO,
    XMPPROSTERITEMS
};




@interface CMOXMPPManager() <XMPPRosterDelegate>{
        
    BOOL isXmppConnected;
    
    NSString *password;
    
    NSManagedObjectContext *managedObjectContext_roster;
    
    CMOXMPPAuthCompletionHandler authCompletionHandler;
    
    CMODidReceivedItems response;
    CMODidReceivedRoster rosterResponse;
    
    CMOXMPPDidReceivePresence didReceivePresence;
    
    CMOXMPPMessageHandler messageHandler;
    
    NSString *conferenceID;
    NSString *roomElementID;
    NSString *rosterElementID;
    NSString *roomInfoElementID;
    NSString *sendMessageID;
    
    NSMutableArray *usersToJoinRoom;
    NSMutableDictionary *messageHandlerDictionary;
    
    XMPPMessageDeliveryReceipts *xmppMessageDeliveryRecipts;
    
    BOOL customCertEvaluation;
    BOOL isAutoPingSuccess;
    
    XMPPMessage *iMessage;
    
    CMORoomDetails *roomDetails;
}


    
@end

static CMOXMPPManager *sharedManager = nil;

@implementation CMOXMPPManager
@synthesize xmppStream,myJID;
@synthesize xmppReconnect;
@synthesize xmppRoster;
@synthesize xmppMUC;
@synthesize xmppRoom;
@synthesize xmppRoomStorage;
@synthesize xmppRosterStorage;
@synthesize xmppCapabilitiesStorage;
@synthesize xmppCapabilities;
@synthesize xmppMessageArchivingCoreDataStorage;
@synthesize xmppMessageArchivingModule;
@synthesize xmppRoomPool;
@synthesize xmppvCardTempModule;
@synthesize xmppvCardStorage;
@synthesize xmppPing;
@synthesize xmppvCardAvatarModule;
@synthesize xmppMessageArchiveManagement;
@synthesize xmppAutoPing;

#pragma mark -
#pragma mark singleton

- (id)init{
    self= [super init];
    if(self){
      // [self setupStorage];
       [self setupStream];
    }
    return self;
}


- (void)setupStorage{
  
}


#pragma mark -
#pragma mark Setup XMPPStream
    
- (void)setupStream {
    NSAssert(xmppStream == nil, @"Method setupStream invoked multiple times");
   
    self.xmppStream = [[XMPPStream alloc]init];
    
    if ([CMOUtils isConnectionSecured]){
        self.xmppStream.startTLSPolicy = XMPPStreamStartTLSPolicyRequired;
    }
    
    messageHandlerDictionary = [[NSMutableDictionary alloc]init];

    self.xmppReconnect = [[XMPPReconnect alloc] init];
    self.xmppReconnect.reconnectTimerInterval = 20.0;
    //self.xmppReconnect.autoReconnect = false;
    xmppRoomPool = [[CMOXMPPRoomPool alloc]init];
    
    customCertEvaluation = YES;
    
    xmppRosterStorage = [[XMPPRosterCoreDataStorage alloc]initWithDatabaseFilename:XMPP_ROSTER_DATAMODEL storeOptions:nil];
    xmppRoomStorage = [[XMPPRoomCoreDataStorage alloc]initWithDatabaseFilename:@"CMOXMPPRoomCoreData" storeOptions:nil];
    xmppvCardStorage = [[XMPPvCardCoreDataStorage alloc]initWithDatabaseFilename:@"CMOXMPPvCardStorage" storeOptions:nil];
    
   // xmppRosterStorage = [[XMPPRosterCoreDataStorage alloc]initWithDatabaseFilename:XMPP_ROSTER_DATAMODEL storeOptions:nil];//[XMPPRosterCoreDataStorage sharedInstance];
    xmppRoster = [[XMPPRoster alloc] initWithRosterStorage:xmppRosterStorage];
    xmppRoster.autoFetchRoster = YES;
    xmppRoster.autoAcceptKnownPresenceSubscriptionRequests = YES;
    
    xmppMUC = [[XMPPMUC alloc]initWithDispatchQueue:dispatch_get_main_queue()];
    
    //xmppvCardStorage = [[XMPPvCardCoreDataStorage alloc]initWithDatabaseFilename:@"CMOXMPPvCardStorage" storeOptions:nil];
    xmppvCardTempModule = [[XMPPvCardTempModule alloc]initWithvCardStorage:xmppvCardStorage];
    
    xmppvCardAvatarModule = [[XMPPvCardAvatarModule alloc]initWithvCardTempModule:xmppvCardTempModule];
    //xmppMessageArchiveManagement = [[XMPPMessageArchiveManagement alloc]initWithDispatchQueue:dispatch_get_main_queue()];
    
    
    xmppAutoPing = [[XMPPAutoPing alloc]init];
    xmppAutoPing.pingInterval = 15.0f;
    //xmppPing = [[XMPPPing alloc]init];
    //xmppPing.respondsToQueries = YES;
    

   // [xmppPing              activate:xmppStream];
    [xmppAutoPing           activate:xmppStream];
    [xmppvCardTempModule   activate:xmppStream];
    [xmppvCardAvatarModule activate:xmppStream];
    [xmppMUC               activate:xmppStream];
    [xmppReconnect         activate:xmppStream];
    [xmppRoster            activate:xmppStream];
   
    
    [xmppAutoPing addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [xmppRoster addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [xmppPing addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [xmppvCardTempModule addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [xmppvCardAvatarModule addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [xmppMUC addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [xmppReconnect addDelegate:self delegateQueue:dispatch_get_main_queue()];
    //[xmppCapabilities addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
    
   // [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(networkOnline:) name:XMPP_NETWORK_ONLINE_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(roomAlreadyJoined:) name:@"xmppAlreadyJoinedNotification" object:nil];
    
   
}

- (void)networkOnline:(NSNotification *)notification{
    ////DDLogInfo(@"Network online. Now try to reconnect");
    //[self.xmppReconnect manualStart];
}

- (NSManagedObjectContext *)managedObjectContext_rooms
{
    if (!xmppRoomStorage){
        DDLogError(@"XMPP Room Storage is NIL %@,%@",THIS_FILE,THIS_METHOD);
    }
    return [xmppRoomStorage mainThreadManagedObjectContext];
}


- (NSManagedObjectContext *)managedObjectContext_messageArchive{
    return [xmppMessageArchivingCoreDataStorage mainThreadManagedObjectContext];
}

- (NSManagedObjectContext *)managedObjectContext_roster{
    return [xmppRosterStorage mainThreadManagedObjectContext];
}

- (NSManagedObjectContext *)managedObjectContext_vCard{
    return [xmppvCardStorage mainThreadManagedObjectContext];
}

- (NSEntityDescription *)roomEntity{
    return [NSEntityDescription entityForName:@"XMPPRoomMessageCoreDataStorageObject" inManagedObjectContext:self.managedObjectContext_rooms];
}


/*
 
 NSManagedObjectContext *context = [self.xmppManager managedObjectContext_messageArchive];
 NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"XMPPMessageArchiving_Message_CoreDataObject" inManagedObjectContext:context];
 */

- (void)teardownStream{

    [xmppStream removeDelegate:self];
    [xmppPing removeDelegate:self];
    [xmppvCardTempModule removeDelegate:self];
    [xmppvCardAvatarModule removeDelegate:self];
    [xmppMUC removeDelegate:self];
    [xmppReconnect removeDelegate:self];

    [xmppRoster removeDelegate:self];
    
//    [xmppPing               deactivate];
//    [xmppvCardTempModule    deactivate];
//    [xmppvCardAvatarModule  deactivate];
//    [xmppMUC                deactivate];
//    [xmppRoster             deactivate];
//    [xmppRoster            deactivate];

    //[xmppCapabilities      deactivate];
    
    [xmppStream disconnect];
    
    xmppStream = nil;
    xmppPing = nil;
    xmppvCardTempModule = nil;
    xmppMUC = nil;
    xmppvCardAvatarModule = nil;
    xmppReconnect = nil;
    xmppRoster = nil;

}
    
    
#pragma mark
#pragma mark Online and Offline

- (void)goOnline{
    XMPPPresence *presence = [XMPPPresence presence];
    [xmppStream sendElement:presence];
}


- (void)goOffline{
    XMPPPresence *presence = [XMPPPresence presenceWithType:XMPP_PRESENCE_UNAVAILABLE];
    [xmppStream sendElement:presence];
}


- (void)failedToConnect{
    //[[NSNotificationCenter defaultCenter]
    //     postNotificationName:kOFCServerLoginFail object:self];
    //DDLogVerbose(@"DAMAC: 1 %@ %@",THIS_METHOD,THIS_FILE);
    [xmppStream disconnect];
}

#pragma mark
#pragma mark Send Message

- (void)sendMessage:(XMPPMessage *)message toRoom:(NSString *)roomID completionHandler:(CMOXMPPMessageHandler)handler{
    messageHandler = handler;
    iMessage = message;
    sendMessageID = [message attributeStringValueForName:@"id"];
    
    [messageHandlerDictionary setObject:handler forKey:sendMessageID];
    
    //DDLogInfo(@"DAMAC: 1 %@ %@",THIS_METHOD,THIS_FILE);
    if (![self.xmppRoom isJoined]){
//#warning Handle `didReceivePresence` in timoeout
        [self createOrJoinRoom:roomDetails userstoInvite:nil history:nil completionHandler:^(id response1, NSError *error) {
            if (response1){
                //DDLogInfo(@"DAMAC: 2 %@ %@",THIS_METHOD,THIS_FILE);
                self.xmppRoom = [self roomForId:[self roomJIDForName:roomID]];
                [self.xmppRoom sendMessage:message];
            }
            else{//Unable to join the room
                //DDLogInfo(@"DAMAC: 3 %@ %@",THIS_METHOD,THIS_FILE);
                if (handler){
                    //DDLogInfo(@"DAMAC: 4 %@ %@",THIS_METHOD,THIS_FILE);
                    handler(message,error);
                }
                //DDLogInfo(@"DAMAC: 5 %@ %@",THIS_METHOD,THIS_FILE);
            }
        }];
    }
    else{
        //DDLogInfo(@"DAMAC: 6 %@ %@",THIS_METHOD,THIS_FILE);
        self.xmppRoom = [self roomForId:[self roomJIDForName:roomID]];
        [self.xmppRoom sendMessage:message];
    }
}

- (void)addBuddyOrSendPresence:(NSString *)newBuddy toAdd:(BOOL)toAdd
{
    XMPPJID * newJID = [XMPPJID jidWithUser:newBuddy domain:self.domainName resource:nil];
    [self.xmppRoster addUser:newJID withNickname:newBuddy];
}


- (BOOL)isXmppStreamConnected{
    return [self.xmppStream isConnected];
}
    
#pragma mark -
#pragma mark XMPPStream Connect/Disconnect
- (BOOL)connectWithJID:(NSString *)JID
              password:(NSString *)myPassword
     completionHandler:(CMOXMPPAuthCompletionHandler)handler{
    
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    //Already connected
    authCompletionHandler = handler;
    if ([xmppStream isConnected]) {
        //Add XML Error
        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        ////DDLogInfo(@"****** XMPPStream Connected ******");
        
        //authCompletionHandler(nil,[NSXMLElement elementWithName:@"error" xmlns:@""]);
        return YES;
    }
    if(JID == nil || myPassword == nil){
        /*if (authCompletionHandler){
            NSXMLElement *element = [NSXMLElement elementWithName:@"error" xmlns:@"error"];
            authCompletionHandler(nil,element);
            authCompletionHandler = nil;
        }*/
        ////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
        ////DDLogInfo(@"JID Or Password is nil %@ %@",JID,myPassword);
        return NO;
    }
    
    ////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
    myJID = [XMPPJID jidWithUser:JID domain:self.domainName resource:CMOCHATIPHONE];
    
    [xmppStream setMyJID:myJID];
    [xmppStream setHostName:self.serverName];
    [xmppStream setHostPort:self.serverHost];
    password = myPassword;
    NSError *error;
    
    if (![xmppStream connectWithTimeout:XMPPStreamTimeoutNone error:&error]){
        ////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
        /*if (authCompletionHandler){
            NSXMLElement *element = [NSXMLElement elementWithName:@"error" xmlns:@"error"];
            authCompletionHandler(nil,element);
            authCompletionHandler = nil;
        }*/
        return NO;
    }
   // authCompletionHandler = handler;
    ////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
    return YES;
}

- (BOOL)disconnect{
    if (![xmppStream isDisconnected]) {
         [xmppStream disconnect];
        //[self teardownStream];
        return YES;
    }
    return NO;
}


#pragma mark
#pragma mark XMPP Fetch Rosters

- (void)fetchRosterswithCompletionHandler:(CMODidReceivedRoster)handler
{
    
    rosterResponse = handler;
    [self.xmppRoster fetchRoster];
    /*response = handler;
    rosterElementID = [self.xmppStream generateUUID];
 
    XMPPElement *query = [[XMPPElement alloc]initWithName:@"query" xmlns:@"jabber:iq:roster"];
    XMPPIQ *iq = [XMPPIQ iqWithType:@"get" elementID:rosterElementID];
    [iq addAttributeWithName:@"from" stringValue:[myJID full]];
    [iq addChild:query];
    [self.xmppStream sendElement:iq];*/
    
}


#pragma mark MUC - Rooms

- (XMPPElement *)query:(XMPPQuery)q{
    NSString *xmlns = @"";
    switch (q) {
        case XMPPDISCOITEMS:
            xmlns = MUC_DISCO_ITEMS;
            break;
        case XMPPDISCOINFO:
            xmlns = MUC_DISCO_INFO;
            break;
        case XMPPROSTERITEMS:
            xmlns = MUC_ROSTER_ITEMS;
            break;
        default:
            xmlns = MUC_DISCO_INFO;
            break;
    }
    return [[XMPPElement alloc]initWithName:@"query" xmlns:xmlns];
}

- (NSString *)conferenceChatDomain{
    return self.conferenceURL;//[NSString stringWithFormat:@"conference.%@",self.serverName];
}

- (XMPPJID *)roomJIDForName:(NSString *)name{
    return [XMPPJID jidWithUser:name
                         domain:[self conferenceChatDomain]
                       resource:CMOCHATIPHONE];
}


- (BOOL)isJoinedInRoom:(NSString *)roomId{
    if (!roomId && [roomId length] == 0){
        DDLogError(@"ROOM ID IS NIL");
        return false;
    }
    XMPPJID *jid = [self roomJIDForName:roomId];
    XMPPRoom *room = [self roomForId:jid];
    return [room isJoined];
}



//Get List of Rooms:
#pragma mark Discover Rooms

- (void)discoverServicesWithCompletionHandler:(CMODidReceivedItems)handler{
    conferenceID = [self.xmppStream generateUUID];
    //response = handler;
    [self.xmppMUC discoverRoomsForServiceNamed:[self conferenceChatDomain]];
}

//Utility - Get XMPPRoom Object
- (XMPPRoom *)roomForId:(XMPPJID *)chatroomJID{
    //Add rooms to Room pool.
    self.xmppRoom = [self.xmppRoomPool roomForKey:[chatroomJID user]];
    if (!self.xmppRoom){
        self.xmppRoom = [[XMPPRoom alloc] initWithRoomStorage:self.xmppRoomStorage
                                                          jid:chatroomJID
                                                dispatchQueue:dispatch_get_main_queue()];
        
        [self.xmppRoom activate:self.xmppStream];
        [self.xmppRoom addDelegate:self delegateQueue:dispatch_get_main_queue()];
        [self.xmppRoomPool setRoom:self.xmppRoom forJid:[chatroomJID user]];
    }
    
    return self.xmppRoom;
}


- (void)fetchRoomInfo:(NSString *)roomID{
    roomInfoElementID = [self.xmppStream generateUUID];
    
    XMPPJID *jid = [XMPPJID jidWithUser:roomID
                                 domain:[self conferenceChatDomain]
                               resource:CMOCHATIPHONE];
    XMPPIQ *iq = [XMPPIQ iqWithType:@"get"
                                 to:jid
                          elementID:roomInfoElementID child:[self query:XMPPDISCOINFO]];
    [iq addAttributeWithName:@"from" stringValue:[myJID full]];
    [self.xmppStream sendElement:iq];
    
}

- (void)inviteUsersToRoom:(XMPPRoom*)xmppRoomToInvite {
    for (id user in usersToJoinRoom){
        XMPPJID *userJid = [XMPPJID jidWithString:user];//[XMPPJID jidWithString:[NSString stringWithFormat:@"%@@%@",user,self.domainName]];
        [xmppRoomToInvite editRoomPrivileges:@[[XMPPRoom itemWithAffiliation:@"member" jid:userJid]]];
        [xmppRoomToInvite inviteUser:userJid withMessage:@"Welcome"];
    }
  //  [xmppRoomToInvite inviteUser:[XMPPJID jidWithString:@"CMOGroup"] withMessage:@"Welcome"];
    //Flush users after invitation
    if (usersToJoinRoom.count > 0){
        [usersToJoinRoom removeAllObjects];
        usersToJoinRoom = nil;
    }
    //Joined in the room
}

- (void)inviteUsersToJoinTheRoom:(id)users forRoom:(NSString *)roomId affiliation:(Affiliation)affiliation{
    XMPPJID *roomJid = [self roomJIDForName:roomId];
    XMPPRoom *room = [self roomForId:roomJid];
    for (id user in users){
        XMPPJID *userJid = [XMPPJID jidWithString:user];
        if (affiliation == AffiliationMember){
            [room editRoomPrivileges:@[[XMPPRoom itemWithAffiliation:@"member" jid:userJid]]];
        }
        /*else{
            [room editRoomPrivileges:@[[XMPPRoom itemWithAffiliation:@"none" jid:userJid]]];
        }*/
        [room inviteUser:userJid withMessage:@"Welcome"];
    }
}

//Room: 1
//The user sends presence to <room@service/nick> and signal his or her support for the Multi-User Chat protocol. This operation will be done by XMPPRoom.
//roomName Optional


//If roomJID available, then user can join the group. If roomJID not available, then new room will be created and user will join the group.
- (void)createOrJoinRoom:(CMORoomDetails *)roomInfo
           userstoInvite:(NSMutableArray *)users
                 history:(NSString *)date
       completionHandler:(CMOXMPPDidReceivePresence)handler {
  
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (roomInfo.roomName.length == 0)return;
    roomDetails = roomInfo;
    XMPPJID *chatRoomJID = [XMPPJID jidWithUser:
                            (roomInfo.roomName == nil ? [self.xmppStream generateUUID] : roomInfo.roomName)
                                         domain:[self conferenceChatDomain]
                                       resource:CMOCHATIPHONE];
    self.xmppRoom = [self roomForId:chatRoomJID];
    
    didReceivePresence = handler;
    
    if ([self.xmppRoom isJoined]){
        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        DDLogError(@"%@ is already joined",[self.xmppRoom.myRoomJID user]);
        handler(@"",nil);
        return;
    }

    /*if ([self.xmppStream myJID] == nil || password == nil){
        ////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
        handler(nil,[NSError errorWithDomain:@"Leaving Room" code:-9001 userInfo:@{@"room":self.xmppRoom ? self.xmppRoom : @""}]);
        return;
    }*/
    
    if ([self.xmppStream isDisconnected]){
        ////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
        DDLogError(@"***** XMPPStream is disconnected *****");
        [self connectWithJID:[[self.xmppStream myJID]user]
                    password:password
           completionHandler:^(XMPPStream *stream, DDXMLElement *error) {
               
            if (error){
                ////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
                DDLogError(@"Error in connecting stream");
            }
            else{
                ////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
                ////DDLogInfo(@"Stream connected");
                if (![self.xmppRoom isJoined]){
                     ////DDLogInfo(@"%@ %@ 7",THIS_METHOD,THIS_FILE);
                    [self.xmppRoom joinRoomUsingNickname:[self.myJID user] history:(date == nil) ? nil : [self chatHistory:date]];
                }
            }
        }];
    }
    else{
            ////DDLogInfo(@"%@ %@ 7 %@",THIS_METHOD,THIS_FILE,didReceivePresence);
        if (![self.xmppRoom isJoined]){
            ////DDLogInfo(@"%@ %@ 8",THIS_METHOD,THIS_FILE);
                [self.xmppRoom joinRoomUsingNickname:[self.myJID user] history:(date == nil) ? nil : [self chatHistory:date]];
        }
    }
}

- (void)sendPresenceToRooms:(NSArray *)rooms{
    if (rooms.count <= 0)return;
    /*
     <presence from='hildjj@jabber.com' to='multicast.jabber.org' type='unavailable'>
     <addresses xmlns='http://jabber.org/protocol/address'>
     <address type='bcc' jid='temas@jabber.org'/>
     <address type='bcc' jid='jer@jabber.org'/>
     </addresses>
     </presence>
     */
    XMPPPresence *presence = [XMPPPresence presence];
    [presence addAttributeWithName:@"from" stringValue:[[self.xmppStream myJID] bare]];
    [presence addAttributeWithName:@"to" stringValue:self.conferenceChatDomain];
    XMPPElement *addressNode = [[XMPPElement alloc]initWithName:@"addresses" xmlns:@"http://jabber.org/protocol/address"];
    for (NSString *roomId in rooms){
        XMPPElement *addressElement = [XMPPElement elementWithName:@"address"];
        [addressElement addAttributeWithName:@"type" stringValue:@"to"];
        [addressElement addAttributeWithName:@"jid" stringValue:[NSString stringWithFormat:@"%@@%@",roomId,self.conferenceChatDomain]];
        [addressNode addChild:addressElement];
    }
    [presence addChild:addressNode];
    [self.xmppStream sendElement:presence];
}

- (void)leaveRoom{
    if (self.xmppRoom){
        [self.xmppRoom leaveRoom];
    }
}


- (NSXMLElement *)chatHistory:(NSString *)date{
     NSXMLElement *history = [NSXMLElement elementWithName:@"history"];
    [history addAttributeWithName:@"since" stringValue:date];
    return history;
}


- (void)roomAlreadyJoined:(NSNotification *)notification{
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (didReceivePresence != nil){
        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        XMPPRoom *room = notification.userInfo[@"room"];
        didReceivePresence(room,nil);
        didReceivePresence = nil;
    }
}

#pragma mark Room Subject

- (void)setRoomSubject:(NSString *)roomSubject forRoom:(NSString *)roomJID{
    if (!roomSubject)return;
    
    XMPPJID *jid = [XMPPJID jidWithUser:roomJID
                                 domain:[self conferenceChatDomain]
                               resource:CMOCHATIPHONE];
    self.xmppRoom = [self roomForId:jid];
    [self.xmppRoom changeRoomSubject:roomSubject];
}

- (void)getMyRooms{
    
   XMPPElement *query = [self query:XMPPDISCOITEMS];
//    XMPPElement *node = [[XMPPElement alloc]initWithName:@"node" xmlns:@"http://jabber.org/protocol/muc#rooms"];
//    [query addChild:node];
   // XMPPElement *query = [[XMPPElement alloc]initWithXMLString:<#(nonnull NSString *)#> error:<#(NSError * _Nullable __autoreleasing * _Nullable)#>]
    [query addAttributeWithName:@"node" stringValue:@"http://jabber.org/protocol/muc#rooms"];
    XMPPIQ *iq = [XMPPIQ iqWithType:@"get"
                                 to:[XMPPJID jidWithString:@"subash@hmecmac000094.local/CMOCHATIPHONE"]
                          elementID:[self.xmppStream generateUUID] child:query];
    [iq addAttributeWithName:@"from" stringValue:[myJID full]];
    [self.xmppStream sendElement:iq];
}

//Room:2
/*- (void)getRoomConfiguration{
    XMPPElement *query = [[XMPPElement alloc]initWithName:@"query" xmlns:MUC_DISCO_ITEMS];
    
    XMPPIQ *iq = [XMPPIQ iqWithType:@"get"
                                 to:[XMPPJID jidWithString:kCMOXMPPServerDomain]
                          elementID:[self.xmppStream generateUUID] child:query];
    [self.xmppStream sendElement:iq];
    
}*/

/*- (void)occupantsOfRooms:(NSString *)roomJId completionHandler:(CMODidReceivedItems)handler{
    //response = handler;
    XMPPJID *jid = [XMPPJID jidWithUser:roomJId
                                 domain:[self conferenceChatDomain]
                               resource:CMOCHATIPHONE];
    self.xmppRoom = [self roomForId:jid];
    [self.xmppRoom fetchMembersList];
    [self fetchOwnerList:jid];
    [self fetchAdminsList:jid];
}*/


- (void)fetchOwnerList:(XMPPJID *)roomJID{
    NSString *fetchID = [xmppStream generateUUID];
    
    NSXMLElement *item = [NSXMLElement elementWithName:@"item"];
    [item addAttributeWithName:@"affiliation" stringValue:@"admin"];
    
    NSXMLElement *query = [NSXMLElement elementWithName:@"query" xmlns:XMPPMUCAdminNamespace];
    [query addChild:item];
    
    XMPPIQ *iq = [XMPPIQ iqWithType:@"get" to:roomJID elementID:fetchID child:query];
    
    [self.xmppStream sendElement:iq];
}


- (void)fetchAdminsList:(XMPPJID *)roomJID{
    NSString *fetchID = [xmppStream generateUUID];
    
    NSXMLElement *item = [NSXMLElement elementWithName:@"item"];
    [item addAttributeWithName:@"affiliation" stringValue:@"owner"];
    
    NSXMLElement *query = [NSXMLElement elementWithName:@"query" xmlns:XMPPMUCAdminNamespace];
    [query addChild:item];
    
    XMPPIQ *iq = [XMPPIQ iqWithType:@"get" to:roomJID elementID:fetchID child:query];
    
    [self.xmppStream sendElement:iq];
}

- (void)fetchOfflineMessages{
    /*
     <iq type='get'>
     <query xmlns='http://jabber.org/protocol/disco#info'
     node='http://jabber.org/protocol/offline'/>
     </iq>
     */
    
    DDXMLElement *element = [XMPPElement elementWithName:@"query" xmlns:@"http://jabber.org/protocol/disco#info"];
    [element addAttributeWithName:@"node" stringValue:@"http://jabber.org/protocol/offline"];
    XMPPIQ *iq = [XMPPIQ iqWithType:@"get" elementID:@"offline123" child:element];
   
   // DDXMLElement *node = [DDXMLElement elementWithName:@"node" stringValue:@"http://jabber.org/protocol/offline/"];
    //[element addChild:node];
    //[iq addChild:element];
    [self.xmppStream sendElement:iq];
}


#pragma mark Chat Typing Status

- (void)sendChatStatus:(NSString *)roomID status:(ChatTypStatus)status{
    XMPPMessage *message = [XMPPMessage message];
    switch (status) {
        case ChatTypeActive:
            [message addActiveChatState];
            break;
        case ChatTypeComposing:
            [message addComposingChatState];
            break;
        case ChatTypePaused:
            [message addPausedChatState];
            break;
        case ChatTypeInactive:
            [message addInactiveChatState];
            break;
        case ChatTypeGone:
            [message addGoneChatState];
            break;
        default:
            [message addInactiveChatState];
            break;
    }
    if (roomID){
        self.xmppRoom = [self roomForId:[self roomJIDForName:roomID]];
        [self.xmppRoom sendMessage:message];
    }
}


#pragma mark User Information - vCard

- (void)updateUserInformation:(CMOUser *)user{
    NSData *imageData = nil;
    if (user.userAvatar){
        imageData = UIImagePNGRepresentation(user.userAvatar);
    }
    
    dispatch_queue_t queue = dispatch_queue_create("queue", DISPATCH_QUEUE_PRIORITY_DEFAULT);
    dispatch_async(queue, ^{
        
        XMPPvCardTemp *myVcardTemp = [self.xmppvCardTempModule myvCardTemp];
        if (!myVcardTemp)
        {
            NSXMLElement *vCardXML = [NSXMLElement elementWithName:@"vCard" xmlns:@"vcard-temp"];
            myVcardTemp = [XMPPvCardTemp vCardTempFromElement:vCardXML];
            //[newvCardTemp setNickname:@"nick"];
            //[xmppvCardTempModule updateMyvCardTemp:newvCardTemp];
        }
        
        if (user.username){
            [myVcardTemp setNickname:[NSString stringWithFormat:@"%@",user.username]];
        }
        if (imageData){
            [myVcardTemp setPhoto:imageData];
        }
        
        [self.xmppvCardTempModule updateMyvCardTemp:myVcardTemp];
    });
}

- (XMPPvCardTemp *)myvCard{
    return [self.xmppvCardTempModule myvCardTemp];
}


#pragma mark Fetch vCard

- (XMPPvCardTemp *)fetchUservCardforJID:(NSString *)jid{
    XMPPJID *userJID =  [XMPPJID jidWithString:[NSString stringWithFormat:@"%@@%@",jid,self.domainName]];
    //Note: This will return vCard if it is available in local db. else it will fetch it from server and return it in xmppvCardTempModule delegate methods.
    return [self.xmppvCardTempModule vCardTempForJID:userJID shouldFetch:true];
}


#pragma mark Mesage Archive Management

- (void)retrieveArchivedMessages:(NSString *)roomId startdate:(NSString *)startdate endDate:(NSString *)enddate max:(NSInteger)max{
    
   /* XMPPIQ *iq = [XMPPIQ iqWithType:@"get" elementID:[xmppStream generateUUID]];
    //[iq addAttributeWithName:@"from" stringValue:[NSString stringWithFormat:@"%@@%@",roomId,self.conferenceChatDomain]];

     XMPPElement *query = [[XMPPElement alloc]initWithName:@"retrieve" xmlns:MUC_ARCHIVE];
    [query addAttributeWithName:@"with" stringValue:[NSString stringWithFormat:@"%@@%@",roomId,self.conferenceChatDomain]];
    
    //[NSString stringWithFormat:@"%@@%@",roomId,self.conferenceChatDomain]
    
    //start='1469-07-21T02:00:00Z'
     XMPPElement *rsm = [[XMPPElement alloc]initWithName:@"set" xmlns:@"http://jabber.org/protocol/rsm"];
    if (startdate.length > 0){
        DDXMLElement *startDateElement = [XMPPElement elementWithName:@"start" stringValue:startdate];
        [rsm addChild:startDateElement];
    }
    if (enddate.length > 0){
        DDXMLElement *endDateElement = [XMPPElement elementWithName:@"end" stringValue:startdate];
       // [rsm addChild:endDateElement];
    }
    
    if (max > 0){
        DDXMLElement *maxElement = [XMPPElement elementWithName:@"max" numberValue:[NSNumber numberWithInteger:max]];
        [rsm addChild:maxElement];
    }
    
    [query addChild:rsm];
    [iq addChild:query];
    [self.xmppStream sendElement:iq];*/
    
    /*
     <iq type='get' id='page1'>
     <retrieve xmlns='urn:xmpp:archive'
     with='juliet@capulet.com/chamber'
     start='1469-07-21T02:56:15Z'>
     <set xmlns='http://jabber.org/protocol/rsm'>
     <max>100</max>
     </set>
     </retrieve>
     </iq>
     
     */
    
    XMPPIQ *iq = [XMPPIQ iqWithType:@"set" elementID:@"juliet1"];
    XMPPElement *query = [[XMPPElement alloc]initWithName:@"query" xmlns:@"urn:xmpp:mam:0"];
    XMPPElement *x = [[XMPPElement alloc]initWithName:@"x" xmlns:@"jabber:x:data"];
    [x addAttributeWithName:@"type" stringValue:@"submit"];
    
    XMPPElement *field1 = [XMPPElement elementWithName:@"field"];
    [field1 addAttributeWithName:@"var" stringValue:@"FORM_TYPE"];
    [field1 addAttributeWithName:@"type" stringValue:@"hidden"];

    DDXMLElement *value1 = [DDXMLElement elementWithName:@"value" stringValue:@"urn:xmpp:mam:0"];
    [field1 addChild:value1];
    
    XMPPElement *field2 = [XMPPElement elementWithName:@"field"];
    [field2 addAttributeWithName:@"var" stringValue:@"with"];
    
    DDXMLElement *value2 = [DDXMLElement elementWithName:@"value" stringValue:[NSString stringWithFormat:@"%@@%@",roomId,self.conferenceChatDomain]];
    [field2 addChild:value2];
    //[query addAttributeWithName:@"with" stringValue:[NSString stringWithFormat:@"%@@%@",roomId,self.conferenceChatDomain]];
    
    
    [x addChild:field1];
    [x addChild:field2];
    
    XMPPElement *rsm = [[XMPPElement alloc]initWithName:@"set" xmlns:@"http://jabber.org/protocol/rsm"];
    
    DDXMLElement *maxElement = [XMPPElement elementWithName:@"max" numberValue:[NSNumber numberWithInteger:100]];
    [rsm addChild:maxElement];
    
    //XMPPElement *beforeElement = [XMPPElement elementWithName:@"before"];
    //[rsm addChild:beforeElement];
    [query addChild:rsm];
    [query addChild:x];
    [iq addChild:query];
     [self.xmppStream sendElement:iq];
}


#pragma mark Offline Messages

- (void)retrieveOfflineMessages{
    /*
     <iq type='get'>
     <query xmlns='http://jabber.org/protocol/disco#info'
     node='http://jabber.org/protocol/offline'/>
     </iq>
     */
    
    XMPPElement *query = [[XMPPElement alloc]initWithName:@"query" xmlns:@"http://jabber.org/protocol/disco#info"];
    [query addAttributeWithName:@"node" stringValue:@"http://jabber.org/protocol/offline"];
    XMPPIQ *iq = [XMPPIQ iqWithType:@"get"];
    [iq addChild:query];
    [self.xmppStream sendElement:iq];
}

- (void)removeAllRooms{
    if (self.xmppRoomPool){
        [self.xmppRoomPool removeAllRooms];
    }
}

#pragma mark
#pragma mark XMPP Delegate Methods
    
- (void)xmppStreamDidConnect:(XMPPStream *)sender{
    ////DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    [self authenticateWithStream:sender];
}


- (void)authenticateWithStream:(XMPPStream *)sender{
    NSError *authenticationError = nil;
    if (![[self xmppStream] authenticateWithPassword:password error:&authenticationError])
    {
        DDLogError(@"Error authenticating: %@", authenticationError);
        isXmppConnected = NO;
        if (authCompletionHandler){
            authCompletionHandler(sender,nil);
            authCompletionHandler = nil;
        }
        return;
    }
    isXmppConnected = YES;
}
    
- (void)xmppStreamDidAuthenticate:(XMPPStream *)sender
{
    if (authCompletionHandler){
        authCompletionHandler(sender,nil);
        authCompletionHandler = nil;
    }
    [self goOnline];
    isAutoPingSuccess = true;
    //Send Ping to server once authenticated to keep the session alive.
    [self.xmppPing sendPingToServer];
    
    //Get Current user vCard on Authenticate
    [self myvCard];
    //XMPPvCardTemp *myvCard = [self myvCard];
    //////DDLogInfo(@"My vCard %@",myvCard);
//    if (!myvCard){
//        CMOUser *user = [[CMOUser alloc]init];
//        user.username = [[sender myJID]user];
//        [self updateUserInformation:user];
//    }

    [[NSNotificationCenter defaultCenter] postNotificationName: XMPP_CONNECTION_ESTABLISHED object:nil userInfo:nil];
}

- (void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(NSXMLElement *)error
{
    //DDLogVerbose(@"**** Did Not Authenticate **** %@: %@", THIS_FILE, THIS_METHOD);
    if (authCompletionHandler){
        authCompletionHandler(sender,error);
        authCompletionHandler = nil;
    }
    [self failedToConnect];
}
 
- (BOOL)xmppStream:(XMPPStream *)sender didReceiveIQ:(XMPPIQ *)iq{
    //////DDLogInfo(@"IQ Description: %@",iq.description);
    
    if ([iq isErrorIQ]){
        DDLogError(@"Some Error Occured for IQ: %@",iq.description);
        if (rosterResponse){
            NSError *error = [self.xmppErrorHandler xmppIQError:iq];
            rosterResponse(nil,error);
        }
        return NO;
    }
    /*if([iq isResultIQ])
    {
        if ([[iq elementID] isEqualToString:@"offline123"]){
            NSLog(@"Offline result %@",iq);
        }
        
        if([iq elementForName:@"query" xmlns:MUC_DISCO_ITEMS]){
            NSXMLElement *query = [iq childElement];
            NSArray *items = [query children];
            if (response){
                response(items,nil);
            }
        }
        
        if([iq elementForName:@"query" xmlns:MUC_DISCO_INFO]){
            DDXMLElement *query = [iq elementForName:@"query" xmlns:MUC_DISCO_INFO];
            NSString *node = [query attributeStringValueForName:@"node"];
            if ([node isEqualToString:@"http://jabber.org/protocol/offline"]){
                ////DDLogInfo(@"Offline Messages %@",iq);
            }
            
            //node='http://jabber.org/protocol/offline'
            //NSXMLElement *query = [iq childElement];
            //NSArray *items = [query children];
            //response(items,nil);
        }
        
        if ([iq elementForName:@"retrieve" xmlns:MUC_ARCHIVE]){//[iq elementForName:@"xmlns" xmlns:MUC_ARCHIVE]){
            NSXMLElement *query = [iq childElement];
            NSArray *items = [query children];
            [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_ARCHIVE_CONVERSATION_NOTIFICATION object:nil userInfo:@{@"archives":items}];
        }
        
        
        //Getting Room Info
        if ([iq.elementID isEqualToString:roomInfoElementID]){
            if([iq elementForName:@"query" xmlns:MUC_DISCO_INFO]){
                NSXMLElement *query = [iq childElement];
                NSArray *items = [query children];
                if (response){
                    response(items,nil);
                }
            }
        }
        
        //if ([iq.elementID isEqualToString:rosterElementID]){
            if([iq elementForName:@"query" xmlns:MUC_ROSTER_ITEMS]){
                NSXMLElement *query = [iq childElement];
                NSArray *items = [query children];
                if (rosterResponse){
                    rosterResponse(items,nil);
                }
            }
        //}
    }*/
    return NO;
    
}


- (void)xmppStream:(XMPPStream *)sender didSendMessage:(XMPPMessage *)message{
    //[xmppMessageArchivingCoreDataStorage archiveMessage:message outgoing:true xmppStream:sender];
    if (message.hasChatState){
        return;
    }
 
}

- (void)xmppStream:(XMPPStream *)sender didFailToSendIQ:(XMPPIQ *)iq error:(NSError *)error{
   
}

- (void)xmppStream:(XMPPStream *)sender didFailToSendMessage:(XMPPMessage *)message error:(NSError *)error{
    DDLogInfo(@"DAMAC: 1 %@ %@",THIS_METHOD,THIS_FILE);
    if (message.hasChatState){
        return;
    }
    //DDLogInfo(@"DAMAC: 2 %@ %@",THIS_METHOD,THIS_FILE);
    if (messageHandler){
        //DDLogInfo(@"DAMAC: 3 %@ %@",THIS_METHOD,THIS_FILE);
        messageHandler(message,error);
        messageHandler = nil;
    }
    //DDLogInfo(@"DAMAC: 99 %@ %@",THIS_METHOD,THIS_FILE);
}

//Error
- (void)xmppStream:(XMPPStream *)sender didFailToSendPresence:(XMPPPresence *)presence error:(NSError *)error{
    DDLogError(@"Failed to send presence");
}

- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message{
   // //DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    //User Type Status
    //////DDLogInfo(@"Message is %@",message);
    //Update message table status
    // DDLogError(@"DAMAC: 1 %@ %@",THIS_METHOD,THIS_FILE);
    
    if ([message isGroupChatMessageWithBody]){
        NSString *messageId = [message attributeStringValueForName:@"id"];
        //DDLogInfo(@"Message ID is %@",messageId);
        CMOXMPPMessageHandler handler = [messageHandlerDictionary valueForKey:messageId];
        if (handler){
            handler(message,nil);
            [messageHandlerDictionary removeObjectForKey:messageId];
            handler = nil;
        }
    }
        
    /*if ([message isGroupChatMessageWithBody] && [[message attributeStringValueForName:@"id"] isEqualToString:sendMessageID]){
       //  DDLogError(@"DAMAC: 2 %@ %@",THIS_METHOD,THIS_FILE);
        NSString *user = [message.to user];
        if ([[sender.myJID user] isEqualToString:user]){
          //  DDLogError(@"DAMAC: 3 %@ %@",THIS_METHOD,THIS_FILE);
            DDLogError(@"Message received i.e., Message Sent Successfully");
            if (messageHandler) {
               // DDLogError(@"DAMAC: 4 %@ %@",THIS_METHOD,THIS_FILE);
                messageHandler(message,nil);
                sendMessageID = nil;
                iMessage = nil;
                messageHandler = nil;
            }
        }
    }*/

    if (message.hasChatState && !message.isErrorMessage){
        if ([[sender.myJID user] isEqualToString:[message.from resource]])return;
        NSString *messageType = XMPP_MESSAGE_INACTIVE;
        if (message.hasActiveChatState){
            messageType = XMPP_MESSAGE_ACTIVE;
        }
        else if (message.hasComposingChatState){
            messageType = XMPP_MESSAGE_COMPOSING;
            ////DDLogInfo(@"Composing Message");
        }
        else if (message.hasPausedChatState){
            messageType = XMPP_MESSAGE_PAUSED;
            ////DDLogInfo(@"Paused Message");
        }
        else if (message.hasInactiveChatState){
            messageType = XMPP_MESSAGE_INACTIVE;
            ////DDLogInfo(@"InActive in Chat");
        }
        else if (message.hasGoneChatState){
            messageType = XMPP_MESSAGE_GONE;
            ////DDLogInfo(@"Gone in Chat");
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_USER_TYPING_NOTIFICATION object:nil userInfo:@{@"message":message}];
        return;
    }
    
    //If sender receives the message which he send into the room, simply discard it.
    if ([message.elementID isEqualToString:sendMessageID]){
        return;
    }
    //DDLogError(@"DAMAC: 99 %@ %@",THIS_METHOD,THIS_FILE);

    //Message Received Acknowlegement
    /*if([message hasReceiptRequest]){
        XMPPMessage *responseMessage = [message generateReceiptResponse];
        NSXMLElement *body = [NSXMLElement elementWithName:@"body"];
        [body setStringValue:@"r"];
        [responseMessage addChild:body];
        [self.xmppStream sendElement:responseMessage];
    }
    if([message hasReceiptResponse]){
        return;
    }*/
    
    /*** 
      Message handled via Notification from Database insertion part.
     Refer XMPPRoomCoreDataStorage+CMORoomCoreDataStorage.m for more detail
     
     */
    
   /* if ([message isGroupChatMessageWithBody]){//|| [self isImage:message]
        
        NSString *messageBody = [[message elementForName:@"body"] stringValue];
        if (self.responseDelegate == nil){
            DDLogError(@"Response Delegate becomes nil. Check the conditions");
        }
        
        // Should Add delay, because data will be stored after the current method call. so wait for a second for database update and send the message to ui.
        //dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            [self.responseDelegate cmoxmppStream:sender didReceiveMessage:message];
        //});
        //DDLogVerbose(@"Received message %@",messageBody);
    }*/
}


- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence
{
    if (!presence){
        return;
    }
    
    if ([presence isErrorPresence]){
        NSError *error = [self.xmppErrorHandler xmppPresenceError:presence];
        if (didReceivePresence != nil){
            DDXMLElement *errorElement = [presence elementForName:@"error"];
            NSString *errorCode = [errorElement attributeStringValueForName:@"code"];
            NSError *presenceError = [NSError errorWithDomain:@"NOT ALLOWED TO JOIN" code:[errorCode integerValue] userInfo:nil];
            didReceivePresence(nil,presenceError);
            
            if ([errorCode integerValue] == 407){
                [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_REGISTRATION_REQUIRED_NOTIFICATION object:nil];
            }
            didReceivePresence = nil;
        }
        //DDLogVerbose(@"Error Occured at Presence %@",presence.description);
        return;
    }
    
    if([xmppMUC isMUCRoomPresence:presence]){
        //DDLogVerbose(@"Get Room presence");
        /*
         <presence xmlns="jabber:client" to="krishna@hmecd001128/CMOCHATIPHONE" from="20a02c3e-b59f-4fc8-8672-b5d544e6c96a@conference.hmecd001128/krishna"><x xmlns="vcard-temp:x:update"><photo>448bb1d356a8944aa2e820527e2ff66802631e8a</photo></x><x xmlns="http://jabber.org/protocol/muc#user"><item jid="krishna@hmecd001128/CMOCHATIPHONE" affiliation="owner" role="moderator"/><status code="110"/><status code="100"/></x></presence>
         */
       // XMPPElement *xmppPresence = [XMPPElement elementWithName:@"presence"];
        NSString *from = [presence attributeStringValueForName:@"from"];
        XMPPJID *fromJID = nil;
        if (from){
            fromJID = [XMPPJID jidWithString:from];
            from = [fromJID user];
        }
        NSArray *x = [presence elementsForName:@"x"];
        for (XMPPElement *xElement in x){
            if ([xElement.xmlns isEqualToString:@"http://jabber.org/protocol/muc#user"]){
                NSArray *statusCodes = [xElement elementsForName:@"status"];
                for (XMPPElement *status in statusCodes){
                    //201 - Room Created
                    /*
                        If the user is entering a room that is non-anonymous (i.e., which informs all occupants of each occupant's full JID as shown above), the service MUST warn the user by including a status code of "100" in the initial presence that the room sends to the new occupant:
                     */
                    //100 - Initial Presence with full JID to other occupants
                    //110 - Self Presence
                    if ([[status attributeStringValueForName:@"code"]integerValue] == 201){
                        NSLog(@"Room is created");
                        [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_ROOM_CREATION_NOTIFICATION object:nil userInfo:@{@"presence":presence}];
                    }
                    else if ([[status attributeStringValueForName:@"code"]integerValue] == 110){
                        [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_ROOM_SELF_JOINED_NOTIFICATION object:nil userInfo:@{@"presence":presence}];
                    }
                    else{
                        ////DDLogInfo(@"Send Presence with full JID to other occupants : Status: %ld",(long)[[status attributeStringValueForName:@"code"]integerValue]);
                    }
                }
            }
        }
    }
    
    if ([self isSelfRemoved:presence]) {
        XMPPRoom *removeRoom = [self.xmppRoomPool roomForKey:[presence.from.bare componentsSeparatedByString:@"@"][0]];
        [removeRoom leaveRoom];
        [[NSNotificationCenter defaultCenter]postNotificationName:DID_RECEIVED_REMOVE_NOTIFICATION object:nil userInfo:nil];
    }

    [self.notificationDelegate cmoxmppStream:sender didReceivePresence:presence isMUC:[xmppMUC isMUCRoomPresence:presence]];
    
   // //DDLogVerbose(@"%@: %@ - %@\nType: %@\nShow: %@\nStatus: %@", THIS_FILE, THIS_METHOD, [presence from], [presence type], [presence show],[presence status]);
    
}
    
- (void)xmppStream:(XMPPStream *)sender didReceiveError:(id)error
{
    DDLogInfo(@"%@: %@", THIS_FILE, THIS_METHOD);
    //didReceiveError(sender,error);
}

- (void)xmppStreamDidDisconnect:(XMPPStream *)sender withError:(NSError *)error
{
    DDLogInfo(@"Did Disconnect XMPPStream %@: %@", sender.myJID.user, error);
    //DDLogVerbose(@"DAMAC: 1 %@ %@",THIS_METHOD,THIS_FILE);

    //[[NSNotificationCenter defaultCenter]
     //postNotificationName:kOFCServerDisconnect object:self];
     [[NSNotificationCenter defaultCenter] postNotificationName: XMPP_DISCONNECT object:nil userInfo:nil];
    
    if (!isXmppConnected)
    {
        //DDLogVerbose(@"DAMAC: 2 %@ %@",THIS_METHOD,THIS_FILE);
        //DDLogVerbose(@"Unable to connect to server. Check xmppStream.hostName %@",error);
        //didDisconnect(sender,error);
        [[NSNotificationCenter defaultCenter] postNotificationName:XMPP_CONNECTION_FAILED object:nil userInfo:nil];
        [self failedToConnect];
        [self callAllMessagesCallBack];
        //[self messageFailedCallBack];
        //DDLogVerbose(@"DAMAC: 3 %@ %@",THIS_METHOD,THIS_FILE);
    }
    else {
        //Lost connection
        //DDLogVerbose(@"DAMAC: 4 %@ %@",THIS_METHOD,THIS_FILE);
    }
    //DDLogVerbose(@"DAMAC: 99 %@ %@",THIS_METHOD,THIS_FILE);
}

#pragma mark XMPP Reconnect

- (void)xmppReconnect:(XMPPReconnect *)sender didDetectAccidentalDisconnect:(SCNetworkReachabilityFlags)connectionFlags
{
     DDLogInfo(@"%@: %@", THIS_FILE, THIS_METHOD);
     [[NSNotificationCenter defaultCenter] postNotificationName: XMPP_ACCIDENTAL_DISCONNECT_NOTIFICATION object:nil userInfo:nil];
     //[self messageFailedCallBack];
     [self callAllMessagesCallBack];
}
- (BOOL)xmppReconnect:(XMPPReconnect *)sender shouldAttemptAutoReconnect:(SCNetworkReachabilityFlags)reachabilityFlags
{
    NSLog(@"shouldAttemptAutoReconnect:%u",reachabilityFlags);
    return YES;
}

#pragma mark XMPP Room Delegate Methods

- (void)xmppMUC:(XMPPMUC *)sender didDiscoverRooms:(NSArray *)rooms forServiceNamed:(NSString *)serviceName{
    //DDLogVerbose(@"Did received rooms %@",rooms);
    if (response){
        response(rooms,nil);
    }
}

- (void)xmppMUC:(XMPPMUC *)sender failedToDiscoverRoomsForServiceNamed:(NSString *)serviceName withError:(NSError *)error{
     //DDLogVerbose(@"Services Failed");
    if (response){
        response(nil,error);
    }
}


- (void)xmppRoomDidCreate:(XMPPRoom *)sender{
    //DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    //Make room persistant
    //[self.xmppRoom fetchConfigurationForm]; //will call xmppRoom:didFetchConfigurationForm:
    //Room created and configured
   // didReceivePresence(sender,nil);
}

- (void)xmppRoomDidJoin:(XMPPRoom *)sender{
    //DDLogVerbose(@" Joined in ther room %@ and room %@",sender.myNickname,sender.myRoomJID);
    NSString *user = [[sender myRoomJID] resource];
    if ([user isEqualToString:roomDetails.roomOwner] && [[roomDetails membersOnly]boolValue] == false){
        [sender fetchConfigurationForm];
        roomDetails = nil;
    }
    if (didReceivePresence != nil){
        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        didReceivePresence(sender,nil);
        didReceivePresence = nil;
    }
    [[NSNotificationCenter defaultCenter] postNotificationName: XMPP_ROOM_JOINED_NOTIFICATION object:nil userInfo:@{@"room":sender}];
}

- (void)xmppRoomDidLeave:(XMPPRoom *)sender{
    //DDLogError(@"Did Leave room");
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (didReceivePresence != nil){
        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        didReceivePresence(nil,[NSError errorWithDomain:@"Leaving Room" code:-9001 userInfo:@{@"room":self.xmppRoom}]);
        didReceivePresence = nil;
    }
    [[NSNotificationCenter defaultCenter] postNotificationName: XMPP_ROOM_LEFT_NOTIFICATION object:nil userInfo:@{@"room":sender}];
}

/*- (void)xmppRoomDidDestroy:(XMPPRoom *)sender{
    [[NSNotificationCenter defaultCenter] postNotificationName: XMPP_ROOM_DESTROY_NOTIFICATION object:nil userInfo:@{@"room":sender}];
}

- (void)xmppRoom:(XMPPRoom *)sender didFailToDestroy:(XMPPIQ *)iqError{
    
}*/


- (void)xmppRoom:(XMPPRoom *)sender occupantDidJoin:(XMPPJID *)occupantJID withPresence:(XMPPPresence *)presence{
    //add Notification
}

- (void)xmppRoom:(XMPPRoom *)sender occupantDidLeave:(XMPPJID *)occupantJID withPresence:(XMPPPresence *)presence{
    //add Notification
}

- (void)xmppRoom:(XMPPRoom *)sender occupantDidUpdate:(XMPPJID *)occupantJID withPresence:(XMPPPresence *)presence{
    //add Notification
}



//Note: This configuration can be done at server level under Group chat settings in Open fire.

- (void)xmppRoom:(XMPPRoom *)sender didFetchConfigurationForm:(NSXMLElement *)configForm{
    
    NSXMLElement *newConfig = [configForm copy];
    NSArray* fields = [newConfig elementsForName:@"field"];
    for (NSXMLElement *field in fields) {
        NSString *var = [field attributeStringValueForName:@"var"];
        //Make persistant in Openfire Group chat settings
        //roomconfig_membersonly
        if ([var isEqualToString:@"muc#roomconfig_membersonly"]) {
            [field removeChildAtIndex:0];
            [field addChild:[NSXMLElement elementWithName:@"value" stringValue:@"1"]];
        }
    }
    [sender configureRoomUsingOptions:newConfig];
}




#pragma mark MUC - Invitations
//Accept invitations automatically
- (void)xmppMUC:(XMPPMUC *)sender roomJID:(XMPPJID *) roomJID didReceiveInvitation:(XMPPMessage *)message{
    //If user is not joined in the group, then he has not accepted the invitation
    self.xmppRoom = [self.xmppRoomPool roomForKey:[roomJID user]];
    if (self.xmppRoom == nil){
        self.xmppRoom = [self roomForId:roomJID];
    }
    
    NSMutableDictionary *roomInfo = [[NSMutableDictionary alloc]init];
    [roomInfo setValue:[[self.xmppRoom roomJID]user] forKey:@"roomid"];
    [roomInfo setValue:message forKey:@"message"];
    [[NSNotificationCenter defaultCenter]postNotificationName:DID_RECEIVE_INVITATION object:nil userInfo:roomInfo];
    
//    [self.xmppRoom joinRoomUsingNickname:[self.xmppStream.myJID user] history:nil];
    /*[self createOrJoinRoom:[roomJID user] userstoInvite:nil history:nil completionHandler:^(id response, NSError *error) {
        if (error){
            DDLogError(@"Accepted invitation - On Room Join Failed %@",[roomJID user]);
        }
        else{
            ////DDLogInfo(@"Accepted Invitation - On Room Join Success %@",[roomJID user]);
        }
    }];*/
    
}

- (void)xmppMUC:(XMPPMUC *)sender roomJID:(XMPPJID *) roomJID didReceiveInvitationDecline:(XMPPMessage *)message{
    
}

#pragma mark - Members List
#warning Unused code

- (void)xmppRoom:(XMPPRoom *)sender didFetchMembersList:(NSArray *)items{
    NSLog(@"print user list=====%@",items);
    for (NSXMLElement *xmlItem in items) {
        NSString *jid = [[xmlItem attributeForName:@"jid"]stringValue];
        NSLog(@"print user jid=====%@",jid);
    }
    if (response){
        response(items,nil);
    }
}

- (void)xmppRoom:(XMPPRoom *)sender didNotFetchMembersList:(XMPPIQ *)iqError{
    NSLog(@"Failed to fetch member list");
    response(nil,iqError);
}


#pragma mark XMPP vCard Module

- (void)xmppvCardTempModule:(XMPPvCardTempModule *)vCardTempModule
        didReceivevCardTemp:(XMPPvCardTemp *)vCardTemp
                     forJID:(XMPPJID *)jid{
    
    XMPPvCardTemp *storedCard = [xmppvCardTempModule vCardTempForJID:jid shouldFetch:YES];
    //DDLogInfo(@"Stored card: %@ +++++++++++++++++++++",storedCard.prettyXMLString);

    DDLogInfo(@"Give Name is %@,\n Email Id is %@ \n and Address is %@ \n",storedCard.givenName,storedCard.emailAddresses,storedCard.addresses);
    [self didRecievedvCard:storedCard];
    [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_RECEIVED_VCARD object:nil userInfo:@{XMPP_NOTIFICATION_KEY_VCARD:storedCard != nil ? storedCard : XMPP_NOTIFACATION_VALUE_NULL}];
}


- (void)didRecievedvCard:(XMPPvCardTemp *)storedCard{
   // NSLog(@"Did received vCard %@",notification.userInfo);
    if (storedCard != nil){
        id <CMOUserClient>userClient = [_coreComponents userService];
        NSArray *emailAddresses = storedCard.emailAddresses;
        if (emailAddresses.count > 0){
            XMPPvCardTempEmail *emailvCard = emailAddresses[0];
            NSString *email = emailvCard.userid;
            if (email){
                NSArray *userDetails = [email componentsSeparatedByString:@"@"];
                NSLog(@"User details %@",userDetails);
                if (userDetails.count > 1){
                   
                    CMOUser *cmoUser = [userClient toCMOUSer:storedCard forUser:[userDetails[0] lowercaseString]];
                    NSLog(@"Name is %@ and Street is %@",cmoUser.username,cmoUser.street);
                    id <CMORepositoryClient>repoClient = [_coreComponents repositoryService];
                    [repoClient updatevCardDetailsToRoster:cmoUser];
                }
            }
        }
    }
}

- (void)xmppvCardTempModule:(XMPPvCardTempModule *)vCardTempModule
   failedToFetchvCardForJID:(XMPPJID *)jid
                      error:(NSXMLElement*)error{
    [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_RECEIVE_FAILED_VCARD object:nil userInfo:@{@"error":error == nil ? @"error in fetching vCard" : error}];
}

- (void)xmppvCardTempModuleDidUpdateMyvCard:(XMPPvCardTempModule *)vCardTempModule{
    [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_UPDATE_VCARD_SUCCESS object:nil];
}

- (void)xmppvCardTempModule:(XMPPvCardTempModule *)vCardTempModule failedToUpdateMyvCard:(NSXMLElement *)error{
    [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_UPDATE_VCARD_FAILED object:nil userInfo:@{@"error":error}];
}

#pragma mark XMPP Roster Delegate

- (void)xmppRoster:(XMPPRoster *)sender didReceiveRosterItem:(NSXMLElement *)item {
    ////DDLogVerbose(@"In Roster");
    //Roster response
    if (rosterResponse){
        rosterResponse(@[item],nil);
    }
}

-(void)xmppRoster:(XMPPRoster *)sender didReceivePresenceSubscriptionRequest:(XMPPPresence *)presence
{
    //DDLogVerbose(@"didReceivePresenceSubscriptionRequest");
    [self.xmppRoster acceptPresenceSubscriptionRequestFrom:[presence from] andAddToRoster:YES];
}

- (void)xmppRoster:(XMPPRoster *)sender didReceiveRosterPush:(XMPPIQ *)iq{
   // //DDLogVerbose(@"didReceiveRosterPush");
}

/**
 * Sent when the initial roster is received.
 **/
- (void)xmppRosterDidBeginPopulating:(XMPPRoster *)sender withVersion:(NSString *)version{
    
}

/**
 * Sent when the initial roster has been populated into storage.
 **/
- (void)xmppRosterDidEndPopulating:(XMPPRoster *)sender{
    
}


#pragma mark XMPP Secure Settings
- (void)xmppStream:(XMPPStream *)sender willSecureWithSettings:(NSMutableDictionary *)settings
{
    /*
     * Properly secure your connection by setting kCFStreamSSLPeerName
     * to your server domain name
     */
    [settings setObject:xmppStream.myJID.domain forKey:(NSString *)kCFStreamSSLPeerName];
    
    /*
     * Use manual trust evaluation
     * as stated in the XMPPFramework/GCDAsyncSocket code documentation
     */
    if (customCertEvaluation)
        [settings setObject:@(YES) forKey:GCDAsyncSocketManuallyEvaluateTrust];
}

/*
 * This is only called if the stream is secured with settings that include:
 * - GCDAsyncSocketManuallyEvaluateTrust == YES
 * That is, if a delegate implements xmppStream:willSecureWithSettings:, and plugs in that key/value pair.
 */
- (void)xmppStream:(XMPPStream *)sender didReceiveTrust:(SecTrustRef)trust completionHandler:(void (^)(BOOL shouldTrustPeer))completionHandler
{
    /* Custom validation for your certificate on server should be performed */
    
    completionHandler(YES); // After this line, SSL connection will be established
}


#pragma mark XMPP Ping Delegate Methods
- (void)xmppPing:(XMPPPing *)sender didReceivePong:(XMPPIQ *)pong withRTT:(NSTimeInterval)rtt{
    ////DDLogInfo(@"Did Receive Pong: %@ : Time : %f",pong,rtt);
}

- (void)xmppPing:(XMPPPing *)sender didNotReceivePong:(NSString *)pingID dueToTimeout:(NSTimeInterval)timeout{
    ////DDLogInfo(@"Dud Not Receive Pong Ping Id: %@ and Due time : %f",pingID,timeout);
}


#pragma mark XMPP Ping Delegate Methods

- (void)xmppAutoPingDidSendPing:(XMPPAutoPing *)sender{
    //////DDLogInfo(@"xmppAutoPingDidSendPing");
}
- (void)xmppAutoPingDidReceivePong:(XMPPAutoPing *)sender{
    //////DDLogInfo(@"xmppAutoPingDidReceivePong");
    if (!isAutoPingSuccess){//
        [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_PING_SUCCESS_NOTIFICATION object:nil];
        isAutoPingSuccess = true;
    }
}

- (void)xmppAutoPingDidTimeout:(XMPPAutoPing *)sender{
    ////DDLogInfo(@"xmppAutoPingDidTimeout");
    DDLogInfo(@"%@: %@", THIS_FILE, THIS_METHOD);
    if (isAutoPingSuccess){
        //DDLogVerbose(@"DAMAC: 1 %@ %@",THIS_METHOD,THIS_FILE);
        [[NSNotificationCenter defaultCenter]postNotificationName:XMPP_PING_FAILED_NOTIFICATION object:nil];
        isAutoPingSuccess = false;
       //No need to call. because the message is already in the queue.
        //sendMessageID & iMessage should not be nil. bcoz XMPP connection is still alive.
        
        
        //the following objects are not reset because the message might be in XMPP Queue, so whenever message is successfully sent, it has to be called back to actual sender.
        /*if (messageHandler && sendMessageID && iMessage) {
            //DDLogVerbose(@"DAMAC: 2 %@ %@",THIS_METHOD,THIS_FILE);

            messageHandler(iMessage,[NSError errorWithDomain:@"Message Failed Due to timeout" code:XMPP_TIMEOUT_ERROR userInfo:nil]);
        }
        else*/ if (didReceivePresence){
            didReceivePresence(nil,[NSError errorWithDomain:@"Leaving Room" code:-9001 userInfo:@{@"room":self.xmppRoom ? self.xmppRoom : @""}]);
            didReceivePresence = nil;
            //DDLogVerbose(@"DAMAC: 3 %@ %@",THIS_METHOD,THIS_FILE);
        }
        else{
            //Do Nothing
            //DDLogVerbose(@"DAMAC: 4 %@ %@",THIS_METHOD,THIS_FILE);
        }
        //[self messageFailedCallBack];
    }
    else{
        //Join Room Failed Call back
        //DDLogVerbose(@"DAMAC: 5 %@ %@",THIS_METHOD,THIS_FILE);
        if (didReceivePresence != nil){
            ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
            didReceivePresence(nil,[NSError errorWithDomain:@"Joining Failed due to Timeout" code:-1111 userInfo:nil]);
            didReceivePresence = nil;
            //DDLogVerbose(@"DAMAC: 6 %@ %@",THIS_METHOD,THIS_FILE);
        }
    }
    //DDLogVerbose(@"DAMAC: 99 %@ %@",THIS_METHOD,THIS_FILE);
}


- (void)messageFailedCallBack{
    //DDLogVerbose(@"DAMAC: 1 %@ %@",THIS_METHOD,THIS_FILE);
    if (messageHandler && sendMessageID && iMessage) {
        //DDLogVerbose(@"DAMAC: 2 %@ %@",THIS_METHOD,THIS_FILE);
        messageHandler(iMessage,[NSError errorWithDomain:@"Message Failed Due to N/w Disconnection" code:XMPP_ACCIDENTAL_DISCONNECT_ERROR userInfo:nil]);
        sendMessageID = nil;
        iMessage = nil;
    }
    //DDLogVerbose(@"DAMAC: 99 %@ %@",THIS_METHOD,THIS_FILE);
}


#pragma XMPP Message Archive Managements Delegate Methods
- (void)xmppMessageArchiveManagement:(XMPPMessageArchiveManagement *)xmppMessageArchiveManagement didFinishReceivingMessagesWithSet:(XMPPResultSet *)resultSet{
    
}

- (void)xmppMessageArchiveManagement:(XMPPMessageArchiveManagement *)xmppMessageArchiveManagement didReceiveMAMMessage:(XMPPMessage *)message{
    
}

- (void)xmppMessageArchiveManagement:(XMPPMessageArchiveManagement *)xmppMessageArchiveManagement didFailToReceiveMessages:(XMPPIQ *)error{
    
}

- (void)xmppMessageArchiveManagement:(XMPPMessageArchiveManagement *)xmppMessageArchiveManagement didReceiveFormFields:(XMPPIQ *)iq{
    NSLog(@"Form Fields %@",iq);
}

- (void)xmppMessageArchiveManagement:(XMPPMessageArchiveManagement *)xmppMessageArchiveManagement didFailToReceiveFormFields:(XMPPIQ *)iq{
    NSLog(@"Failed to recieve Form Fields %@",iq);
}

- (BOOL)isSelfRemoved:(XMPPPresence *)presence{
    NSArray *nodeX = [presence elementsForName:@"x"];
    for (XMPPElement *element in nodeX){
        if ([element.xmlns isEqualToString:@"http://jabber.org/protocol/muc#user"]){
            DDXMLElement *status = [element elementForName:@"status"];
            NSString *code = [status attributeStringValueForName:@"code"];
            if ([code isEqualToString:@"321"]) {
                return YES;
            }
        }
    }
    return NO;
}

- (void)callAllMessagesCallBack{
    for (NSString *key in [messageHandlerDictionary allKeys]){
        CMOXMPPMessageHandler xmppHandler = [messageHandlerDictionary valueForKey:key];
        xmppHandler(nil,[NSError errorWithDomain:@"Network Error" code:-9876 userInfo:nil]);
    }
    [self resetAllMessagesCallBack];
}

- (void)resetAllMessagesCallBack{
    if ([[messageHandlerDictionary allKeys]count] > 0){
        [messageHandlerDictionary removeAllObjects];
    }
}



@end
