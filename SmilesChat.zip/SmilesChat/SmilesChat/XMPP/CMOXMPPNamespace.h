//
//  CMOXMPPNamespace.h
//  CMOChat
//
//  Created by Administrator on 10/29/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#ifndef CMOXMPPNamespace_h
#define CMOXMPPNamespace_h


#define MUC_DISCO_ITEMS @"http://jabber.org/protocol/disco#items"
#define MUC_DISCO_INFO @"http://jabber.org/protocol/disco#info"
#define MUC_ADMIN @"http://jabber.org/protocol/muc#admin"
#define MUC_ARCHIVE @"urn:xmpp:archive"


#define MUC_ROSTER_ITEMS @"jabber:iq:roster"
#define MUC_CONFERENCE @"jabber:x:conference"
#endif /* CMOXMPPNamespace_h */
