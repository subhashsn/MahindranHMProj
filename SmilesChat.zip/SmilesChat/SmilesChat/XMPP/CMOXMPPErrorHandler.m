//
//  CMOXMPPErrorHandler.m
//  CMOChat
//
//  Created by Administrator on 10/31/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOXMPPErrorHandler.h"
#import "XMPPHeader.h"

#define XMPP_PRESENCE_ERROR_DOMAIN @"XMPP_PRESENCE_ERROR"
#define XMPP_ROSTER_ERROR_DOMAIN @"XMPP_ROSTER_ERROR"
#define XMPP_PARSING_ERROR_DOMAIN @"XMPP_PARSING_ERROR"
#define XMPP_ERROR @"error"
#define XMPP_ERROR_CONFILCT @"conflict"
#define XMPP_ERROR_CONFILCT_NS @"urn:ietf:params:xml:ns:xmpp-stanzas"
#define XMPP_CHATROOM_LOCKED @"This room is locked from entry until configuration is confirmed."
#define XMPP_CHATROOM_UNLOCKED @"This room is now unlocked."

#define NOT_FOUND 404
#define PARSING_ERROR 143



@implementation CMOXMPPErrorHandler

/*
 <presence xmlns="jabber:client" to="subash@hmecmac000094.local/CMOChat" from="hmgroup@sample.com/subash" type="error"><error code="404" type="cancel"><remote-server-not-found xmlns="urn:ietf:params:xml:ns:xmpp-stanzas"/></error></presence>
 */
- (NSError *)xmppPresenceError:(XMPPPresence *)presence{
    NSError *error = nil;
    DDXMLElement *presenceError = [[presence copy] elementForName:XMPP_ERROR];
    NSString *errorCode = [presenceError attributeStringValueForName:@"code"];
    NSArray *childElement = [presenceError children];
    NSMutableDictionary *userInfo = nil;
    if (childElement.count > 0){
        userInfo = [[NSMutableDictionary alloc]initWithObjectsAndKeys:childElement,@"userInfo", nil];
    }
    error = [NSError errorWithDomain:XMPP_PRESENCE_ERROR_DOMAIN code:[errorCode integerValue] userInfo:userInfo];
    
    return error;
}

- (NSError *)xmppIQError:(XMPPIQ *)iq{
    NSError *error = nil;
    if ([iq isErrorIQ]){
        
        DDXMLElement *presenceError = [[iq copy] elementForName:XMPP_ERROR];
        NSString *errorCode = [presenceError attributeStringValueForName:@"code"];
        NSArray *childElement = [presenceError children];
        NSMutableDictionary *userInfo = nil;
        if (childElement.count > 0){
            userInfo = [[NSMutableDictionary alloc]initWithObjectsAndKeys:childElement,@"userInfo", nil];
        }
        error = [NSError errorWithDomain:XMPP_ROSTER_ERROR_DOMAIN code:[errorCode integerValue] userInfo:userInfo];
        
        return error;
    }
    error = [NSError errorWithDomain:XMPP_PARSING_ERROR_DOMAIN code:PARSING_ERROR userInfo:nil];
    return error;
}

@end
