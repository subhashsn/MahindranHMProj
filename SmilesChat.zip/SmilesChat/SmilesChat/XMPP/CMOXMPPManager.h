//
//  XMPPManager.h
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMPPHeader.h"
#import "CMOXMPPClient.h"
#import "CMOXMPPNamespace.h"
#import "CMOConstant.h"
#import "CMOMessage.h"
#import "CMOXMPPErrorHandler.h"
#import "CMOXMPPRoomPool.h"

#define XMPPMessageArchiveCoreData @"XMPPMessageArchiving_Message_CoreDataObject"
#define XMPPRoomMessageCoreData @"XMPPRoomMessageCoreDataStorageObject"

#define CMOCHATIPHONE @"CMOCHATIPHONE"

@class CMOCoreComponents;


typedef NS_ENUM(NSInteger, XMPPCMOErrorCode) {
    XMPPCMOErrorAlreadyAuthenticated = 100,
    XMPPCMOErrorNotAuthenicated
};


@interface CMOXMPPManager : NSObject <CMOXMPPDelegate>{
    CMOXMPPDidReceiveIQ didReceiveIQ;
}

@property (nonatomic, strong)NSString *serverName;
@property (nonatomic, assign)NSInteger serverHost;
@property (nonatomic, strong)NSString *domainName;
@property (nonatomic, strong)NSString *conferenceURL;
@property(nonatomic, strong) XMPPStream *xmppStream;

@property(nonatomic, strong) CMOCoreComponents *coreComponents;

@property(nonatomic, strong) CMOXMPPErrorHandler *xmppErrorHandler;

@property(nonatomic, strong) id<CMOXMPPResponseDelegate> responseDelegate;
@property(nonatomic, strong) id<CMOXMPPNotificationDelegate> notificationDelegate;

@property(nonatomic, strong)CMOXMPPRoomPool *xmppRoomPool;
@property(nonatomic, strong)XMPPReconnect *xmppReconnect;
@property(nonatomic, strong)XMPPRoster *xmppRoster;
@property(nonatomic, strong)XMPPMUC *xmppMUC;
@property(nonatomic, strong)XMPPRoom *xmppRoom;
@property(nonatomic, strong)XMPPPing *xmppPing;
@property(nonatomic, strong)XMPPAutoPing *xmppAutoPing;

@property(nonatomic, strong)XMPPMessageArchivingCoreDataStorage *xmppMessageArchivingCoreDataStorage;
@property(nonatomic, strong)XMPPMessageArchiving *xmppMessageArchivingModule;
@property(nonatomic, strong)XMPPRoomCoreDataStorage *xmppRoomStorage;
@property(nonatomic, strong)XMPPRosterCoreDataStorage *xmppRosterStorage;
@property(nonatomic, strong)XMPPCapabilitiesCoreDataStorage *xmppCapabilitiesStorage;
@property(nonatomic, strong)XMPPCapabilities *xmppCapabilities;
@property(nonatomic, strong)XMPPvCardTempModule *xmppvCardTempModule;
@property(nonatomic, strong)XMPPvCardCoreDataStorage *xmppvCardStorage;
@property(nonatomic, strong)XMPPvCardAvatarModule *xmppvCardAvatarModule;
@property(nonatomic, strong)XMPPMessageArchiveManagement *xmppMessageArchiveManagement;
@property (nonatomic,strong)XMPPJID *myJID;

- (void)setupStream;

- (void)teardownStream;

- (NSString *)conferenceChatDomain;

@end
