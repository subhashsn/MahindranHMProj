//
//  CMOXMPPRoomPool.m
//  CMOChat
//
//  Created by Administrator on 11/5/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOXMPPRoomPool.h"

@interface CMOXMPPRoomPool()

@property (nonatomic, strong)NSMutableDictionary *roomDictionary;

@end

@implementation CMOXMPPRoomPool

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.roomDictionary = [[NSMutableDictionary alloc]init];
    }
    return self;
}

- (void)setRoom:(XMPPRoom *)room forJid:(NSString *)jid{
    if (![self roomForKey:jid]){
        [self.roomDictionary setObject:room forKey:jid];
    }
   // ////DDLogInfo(@"Rooms List: %@",self.roomDictionary);
}

- (XMPPRoom *)roomForKey:(NSString *)jid{
    return [self.roomDictionary valueForKey:jid];
}

- (void)removeAllRooms{
    if ([[self.roomDictionary allKeys] count] > 0){
        [self.roomDictionary removeAllObjects];
    }
}


@end
