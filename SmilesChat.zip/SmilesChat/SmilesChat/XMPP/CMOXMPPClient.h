//
//  CMOXMPPDao.h
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "XMPPHeader.h"



@class CMOXMPPManager;
@class CMOUser;
@class CMORoomInfo;
@class CMORoomDetails;

typedef void(^CMOXMPPAuthCompletionHandler)(XMPPStream* stream,NSXMLElement *error);
//- (void)retreiveChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;
typedef void (^CMOXMPPMessageHandler)(XMPPMessage *message, NSError *error);

typedef void(^CMOXMPPDidReceiveMessage)(XMPPStream* stream,XMPPMessage *message);
typedef void(^CMOXMPPDidUserTyping)(XMPPStream* stream,XMPPMessage *message);
typedef void(^CMOXMPPDidReceiveIQ)(XMPPStream* stream,XMPPIQ *iq);
//typedef void(^CMOXMPPDidReceivePresence)(XMPPStream* stream,XMPPPresence *presence);
typedef void(^CMOXMPPDidReceiveError)(XMPPStream* stream,XMPPIQ *iq);
typedef void(^CMOXMPPDidDisconnect)(XMPPStream* stream,NSError *error);

typedef void(^CMOXMPPDidReceivePresence)(id response,NSError *error);

typedef void (^CMODidReceivedItems)(NSArray *items, NSError *error);

typedef void (^CMODidReceivedRoster)(NSArray *items, NSError *error);

@protocol CMOXMPPDelegate <NSObject>

- (void)setupStream;

- (void)teardownStream;

- (NSManagedObjectContext *)managedObjectContext_messageArchive;

- (NSManagedObjectContext *)managedObjectContext_rooms;

- (NSManagedObjectContext *)managedObjectContext_roster;

- (NSManagedObjectContext *)managedObjectContext_vCard;

- (NSEntityDescription *)roomEntity;

- (BOOL)connectWithJID:(NSString *)JID password:(NSString *)myPassword completionHandler:(CMOXMPPAuthCompletionHandler)handler;

- (BOOL)disconnect;

- (BOOL)isXmppStreamConnected;

- (void)sendMessage:(XMPPMessage *)message toRoom:(NSString *)roomID completionHandler:(CMOXMPPMessageHandler)handler;

- (void)addBuddyOrSendPresence:(NSString *)newBuddy toAdd:(BOOL)toAdd;

- (void)sendSearchRequest:(NSString *)searchQuery;

- (void)fetchRosterswithCompletionHandler:(CMODidReceivedItems)handler;

- (void)discoverServicesWithCompletionHandler:(CMODidReceivedItems)handler;

- (void)createOrJoinRoom:(CMORoomDetails *)roomInfo userstoInvite:(NSMutableArray *)users history:(NSString *)date completionHandler:(CMOXMPPDidReceivePresence)handler;

- (void)leaveRoom;

- (BOOL)isJoinedInRoom:(NSString *)roomId;

//- (void)occupantsOfRooms:(NSString *)roomJId completionHandler:(CMODidReceivedItems)handler;

- (void)inviteUsersToJoinTheRoom:(id)users forRoom:(NSString *)roomId affiliation:(Affiliation)affiliation;

- (void)fetchRoomInfo:(NSString *)roomID;

- (void)setRoomSubject:(NSString *)roomSubject forRoom:(NSString *)roomJID;

- (void)sendChatStatus:(NSString *)roomID status:(ChatTypStatus)status;

- (void)updateUserInformation:(CMOUser *)user;

- (XMPPvCardTemp *)myvCard;

- (XMPPvCardTemp *)fetchUservCardforJID:(NSString *)jid;

- (void)retrieveArchivedMessages:(NSString *)roomId startdate:(NSString *)date endDate:(NSString *)date max:(NSInteger)max;

- (void)retrieveOfflineMessages;

- (void)sendPresenceToRooms:(NSArray *)rooms;

- (void)removeAllRooms;

- (void)fetchOfflineMessages;

@end

//
//@protocol CMOXMPPMUCProtcol <NSObject>
//
//- (void)discoverRooms:(XMPPJID *)sender completionHandler:(CMOXMPPDidReceiveIQ)handler;
//
//- (void)getRoomConfiguration;
//
//- (BOOL)xmppStreamMUC:(XMPPStream *)sender didReceiveIQ:(XMPPIQ *)iq;
//
//@end

@protocol CMOXMPPResponseDelegate <NSObject>
//- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message{

- (void)cmoxmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message;


@end

@protocol CMOXMPPNotificationDelegate <NSObject>

- (void)cmoxmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence isMUC:(BOOL)isMUC;

@end

