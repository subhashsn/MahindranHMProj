//
//  CMOWebDavClient.h
//  CMOChat
//
//  Created by Amit Kumar on 14/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#ifndef CMOWebDavClient_h
#define CMOWebDavClient_h

#import <Foundation/Foundation.h>


typedef void (^APIResponseSuccess)(id _Nullable response);
typedef void (^APIProgress)(id _Nullable progress);
typedef void (^APIResponseFailed)(NSError * _Nonnull error);

@protocol CMOWebDavClient <NSObject>

- (void)putPath:(NSString * _Nonnull)path
     parameters:(nullable id)parameters
           data:(NSData * _Nonnull)data
       mimeType:(NSString * _Nonnull)mimeType
     OnProgress:(APIProgress _Nullable)progress
      OnSuccess:(APIResponseSuccess _Nullable)responseBlock
      onFailure:(APIResponseFailed _Nonnull)failureBlock;

- (void)makeCollection:(NSString * _Nonnull )path
            parameters:( nullable id )parameters
             onSuccess:(APIResponseSuccess _Nullable )responseBlock
             onFailure:(APIResponseFailed _Nonnull )failureBlock;

- (void)getProperty:(NSString * _Nonnull )path
         parameters:( nullable id )parameters
          onSuccess:(APIResponseSuccess _Nullable )responseBlock
          onFailure:(APIResponseFailed _Nonnull )failureBlock;

- (void)get:(NSString * _Nonnull )URLString parameters:( nullable id )parameters
 OnProgress:(APIProgress _Nonnull)progress
  OnSuccess:(APIResponseSuccess _Nullable)responseBlock
  onFailure:(APIResponseFailed _Nonnull)failureBlock;


@end


#endif /* CMOWebDavClient_h */
