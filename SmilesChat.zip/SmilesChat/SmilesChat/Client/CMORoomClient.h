//
//  CMORoomClient.h
//  CMOChat
//
//  Created by Administrator on 4/5/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CMORoomDetails;


@protocol CMORoomClient <NSObject>

- (void)createRoom:(NSDictionary *)params
         onSuccess:(void (^)(id result))success
         onFailure:(void (^)(NSError *error))failure;

- (void)inviteUsersToJoinTheRoom:(id)user
                         forRoom:(NSString *)roomName
                 withAffiliation:(Affiliation)affiliation;

- (void)addGroups:(NSMutableArray *)groups
       toChatRoom:(NSString *)roomId
        onSuccess:(void (^)(id response))success
        onFailure:(void (^)(NSError *error))failure;

- (void)joinToRoom:(CMORoomDetails *)roomId
           history:(NSDate *)date
         onSuccess:(void (^)(BOOL result))success
         onFailure:(void (^)(NSError *error))failure;

- (CMORoomDetails *)retreiveChatRoom:(NSString *)roomId
                           onSuccess:(void (^)(id result))success
                           onFailure:(void (^)(NSError *error))failure;

- (BOOL)isJoinedInRoom:(NSString *)roomId;


- (void)getAllRooms:(NSString *)user
          onSuccess:(void (^)(id result))success
          onFailure:(void (^)(NSError *error))failure;

@end
