//
//  AFClient.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CMOUser;
@class XMPPvCardTemp;

@protocol CMOUserClient <NSObject>

- (CMOUser *)user;

- (void)saveUser:(CMOUser *)user;

- (void)updateUserInformation:(CMOUser *)user;

- (CMOUser *)fetchUservCard:(NSString *)userName;

- (CMOUser *)toCMOUSer:(XMPPvCardTemp *)vCard;

- (CMOUser *)toCMOUSer:(XMPPvCardTemp *)vCard forUser:(NSString *)userName;

- (BOOL)isChairman;

- (void)uploadLogFileonSuccess:(void (^)(id result))success
                     onFailure:(void (^)(NSError *error))failure;

@end
