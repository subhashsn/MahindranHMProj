//
//  AFClient.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef void (^APIResponseSuccess)(id _Nullable response);
typedef void (^APIProgress)(id _Nullable progress);
typedef void (^APIResponseFailed)(NSError * _Nonnull error);

@protocol APIClient <NSObject>

- (void)GET:( NSString * _Nonnull )URLString parameters:(nullable id)parameters
  OnProgress:(APIProgress _Nullable)progress
  OnSuccess:(APIResponseSuccess _Nullable)responseBlock
  onFailure:(APIResponseFailed _Nonnull)failureBlock;


- (void)POST:(NSString * _Nonnull)URLString parameters:(nullable id)parameters
   OnProgress:(APIProgress _Nullable)progress
   OnSuccess:(APIResponseSuccess _Nullable)responseBlock
   onFailure:(APIResponseFailed _Nonnull)failureBlock;


- (void)POSTMultipart:(NSString * _Nonnull)URLString parameters:(nullable id)parameters
            OnProgress:(APIProgress _Nullable)progress
            OnSuccess:(APIResponseSuccess _Nullable)responseBlock
            onFailure:(APIResponseFailed _Nonnull)failureBlock;

- (void)DELETE:(NSString * _Nonnull)URLString parameters:(nullable id)parameters
            OnSuccess:(APIResponseSuccess _Nullable)responseBlock
            onFailure:(APIResponseFailed _Nonnull)failureBlock;

- (void)GETMessageCount:( NSString * _Nonnull )URLString parameters:(nullable id)parameters
             OnProgress:(APIProgress _Nullable)progress
              OnSuccess:(APIResponseSuccess _Nullable)responseBlock
              onFailure:(APIResponseFailed _Nonnull)failureBlock;

@end
