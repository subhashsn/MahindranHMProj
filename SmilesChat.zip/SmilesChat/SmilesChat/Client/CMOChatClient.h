//
//  CMOChatClient.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CMOUser;
@class CMOMessage;
@class CMOMessageBody;
@class XMPPMessage;
@class CMORoomDetails;
@class CMORoomInfo;

//@class CMOChatPresentation;

typedef void(^CMOXMPPConnection)(BOOL success);
typedef void(^CMOXMPPMessageReceived)(CMOMessage *message);

typedef void(^CMODotCMSResponseBlock)(id response, NSError *error);


@protocol CMOSLAClient <NSObject>

- (void)didReceiveRemainingSLATime:(NSTimeInterval)mins slaCrossed:(BOOL)isSlaCrossed slaClosed:(BOOL)isSlaClosed;

@end

@protocol CMOChatClient <NSObject>

- (BOOL)connect:(CMOUser *)user andPassword:(NSString *)password completionHandler:(CMOXMPPConnection)completion;

- (BOOL)disconnect;

- (BOOL)isConnectedToXMPP;
//- (void)startRoom;

- (NSArray *)fetchRooms:(NSString *)user completionHandler:(void (^)(NSArray *items,NSError *error))handler;

- (NSArray *)fetchRoomDetailsAndMessage:(NSString *)user completionHandler:(void (^)(NSArray *items,NSError *error))handler;

- (CMORoomDetails *)retreiveChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;

- (void)removeUser:(NSString *)userId fromChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;

- (void)addGroup:(NSString *)groupId toChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;

- (void)addUser:(NSString *)userName toChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;


- (void)sendMessage:(CMOMessage *)message roomId:(NSString *)roomID
  completionHandler:(void (^)(XMPPMessage *message,NSError *error))handler;

- (NSString *)getFormattedMessageBody:(CMOMessageBody *)messageBody fromMe:(BOOL)fromMe;

- (CMOMessage *)toCMOMessage:(XMPPMessage *)message;

- (CMOMessageBody *)messageBody:(NSString *)messageString;

- (void)createOrJoinRoom:(CMORoomDetails *)roomJID userstoInvite:(NSMutableArray *)users history:(NSString *)date completionHandler:(void (^)(BOOL result, NSError *error))handler;

//- (void)createRoom:(CMORoomInfo *)roomInfo participants:(id)participants
      //   onSuccess:(void (^)(id result))success
      //   onFailure:(void (^)(NSError *error))failure;

- (void)inviteUsersToJoinTheRoom:(id)user forRoom:(NSString *)roomName withAffiliation:(Affiliation)affiliation;

- (void)leaveRoom;

- (void)getUnReadMessagesCountOfAllRoomsonSuccess:(void (^)(id result))success
                                        onFailure:(void (^)(NSError *error))failure;

- (void)updateSyncDataonSuccess:(void (^)(id result))success
                      onFailure:(void (^)(NSError *error))failure;

//New - Anish

- (void)uploadDocumentWithMessage:(CMOMessage *)message
                             data:(id)documentData
                       OnProgress:(void (^)(id progress))onProgress
                        onSuccess:(void (^)(id result))success
                        onFailure:(void (^)(NSError *error))failure;

- (void)downloadDocument:(NSString *)documentName
              OnProgress:(void (^)(id progress))onProgress
               onSuccess:(void (^)(id result))success
               onFailure:(void (^)(NSError *error))failure;


/*- (void)uploadDocument:(NSString *)docName
          documentData:(id)docData
               message:(CMOMessage *)message
     completionHandler:(void (^)(id success, NSError *error))handler;

-(void)downloadDocument:(NSString *)docName
                message:(CMOMessage *)message
      completionHandler:(void (^)(id success, NSError *error))handler;*/

- (void)saveDocument:(NSString *)documentName docData:(id)docData forRoom:(NSString *)roomID;

- (id)getDocument:(NSString *)documentName forRoom:(NSString *)roomID;

- (BOOL)deleteDocument:(NSString *)documentName forRoom:(NSString *)roomID;

- (NSString *)getFilePath:(NSString *)fileName roomName:(NSString *)roomName;

- (void)removeAllFiles;

- (void)setRoomSubject:(NSString *)roomSubject forRoom:(NSString *)roomJID;

- (void)sendChatStatus:(NSString *)roomID status:(ChatTypStatus)status;

//- (NSTimeInterval)calculateSLATime:(CMOMessage *)message;


@end
