//
//  CMORepositoryClient.h
//  CMOChat
//
//  Created by Administrator on 11/4/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

@class CMORoomDetails;
@class CMORoster;
@class CMOMessage;
@class CMOOfflineMessages;
@class CMOArchivedRooms;
@class CMOLastMessages;
@class CMOMessageReadStatus;
@class CMOVisitedRooms;
@class CMODeletedRooms;
@class XMPPRoomMessageCoreDataStorageObject;
@class CMORosterGroup;
@class CMOUser;

#import "CMODraftMessages+CoreDataClass.h"
#import <AddressBook/AddressBook.h>

@protocol CMORepositoryClient <NSObject>

- (NSArray *)fetchMessages;

- (void)clearMessages;

- (NSArray *)fetchMessageForRoom:(NSString *)roomId;

- (NSInteger)fetchMessageCountForRooms:(NSString *)roomId;

- (CMOOfflineMessages *)updateOfflineMessage:(CMOMessage *)message;

- (void)saveMessageOffline:(CMOMessage *)message;

- (void)deleteOfflineMessage:(CMOMessage *)message;

- (void)deleteXMPPMessage:(XMPPRoomMessageCoreDataStorageObject *)message;

- (XMPPRoomMessageCoreDataStorageObject *)fetchMessage:(CMOMessage *)message
                                                ofRoom:(NSString *)room;

- (NSArray *)fetchOfflineMessageOfRoom:(NSString *)roomID;

- (NSInteger)fetchOfflineMessageCountOfRoom:(NSString *)roomId;

- (NSArray *)fetchAllOfflineMessages;

- (void)compareOfflineAndRemoveXMPPMessages;

- (void)clearAllPendingXMPPMessages;

- (void)updateAllOfflineMessages;

- (void)saveChatRoomDetailsAndMessage:(id)chatRoom;

- (void)updateArchiveStatus:(BOOL)isArchived toRoom:(CMORoomDetails *)roomDetail;

- (void)saveRoomDetailsAndMessage:(NSDictionary *)jsonDict offline:(BOOL)isOffline;

- (void)saveRoomInfo:(NSDictionary *)jsonDict offline:(BOOL)isOffline;

- (void)updateSLATime:(NSInteger)slaTime
         confidential:(BOOL)isConfidential
               roomId:(NSString *)roomId;

- (void)updateFirstMessageDate:(NSDate *)date
                        roomId:(NSString *)roomId;

- (void)updateTotalMessageCount:(int64_t)messageCount ofRoom:(NSString *)roomId;

- (void)updateJoiningStatusOfUserInRoom:(CMORoomDetails *)roomDetail
                               isJoined:(BOOL)isJoined;

- (void)saveSmsusersToChatRoom:(NSString *)users roomId:(NSString *)roomId;

- (void)saveGroupMember:(id)groups toRoom:(NSString *)roomId;

- (void)saveReadMessageCountToRoom:(NSString *)roomId count:(int64_t)count;

- (void)saveVisitedRoom:(NSString *)roomName readCount:(int32_t)readCount;

- (void)syncVisitedRoom:(NSString *)roomName readCount:(int32_t)readCount;

- (CMOVisitedRooms *)fetchVisitedRoom:(NSString *)roomName;

- (void)deleteAllVisitedRooms;

- (NSArray *)fetchAllVisitedRooms;

- (void)saveDeletedRoom:(NSString *)roomName;

- (CMODeletedRooms *)fetchDeletedRooms:(NSString *)roomName;

- (NSArray *)fetchAllDeletedRooms;

- (void)saveDocumentUploadStatusForRoom:(NSString *)roomId inprogress:(BOOL)status;

- (BOOL)documentUploadStatusOfRoom:(NSString *)roomId;

- (void)updateDocumentUploadStatusOfAllRooms;

- (NSArray *)fetchOfflineChatRooms;

- (void)saveHideStatusOfRoom:(NSString *)roomId shouldHide:(BOOL)hide;

- (BOOL)isRoomMessageHidden:(NSString *)roomId;

- (NSArray *)fetchChatRooms;

- (NSArray *)fetchChatRoomsForArchivedStatus:(BOOL)archived;

- (NSInteger )fetchChatRoomCount;

- (CMOOfflineMessages *)fetchOfflineMessage:(NSString *)elementId;

- (CMORoomDetails *)fetchRoomInfo:(NSString *)roomName;

- (void)updateRoomInfo:(NSString *)roomName withLastMessageDate:(NSDate*)interval;

- (NSArray *)getActiveRooms;

- (void)clearAllRooms;

- (void)clearAllData;

- (void)saveCurrentUserPhoneNumber:(NSString *)phoneNumber;

- (void)saveUsers:(NSDictionary *)jsonDict;

- (void)saveGroups:(NSDictionary *)jsonDict;

- (void)saveGroupsMembers:(NSDictionary *)jsonDict;

- (void)saveTempGroupsToRoomProperty:(NSMutableArray *)groups roomId:(NSString *)roomId;

- (void)removeTempGroupsFromRoomProperty:(NSString *)roomId;

- (NSArray*)fetchMembersForGroup:(NSString*)groupName;

- (CMORoster *)fetchRoster:(NSString *)userName;

- (NSArray *)fetchAllRosters;

- (NSArray *)fetchAllRostersIncludingLoggedInUser;

//- (NSArray *)fetchCurrentUserRosters;

- (NSArray *)fetchAllGroupRosters;

- (CMORosterGroup *)fetchGroupRoster:(NSString *)name;

- (void)makeRoomArchived:(NSString *)roomId unreadCount:(NSInteger)msgCount;

- (void)makeRoomUnarchived:(NSString *)roomId;

- (BOOL)isRoomArchived:(NSString *)roomId;

- (BOOL)isMessageAlreadyExist:(XMPPRoomMessageCoreDataStorageObject *)message;

- (CMOArchivedRooms *)fetchArchivedRoom:(NSString *)roomName;

- (NSArray *)fetchAllArchivedRooms;

- (NSArray *)filterNonRostersfromAllUser;

/*!
 * Returns the `CMORoster` based on the predicate passed.
 * \param predicate - Filter based on the predicate
 * \returns Array of `CMORoster` object based on the predicate passed.
 */

- (NSArray *)fetchRostersWithPredicate:(NSPredicate *)predicate;

- (NSArray *)filterRostersFromXMPPRoster;

- (NSArray *)filterRoomsbySMSUser:(NSString *)userName;

- (void)saveUserRolesAndPermissions:(NSDictionary *)jsonDict;

- (BOOL)isMessageAvailableOtherThanOwnerOfRoom:(NSString *)roomId;

- (void)updateSLATime:(NSInteger)slaTime slaEnabled:(BOOL)slaEnabled slaClosed:(BOOL)slaClosed confidential:(BOOL)confidential OfRoom:(NSString *)roomName slaRemainingTime:(NSInteger)slaRemainingTime;

- (void)updateMessageStatus:(MessageDeliveryStatus)status roomId:(NSString *)roomId messageId:(CMOMessage *)message;

- (void)saveDraftMessage:(NSString *)message forRoom:(NSString *)roomId;

- (CMODraftMessages *)fetchDraftMessageForRoom:(NSString *)roomId;


- (void)messageRead:(BOOL)didRead unreadCount:(int32_t)count forRoom:(NSString *)roomId;

- (CMOMessageReadStatus *)fetchMessageReadStatusForRoom:(NSString *)roomId;

- (NSArray *)fetchAllUnReadMessagesOfAllRooms;

- (void) savePeopleInAddressBook:(ABAddressBookRef)addressBook;

- (void)saveExchangeServerUsers:(NSDictionary *)jsonDict;

- (NSManagedObjectContext *)getManagedObjectContext;

- (void)saveUsersAndGroups:(NSDictionary *)jsonDict;

- (void)updatevCardDetailsToRoster:(CMOUser *)cmoUser;

- (void) clearDataOnVersionUpdate;

- (void)updateUserNicname:(NSString *)nicName forUser:(NSString*)userName;

- (NSString*)getUsernameForNicname:(NSString *)nicname;

@end
