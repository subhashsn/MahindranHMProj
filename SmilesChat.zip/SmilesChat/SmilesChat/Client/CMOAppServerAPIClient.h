//
//  CMOAppServerAPIClient.h
//  CMOChat
//
//  Created by Amit Kumar on 17/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#ifndef CMOAppServerAPIClient_h
#define CMOAppServerAPIClient_h

#import <Foundation/Foundation.h>


typedef void (^APIResponseSuccess)(id _Nullable response);
typedef void (^APIProgress)(id _Nullable progress);
typedef void (^APIResponseFailed)(NSError * _Nonnull error);

@protocol CMOAppServerAPIClient <NSObject>

- (void)GET:( NSString * _Nonnull )URLString parameters:(nullable id)parameters
 OnProgress:(APIProgress _Nullable)progress
  OnSuccess:(APIResponseSuccess _Nullable)responseBlock
  onFailure:(APIResponseFailed _Nonnull)failureBlock;

- (void)POST:(NSString * _Nonnull)URLString parameters:(nullable id)parameters
  OnProgress:(APIProgress _Nullable)progress
   OnSuccess:(APIResponseSuccess _Nullable)responseBlock
   onFailure:(APIResponseFailed _Nonnull)failureBlock;

@end

#endif /* CMOAppServerAPIClient_h */
