//
//  CMORosterClient.h
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CMORoster, CMORosterGroup;

typedef void (^UserResponseSuccess)(id users);
typedef void (^UserResponseFailed)(NSError *error);
typedef void (^GroupResponseSuccess)(id groups);
typedef void (^GroupResponseFailed)(NSError *error);

@protocol CMORosterClient <NSObject>

/**
  This method fetches users from openfire using restapi.
 */

- (NSArray *)getUsers:(NSDictionary  *)params onSuccess:(UserResponseSuccess)users
       onFailure:(UserResponseFailed )error;

- (NSArray *)getGroups:(NSDictionary  *)params onSuccess:(GroupResponseSuccess)groups
            onFailure:(GroupResponseFailed )error;

- (CMORoster *)getCurrentUserInfo:(NSDictionary  *)params onSuccess:(UserResponseSuccess)users
            onFailure:(UserResponseFailed )error;

//- (NSArray *)getCurrentUserInfo:(NSDictionary  *)params onSuccess:(UserResponseSuccess)users
  //           onFailure:(GroupResponseFailed )error;

- (void)fetchRosterswithCompletionHandler:(void (^)(NSArray *items, NSError *error))handler;

- (CMORosterGroup *)fetchGroupRoster:(NSString *)name;

- (void)addBuddyOrSendPresence:(NSString *)newBuddy toAdd:(BOOL)toAdd;

- (CMORoster *)fetchRoster:(NSString *)name;

- (void)getGroupDetails:(NSString *)groupNme withCompletionHandler:(void (^)(NSArray *items, NSError *error))handler;

- (NSArray *)getExchangeServerUsers:(NSDictionary  * _Nullable )params
                          onSuccess:(UserResponseSuccess _Nullable)response
                          onFailure:(UserResponseFailed _Nonnull)failure;

- (void)fetchAllUsersAndGroups:(NSDictionary  * _Nullable )params onSuccess:(UserResponseSuccess _Nullable)response
                     onFailure:(UserResponseFailed _Nonnull)failure;

- (void)updateUserNicname:(NSString *_Nullable)nicName forUser:(NSString*_Nonnull)userName;

- (NSString*_Nullable)getUsernameForNicname:(NSString *_Nonnull)nicname;

@end
