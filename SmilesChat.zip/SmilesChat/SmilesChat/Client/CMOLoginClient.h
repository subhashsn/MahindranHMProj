//
//  CMOLoginClient.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CMOLoginPresentation;
@class CMOUser;


typedef void(^CMOLoginReceivedBlock)(CMOUser* user);

typedef void(^CMOLoginErrorBlock)(NSError* error);

@protocol CMOLoginClient <NSObject>

- (void)login:(CMOLoginPresentation *)login onSuccess:(CMOLoginReceivedBlock)successBlock
                                           onError: (CMOLoginErrorBlock)errorBlock;

- (void)updateAppVersionWithUser:(NSString *)userName  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;

@end
