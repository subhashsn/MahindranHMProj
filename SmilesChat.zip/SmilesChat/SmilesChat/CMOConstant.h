//
//  CMOConstant.h
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#ifndef CMOConstant_h
#define CMOConstant_h

#define kCMOXMPPServerDomain @"hmecmac000094.local"//@"subhash-2.local"//@"hmecmac000094.local"
#define kCMOXMPPServerPort 5222

#define kCMOConferenceDomain @"conference.hmecmac000094.local"

#define kOFServerNameKey @"ofserver.name"
#define kOFServerPortKey @"ofserver.port"
#define kOFConferenceName @"ofserver.conference"
#define kOFDomainName @"ofserver.domain"
#define kAppServerPort @"appserver.port"


//Following are the constant for keys used in Configurations.plist. Make sure that following key should match the keys in the plist.

#define GETUSERS @"users"
#define GETGROUPS @"groups"
#define GETCHATROOMS @"chatrooms"
#define GETROOMSLIST @"roomslist"


#define MSGSTATUS_PENDING @"Pending"
#define MSGSTATUS_Failed @"Failed"
#define MSGSTATUS_SENT @"  ✓"
#define MSGSTATUS_DELIVERED @"✓✓"
#define MSGSTATUS_RECEIVED @"  ✓"

/*typedef NS_ENUM(NSInteger, UserType){
    UserTypePrimaryChairman,
    //UserTypeSecondaryChairman,
    UserTypeNormalUser
};*/

typedef NS_ENUM(NSInteger, SMSTYPE){
    SMSTYPENONE = -1,
    SMSTYPEGROUP1,
    SMSTYPEGROUP2,
    SMSTYPEBOTH
};


typedef NS_ENUM(NSInteger, Affiliation){
    AffiliationNone,
    AffiliationMember,
    AffiliationAdmin,
    AffiliationOwner,
};

typedef NS_ENUM(NSInteger,ChatType){
    ChatTypeNewChat,
    ChatTypeExistingChat
};

typedef NS_ENUM(NSInteger, DocumentType){
    DocumentTypeImage,
    DocumentTypeVideo,
    DocumentTypeAudio,
    DocumentTypeLocation,
    DocumentTypeMedia, //PDF, XLS etc.
    DocumentTypeUnknown
};


typedef NS_ENUM(NSInteger, ChatTypStatus){
    ChatTypeActive,
    ChatTypeComposing,
    ChatTypePaused,
    ChatTypeInactive,
    ChatTypeGone
};

typedef NS_ENUM(NSInteger, MessageDeliveryStatus){
    MessageDeliveryPending,
    MessageDeliveryFailed,
    MessageDeliverySuccess
};

//1970-01-01T00:00:00Z
#define DATE_FORMAT @"yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ"
#define SLA_DATE_FORMAT @"E, d MMM yyyy HH:mm:ss Z"
#define MESSAGE_TIME_FORMAT @"yyyy-MM-dd HH:mm:ss.SSS Z"
#define XMPP_DATE_FORMAT @"CCYY-MM-DDThh:mm:ss[.sss]TZD"

#define SHOW_CROSSED_SLA_DATE_FORMAT @"dd MMM yyyy HH:mm"
//Rest Secret

//dotCMS
//http://10.2.30.130:8088/webdav/live/1/demo.dotcms.com
//http://hmecd001128:9090/plugins/mucusermessageapi/v1/mucusermessages/krishna

//Production URL

//"https://cma.damacgroup.com:8088/webdav/working/1/demo.dotcms.com"


//#ifdef DEBUG

//#define MUC_API_BASE_URL @"http://10.16.22.176:9090/plugins/mucusermessageapi/v1/mucusermessages"
//#define DOTCMS_BASEURL  @"http://10.16.22.176:8080/webdav/autopub/demo.dotcms.com"
//#define DOTCMS_USER     @"admin@dotcms.com"
//#define DOTCMS_PASSWORD @"admin"
//#define REST_SECRET_KEY  @"aqp0mptfbeiFC282"
//#define CMOGroupName @"CMOUAT"
//#define CMONonAppUsersGroup @"CMOSMSUAT"

#define MUC_API_BASE_URL @"http://devhomestaycare.southindia.cloudapp.azure.com/plugins/mucusermessageapi/v1/mucusermessages"
#define DOTCMS_BASEURL  @"http://10.16.33.71:8080/webdav/live/1/demo.dotcms.com/"
#define DOTCMS_USER     @"admin@dotcms.com"
#define DOTCMS_PASSWORD @"admin"
#define REST_SECRET_KEY  @"1dSkHzCplsV61Nj4"
#define CMOGroupName @"CMOUAT"
#define CMONonAppUsersGroup @"CMOSMSUAT"
#define CMONonAppSecUsersGroups @"CMOSMSUAT2"
#define CHAIRMANUSERNAME @"cm.user2"
#define APP_VERSION 1.29

#define SAS_URL @"?sv=2017-04-17&ss=b&srt=sco&sp=rwdlac&se=2018-02-22T23:06:03Z&st=2018-01-22T15:06:03Z&sip=10.16.24.135&spr=https,http&sig=TvrduxziX5ac3VM8XloddpRWdpKSJmypeENbszK%2FipA%3D"
#define DOMAIN_URL @"https://smileschat.blob.core.windows.net/"
#define CONTAINER_NAME @"sharedfiles"
#define IMAGE_PATH @"/thumb_"

//#define MUC_API_BASE_URL @"http://83.111.194.182:9090/plugins/mucusermessageapi/v1/mucusermessages"
//#define DOTCMS_BASEURL  @"http://83.111.194.182:8088/webdav/working/1/demo.dotcms.com"
//#define DOTCMS_USER     @"admin@dotcms.com"
//#define DOTCMS_PASSWORD @"admin@123"
//#define REST_SECRET_KEY  @"CpVU7H4ljt9WIUJk"
//#define CMOGroupName @"CMOUAT"
//#define CMONonAppUsersGroup @"CMOSMSUAT"
//#define CMONonAppSecUsersGroups @"CMOSMSUAT2"
//#define CHAIRMANUSERNAME @"cm.user2"
//#define APP_VERSION 1.29

//#else

//#define MUC_API_BASE_URL @"https://cma.damacgroup.com:9091/plugins/mucusermessageapi/v1/mucusermessages"
//#define DOTCMS_BASEURL  @"https://cma.damacgroup.com:8088/webdav/working/1/demo.dotcms.com"
//#define DOTCMS_USER     @"admin@dotcms.com"
//#define DOTCMS_PASSWORD @"admin"
//#define REST_SECRET_KEY  @"M3vIi37YCB28sw6t"
//#define CMOGroupName @"CMOReach.Users"
//#define CMONonAppUsersGroup @"CMOSMS"
//#define CMONonAppSecUsersGroups @"CMOSMSGEN"
//#define CHAIRMANUSERNAME @"hussain"
//#define APP_VERSION 1.9

//#endif


#define EXISTINGUSER @"CMODAMAC"



#define MESSAGEBODY_FORMAT @"%@ \n \n .......... \n SMS sent to:\n %@"

#define SYNC_VERSION @"syncVersion"
#define SYNC_DATE @"syncDate"

#define VISITED_ROOM_INFO @"visitedRooms"
#define ARCHIVED_ROOM_INFO @"archivedRooms"
#define SMS_USER_INFO @"smsRooms"

#define MACROS_CONTACTS @"contacts"
#define MACROS_GROUPS @"groups"

#define kPresence @"presence"


#define XMPP_TIMEOUT_ERROR -1103
#define XMPP_ACCIDENTAL_DISCONNECT_ERROR -1104

#define XMPP_REGISTRATION_REQUIRED_CODE 407

//This happens if network is gone.
// `XMPP_PING_FAILED_NOTIFICATION` will be called, if client is unable to reach server or timeout error.
#define XMPP_PING_FAILED_NOTIFICATION @"pingFailedNotification"
#define XMPP_PING_SUCCESS_NOTIFICATION @"pingSuccessNotification"

#define XMPP_REGISTRATION_REQUIRED_NOTIFICATION @"registrationRequiredNotification"
#define XMPP_PRESENCE_NOTIFICATION @"presenceNotification"
#define XMPP_CONNECTION_ESTABLISHED @"connectionEstablisedNotification"
#define XMPP_CONNECTION_FAILED @"connectionFailedNotification"
#define XMPP_DISCONNECT @"xmppDisconnected"
#define XMPP_USER_PRESENCE_NOTIFICATION @"updateUserPresence"
#define XMPP_ROOM_CREATION_NOTIFICATION @"roomCreationNotification"
#define XMPP_ROOM_SELF_JOINED_NOTIFICATION @"selfjoinedRoomNotification"

#define REFRESH_ROOM_NOTIFICATION @"refreshRoomNotification"

//This happens if network is gone.
#define XMPP_ACCIDENTAL_DISCONNECT_NOTIFICATION @"accidentalDisconnect"
#define XMPP_ROOM_JOINED_NOTIFICATION @"joinedRoomNotification"
#define XMPP_ROOM_LEFT_NOTIFICATION @"leftRoomNotification"
#define XMPP_ROOM_DESTROY_NOTIFICATION @"destroyRoomNotification"

#define DID_MESSAGE_INSERT_NOTIFICATION @"didXMPPMessageInsertedNotification"
#define DID_RECEIVE_INVITATION @"didReceiveInvitation"

#define APP_WILL_RESIGN_ACTIVE_NOTIFICATION @"appWillResignActiveNotification"

#define XMPP_RECEIVED_VCARD @"vCardReceived"
#define XMPP_RECEIVE_FAILED_VCARD @"vCardFailedToReceive"

#define XMPP_UPDATE_VCARD_SUCCESS @"updatevCard"
#define XMPP_UPDATE_VCARD_FAILED @"updatevCardFailed"

#define XMPP_ARCHIVE_CONVERSATION_NOTIFICATION @"archiveConversationNotification"

#define XMPP_USER_TYPING_NOTIFICATION @"userTypingNotification"

#define DID_RECEIVED_MESSAGE_NOTIFICATION @"messageReceivedNotification"

#define XMPP_NETWORK_OFFLINE_NOTIFICATION @"networkOfflineNotification"
#define XMPP_NETWORK_ONLINE_NOTIFICATION @"networkOnlineNotification"

#define DID_RECEIVED_UPDATE_TABLE_NOTIFICATION @"reloadNewTableData"
#define DID_UPDATE_DEVICE_TOKEN_NOTIFICATION @"updatedDeviceToken"

#define DID_RECEIVED_REMOVE_NOTIFICATION @"removedFromGroupNotification"

#define MESSAGE_UPDATE_UI_NOTIFICATION @"messageUpdateInUI"
#define DELETE_DOCUMENT_NOTIFICATION @"deleteDocumentNotification"
#define APP_BACKGROUND_NOTIFICATION @"appInBackground"

#define XMPP_MESSAGE_COMPOSING @"composingMessage"
#define XMPP_MESSAGE_ACTIVE @"activeMessage"
#define XMPP_MESSAGE_INACTIVE @"inactiveMessage"
#define XMPP_MESSAGE_PAUSED @"pausedMessage"
#define XMPP_MESSAGE_GONE @"goneMessage"

#define LOGOUT_NOTIFICATION @"logoutNotification"

#define NEW_ROOM_CREATED_NOTIFICATION @"newRoomCreatedNotification"

#define NETWORK_CONNECTED @"internetAvailable"


#define XMPP_NOTIFICATION_KEY_VCARD @"vCard"

#define XMPP_NOTIFACATION_VALUE_NULL @"NIL"

#define NOT_JOINED_IN_ROOM  150
#define XMPP_ALREADY_JOINED_NOTIFICATION @"xmppAlreadyJoinedNotification"

#define XMPP_ROSTER_DATAMODEL @"CMOXMPPRosterCoreData"


//Messages
#define NOT_A_PARTICIPANT_MSG @"You can't send messages to this group because you're no longer a participant."
#define PARTICIPANT_REQUIRED_MSG @"Please add at least one non SMS user to continue the chat"
#define PARTICIPANT_REQUIRED_MSG_CM @"SMS or iMessage  is not enabled for this device. Add a non SMS user to continue"
#define NO_PHONE_NUMBER_FOUND_FOR_PARTICIPANT @"No Phone number found for selected participant."
#define ROOM_DISCARD_MSG @"Are you sure you want to discard the uncreated chat room?"
#define CANNOT_SEND_CHATROOM_NOT_CREATED_MSG @"Chat room is not created. Please retry uploading document."
#define MAX_CHAR_EXCEEDED_MSG @"You have crossed maximum allowed characters"

#define MMS_NOT_SUPPORTED_MSG @"Only text message is supported for SMS"
#define SERVER_ACCESS_ERROR_MSG @"Could not connect to server. Please try again later."

#define RESEND_FIRST_MSG @"Please tap on the message to resend."
#define OFFLINE_MESSAGE_NOT_AVAILBLE @"Please resend the failed message from previous device."

//User Presence Status
#define XMPP_PRESENCE_AVAILABLE @"available"
#define XMPP_PRESENCE_UNAVAILABLE @"unavailable"
#define CMOGroupDisplayName @"CM Office"
#define RELOAD_CONTACT_NOTIFICATION @"reloadOnLocalContacts"

#define CANT_SEND_SMS @"Could not send SMS as your device does not support SMS."
#define SMS_NOT_SUPPORTED @"Only SMS users added. Your device does not support SMS."
#define ENCRYPTED_USER_DATA @"EncryptedUserData"




#endif /* CMOConstant_h */
