//
//  CMOMessageBuilder.h
//  CMOChat
//
//  Created by Anish on 10/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CMOMessage.h"

@protocol CMOMessageBuilderDelegate <NSObject>

- (CMOMessage *)getMessage;

- (XMPPMessage *)build;

@end

@interface CMOMessageBuilder : NSObject <CMOMessageBuilderDelegate>

- (instancetype)initWithMessage:(CMOMessage *)cmoMessage;

@property (nonatomic,strong)NSString *serverName;

@end
