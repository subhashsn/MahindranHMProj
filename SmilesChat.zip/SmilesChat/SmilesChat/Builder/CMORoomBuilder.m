//
//  CMORoomBuilder.m
//  CMOChat
//
//  Created by Administrator on 1/27/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMORoomBuilder.h"


@interface CMORoomBuilder() {
    CMORoomInfo *_roomInfo;
}

@end

@implementation CMORoomBuilder

/*
 {
 "roomName": "global",
 "naturalName": "global-2",
 "description": "Global chat room"
 }
 
 */
- (instancetype)initWithRoom:(CMORoomInfo *)roomInfo
{
    self = [super init];
    if (self) {
        _roomInfo = roomInfo;
    }
    return self;
}

- (NSDictionary *)build{
    return [_roomInfo toDictionary];
}







@end
