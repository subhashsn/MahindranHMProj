//
//  CMOMessageBuilder.m
//  CMOChat
//
//  Created by Anish on 10/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOMessageBuilder.h"
#import "CMOCoreComponents.h"
#import "NSDictionary+Custom.h"
#import "CMOUtils.h"

@interface CMOMessageBuilder(){
    CMOMessage *message;
}

@end

@implementation CMOMessageBuilder



- (instancetype)initWithMessage:(CMOMessage *)cmoMessage;
{
    self = [super init];
    if (self) {
        message = cmoMessage;
    }
    return self;
}

- (CMOMessage *)getMessage{
    return message;
}


- (XMPPMessage *)build{
    //Note: type:chat or groupchat will be added automatically by XMPPManager
  //  NSLog(@"Typhoon Config %@",TyphoonConfig(kOFServerNameKey));
    
   // message.senderJabberId = [NSString stringWithFormat:@"%@@%@",message.senderJabberId,self.serverName];
   
    //Message target id will be room id which is already configured and here you'll get full room id.
    // message.targetBareId = [NSString stringWithFormat:@"%@@%@",message.targetBareId,self.serverName];
    
    XMPPMessage *messageXML = [XMPPMessage elementWithName:@"message"];
    
    //Should add nickname at the last
    [messageXML addAttributeWithName:@"from" stringValue:[NSString stringWithFormat:@"%@@%@/%@",message.userName,self.serverName,message.userName]];
    
    [messageXML addAttributeWithName:@"to" stringValue:[NSString stringWithFormat:@"%@@%@",message.roomIDStr,self.serverName]];
    
    [messageXML addAttributeWithName:@"roomName" stringValue:message.roomIDStr];
    
    
    [messageXML addAttributeWithName:@"slaFlag" stringValue:message.slaFlag ? @"true": @"false"];
    
    [messageXML addAttributeWithName:@"slaTime" stringValue:[NSString stringWithFormat:@"%ld",(long)message.slaTime]];
    
    XMPPMessage * receiptRequest = [XMPPMessage elementWithName:@"request"];
    [receiptRequest addAttributeWithName:@"xmlns" stringValue:@"urn:xmpp:receipts"];
    [messageXML addChild:receiptRequest];

    /* For client side tracking purpose */
    message.messageBody.slaFlag = message.slaFlag ? @"true" : @"false";
    message.messageBody.slaTime = [NSString stringWithFormat:@"%ld",(long)message.slaTime];
   
    
    XMPPMessage *body = [XMPPMessage elementWithName:@"body"];
    [body setStringValue:[self jsonString:message.messageBody]];
    [messageXML addChild:body];
    
    XMPPMessage *thread = [XMPPMessage elementWithName:@"thread"];
    [thread setStringValue:[CMOUtils getUniqueString]];
    [messageXML addChild:thread];
    
    //slaFlag="true" roomId="23" slaTime="30"
    
    //Because element ID is already added in chatview controller when we send. This is conidition is important. don't change.
    if (message.elementID == nil){
        [messageXML addAttributeWithName:@"id" stringValue:[CMOUtils getUniqueString]];
    }
    else{
        [messageXML addAttributeWithName:@"id" stringValue:message.elementID];
    }
    
    NSLog(@"Message ---------->>>>> %@",messageXML);
    return messageXML;
}



- (NSString *)jsonString:(CMOMessageBody *)messageBody{
    
    NSMutableDictionary *dictionary = [[NSMutableDictionary alloc]init];
    if (messageBody.body.length > 0){
        [dictionary setValue:messageBody.body forKey:@"body"];
    }
    
    if (messageBody.mediaItem.length > 0){
        [dictionary setValue:messageBody.mediaItem forKey:@"mediaItem"];
    }
    
    if (messageBody.mediaType.length > 0){
        [dictionary setValue:messageBody.mediaType forKey:@"mediaType"];
    }
    
    if (messageBody.slaTime.length > 0){
        [dictionary setValue:messageBody.slaTime forKey:@"slaTime"];
    }
    
    if (messageBody.slaFlag.length > 0){
        [dictionary setValue:messageBody.slaFlag forKey:@"slaFlag"];
    }
    
    if (messageBody.shouldVisible.length > 0){
        [dictionary setValue:messageBody.shouldVisible forKey:@"show"];
    }
    
    if (messageBody.isConfidential.length > 0){
        [dictionary setValue:messageBody.isConfidential forKey:@"isConfidential"];
    }
    
    if (messageBody.fileName.length > 0){
        [dictionary setValue:messageBody.fileName forKey:@"fileName"];
    }
    
    if (messageBody.smsUsers.length > 0){
        [dictionary setValue:messageBody.smsUsers forKey:@"smsUsers"];
    }
    
    if (messageBody.messageId.length > 0){
        [dictionary setValue:messageBody.messageId forKey:@"messageId"];
    }
    else{
        DDLogError(@"Message Id is NIL. Please verify");
    }
    
    if (messageBody.messageDateString.length > 0){
        [dictionary setValue:messageBody.messageDateString forKey:@"date"];
    }
    else{
        [dictionary setValue:[CMOUtils getServerTime] forKey:@"date"];
    }
    return [dictionary toJSON];
}



@end
