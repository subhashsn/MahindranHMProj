//
//  CMORosterService.m
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMORosterService.h"
#import "APIClient.h"
#import "CMOCoreComponents.h"
#import "CMOUtils.h"
#import "CMOUser.h"
#import "CMOAssembly.h"
#import "CMOXMPPClient.h"
#import "CMORepositoryClient.h"
#import "NSData+AES.h"

@interface CMORosterService(){
    id <APIClient>apiClient;
}

@end


@implementation CMORosterService


- (instancetype)init
{
    self = [super init];
    if (self) {
        
       // [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(didRecievedvCard:) name:XMPP_RECEIVED_VCARD object:nil];
    }
    return self;
}

/*- (void)didRecievedvCard:(NSNotification *)notification{
    NSLog(@"Did received vCard %@",notification.userInfo);
    if (notification.userInfo != nil){
        id <CMOUserClient>userClient = [_coreComponents userService];
        XMPPvCardTemp *storedCard = notification.userInfo[XMPP_NOTIFICATION_KEY_VCARD];
        NSArray *emailAddresses = storedCard.emailAddresses;
        if (emailAddresses.count > 0){
            XMPPvCardTempEmail *emailvCard = emailAddresses[0];
            NSString *email = emailvCard.userid;
            if (email){
                NSArray *userDetails = [email componentsSeparatedByString:@"@"];
                if (userDetails.count > 1){
                    CMOUser *cmoUser = [userClient toCMOUSer:storedCard forUser:userDetails[0]];
                    id <CMORepositoryClient>repoClient = [_coreComponents repositoryService];
                    [repoClient updatevCardDetailsToRoster:cmoUser];
                }
            }
        }
    }
}*/


#pragma GET User
- (NSArray *)getUsers:(NSDictionary  * _Nullable )params
       onSuccess:(UserResponseSuccess _Nullable)response
       onFailure:(UserResponseFailed _Nonnull)failure{
    apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    
    [apiClient GET:[CMOUtils appConfigurations][GETUSERS]  parameters:params OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable users) {
        // NSLog(@"Response is %@",users);
         [repositoryClient saveUsers:users];
         response([repositoryClient fetchAllRosters]);
    } onFailure:^(NSError * _Nonnull error) {
        NSLog(@"Error is %@",error);
        failure(error);
    }];
    return [repositoryClient fetchAllRosters];
}

- (void)getAllGroupDetails:(NSArray *)groupArray {
    apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    
    for(id group in groupArray) {
        NSString *str = [NSString stringWithFormat:@"%@/%@",[CMOUtils appConfigurations][GETGROUPS], [group valueForKey:@"name"]];
        [apiClient GET:str parameters:nil OnProgress:^(id  _Nullable progress) {
            
        } OnSuccess:^(id  _Nullable groupsResponse) {
            //NSLog(@"######Response is %@",groupsResponse);
            //save to core data
            [repositoryClient saveGroupsMembers:groupsResponse];
        } onFailure:^(NSError * _Nonnull error) {
            ////DDLogInfo(@"Error is %@",error);
        }];
    }
}

- (void)getGroupDetails:(NSString *)groupNme withCompletionHandler:(void (^)(NSArray *items, NSError *error))handler {
    apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];

    NSString *str = [NSString stringWithFormat:@"%@/%@",[CMOUtils appConfigurations][GETGROUPS], groupNme];
    [apiClient GET:str parameters:nil OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable groupsResponse) {
        //completion handle
        [repositoryClient saveGroupsMembers:groupsResponse];
        NSMutableArray *users = [[NSMutableArray alloc]init];
        id members = groupsResponse[@"members"];
        if ([members isEqual:[NSNull null]]) {
            users = nil;
        }
        id member = members[@"member"];
        
        if ([member isKindOfClass:[NSArray class]]){
            [users addObjectsFromArray:member];
        }
        else{
            [users addObject:member];
        }

        handler(users,nil);
    } onFailure:^(NSError * _Nonnull error) {
        NSLog(@"Error is %@",error);
        //completion handle
        handler(nil,error);
    }];

}


- (NSArray *)getGroups:(NSDictionary  *)params onSuccess:(GroupResponseSuccess)response
             onFailure:(GroupResponseFailed )failure {
    apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    
    [apiClient GET:[CMOUtils appConfigurations][GETGROUPS] parameters:params OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable groups) {
       // NSLog(@"Response is %@",groups);
        NSArray *grpDictArray = nil;
        id value = [groups valueForKey:@"group"];
        if ([value isKindOfClass:[NSDictionary class]]) {
            NSDictionary *tmpVal = value;
            grpDictArray = [NSArray arrayWithObject:tmpVal];
        } else {
            NSArray *tmpVal = value;
            grpDictArray = [NSArray arrayWithArray:tmpVal];
        }
        [repositoryClient saveGroups:groups];
        [self getAllGroupDetails:grpDictArray];
        response([repositoryClient fetchAllGroupRosters]);
    } onFailure:^(NSError * _Nonnull error) {
        NSLog(@"Error is %@",error);
        failure(error);
    }];
    return [repositoryClient fetchAllGroupRosters];
}

/*
- (NSArray *)getCurrentUserInfo:(NSDictionary  * _Nullable )params
               onSuccess:(UserResponseSuccess _Nullable)response
               onFailure:(UserResponseFailed _Nonnull)failure{
    apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    
    [apiClient GET:[CMOUtils appConfigurations][GETUSERS]  parameters:params OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable users) {
        // NSLog(@"Response is %@",users);
        [repositoryClient saveUsers:users];
        response([repositoryClient fetchCurrentUserRosters]);
    } onFailure:^(NSError * _Nonnull error) {
        NSLog(@"Error is %@",error);
        failure(error);
    }];
    return [repositoryClient fetchCurrentUserRosters];
    
    //id <CMOUserClient>userClient = [_coreComponents userService];
    //CMOUser *owner = [userClient user];
    //CMORoster *roster = [rosterClient fetchRoster:owner.username];
}
*/

- (CMORoster *)getCurrentUserInfo:(NSDictionary  * _Nullable )params
                      onSuccess:(UserResponseSuccess _Nullable)response
                      onFailure:(UserResponseFailed _Nonnull)failure{
    apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    
    [apiClient GET:[CMOUtils appConfigurations][GETUSERS]  parameters:params OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable users) {
        // NSLog(@"Response is %@",users);
        [repositoryClient saveUsers:users];
        response([repositoryClient fetchRoster:owner.username]);
    } onFailure:^(NSError * _Nonnull error) {
        NSLog(@"Error is %@",error);
        failure(error);
    }];
    return [repositoryClient fetchRoster:owner.username];
}

- (CMORoster *)fetchRoster:(NSString *)name{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    return [repositoryClient fetchRoster:name];
}

- (CMORosterGroup *)fetchGroupRoster:(NSString *)name{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    return [repositoryClient fetchGroupRoster:name];
}

- (void)updateUserNicname:(NSString *_Nullable)nicName forUser:(NSString*_Nonnull)userName
{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    [repositoryClient updateUserNicname:nicName forUser:userName];
}

- (NSString*_Nullable)getUsernameForNicname:(NSString *_Nonnull)nicname
{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    return [repositoryClient getUsernameForNicname:nicname];
}


//onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure;
- (void)fetchRosterswithCompletionHandler:(void (^)(NSArray *items, NSError *error))handler{
    id <CMOXMPPDelegate>xmppClient = [_coreComponents xmppManager];
    [xmppClient fetchRosterswithCompletionHandler:^(NSArray *items,NSError *error) {
        if (error){
            handler(nil,error);
            return;
        }
        handler(items,nil);
    }];
}

- (void)addBuddyOrSendPresence:(NSString *)newBuddy toAdd:(BOOL)toAdd{
    id <CMOXMPPDelegate>xmppClient = [_coreComponents xmppManager];
    [xmppClient addBuddyOrSendPresence:newBuddy toAdd:toAdd];
}

- (NSArray *)getExchangeServerUsers:(NSDictionary  * _Nullable )params
            onSuccess:(UserResponseSuccess _Nullable)response
            onFailure:(UserResponseFailed _Nonnull)failure{
    
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    id <CMOAppServerAPIClient> client = [_coreComponents appServerAPIHandler];
    
    params = [[NSDictionary alloc]initWithObjectsAndKeys:[CMOUtils getUserEncryptedData], @"encryptedData", [CMOUtils getExchangeContactsLastSyncTime], @"lastSyncTime", nil];
    
    [client POST:@"/FetchContacts" parameters:params OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable users) {
        ////DDLogInfo(@"Fetch Contacts Response %@",response);
        [repositoryClient saveExchangeServerUsers:users];
        response([repositoryClient fetchAllRosters]);
    } onFailure:^(NSError * _Nonnull error) {
        ////DDLogInfo(@"****** Fetch Contacts failed *****");
        failure(error);
    }];
     
    return [repositoryClient fetchAllRosters];
}

#pragma mark --
#pragma mark get and save users and group

- (void)fetchAllUsersAndGroups:(NSDictionary  * _Nullable )params onSuccess:(UserResponseSuccess _Nullable)response
                     onFailure:(UserResponseFailed _Nonnull)failure
{
    apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    
    [apiClient GET:@"users"  parameters:params OnProgress:^(id  _Nullable progress) {
    } OnSuccess:^(id  _Nullable usersAndGroups) {
        [repositoryClient saveUsersAndGroups:usersAndGroups];
        response(usersAndGroups);
    } onFailure:^(NSError * _Nonnull error) {
        NSLog(@"Error is %@",error);
        failure(error);
    }];
}


@end
