//
//  CMORepositoryService.h
//  CMOChat
//
//  Created by Anish on 11/4/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CMOXMPPManager.h"
#import "CMOCoreDataComponents.h"

@class CMOCoreComponents;
@class CMORoomDetails;

@interface CMORepositoryService : NSObject

@property (nonatomic, strong)CMOCoreComponents *coreComponents;

@property (nonatomic, strong) NSString *conferenceURL;

@property (nonatomic, strong) NSManagedObjectContext *managedObjectcontext;

@property (nonatomic, strong)NSString *serverName;

@property (nonatomic, strong) NSString *domainName;

- (NSArray *)fetchMessages;

- (CMORoomDetails *)fetchRoomInfo:(NSString *)roomName;

@end
