//
//  CMORoomService.m
//  CMOChat
//
//  Created by Administrator on 4/5/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMORoomService.h"
#import "CMORoomInfo.h"
#import "CMOUserService.h"
#import "CMOCoreComponents.h"
#import "CMOUser.h"
#import "CMORoster+CoreDataProperties.h"
#import "CMORosterGroup+CoreDataClass.h"

#import "CMOUtils.h"
#import "CMORoomDetails+CoreDataProperties.h"

#define MAX_ALLOWED_CHARS 50
#define MAX_ALLOWED_CHARS_ROOM_SUBJECT 150
#define MAX_ALLOWED_CHARS_TEXT_MESSAGE 3000

@interface CMORoomService() {
    id <CMOXMPPDelegate> delegate;
}

@end

@implementation CMORoomService




- (instancetype)initWithManager:(id <CMOXMPPDelegate>)manager{
    self = [super init];
    if (self) {
        delegate = manager;
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)createRoom:(NSDictionary *)params
         onSuccess:(void (^)(id result))success
         onFailure:(void (^)(NSError *error))failure{
    
    id <APIClient>apiClient = [_coreComponents networkHandler];
    ////DDLogInfo(@"%@ %@ %@",THIS_FILE,THIS_METHOD,params);
    [apiClient POST:GETCHATROOMS parameters:params OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
        success(response);
    } onFailure:^(NSError * _Nonnull error) {
        failure(error);
    }];
}

- (void)inviteUsersToJoinTheRoom:(id)user forRoom:(NSString *)roomName withAffiliation:(Affiliation)affiliation{
    if (!user || !roomName){
        DDLogError(@"No Roomname or User found");
        return;
    }
    if ([user isKindOfClass:[NSArray class]] || [user isKindOfClass:[NSMutableArray class]]){
        [delegate inviteUsersToJoinTheRoom:user forRoom:roomName affiliation:affiliation];
    }
    else{
        [delegate inviteUsersToJoinTheRoom:[self userNameList:user] forRoom:roomName affiliation:affiliation];
    }
}

- (void)saveRoomLocal:(NSDictionary *)params offline:(BOOL)isOffline{
    id<CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    [repoClient saveRoomInfo:params offline:isOffline];
    //[repoClient saveRoomInfo:params offline:isOffline];
}

#pragma mark - Add Groups to ChatRoom
- (void)addGroups:(NSMutableArray *)groups
       toChatRoom:(NSString *)roomId
        onSuccess:(void (^)(id))success
        onFailure:(void (^)(NSError *error))failure{
    
    id <CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    //[repoClient saveTempGroupsToRoomProperty:groups roomId:roomId];
    
    id<APIClient> apiClient = [_coreComponents networkHandler];
    NSString *url = [NSString stringWithFormat:@"chatroom/%@/addGroups",roomId];
    [apiClient POST:url parameters:[self constructGroupsParam:groups] OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
        [repoClient saveGroupMember:groups toRoom:roomId];
        [repoClient removeTempGroupsFromRoomProperty:roomId];
        success(response);
    } onFailure:^(NSError * _Nonnull error) {
        failure(error);
    }];
}

- (BOOL)isJoinedInRoom:(NSString *)roomId{
   return [delegate isJoinedInRoom:roomId];
}

/*
 {
	"groups": [{
        "name": "group1",
        "role": "members"
	},
    {
        "name": "group2",
        "role": "members"
	}]
 }
 */

- (NSMutableDictionary *)constructGroupsParam:(NSMutableArray *)groups{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    NSMutableArray *groupsArray = [NSMutableArray new];
    for (id group in groups){
        NSString *grpName = nil;
        //check group class as for fist time chat creation group is CMORosterGroup,otherwise a string
        if ([group isKindOfClass:[NSString class]]) {
            grpName = (NSString*)group;
        } else if ([group isKindOfClass:[CMORosterGroup class]]) {
            CMORosterGroup *grp = (CMORosterGroup*)group;
            grpName = grp.name;
        }
        NSMutableDictionary *groupDict = [[NSMutableDictionary alloc]init];
        [groupDict setValue:grpName forKey:@"name"];
        [groupDict setValue:@"members" forKey:@"role"];
        [groupsArray addObject:groupDict];
    }
    [dict setObject:groupsArray forKey:@"groups"];
    
    return dict;
}


- (void)joinToRoom:(CMORoomDetails *)roomId
           history:(NSDate *)date
         onSuccess:(void (^)(id))success
         onFailure:(void (^)(NSError *))failure{
    
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    id <CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    NSString *history = [CMOUtils toSpecifiedFormatString:date format:DATE_FORMAT];
    [delegate createOrJoinRoom:roomId userstoInvite:nil history:history completionHandler:^(id response, NSError *error) {
        if (error){//isEligibleToJoin
            ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
            if (error.code == XMPP_REGISTRATION_REQUIRED_CODE && roomId.roomProperty.isEligibleToJoin != false){
                [repoClient updateJoiningStatusOfUserInRoom:roomId isJoined:false];
            }
            failure(error); //Got response from room delegates
        }
        else{
            ////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
            if (roomId.roomProperty.isEligibleToJoin == false){
                [repoClient updateJoiningStatusOfUserInRoom:roomId isJoined:true];
            }
           success(response);
        }
    }];
}


#pragma mark Retrieve Chat Room

- (CMORoomDetails *)retreiveChatRoom:(NSString *)roomId
                           onSuccess:(void (^)(id result))success
                           onFailure:(void (^)(NSError *error))failure{
    
    id<APIClient> apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    NSString *url = [NSString stringWithFormat:@"%@/%@",[CMOUtils appConfigurations][GETCHATROOMS],roomId];
    [apiClient GET:url parameters:nil OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
        [repositoryClient saveRoomInfo:response offline:false];
        success([repositoryClient fetchRoomInfo:roomId]);
        
    } onFailure:^(NSError * _Nonnull error) {
            failure(error);
    }];
    return [repositoryClient fetchRoomInfo:roomId];
}


- (void)getAllRooms:(NSString *)user
          onSuccess:(void (^)(id result))success
          onFailure:(void (^)(NSError *error))failure{
    
    ////http://devhomestaycare.southindia.cloudapp.azure.com/plugins/restapi/v1/chatrooms/of/anish.kumar_happiestminds.com
    NSString *url = [NSString stringWithFormat:@"%@/of/%@",GETCHATROOMS,user];
    ////DDLogInfo(@"Fetch Room URL: %@",url);
    
    if ([NSThread isMainThread]){
        NSLog(@"I am in main thread");
    }
    
    
    id <CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    id<APIClient> apiClient = [_coreComponents networkHandler];
    [apiClient GET:url parameters:nil OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
        DDLogInfo(@"Response is %@",response);
        //////DDLogInfo(@"All Rooms %@",response);
        //NSDate *Finish_Time_OF_Method = [NSDate date];
        //NSTimeInterval executionTime = [Finish_Time_OF_Method timeIntervalSinceDate:Start_Time_OF_Method];
        
        ////DDLogInfo(@"Success: executionTime = %f", executionTime);
        [repoClient saveChatRoomDetailsAndMessage:response];
       //[repositoryClient saveChatRoomDetailsAndMessage:response];
        success([repoClient fetchChatRooms]);
        
    } onFailure:^(NSError * _Nonnull error) {
        failure(error);
    }];
    
    
    
}

- (NSMutableArray *)userNameList:(NSMutableDictionary *)users{
    NSMutableArray *userNameArray = [[NSMutableArray alloc]init];
    if (users.allKeys.count > 0){
        for (NSString *key in users.allKeys){
            NSMutableArray *array = [users valueForKey:key];
            if (array){
                for (id roster in array){
                    if ([roster isKindOfClass:[CMORoster class]]){
                        CMORoster *userRoster = (CMORoster *)roster;
                        [userNameArray addObject:[NSString stringWithFormat:@"%@@%@",userRoster.username,[CMOUtils domainName]]];
                    }
                }
            }
        }
    }
    return userNameArray;
}




@end
