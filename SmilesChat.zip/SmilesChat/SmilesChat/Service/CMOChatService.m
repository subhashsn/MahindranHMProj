//
//  CMOChatClient.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOChatService.h"
#import "CMOXMPPManager.h"
#import "CMOUser.h"
#import "CMOMessage.h"
#import "CMOMessageBuilder.h"
#import "CMOXMPPClient.h"
#import "CMORoomInfo.h"
#import "CMOParticipantInfo.h"
#import "CMOUtils.h"
#import "JSQPhotoMediaItem.h"
#import "CMORoster+CoreDataProperties.h"
#import "CMOUserPresence.h"
//#import "DZWebDDAVClient.h"
#import "CMOMessage.h"
#import "CMOMessageCount.h"

#import "NSDictionary+Custom.h"

#import "CMORoomBuilder.h"
#import "CMOMembers+CoreDataProperties.h"
#import "CMORosterGroup+CoreDataClass.h"
#import "CMOVisitedRooms+CoreDataClass.h"
#import "CMOArchivedRooms+CoreDataClass.h"
#import "CMODeletedRooms+CoreDataClass.h"

#define DOCUMENT_FOLDER @"Media"

typedef NS_ENUM (NSInteger, DocumentTask){
    DocumentTaskUpload = 1,
    DocumentTaskDownload
};

@interface CMOChatService() <CMOXMPPResponseDelegate, CMOXMPPNotificationDelegate>{
    CMODotCMSResponseBlock imageResponseBlock;
    id <CMOXMPPDelegate> delegate;
    
    BOOL imageUploadStarted,imageDownloadStarted;
}

@end

@implementation CMOChatService

- (instancetype)initWithManager:(id <CMOXMPPDelegate>)manager{
    self = [super init];
    if (self) {
        delegate = manager;
        CMOXMPPManager *manager = (CMOXMPPManager *)delegate;
        manager.responseDelegate = self;
        manager.notificationDelegate = self;
        
        imageUploadStarted = false;
        imageDownloadStarted = false;
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (BOOL)connect:(CMOUser *)user andPassword:(NSString *)password completionHandler:(CMOXMPPConnection)completion {
    
     BOOL connected = [delegate connectWithJID:user.username password:password completionHandler:^(XMPPStream *stream, DDXMLElement *error) {
        if (error){
            completion(false);
            return;
        }
        completion(true);
    }];
    
    if (!connected){
        return false;
    }
    return true;
}

- (BOOL)disconnect{
    return [delegate disconnect];
}


- (void)sendMessage:(CMOMessage *)lmessage roomId:(NSString *)roomID
  completionHandler:(void (^)(XMPPMessage *xmppmessage,NSError *error))handler{
    
    //DDLogVerbose(@"DAMAC: 1 %@ %@",THIS_METHOD,THIS_FILE);

    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    id<CMOMessageBuilderDelegate> messageBuilder = [_coreComponents messageBuilder:lmessage];
    
    [delegate sendMessage:[messageBuilder build] toRoom:roomID completionHandler:^(XMPPMessage *message, NSError *error) {
        if (error){
            DDLogInfo(@"DAMAC: 2 %@ %@ %@",THIS_METHOD,THIS_FILE,error);
            //Updating Message status
            [client compareOfflineAndRemoveXMPPMessages];
            [client updateAllOfflineMessages];
            
            /* CMOMessage *rMessage = [self toCMOMessage:message];
             lmessage.status = MessageDeliveryFailed;
             [client saveMessageOffline:rMessage];
            //#warning CHECK THIS METHOD
            XMPPRoomMessageCoreDataStorageObject *roomMessage = [client fetchMessage:rMessage ofRoom:rMessage.roomIDStr];
            [client deleteXMPPMessage:roomMessage];*/
            handler(message,error);
        }
        else{
            DDLogInfo(@"DAMAC: 3 %@ %@ %@",THIS_METHOD,THIS_FILE,message);
            CMOMessage *rMessage = [self toCMOMessage:message];
            //Delete message from offline table if message is successfully sent.
            [client deleteOfflineMessage:rMessage];
            //[client updateMessageStatus:MessageDeliverySuccess roomId:roomID messageId:rMessage];
            if (lmessage.isFirstMessage){//Update total message count. when `getAllRooms` called, it will get updated.
                ////DDLogInfo(@"New Room Update 1 %@ %@",THIS_METHOD,THIS_FILE);
                //DDLogVerbose(@"DAMAC: 4 %@ %@",THIS_METHOD,THIS_FILE);
                [client updateTotalMessageCount:1 ofRoom:roomID];
                [client updateFirstMessageDate:rMessage.messageBody.messageDate roomId:roomID];
            }
            //DDLogVerbose(@"DAMAC: 5 %@ %@",THIS_METHOD,THIS_FILE);
           
            /*[client deleteMessage:lmessage];
            [client updateMessageStatus:MessageDeliverySuccess roomId:roomID messageId:lmessage];*/
            handler(message,error);
        }
    }];
    //DDLogVerbose(@"DAMAC: 99 %@ %@",THIS_METHOD,THIS_FILE);

}

- (NSArray *)fetchRooms:(NSString *)user completionHandler:(void (^)(NSArray *items,NSError *error))handler{
    id<APIClient> apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    //chairman/rooms
    NSString *lastSyncTime = [CMOUtils getAllRoomsLastSyncTime];
    if (!lastSyncTime) {
        lastSyncTime = @"0";
    }
    
    NSString *deviceSyncVersion = [CMOUtils getDeviceSyncVersion];
    if (!deviceSyncVersion){
        deviceSyncVersion = @"0";
    }
    
    __block NSDate *Start_Time_OF_Method = [NSDate date];

    NSString *url = [NSString stringWithFormat:@"%@/%@/rooms?lastSyncTime=%@&syncVersion=%@",[CMOUtils appConfigurations][GETCHATROOMS],user,lastSyncTime,deviceSyncVersion];
    ////DDLogInfo(@"Fetch Room URL: %@",url);
    
    [apiClient GET:url parameters:nil OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
        //////DDLogInfo(@"All Rooms %@",response);
        NSDate *Finish_Time_OF_Method = [NSDate date];
        NSTimeInterval executionTime = [Finish_Time_OF_Method timeIntervalSinceDate:Start_Time_OF_Method];
        
        ////DDLogInfo(@"Success: executionTime = %f", executionTime);
        
        [repositoryClient saveChatRoomDetailsAndMessage:response];
        NSDate *saveFinish_Time_OF_Method = [NSDate date];
        NSTimeInterval saveTime = [saveFinish_Time_OF_Method timeIntervalSinceDate:Start_Time_OF_Method];
        ////DDLogInfo(@"Success: save executionTime = %f", saveTime);

        handler([repositoryClient fetchChatRooms],nil);
    } onFailure:^(NSError * _Nonnull error) {
        
        NSDate *Finish_Time_OF_Method = [NSDate date];
        NSTimeInterval executionTime = [Finish_Time_OF_Method timeIntervalSinceDate:Start_Time_OF_Method];
        
        ////DDLogInfo(@"Failure: executionTime = %f", executionTime);
        
        handler(nil,error);
    }];
    
    return [repositoryClient fetchChatRooms];

}

- (void)roomsForGroups:(NSMutableArray *)grouplist RoomList:(NSMutableArray *)roomList withCompletionHandler:(void (^)(NSArray *items,NSError *error))handler{
    id<APIClient> apiClient = [_coreComponents networkHandler];
    NSString *groupName = [grouplist firstObject];
    
    //call api for getting rooms for group and join two room list and save
    NSString *groupurl = [NSString stringWithFormat:@"%@/%@/rooms",[CMOUtils appConfigurations][GETCHATROOMS],groupName];
    [apiClient GET:groupurl parameters:nil OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
        //rooms for group
        NSMutableArray *groupRoomsArray = [[NSMutableArray alloc]init];
        if ([response valueForKey:@"chatRoom"] == nil){
            groupRoomsArray = nil;
        } else {
            if ([response[@"chatRoom"] isKindOfClass:[NSArray class]]){
                [groupRoomsArray addObjectsFromArray:response[@"chatRoom"]];
            }
            else{
                [groupRoomsArray addObject:response[@"chatRoom"]];
            }
        }
        //join two room list and send response
        NSMutableArray *combinedRoomsArray = [NSMutableArray arrayWithArray:roomList];
        
        for (NSDictionary *room in groupRoomsArray) {
            NSString *roomName = [room valueForKey:@"roomName"];
            
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomName == %@",roomName];
            NSArray *result = [combinedRoomsArray filteredArrayUsingPredicate:predicate];
            if (result.count == 0) {
                [combinedRoomsArray addObject:room];
            }
        }
    
        //NSLog(@"Combined array = %@",combinedRoomsArray);
        
        if ([grouplist count] > 1) {
            [grouplist removeObjectAtIndex:0];
            //return [self roomsForGroups:grouplist RoomList:combinedRoomsArray];
            [self roomsForGroups:grouplist RoomList:combinedRoomsArray withCompletionHandler:handler];
        } else {
            handler(combinedRoomsArray,nil);
        }
    } onFailure:^(NSError * _Nonnull error) {
        // send only user's room list
        ////DDLogInfo(@"Error case: returning passed list: %@",roomList);
        handler(roomList,nil);
    }];
}


- (NSMutableArray *)roomForItems:(NSArray *)items{
    NSMutableArray *itemsArray = nil;
    if (items.count > 0){
        itemsArray = [[NSMutableArray alloc]init];
    }
    for (NSXMLElement *item in items){
        XMPPJID *jid = [XMPPJID jidWithString:[item attributeStringValueForName:@"jid"]];
        
        CMORoomInfo *roomInfo = [[CMORoomInfo alloc]init];
        roomInfo.roomName = [jid user];
        roomInfo.naturalName = [item attributeStringValueForName:@"name"];
        //roomInfo.roomId = [item attributeStringValueForName:@"jid"];
        [itemsArray addObject:roomInfo];
    }
    return itemsArray;
}


/*- (NSMutableArray *)occupantsForItems:(NSArray *)items{
    NSMutableArray *itemsArray = nil;
    if (items.count > 0){
        itemsArray = [[NSMutableArray alloc]init];
    }
    for (NSXMLElement *item in items){
        CMOParticipantInfo *participantInfo = [[CMOParticipantInfo alloc]init];
        participantInfo.jid = [item attributeStringValueForName:@"jid"];
        participantInfo.participantName = [item attributeStringValueForName:@"name"];
        [itemsArray addObject:participantInfo];
    }
    return itemsArray;
}*/

//- (void)createOrJoinRoom:(NSString *)roomJID userstoInvite:(NSMutableArray *)users completionHandler:(CMOXMPPDidRoomCreateOrJoin)handler{

- (void)createOrJoinRoom:(CMORoomDetails *)roomJID userstoInvite:(id)users history:(NSString *)date completionHandler:(void (^)(BOOL result, NSError *error))handler{
    
    [delegate createOrJoinRoom:roomJID userstoInvite:[self userNameList:users] history:date completionHandler:^(id presence, NSError *error) {
        if (error){
            handler(false,error); //Got response from room delegates
        }
        else{
            handler(true,nil);
        }
    }];
}

- (void)createRoom:(CMORoomInfo *)roomInfo participants:(id)participants onSuccess:(void (^)(id result))success
         onFailure:(void (^)(NSError *error))failure{
    id<APIClient> apiClient = [_coreComponents networkHandler];
    id<CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    
    Members *members = [[Members alloc]init];
    NSMutableArray *array = [self userNameList:participants];
    if (array.count > 0){
         members.member = array;
    }
    /*if (array.count > 0){
        members.member = array;
    }
    else{
        members.member = array[0];
    }*/
    roomInfo.members = members;
    id<CMORoomBuilderDelegate>roomBuilder = [_coreComponents roomBuilder:roomInfo];
    NSDictionary *params = [roomBuilder build];
    [apiClient POST:GETCHATROOMS parameters:params OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
       // [repoClient saveRoomInfo:params offline:true];
        success(response);
    } onFailure:^(NSError * _Nonnull error) {
        failure(error);
    }];
}

- (void)inviteUsersToJoinTheRoom:(id)user forRoom:(NSString *)roomName withAffiliation:(Affiliation)affiliation{
    if (!user || !roomName){
        DDLogError(@"No Roomname or User found");
        return;
    }
    if ([user isKindOfClass:[NSArray class]] || [user isKindOfClass:[NSMutableArray class]]){
        [delegate inviteUsersToJoinTheRoom:user forRoom:roomName affiliation:affiliation];
    }
    else{
        [delegate inviteUsersToJoinTheRoom:[self userNameList:user] forRoom:roomName affiliation:affiliation];
    }
}

- (void)leaveRoom{
    [delegate leaveRoom];
}


- (NSMutableArray *)userNameList:(NSMutableDictionary *)users{
    NSMutableArray *userNameArray = [[NSMutableArray alloc]init];
    if (users.allKeys.count > 0){
        for (NSString *key in users.allKeys){
            NSMutableArray *array = [users valueForKey:key];
            if (array){
                for (id roster in array){
                    if ([roster isKindOfClass:[CMORoster class]]){
                        CMORoster *userRoster = (CMORoster *)roster;
                        [userNameArray addObject:[NSString stringWithFormat:@"%@@%@",userRoster.username,[CMOUtils domainName]]];
                    }
                }
            }
        }
    }
    return userNameArray;
    
   /* NSMutableArray *userNameArray = [[NSMutableArray alloc]init];
    //check this AMIT
    if (users.count > 0) {
        if ([users[0] isKindOfClass:[CMORoster class]]) {
            for (CMORoster *user in users){
                if (user.username){
                    [userNameArray addObject:user.username];
                }
            }
        } else if ([users[0] isKindOfClass:[NSString class]]) {
            userNameArray = [users copy];
        }
    }
    return userNameArray;*/
}


- (void)cmoxmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message{
    
    CMOMessage *cmomessage = [self toCMOMessage:message];
    [[NSNotificationCenter defaultCenter]postNotificationName:DID_RECEIVED_MESSAGE_NOTIFICATION object:nil userInfo:@{@"message":cmomessage ? cmomessage : @"MESSAGE IS NIL"}];
    //[self.chatResponseDelegate didReceiveMessage:[self toCMOMessage:message]];
}

#pragma mark Presence Notification
- (void)cmoxmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence isMUC:(BOOL)isMUC{
    if (!presence)return;
    dispatch_async(dispatch_get_main_queue(),^{
        CMOUserPresence *userPresence = [self userPresence:presence isMUC:isMUC];
        if (userPresence){
            NSDictionary *userInfo = [NSDictionary dictionaryWithObject:userPresence != nil ? userPresence:@"Error in user presence" forKey:kPresence];
            [[NSNotificationCenter defaultCenter] postNotificationName: XMPP_PRESENCE_NOTIFICATION object:nil userInfo:userInfo];
        }
    });
}

#pragma mark User Presence Object
//This object will return the presence of the user
- (CMOUserPresence *)userPresence:(XMPPPresence *)presence isMUC:(BOOL)isMUC{
    if(presence && ![presence isErrorPresence]){
        
        id<CMOUserClient>userService = [_coreComponents userService];
        CMOUser *owner = [userService user];
        
        CMOUserPresence *uPresence = [[CMOUserPresence alloc]init];
        XMPPJID *fromJID = nil;
        if (isMUC){
            fromJID = [XMPPJID jidWithString:[presence attributeStringValueForName:@"from"]];
            uPresence.from = [fromJID resource];
        }
        else{
            fromJID = [XMPPJID jidWithString:[presence attributeStringValueForName:@"from"]];
            uPresence.from = [fromJID user];
        }
        uPresence.to = [presence attributeStringValueForName:@"to"];
        if (!isMUC){
            uPresence.type =  [presence attributeStringValueForName:@"type"];
        }
        if (isMUC){
            NSArray *x = [presence elementsForName:@"x"];
            for (XMPPElement *xElement in x){
                if ([xElement.xmlns isEqualToString:@"vcard-temp:x:update"]){
                    if ([xElement elementForName:@"photo"]){
                        CMOVCard *vCard = [[CMOVCard alloc]init];
                        NSXMLElement *photoElement = [xElement elementForName:@"photo"];
                        vCard.photoSHA = photoElement.stringValue;
                        uPresence.vCard = vCard;
                    }
                }
                if ([xElement.xmlns isEqualToString:@"http://jabber.org/protocol/muc#user"]){
                    if ([xElement elementForName:@"item"]){
                        id item = [xElement elementForName:@"item"];
                        CMOOccupant *occupant = [[CMOOccupant alloc]init];
                        XMPPJID *userJID = [XMPPJID jidWithString:[item attributeStringValueForName:@"jid"]];
                        occupant.jid = [item attributeStringValueForName:@"jid"];
                        occupant.affiliation = [item attributeStringValueForName:@"affiliation"];
                        occupant.role = [item attributeStringValueForName:@"role"];
                        if (userJID){
                            occupant.username = [userJID user];
                        }
                        else{
                            occupant.username = [[XMPPJID jidWithString:[uPresence from]] resource];
                        }
                        uPresence.user = occupant;
                        if ([[userJID user] isEqualToString:owner.username]){
                            uPresence.ownPresence = true;
                        }
                    }
                    /*NSArray *status = [xElement elementsForName:@"status"];
                        for (id st in status){
                        NSString *code = [st attributeStringValueForName:@"code"];
                        if ([code isEqualToString:@"100"]){
                            uPresence.ownPresence = true;
                        }
                    }*/
                }
            }
        }
        uPresence.isMUC = isMUC;
        return uPresence;
    }
    return nil;
}

- (void)setRoomSubject:(NSString *)roomSubject forRoom:(NSString *)roomJID{
    [delegate setRoomSubject:roomSubject forRoom:roomJID];
}

#pragma mark User Typing Status
- (void)sendChatStatus:(NSString *)roomID status:(ChatTypStatus)status{
    [delegate sendChatStatus:roomID status:status];
}

/*- (void)dotcmsResponse:(CMOChatPresentation *)dotcmsResponse onSuccess:(CMODotCMSReceivedBlock)successBlock onError: (CMODotCMSErrorBlock)errorBlock
{
    
}
*/

#pragma mark API Calls
- (CMORoomDetails *)retreiveChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure{
    id<APIClient> apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    NSString *url = [NSString stringWithFormat:@"%@/%@",[CMOUtils appConfigurations][GETCHATROOMS],roomId];
    [apiClient GET:url parameters:nil OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
       // [repositoryClient saveRoomInfo:response offline:false];
        NSError *jsonerror = nil;
        //CMORoomInfo *roomInfo = [[CMORoomInfo alloc]initWithDictionary:response error:&jsonerror];
        if (jsonerror){
            failure(jsonerror);
            return;
        }
        [repositoryClient saveRoomInfo:response offline:false];
        success([repositoryClient fetchRoomInfo:roomId]);

    } onFailure:^(NSError * _Nonnull error) {
        failure(error);
    }];
    return [repositoryClient fetchRoomInfo:roomId];
}



- (void)removeUser:(NSString *)userId fromChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure {
    id<APIClient> apiClient = [_coreComponents networkHandler];
    NSString *url = [NSString stringWithFormat:@"%@/%@/members/%@",[CMOUtils appConfigurations][GETCHATROOMS],roomId,userId];
    
    [apiClient DELETE:url parameters:nil OnSuccess:^(id  _Nullable response) {
        success(response);
    } onFailure:^(NSError * _Nonnull error) {
        failure(error);
    }];
}

- (void)addGroup:(NSString *)groupId toChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure {
    id<APIClient> apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    NSString *url = [NSString stringWithFormat:@"%@/%@/members/group/%@",[CMOUtils appConfigurations][GETCHATROOMS],roomId,groupId];
    
    [apiClient POST:url parameters:nil OnProgress:^(id  _Nullable progress) {
        //handle later
    } OnSuccess:^(id  _Nullable response) {
        [repoClient saveGroupMember:groupId toRoom:roomId];
        success(response);
    } onFailure:^(NSError * _Nonnull error) {
        failure(error);
    }];
}


- (void)addUser:(NSString *)userName toChatRoom:(NSString *)roomId  onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure {
    ///chatrooms/{roomName}/{roles}/{name}
    id<APIClient> apiClient = [_coreComponents networkHandler];
    NSString *url = [NSString stringWithFormat:@"%@/%@/members/%@",[CMOUtils appConfigurations][GETCHATROOMS],roomId,userName];
    [apiClient POST:url parameters:nil OnProgress:^(id  _Nullable progress) {
        //handle later
    } OnSuccess:^(id  _Nullable response) {
        success(response);
    } onFailure:^(NSError * _Nonnull error) {
        failure(error);
    }];
}


- (void)getUnReadMessagesCountOfAllRoomsonSuccess:(void (^)(id result))success
                                        onFailure:(void (^)(NSError *error))failure {
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    
    id<APIClient> apiClient = [_coreComponents networkHandler];
    
    NSString *lastSyncTime = [CMOUtils getUnreadMessageCountLastSyncTime];
    if (!lastSyncTime) {
        lastSyncTime = @"0";
    }

    NSString *url = [NSString stringWithFormat:@"%@/%@?lastSyncTime=%@",MUC_API_BASE_URL,owner.username,lastSyncTime];

    [apiClient GETMessageCount:url parameters:nil OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
        //NSLog(@"Response is %@",response);
        //NSError *error = nil;
        CMOUserMessageCount *messageCount = [self convertToMessageCount:response];//[[CMOUserMessageCount alloc]initWithDictionary:response error:&error];
        if (!messageCount){
            failure([NSError errorWithDomain:@"CMOUserMessageCount is NIL" code:-100 userInfo:nil]);
        }
        else{
            success(messageCount);
        }
        if (messageCount.mucusermessage.count) {
            //Update user defaults for last response time
            NSDictionary * metadata = [response valueForKey:@"meta"];
            if (metadata) {
                NSString *lastResponseTime = [metadata valueForKey:@"responseTime"];
                [CMOUtils saveUnreadMessageCountLastSyncTime:lastResponseTime];
            }
        }

    } onFailure:^(NSError * _Nonnull error) {
        ////DDLogInfo(@"Error is %@",error);
        failure(error);
    }];
}


- (CMOUserMessageCount *)convertToMessageCount:(id)response{
    CMOUserMessageCount *userMessageCount = nil;
    NSMutableArray *array = [[NSMutableArray alloc]init];
    id mucUserMessage = response[@"mucusermessage"];
    if ([mucUserMessage isKindOfClass:[NSDictionary class]]){
        userMessageCount = [[CMOUserMessageCount alloc]init];
        CMOMessageCount *msgCount = [[CMOMessageCount alloc]init];
        long newMsgCount = [mucUserMessage[@"messageCount"] integerValue];
        if (newMsgCount > msgCount.messageCount) {
            //mark message as unread
            id repositoryClient = [_coreComponents repositoryService];
            NSString *roomID = [[mucUserMessage[@"room"] componentsSeparatedByString:@"@"] firstObject];
            [repositoryClient messageRead:false unreadCount:(int)newMsgCount forRoom:roomID];
        }
        msgCount.messageCount = [mucUserMessage[@"messageCount"] integerValue];
        msgCount.room = mucUserMessage[@"room"];
        msgCount.firstMessage = mucUserMessage[@"firstMessage"];
        msgCount.SLAClosed = [mucUserMessage[@"SLAClosed"] integerValue];
        NSTimeInterval val = [mucUserMessage[@"lastMsgTimestamp"] doubleValue];
        msgCount.lastModifiedDate = [NSDate dateWithTimeIntervalSince1970:(val/1000.0)];
        [array addObject:msgCount];
        userMessageCount.mucusermessage = array;
    }
    else{
        userMessageCount = [[CMOUserMessageCount alloc]init];
        for (NSDictionary *dict in mucUserMessage){
            CMOMessageCount *msgCount = [[CMOMessageCount alloc]init];
            long newMsgCount = [dict[@"messageCount"] integerValue];
            if (newMsgCount > msgCount.messageCount) {
                //mark message as unread
                id repositoryClient = [_coreComponents repositoryService];
                NSString *roomID = [[dict[@"room"] componentsSeparatedByString:@"@"] firstObject];
                [repositoryClient messageRead:false unreadCount:(int)newMsgCount forRoom:roomID];
            }
            msgCount.messageCount = [dict[@"messageCount"] integerValue];
            msgCount.room = dict[@"room"];
            msgCount.firstMessage = dict[@"firstMessage"];
            msgCount.SLAClosed = [dict[@"SLAClosed"] integerValue];
            
            NSTimeInterval val = [dict[@"lastMsgTimestamp"] doubleValue];
            msgCount.lastModifiedDate = [NSDate dateWithTimeIntervalSince1970:(val/1000.0)];
            [array addObject:msgCount];
        }
        if (array.count > 0){
            userMessageCount.mucusermessage = array;
        }
    }
    return userMessageCount;
}

#pragma mark - Sync Read Count, Archive, Deleted Rooms

- (void)updateSyncDataonSuccess:(void (^)(id result))success
                   onFailure:(void (^)(NSError *error))failure {
    NSDictionary *syncJson = [self getSyncJson];
    NSData *d = [syncJson[@"data"] dataUsingEncoding:NSUTF8StringEncoding];
    id json = [NSJSONSerialization JSONObjectWithData:d options:0 error:nil];
    if ([[json allKeys] count] <= 0)return;
    
    id <CMOAppServerAPIClient> client = [_coreComponents appServerAPIHandler];
    ////DDLogInfo(@"Sync Json : %@",syncJson);
    [client POST:@"/AppData" parameters:syncJson OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
        ////DDLogInfo(@"Sync Response %@",response);
        //NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        if (response[@"syncVersion"]){
            [CMOUtils saveDeviceSyncVersion:response[@"syncVersion"]];
        }
        if (response[@"syncDate"]){
            [CMOUtils saveDeviceSyncTime:response[@"syncDate"]];
        }
        [CMOUtils clearVisitedRoomInfo];
        [CMOUtils clearSMSUserRoomInfo];
        success(response);
    } onFailure:^(NSError * _Nonnull error) {
        ////DDLogInfo(@"****** SYNC FAILED *****");
        failure(error);
    }];
}


- (id)getSyncJson{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    //NSArray *visitedRooms = [repositoryClient fetchAllVisitedRooms];
    
    NSMutableDictionary *visitedRooms = [CMOUtils allVisitedRoomsInfo];
    
    id <CMOUserClient>userService = [_coreComponents userService];
    CMOUser *owner = [userService user];
    
    //NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSMutableDictionary *syncJson = [[NSMutableDictionary alloc]init];
    [syncJson setValue:owner.username forKey:@"memberName"];
    //if ([userDefault valueForKey:@"APNSDeviceToken"] != nil){
        [syncJson setValue:owner.username forKey:@"deviceId"];
    //}
   // [syncJson setValue:@"" forKey:@"data"];
    
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    
    if(visitedRooms.allKeys.count > 0){
        [dataDict setObject:visitedRooms forKey:@"rooms"];
    }
    
    NSMutableArray *archivedRooms = [CMOUtils allArchivedRoomsInfo];
    //if (archivedRooms.count > 0){
    [dataDict setObject:(archivedRooms == nil ? [NSMutableArray new] : archivedRooms) forKey:@"archivedRooms"];
    //}
    
    NSMutableDictionary *smsUserRooms = [CMOUtils allSMSUserRoomsInfo];
    if (smsUserRooms.allKeys.count > 0){
        [dataDict setObject:smsUserRooms forKey:SMS_USER_INFO];
    }
    
    /*NSArray *archivedRooms = [repositoryClient fetchAllArchivedRooms];
    if (archivedRooms.count > 0){
        NSMutableDictionary *list = [[NSMutableDictionary alloc]init];
        for (CMOArchivedRooms *aRoom in archivedRooms){
            //[list addObject:aRoom.roomName];
            NSMutableArray *array = [self arrayForDictionary:list value:aRoom.roomName];
            [array addObject:[NSString stringWithFormat:@"%d",aRoom.messageCount]];
        }
        [dataDict setValue:list forKey:@"archivedRooms"];
    }*/
    
    NSArray *deletedRooms = [repositoryClient fetchAllDeletedRooms];
    if (deletedRooms.count > 0){
        NSMutableArray *list = [[NSMutableArray alloc]init];
        for (CMODeletedRooms *dRoom in deletedRooms){
            [list addObject:dRoom.roomName];
        }
        [dataDict setValue:list forKey:@"deletedRooms"];
    }
    
    NSError * err;
    NSData * jsonData = [NSJSONSerialization  dataWithJSONObject:dataDict options:0 error:&err];
    NSString * myString = [[NSString alloc] initWithData:jsonData   encoding:NSUTF8StringEncoding];
    
    [syncJson setObject:myString forKey:@"data"];
    
    return syncJson;
}

- (id)arrayForDictionary:(NSMutableDictionary *)dict value:(NSString *)key{
    id value = [dict valueForKey:key];
    NSMutableArray *array = nil;
    if (!value){
        array = [[NSMutableArray alloc]init];
        [dict setObject:array forKey:key];
    }
    return array;
}


/*This condition is to check if there is any difference in room list in db and room list getting from message count api.
  If there is a difference, then call refresh to update UI. This functionality is added because group participant won't get
  the invitation when they are added indirectly (adding group) to the room. so get the updated room for the group user, we are checking this method.
 */

- (BOOL)isRoomDiffered:(CMOUserMessageCount *)usrMsgCount{
    id <CMORepositoryClient>client = [_coreComponents repositoryService];
    //Rooms count will exclude deleted rooms and non participant rooms
    NSInteger roomsCount = [client fetchChatRoomCount];
    NSMutableArray *msgs = usrMsgCount.mucusermessage;
    if (roomsCount != msgs.count){
        return true;
    }
    return false;
    
}


#pragma mark **** SLA Logic - Calculating SLA TIME ****

/*- (NSTimeInterval)calculateSLATime:(CMOMessage *)message{
    if ([message.messageBody.slaFlag boolValue]){
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
        [dateFormatter setDateFormat:MESSAGE_TIME_FORMAT];
        //SLA Start Date
        NSDate *slaStartDate = message.messageBody.messageDate;//[dateFormatter dateFromString:message.messageBody.messageDate];
        //Server Date after last api response
        NSDate *currentDate = [dateFormatter dateFromString:[CMOUtils getServerTime]];
        
        //SLA Duration set by chairman
        NSInteger slaDuration = [message.messageBody.slaTime integerValue];
        
        //SLA Cumulative Date - Total SLA date (i.e) if chairman set 30 mins for SLA and time that he send a SLA message was 1:50 PM, then the following variable return the total sla date (ie) 2:20PM.
        NSDate *cumulSLADate = [slaStartDate dateByAddingTimeInterval:slaDuration*60];
        
        //Time interval between current date and SLA Start Date in seconds.
        NSTimeInterval timeInterval = [currentDate timeIntervalSinceDate:slaStartDate];
        
        //Current Time after SLA
        NSDate *currentTimeDuration = [slaStartDate dateByAddingTimeInterval:timeInterval];
        
        //Remaining SLA time in minutes
        NSTimeInterval slaRemainingTime = [cumulSLADate timeIntervalSinceDate:currentTimeDuration]/60;

        return slaRemainingTime;
    }
    return 0; //SLA NOT ENABLED
}*/


#pragma mark - Upload and download Document <dotcms>

- (void)uploadDocumentWithMessage:(CMOMessage *)message
                  data:(id)documentData
                OnProgress:(void (^)(id progress))onProgress
             onSuccess:(void (^)(id result))success
             onFailure:(void (^)(NSError *error))failure{
    id<CMOWebDavClient> webDavClientHandler = [_coreComponents webDavHandler];
    id <CMORepositoryClient>repoClient = [_coreComponents repositoryService];
   // NSData *data = (NSData *)documentData;
    ////DDLogInfo(@"Size = %.2f MB",(data.length / pow(1024, 2)));

    [webDavClientHandler putPath:[NSString stringWithFormat:@"/%@",message.messageBody.body] parameters:nil data:documentData mimeType:@"image/png" OnProgress:^(id  _Nullable progress) { //mime type should be changed
        NSProgress *prog = progress;
        DDLogInfo(@"Upload progress = (%f)",prog.fractionCompleted*100);
        onProgress(progress);
    } OnSuccess:^(id  _Nullable response) {
        ////DDLogInfo(@"Upload complete");
        // Update Offline table upload flag as `true`
        message.upload = true;
        [repoClient saveMessageOffline:message];
        
        success(response);
        
    } onFailure:^(NSError * _Nonnull error) {
        message.status = MessageDeliveryFailed;
        [repoClient saveMessageOffline:message];
        ////DDLogInfo(@"Upload error:%@",[error description]);
        failure(error);
    }];

}

- (void)downloadDocument:(NSString *)documentName
             OnProgress:(void (^)(id progress))onProgress
             onSuccess:(void (^)(id result))success
             onFailure:(void (^)(NSError *error))failure{

    id<CMOWebDavClient> webDavClientHandler = [_coreComponents webDavHandler];
    [webDavClientHandler get:[NSString stringWithFormat:@"%@",documentName] parameters:nil OnProgress:^(id  _Nonnull progress) {
//        NSProgress *prog = progress;
//        DDLogInfo(@"Download progress %@ = (%f)",documentName,prog.fractionCompleted*100);
        onProgress(progress);
    } OnSuccess:^(id  _Nullable response) {
        ////DDLogInfo(@"Download Success");
        success(response);
    } onFailure:^(NSError * _Nonnull error) {
        ////DDLogInfo(@"Download Failure error:%@",error.description);
        failure(error);
    }];
}

- (BOOL)isConnectedToXMPP{
    return [delegate isXmppStreamConnected];
}
/*- (void)uploadDocument:(NSString *)docName
          documentData:(id)docData
               message:(CMOMessage *)message
  completionHandler:(void (^)(id success, NSError *error))handler
{
    id repositoryClient = [_coreComponents repositoryService];
    [repositoryClient saveDocumentUploadStatusForRoom:message.roomIDStr inprogress:true];
    
    id<CMOWebDavClient> webDavClientHandler = [_coreComponents webDavHandler];
    
    NSData *data = (NSData *)docData;
    ////DDLogInfo(@"Size = %.2f MB",(data.length / pow(1024, 2)));
    
    [webDavClientHandler putPath:[NSString stringWithFormat:@"/%@",docName] parameters:nil data:docData mimeType:@"image/png" OnProgress:^(id  _Nullable progress) { //mime type should be changed
        NSProgress *prog = progress;
        ////DDLogInfo(@"Upload progress = (%f)",prog.fractionCompleted*100);
    } OnSuccess:^(id  _Nullable response) {
        ////DDLogInfo(@"Upload complete");
        //id repositoryClient = [_coreComponents repositoryService];
        [repositoryClient deleteMessage:message];
        [repositoryClient saveDocumentUploadStatusForRoom:message.roomIDStr inprogress:false];
        handler(response,nil);
    } onFailure:^(NSError * _Nonnull error) {
        
        ////DDLogInfo(@"Upload error:%@",[error description]);
        id messageBuilder = [_coreComponents messageBuilder:message];
        CMOMessage *cmoMessage = [self toCMOMessage:[messageBuilder build]];
        //Upload Flag is for client side offline message handling, so set it externally
        //cmoMessage.upload = message.upload;
        //id repositoryClient = [_coreComponents repositoryService];
        [repositoryClient saveMessageOffline:cmoMessage];
        [repositoryClient saveDocumentUploadStatusForRoom:message.roomIDStr inprogress:false];
        handler(nil,error);
    }];
}

- (void)downloadDocument:(NSString *)docName
                message:(CMOMessage *)message
   completionHandler:(void (^)(id success, NSError *error))handler
{
    id<CMOWebDavClient> webDavClientHandler = [_coreComponents webDavHandler];
    [webDavClientHandler get:[NSString stringWithFormat:@"/%@",docName] parameters:nil OnProgress:^(id  _Nonnull progress) {
        NSProgress *prog = progress;
        ////DDLogInfo(@"Download progress %@ = (%f)",docName,prog.fractionCompleted*100);
    } OnSuccess:^(id  _Nullable response) {
        ////DDLogInfo(@"Download Success");
        handler(response,nil);
    } onFailure:^(NSError * _Nonnull error) {
        ////DDLogInfo(@"Download Failure error:%@",error.description);
        handler(nil,error);
    }];
}*/

#pragma mark Save Documents to Documents Directory

- (NSString *)folderPath:(NSString *)folderName{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0]; // Get documents folder
    NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"/%@/",folderName]];
    
    NSError *error = nil;
    if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath])//Check
        [[NSFileManager defaultManager] createDirectoryAtPath:dataPath withIntermediateDirectories:YES attributes:nil error:&error];
    
    return dataPath;
}

- (void)saveDocument:(NSString *)documentName docData:(id)docData forRoom:(NSString *)roomID{
    NSString *roomFolderPath =  [self folderPath:[NSString stringWithFormat:@"%@/%@/%@",DOCUMENT_FOLDER,roomID,[self getIntermediateDirectory:documentName]]];
    NSString *documentPath = [roomFolderPath stringByAppendingPathComponent:documentName];
    if ([docData isKindOfClass:[NSData class]] && docData && ![[NSFileManager defaultManager]fileExistsAtPath:documentPath]){
        NSError *error = nil;
        [docData writeToFile:documentPath options:NSDataWritingAtomic error:&error];
        if (error){
            DDLogError(@"Unable to save document %@",error);
        }
    }
}


- (id)getDocument:(NSString *)documentName forRoom:(NSString *)roomID{
    NSString *roomFolderPath = [self folderPath:[NSString stringWithFormat:@"%@/%@/%@",DOCUMENT_FOLDER,roomID,[self getIntermediateDirectory:documentName]]];
    NSString *documentPath = [roomFolderPath stringByAppendingPathComponent:documentName];
    if (documentPath.length == 0){
        return nil;
    }
    NSData *content = [NSData dataWithContentsOfFile:documentPath];
    return content;
}

- (BOOL) deleteDocument:(NSString *)documentName forRoom:(NSString *)roomID
{
    NSString *roomFolderPath = [self folderPath:[NSString stringWithFormat:@"%@/%@/%@",DOCUMENT_FOLDER,roomID,[self getIntermediateDirectory:documentName]]];
    NSString *documentPath = [roomFolderPath stringByAppendingPathComponent:documentName];
    if (documentPath.length == 0)
    {
        return NO;
    }
    
    NSFileManager* fileManager = [NSFileManager defaultManager];
    BOOL fileExists = [fileManager fileExistsAtPath:documentPath];
    
    if(fileExists)
    {
        BOOL status = [fileManager removeItemAtPath:documentPath error:nil];
        if (status)
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    return NO;
}

//This is to create,fetch,delete image/video/document from Intermediate directory

- (NSString *)getIntermediateDirectory:(NSString *)docName{
    DocumentType docType = [CMOUtils documentType:docName];
    NSString *intermediateDirectory = @"Unknown";
    if (docType == DocumentTypeImage){
        intermediateDirectory = @"Image";
    }
    else if (docType == DocumentTypeVideo){
        intermediateDirectory = @"Video";
    }
    else if (docType == DocumentTypeAudio){
        intermediateDirectory = @"Audio";
    }
    else if (docType == DocumentTypeMedia){ //Document such as PDF, XLS etc
        intermediateDirectory = @"Document";
    }
    else{
        intermediateDirectory = @"Unknown";
    }
    return intermediateDirectory;
}


- (NSString *)getFilePath:(NSString *)fileName roomName:(NSString *)roomName{
   // DocumentType docType = [CMOUtils documentType:fileName];
     NSString *roomFolderPath = [self folderPath:[NSString stringWithFormat:@"%@/%@/%@",DOCUMENT_FOLDER,roomName,[self getIntermediateDirectory:fileName]]];
    NSString *documentPath = [roomFolderPath stringByAppendingPathComponent:fileName];
    if (documentPath.length == 0){
        return nil;
    }
    return documentPath;
}


- (void)removeAllFiles{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *imagesFolderPath = [self folderPath:DOCUMENT_FOLDER];
    NSError *error = nil;
    for (NSString *file in [fileManager contentsOfDirectoryAtPath:imagesFolderPath error:&error]) {
        BOOL success = [fileManager removeItemAtPath:[NSString stringWithFormat:@"%@/%@", imagesFolderPath, file] error:&error];
        if (!success || error) {
            DDLogError(@"Unable to delete file %@",file);
        }
    }
}

- (NSString *)getFormattedMessageBody:(CMOMessageBody *)messageBody fromMe:(BOOL)fromMe{
    NSString *messageContent = messageBody.body;
    if ([messageBody.smsUsers length] > 0 && fromMe && [messageBody.mediaItem integerValue] != 1 && [messageBody.mediaType integerValue] != 1){
        messageContent = [NSString stringWithFormat:MESSAGEBODY_FORMAT,messageBody.body,messageBody.smsUsers];
    }
    return messageContent;
}

#pragma mark XMPP Message to CMOMessage

- (CMOMessage *)toCMOMessage:(XMPPMessage *)message{
    //Issue with message.

    if ([message isKindOfClass:[DDXMLElement class]]){
        message = [XMPPMessage messageFromElement:message];
    }

    NSDate *remoteTimeStamp = [message delayedDeliveryDate];
    
    NSString *user = ([message.from resource] == nil ? [message.from full] : [message.from resource]);
    
    NSString *rawMessage = message.body;
    
    NSString *receiver = ([[message.to user] isEqualToString:user])? [message.from user] : [message.to user];//[toJid user];
    CMOMessageBody *messageBody = [self messageBody:rawMessage];
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    
    NSString *formattedMessage = [self getFormattedMessageBody:messageBody fromMe:[owner.username isEqualToString:user]];
    
    id <CMORosterClient>rosterClient = [_coreComponents rosterService];
    CMORoster *roster = [rosterClient fetchRoster:user];
    NSString *dispName = user;
    if (roster && roster.name) {
        dispName = roster.name;
    }
    //Changed [NSDate date] --> messageBody.messageDate to fix the bug #132043
    CMOMessage *cmoMessage = [[CMOMessage alloc]initWithSenderId:user senderDisplayName:dispName date:messageBody.messageDate ? messageBody.messageDate : [NSDate date] text:formattedMessage];
    cmoMessage.messageBody = messageBody;
    cmoMessage.from = message.from;
    cmoMessage.userName = user; //username should be same as nick name for this app.
    cmoMessage.rawMessage = rawMessage;
    cmoMessage.roomIDStr = receiver;
    //NSLog(@"Message from %@ and %@",message.from,[message.from user]);
    //cmoMessage.status = MessageReceived;
    cmoMessage.elementID = message.elementID;
    cmoMessage.localTimeStamp = remoteTimeStamp ? remoteTimeStamp : [NSDate date];
    cmoMessage.remoteTimeStamp = [message delayedDeliveryDate];
    cmoMessage.messageDate = messageBody.messageDate;
    cmoMessage.slaTime = [messageBody.slaTime integerValue];
    cmoMessage.slaFlag = [messageBody.slaFlag boolValue];
    
    return cmoMessage;
}


- (CMOMessageBody *)messageBody:(NSString *)messageString{
    if (messageString == nil){
        return nil;
    }
    NSData *data = [messageString dataUsingEncoding:NSUTF8StringEncoding];
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    CMOMessageBody *messageBody = [[CMOMessageBody alloc]init];
    //If server is sending welcome message, it should be parsed to message body
    if (json == nil && messageString){
        messageBody.body = messageString;
        messageBody.mediaItem = @"0";
        messageBody.mediaType = @"0";
    }
    else{
        messageBody.body = [json valueForKey:@"body"];
        messageBody.mediaItem = [json valueForKey:@"mediaItem"];
        messageBody.mediaType = [json valueForKey:@"mediaType"];
        messageBody.slaTime = [json valueForKey:@"slaTime"];
        messageBody.slaFlag = [json valueForKey:@"slaFlag"];
        if ([json valueForKey:@"fileName"] != nil || [[json valueForKey:@"fileName"]length] > 0){
            messageBody.fileName = [json valueForKey:@"fileName"];
        }
        messageBody.isConfidential = [json valueForKey:@"isConfidential"];
        messageBody.shouldVisible = [json valueForKey:@"show"] ? [json valueForKey:@"show"] : @"false";
        messageBody.messageDate = [CMOUtils toSpecifiedFormatDate:[json valueForKey:@"date"] format:MESSAGE_TIME_FORMAT];
        messageBody.smsUsers = [json valueForKey:@"smsUsers"] ? [json valueForKey:@"smsUsers"] : @"";
        messageBody.messageDateString = [json valueForKey:@"date"];
        messageBody.messageId = [json valueForKey:@"messageId"];
    }
    return messageBody;
}

- (NSArray *)fetchRoomDetailsAndMessage:(NSString *)user completionHandler:(void (^)(NSArray *items,NSError *error))handler{
    id<APIClient> apiClient = [_coreComponents networkHandler];
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    //chairman/rooms
    NSString *lastSyncTime = [CMOUtils getAllRoomsLastSyncTime];
    if (!lastSyncTime) {
        lastSyncTime = @"0";
    }
    
    NSString *deviceSyncVersion = [CMOUtils getDeviceSyncVersion];
    if (!deviceSyncVersion){
        deviceSyncVersion = @"0";
    }
    
    __block NSDate *Start_Time_OF_Method = [NSDate date];
        
    NSString *url = [NSString stringWithFormat:@"%@/%@/roomsAndMessages?lastSyncTime=%@&syncVersion=%@",[CMOUtils appConfigurations][GETCHATROOMS],user,lastSyncTime,deviceSyncVersion];
    ////DDLogInfo(@"Fetch Room URL: %@",url);
    
    [apiClient GET:url parameters:nil OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
        //////DDLogInfo(@"All Rooms %@",response);
        NSDate *Finish_Time_OF_Method = [NSDate date];
        NSTimeInterval executionTime = [Finish_Time_OF_Method timeIntervalSinceDate:Start_Time_OF_Method];
        
        ////DDLogInfo(@"Success: executionTime = %f", executionTime);
        
        [repositoryClient saveChatRoomDetailsAndMessage:response];
        handler(nil,nil);
    } onFailure:^(NSError * _Nonnull error) {
        
        NSDate *Finish_Time_OF_Method = [NSDate date];
        NSTimeInterval executionTime = [Finish_Time_OF_Method timeIntervalSinceDate:Start_Time_OF_Method];
        
        ////DDLogInfo(@"Failure: executionTime = %f", executionTime);
        
        handler(nil,error);
    }];
    
    return nil;
    
}



@end
