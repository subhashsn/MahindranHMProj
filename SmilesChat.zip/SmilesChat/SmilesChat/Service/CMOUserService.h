//
//  CMOUserService.h
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CMOUserClient.h"

@class CMOCoreComponents;
@class CMOXMPPManager;

@interface CMOUserService : NSObject<CMOUserClient>
@property (nonatomic, strong)CMOCoreComponents *coreComponents;
@property (nonatomic, strong) NSManagedObjectContext *managedObjectcontext;
@end
