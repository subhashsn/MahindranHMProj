//
//  CMOLoginService.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOLoginService.h"
#import "CMOLoginPresentation.h"
#import "CMOUser.h"
#import "CMOAppServerAPIClient.h"
#import "CMOUtils.h"
#import <sys/sysctl.h>
#import "CMOCoreComponents.h"

@implementation CMOLoginService


- (void)login:(CMOLoginPresentation *)loginModel onSuccess:(CMOLoginReceivedBlock)successBlock
                                    onError: (CMOLoginErrorBlock)errorBlock{

    //User information will be retrieved from active directory server
    CMOUser *user = [[CMOUser alloc]init];
    user.username = [loginModel.userName lowercaseString];
    user.email = @"";
    user.name = [loginModel.userName lowercaseString];
    successBlock(user);
}


#pragma mark -- 
#pragma mark app updates

- (void)updateAppVersionWithUser:(NSString *)userName onSuccess:(void (^)(id result))success onFailure:(void (^)(NSError *error))failure
{
    NSDictionary *parameters = [self constructAppVersionRequest:userName];
    
    id <CMOAppServerAPIClient> client = [_coreComponents appServerAPIHandler];
    NSString *url = @"/AppVersion";
    
    [client POST:url parameters:parameters OnProgress:^(id  _Nullable progress) {
        //DDLogInfo(@"AppVersion progress: %@",progress);
    } OnSuccess:^(id  _Nullable response) {
        //DDLogInfo(@"AppVersion success: %@",response);
        success(response);
    } onFailure:^(NSError * _Nonnull error) {
        //DDLogInfo(@"AppVersion error: %@",error);
        failure(error);
    }];
}

- (NSDictionary *)constructAppVersionRequest:(NSString *) user{
    
    NSMutableDictionary *dictonary = [[NSMutableDictionary alloc]init];
    NSString *deviceID = [CMOUtils getDeviceIdentifier];
    if (!deviceID) {
        deviceID = [self getDeviceID];
        [CMOUtils saveDeviceIdentifier:deviceID];
    }
    
    NSString *appVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSString *installedDate = [CMOUtils getLastInstalledDate];
    NSString *deviceName = [self getDeviceName];
    NSString *deviceOSVersion = [self getDeviceOSVersion];
//    NSString *carrier = [self getCarrierName];
    
    [dictonary setObject:user forKey:@"memberName"];
    [dictonary setObject:deviceID forKey:@"deviceId"];
    [dictonary setObject:appVersion forKey:@"appVersion"];
    [dictonary setObject:installedDate forKey:@"installedDate"];
    [dictonary setObject:deviceName forKey:@"deviceName"];
    [dictonary setObject:deviceOSVersion forKey:@"osVersion"];
//    [dictonary setObject:carrier forKey:@"otherInfo"];
    
    return dictonary;
}

- (NSString *)getDeviceName{
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = malloc(size);
    sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithCString:machine encoding:NSUTF8StringEncoding];
    
    return platform;
}

- (NSString *) getDeviceID{
    NSString *uuid = [[NSUUID UUID] UUIDString];
    NSString *deviceId = [NSString stringWithFormat:@"%@", uuid];
    return deviceId;
}

- (NSString *) getDeviceOSVersion{
    NSString *osVersion = [UIDevice currentDevice].systemVersion;
    return osVersion;
}

@end
