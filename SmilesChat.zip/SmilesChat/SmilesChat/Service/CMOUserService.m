//
//  CMOUserService.m
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOUserService.h"
#import "CMOXMPPManager.h"
#import "CMOUser.h"
#import "CMOAppServerAPIClient.h"
#import "CMORepositoryClient.h"
#import "CMOCoreComponents.h"
#import "CMORoster+CoreDataProperties.h"
#import "CMONetworkHandler.h"
#import "AppDelegate.h"

@interface CMOUserService(){
    id <CMOXMPPDelegate> delegate;
}

@end

@implementation CMOUserService

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (instancetype)initWithManager:(id <CMOXMPPDelegate>)manager{
    self = [super init];
    if (self) {
        delegate = manager;
        //CMOXMPPManager *manager = (CMOXMPPManager *)delegate;
    }
    return self;
}


- (CMOUser *)user{
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSMutableArray *archivedArray = [userdefault valueForKey:@"activeuser"];
    if (archivedArray.count > 0)
    {
        NSData *userData = archivedArray[0];
        CMOUser *activeUser = [NSKeyedUnarchiver unarchiveObjectWithData:userData];
        return activeUser;
    }
    return nil;
}

//User should be saved in Database.
//Temperorary: NSUserDefault
- (void)saveUser:(CMOUser *)user{
    NSMutableArray *archiveArray = [[NSMutableArray alloc]init];
    NSData *userData = [NSKeyedArchiver archivedDataWithRootObject:user];
    [archiveArray addObject:userData];
    
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    [userdefault setObject:archiveArray forKey:@"activeuser"];
}

#pragma mark - Is Actual Chairman User

- (BOOL)isChairman{
    CMOUser *user = [self user];
    if ([user.username isEqualToString:CHAIRMANUSERNAME]){
        return true;
    }
    return false;
}




//XMPP vCard Update
- (void)updateUserInformation:(CMOUser *)user{
    [delegate updateUserInformation:user];
}

- (CMOUser *)fetchUservCard:(NSString *)userName{
    return [self toCMOUSer:[delegate fetchUservCardforJID:userName] forUser:userName];
}

- (CMOUser *)toCMOUSer:(XMPPvCardTemp *)vCard forUser:(NSString *)userName {
    if (vCard){
        CMOUser *user = [[CMOUser alloc]init];
        user.username = userName;//vCard.nickname != nil ? vCard.nickname : nil;
        
        //XMPPvCardTempEmail *emailvCard = emailAddresses[0];
//        NSString *email = emailvCard.userid;
        
        if (vCard.emailAddresses.count > 0){
            XMPPvCardTempEmail *emailvCard = vCard.emailAddresses[0];
             NSString *email = emailvCard.userid;
            user.email = email;
        }
       // user.email = vCard.emailAddresses.count > 0 ? vCard.emailAddresses[0] : nil;
        user.userAvatar = vCard.photo != nil ? [UIImage imageWithData:vCard.photo] : [UIImage imageNamed:@"ProfilePic_Placeholder.png"];
        user.orgName = nil;
        //DDLogInfo(@"User Photo is %@",vCard)
        
         NSArray *addresses = vCard.addresses;
        if (addresses.count > 0){
            for (XMPPvCardTempAdr *addr in addresses){
               // DDLogInfo(@"Address is %@",addr.street);
                if ([addr.street isEqualToString:EXISTINGUSER]){
                    user.street = addr.street;
                    break;
                }
            }
        }
        
        if ([vCard.orgUnits count]) {
            user.orgName = [vCard.orgUnits objectAtIndex:0];
        }
        user.orgTitle = vCard.title != nil ? vCard.title : nil;
        user.orgRole = vCard.role != nil ? vCard.role : nil;
        user.phoneNumber = [self getPhoneNumber: vCard];
        
        if(user.phoneNumber){
            [self updatePhoneNumberForUser:user.username andPhoneNumber:user.phoneNumber];
        }
        return user;
    }
    return nil;
}

- (void) updatePhoneNumberForUser:(NSString *)userName andPhoneNumber:(NSString *)phoneNumber
{
    id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    
    CMORoster *roster = [repositoryClient fetchRoster:userName];
    if (roster && ![roster.phoneNumber isEqualToString:phoneNumber]){
        roster.phoneNumber = phoneNumber;
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Save Rosters");
        }
    }
}

- (NSString *)getPhoneNumber:(XMPPvCardTemp *)vCard
{
    NSArray *phonenumbers = [vCard elementsForName:@"TEL"];
    
    for (NSXMLElement *phonenumber in phonenumbers)
    {
        XMPPvCardTempTel *vCardTempTel = [XMPPvCardTempTel vCardTelFromElement:phonenumber];
        
        if (vCardTempTel.isWork && vCardTempTel.isPager && ![vCardTempTel.number isEqualToString:@""])
        {
            NSArray *phoneNumber = [vCardTempTel.number componentsSeparatedByString:@" "];
            return [phoneNumber firstObject];
        }
    }
    return nil;
}

- (NSMutableArray *)errorLogData {
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    DDFileLogger *ddFileLogger = appDelegate.fileLogger;
    NSArray <NSString *> *logFilePaths = [ddFileLogger.logFileManager sortedLogFilePaths];
    NSMutableArray <NSData *> *logFileDataArray = [NSMutableArray new];
    for (NSString* logFilePath in logFilePaths) {
        NSURL *fileUrl = [NSURL fileURLWithPath:logFilePath];
        NSData *logFileData = [NSData dataWithContentsOfURL:fileUrl options:NSDataReadingMappedIfSafe error:nil];
        if (logFileData) {
            [logFileDataArray insertObject:logFileData atIndex:0];
        }
    }
    return logFileDataArray;
}



- (void)uploadLogFileonSuccess:(void (^)(id result))success
                     onFailure:(void (^)(NSError *error))failure{
    
    id<CMOWebDavClient> webDavClientHandler = [_coreComponents webDavHandler];
    
    NSMutableData *errorLogData = [NSMutableData data];
    for (NSData *errorLogFileData in [self errorLogData]) {
        [errorLogData appendData:errorLogFileData];
    }
    if ([errorLogData length] <= 0){
        return;
    }
    
    [webDavClientHandler putPath:@"/Logs" parameters:nil data:errorLogData mimeType:@"text/plain" OnProgress:^(id  _Nullable progress) { //mime type should be changed
        ////DDLogInfo(@"Upload progress = (%f)",prog.fractionCompleted*100);
    } OnSuccess:^(id  _Nullable response) {
        ////DDLogInfo(@"Upload complete");
        // Update Offline table upload flag as `true`
        
        success(response);
        
    } onFailure:^(NSError * _Nonnull error) {
        ////DDLogInfo(@"Upload error:%@",[error description]);
        failure(error);
    }];
    
}


@end
