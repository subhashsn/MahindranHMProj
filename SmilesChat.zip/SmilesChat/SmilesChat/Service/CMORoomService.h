//
//  CMORoomService.h
//  CMOChat
//
//  Created by Administrator on 4/5/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CMOCoreComponents;

@interface CMORoomService : NSObject

@property (nonatomic, strong)CMOCoreComponents *coreComponents;

@end

