//
//  CMORepositoryService.m
//  CMOChat
//
//  Created by Administrator on 11/4/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMORepositoryService.h"
#import <CoreData/CoreData.h>
#import "CMOXMPPManager.h"
#import "CMOCoreComponents.h"
#import "CMOMessageBuilder.h"

#import "CMOOfflineMessages+CoreDataProperties.h"
#import "CMORoomDetails+CoreDataProperties.h"
#import "CMOOwners+CoreDataProperties.h"
#import "CMOMembers+CoreDataProperties.h"
#import "CMOBroadcastPresenceRoles+CoreDataProperties.h"
#import "CMOAdmins+CoreDataProperties.h"
#import "CMORoster+CoreDataProperties.h"
#import "CMOArchivedRooms+CoreDataProperties.h"
#import "CMOUserRoles+CoreDataProperties.h"
#import "CMOUserPermissions+CoreDataProperties.h"
#import "CMORosterGroup+CoreDataProperties.h"
#import "CMOMembersGroup+CoreDataClass.h"
#import "CMOOutcastsGroup+CoreDataClass.h"
#import "CMOOwnersGroup+CoreDataClass.h"
#import "CMOAdminsGroup+CoreDataClass.h"
#import "CMODraftMessages+CoreDataClass.h"
#import "CMOMessageReadStatus+CoreDataClass.h"
#import "CMORoomProperty+CoreDataClass.h"
#import "CMOVisitedRooms+CoreDataClass.h"
#import "CMODeletedRooms+CoreDataClass.h"
#import "AppDelegate.h"

#import "CMOUtils.h"
#import "CMOUser.h"

#import "XMPPUserCoreDataStorageObject.h"
//#import "XMPPvCardAvatarCoreDataStorageObject.h"
#import <AddressBook/AddressBook.h>

#define COMPANY_NAME @"damac"


@interface CMORepositoryService(){
    NSMutableArray *roomNameList;
    NSMutableArray *usersList;
    NSMutableArray *groupsList;
}

@end

@implementation CMORepositoryService

- (instancetype)init
{
    self = [super init];
    if (self) {
        roomNameList = [[NSMutableArray alloc]init];
        usersList = [[NSMutableArray alloc]init];
        groupsList = [[NSMutableArray alloc]init];
    }
    return self;
}


- (NSArray *)fetchMessages{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
   
    //xmppRoomStorage based on current room
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:[xmppManager.xmppRoomStorage messageEntityName] inManagedObjectContext:context];
    fetchRequest.entity = messageEntity;
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"localTimestamp" ascending:YES];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
    if (error){
        DDLogError(@"Error while fetching Message Archive %@, %@, %@",error,THIS_FILE,THIS_METHOD);
    }
    return results;
}


- (NSArray *)fetchMessageForRoom:(NSString *)roomId{
    
    //Delete any unsent messages in the room.
    //[self deleteConflictedRoomMessageIfAny:roomId];
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
     CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
    
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:[xmppManager.xmppRoomStorage messageEntityName] inManagedObjectContext:context];
    fetchRequest.entity = messageEntity;//TyphoonConfig(kOFServerNameKey)//roomJIDStr
    NSString *roomName = [NSString stringWithFormat:@"%@@%@", roomId,self.conferenceURL];

    //It is important to filter the message with roomJIDStr and streamBareJidStr.
    //Suppose if two users login in 2 different time, all the messages will be available in db. In order to differentiate message, we have to filter messages by streamBareJidStr.
    
    [fetchRequest setPredicate:[NSPredicate predicateWithFormat:@"roomJIDStr==%@ AND streamBareJidStr==%@",roomName,[NSString stringWithFormat:@"%@@%@",owner.username,self.domainName]]];
   
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"messageDate" ascending:YES];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
    if (error){
        DDLogError(@"Error while fetching Message Archive %@, %@, %@",error,THIS_FILE,THIS_METHOD);
    }
    return results;
}


- (NSInteger)fetchMessageCountForRooms:(NSString *)roomId{
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
    
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:[xmppManager.xmppRoomStorage messageEntityName] inManagedObjectContext:context];
    fetchRequest.entity = messageEntity;//TyphoonConfig(kOFServerNameKey)//roomJIDStr
    NSString *roomName = [NSString stringWithFormat:@"%@@%@", roomId,self.conferenceURL];
    
    //It is important to filter the message with roomJIDStr and streamBareJidStr.
    //Suppose if two users login in 2 different time, all the messages will be available in db. In order to differentiate message, we have to filter messages by streamBareJidStr.
    
    [fetchRequest setPredicate:[NSPredicate predicateWithFormat:@"roomJIDStr==%@ AND streamBareJidStr==%@",roomName,[NSString stringWithFormat:@"%@@%@",owner.username,self.domainName]]];
    
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"localTimestamp" ascending:YES];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSError *error = nil;
    NSInteger count = [context countForFetchRequest:fetchRequest error:&error];
    return count;
}




/*
    This function will check for messages other than the logged in user. If any message available, it will return true. 
    
 This function is required to keep track of SLA close. If there is any other message other than logged in user, then it means SLA is closed. This case is mostly applicable to chairman.
 
 */
- (BOOL)isMessageAvailableOtherThanOwnerOfRoom:(NSString *)roomId{
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];

    id <CMORosterClient>rosterClient = [_coreComponents rosterService];
    CMORoster *roster = [rosterClient fetchRoster:owner.username];
    
    CMORoomDetails *roomDetails = [self fetchRoomInfo:roomId];
    NSString *roomOwnerName = nil;
    id roomOwners = roomDetails.owners.owner;
    if ([roomOwners isKindOfClass:[NSMutableArray class]]){
        NSMutableArray *ownerList = (NSMutableArray *)roomOwners;
        if (ownerList.count > 0){
            XMPPJID *jid = [XMPPJID jidWithString:ownerList[0]];
            roomOwnerName = [jid user];
        }
    }
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
    
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:[xmppManager.xmppRoomStorage messageEntityName] inManagedObjectContext:context];
    fetchRequest.entity = messageEntity;
    NSString *roomName = [NSString stringWithFormat:@"%@@%@", roomId,self.conferenceURL];
   // NSString *userName = [NSString stringWithFormat:@"%@@%@",roster.username,self.serverName];
    //If user is chairman,
    if ([roster.userPermission.canSetSlaTime boolValue]){
        [fetchRequest setPredicate:[NSPredicate predicateWithFormat:@"roomJIDStr==%@ && nickname !=%@",roomName,owner.username]];
    }
    else{
        //In Participant case, check if any user other than chairman is responded.
        [fetchRequest setPredicate:[NSPredicate predicateWithFormat:@"roomJIDStr==%@ && nickname !=%@",roomName,roomOwnerName]];
    }
    //[fetchRequest setPredicate:[NSPredicate predicateWithFormat:@"roomJIDStr==%@ && nickname !=%@",roomName,owner.username]];
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
    if (error){
        DDLogError(@"Error while fetching Message Archive %@, %@, %@",error,THIS_FILE,THIS_METHOD);
    }
    return results.count > 0;
}


- (void)clearMessages{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
    
    //xmppRoomStorage based on current room
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:[xmppManager.xmppRoomStorage messageEntityName] inManagedObjectContext:context];
    fetchRequest.entity = messageEntity;
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"localTimestamp" ascending:YES];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [context deleteObject:result];
    }
    if (![context save:&error]){
        NSLog(@"Failed to save");
    }
}


- (void)clearAllData{
    [self clearMessages];
    [self clearOfflineMessage];
    [self clearUsers];
    [self clearAllRooms];
    [self clearArchivedRooms];
    [self clearAllRosters];
    [self clearUserRolesAndPermissions];
    //No need to delete group roster as it is common across users
    //[self clearAllRosterGroup];
    [self clearAllDraftMessages];
    [self clearAllUnReadMessages];
    [self deleteAllVisitedRooms];
}

- (void) clearDataOnVersionUpdate{
    [self clearUsers];
    [self clearAllRooms];
    [self clearArchivedRooms];
    [self clearAllRosters];
    [self clearUserRolesAndPermissions];
    [self clearAllUnReadMessages];
    [self deleteAllVisitedRooms];
}


- (void)clearRosterGroups{
    //CMORosterGroup
    NSFetchRequest *fetchRequest = [CMORosterGroup fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORosterGroup" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [_managedObjectcontext deleteObject:result];
    }
    if (results.count > 0){
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Delete message");
        }
    }
}

-(NSManagedObjectContext *)getManagedObjectContext {
    return self.managedObjectcontext;
}

- (void)clearUserRolesAndPermissions{
    NSFetchRequest *fetchRequest = [CMOUserRoles fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMOUserRoles" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [_managedObjectcontext deleteObject:result];
    }
    
    if (results.count > 0){
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to clear - User Roles & Permissions message");
        }
    }
    
    fetchRequest = [CMOUserPermissions fetchRequest];
    messageEntity = [NSEntityDescription entityForName:@"CMOUserPermissions" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [_managedObjectcontext deleteObject:result];
    }
    
    
    if (results.count > 0){
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Delete message");
        }
    }
}

- (void)compareOfflineAndRemoveXMPPMessages{
    BOOL shouldSave = false;
    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
    
    NSArray *offlineMessages = [self fetchAllOfflineMessages];
    NSArray *xmppMessages = [self fetchMessages];
    for (CMOOfflineMessages *offlineMesssage in offlineMessages){
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messageDateString == %@ AND roomJIDStr CONTAINS[cd] %@",offlineMesssage.messageDateString,offlineMesssage.roomID];
        NSArray *messages = [xmppMessages filteredArrayUsingPredicate:predicate];
        if (messages.count > 0){
            for (XMPPRoomMessageCoreDataStorageObject *coredateMsg in messages){
                [context deleteObject:coredateMsg];
                shouldSave = true;
            }
        }
    }
    if (shouldSave){
        NSError *error = nil;
        if (![context save:&error]){
            DDLogError(@"Failed to save - Delete Core data Message");
        }
    }
}


#pragma mark Clear All Pending XMPP Messages
- (void)clearAllPendingXMPPMessages{
    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"XMPPRoomMessageCoreDataStorageObject" inManagedObjectContext:context];
    
    NSFetchRequest *fetchRequest = [NSFetchRequest new];
    fetchRequest.entity = messageEntity;
    // 0 - Pending Status
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"deliveryStatus == 0"];
    fetchRequest.predicate = predicate;
    //fetchRequest.fetchBatchSize = 1;
    
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [context deleteObject:result];
    }
    if (results.count > 0){
        if (![context save:&error]){
            DDLogError(@"Failed to save - Delete XMPP Message with Pending status = true");
        }
    }
}

#pragma mark Update Message Status as Failed

- (void)updateAllOfflineMessages{
    NSArray *offlineMessages = [self fetchAllOfflineMessages];
    for (CMOOfflineMessages *offlineMessage in offlineMessages){
        offlineMessage.status = [NSNumber numberWithInteger:1];
    }
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Upadte Offline Message with Failed status = true");
    }
}


#pragma mark Clear All User

- (void)clearUsers{
    NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [_managedObjectcontext deleteObject:result];
    }
    if (results.count > 0){
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Delete message");
        }
    }
}

- (XMPPRoomMessageCoreDataStorageObject *)fetchMessage:(CMOMessage *)message ofRoom:(NSString *)room{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
    
    //xmppRoomStorage based on current room
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"XMPPRoomMessageCoreDataStorageObject" inManagedObjectContext:context];
    fetchRequest.entity = messageEntity;
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messageDateString == %@",message.messageBody.messageDateString];
    fetchRequest.predicate = predicate;
    fetchRequest.fetchBatchSize = 1;
    
    /*NSDate *minLocalTimestamp = [message.messageDate dateByAddingTimeInterval:-10];
    NSDate *maxLocalTimestamp = [message.messageDate dateByAddingTimeInterval: 10];
    
    
    NSString *predicateFormat = @"body == %@ AND messageDate = %@ OR messageDate BETWEEN {%@,%@}";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:predicateFormat,message.messageBody.body,message.messageDate,minLocalTimestamp,maxLocalTimestamp];
    fetchRequest.predicate = predicate;
    fetchRequest.fetchBatchSize = 1;*/
    
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
    if (error){
        DDLogError(@"Error while fetching Message Archive %@, %@, %@",error,THIS_FILE,THIS_METHOD);
    }
    return results.count > 0 ? [results lastObject] : nil;
}

//messageDate is unique id for each message
- (void)deleteXMPPMessage:(XMPPRoomMessageCoreDataStorageObject *)message{
    ////DDLogInfo(@"Delete XMPP Message %@ %@",THIS_METHOD,THIS_FILE);
    //DDLogVerbose(@"DAMAC: 1 %@ %@ %@",THIS_METHOD,THIS_FILE,message.message);

    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
    
    //xmppRoomStorage based on current room
    NSError *error = nil;
    if (message){
        //DDLogVerbose(@"DAMAC: 2 %@ %@",THIS_METHOD,THIS_FILE);

        [context deleteObject:message];
        if (![context save:&error]){
            //DDLogVerbose(@"DAMAC: 3 %@ %@",THIS_METHOD,THIS_FILE);

            DDLogError(@"Failed to save - Delete message");
        }
    }
}

- (void)updateMessageStatus:(MessageDeliveryStatus)status roomId:(NSString *)roomId messageId:(CMOMessage *)message{
    XMPPRoomMessageCoreDataStorageObject *xmppMessage = [self fetchMessage:message ofRoom:roomId];
    DDLogInfo(@"Update Message ID : %@",xmppMessage.message.body);
    if (xmppMessage){
        id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
        CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
        NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
        xmppMessage.deliveryStatus = status;
        NSError *error = nil;
        if (![context save:&error]){
            DDLogError(@"Failed to save - Delete message");
        }
    }
}

#pragma mark Offline Message Operation
#pragma mark

- (id)offlineMessageEntity{
    return [NSEntityDescription entityForName:@"CMOOfflineMessages" inManagedObjectContext:self.managedObjectcontext];//[NSEntityDescription insertNewObjectForEntityForName:@"CMOOfflineMessages" inManagedObjectContext:self.managedObjectcontext];
}

//This function will delete the message in `XMPPRoomMessageCoreDataStorageObject`, if this message is already saved in the offline table

/*- (void)deleteConflictedRoomMessageIfAny:(NSString *)roomId{
    NSArray *offlineMessages = [self fetchOfflineMessageOfRoom:roomId];
    if (offlineMessages.count > 0){
        for (CMOOfflineMessages *offlineMsg in offlineMessages){
            XMPPRoomMessageCoreDataStorageObject *roomMessage = [self fetchMessage:offlineMsg ofRoom:offlineMsg.roomJIDStr];
            [self deleteXMPPMessage:roomMessage];
        }
    }
}*/

- (CMOOfflineMessages *)updateOfflineMessage:(CMOMessage *)message{
    CMOOfflineMessages *offlineMessage = [self fetchOfflineMessage:message.messageBody.messageDateString];
    if (offlineMessage){
        offlineMessage.messageDate = [CMOUtils toSpecifiedFormatDate:[CMOUtils getServerTime] format:MESSAGE_TIME_FORMAT];
        offlineMessage.messageDateString = [CMOUtils toSpecifiedFormatString:offlineMessage.messageDate format:MESSAGE_TIME_FORMAT];
        
        NSError *error = nil;
        if (![self.managedObjectcontext save:&error]){
            DDLogError(@"Unable to save offline message");
        }
    }
    return offlineMessage;
}

- (void)saveMessageOffline:(CMOMessage *)message{
    
    /*
        We have to delete the message from XMPP Database if any, before saving the message to offline table. This will avoid duplicate of message from XMPPRoomMessageCoreDataStorageObject table and Offline table when the message sending failed.
     */
    /*XMPPRoomMessageCoreDataStorageObject *roomMessage = [self fetchMessage:message ofRoom:message.roomIDStr];
    if (roomMessage){
        [self deleteXMPPMessage:roomMessage];
    }*/
    
    //update `isAnyMessageOffline` to display failed icon.
    if (message.status == MessageDeliveryFailed || message.status == MessageDeliverySuccess) {
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        //DDLogInfo(@"\n%@ %@ 000204\n",THIS_METHOD,THIS_FILE);
        appDelegate.roomCreationInprogress = NO;
    }
    
    id <CMOMessageBuilderDelegate> builder = [_coreComponents messageBuilder:message];
    
    CMOOfflineMessages *offlineMessage = [self fetchOfflineMessageForMessageId:message.messageBody.messageId];
    
    if (!offlineMessage){
        offlineMessage = [NSEntityDescription insertNewObjectForEntityForName:@"CMOOfflineMessages" inManagedObjectContext:self.managedObjectcontext];
    }
    
    XMPPMessage *xMessage = [builder build];
    offlineMessage.body = message.messageBody.body;
    offlineMessage.fromMe = [NSNumber numberWithBool:true];
    offlineMessage.sender = message.userName;
    offlineMessage.messageDate = message.messageBody.messageDate;
    offlineMessage.senderjidStr = [NSString stringWithFormat:@"%@@%@/%@",message.userName,self.conferenceURL,CMOCHATIPHONE];
    offlineMessage.roomID = message.roomIDStr;
    offlineMessage.roomJIDStr = [NSString stringWithFormat:@"%@@%@/%@",message.roomIDStr,self.conferenceURL,message.userName];
    offlineMessage.messageStr = message.rawMessage;
    offlineMessage.nickname = message.userName;
    offlineMessage.localTimestamp = message.date;
    offlineMessage.message = xMessage;
    offlineMessage.elementId = message.elementID;
    offlineMessage.upload = message.upload;
    offlineMessage.status = [NSNumber numberWithInteger:message.status];
    offlineMessage.isOffline = true;
    offlineMessage.fileName = message.messageBody.fileName;
    offlineMessage.messageStr = [[xMessage elementForName:@"body"] stringValue];
    offlineMessage.isMediaMessage = [message.mediaItem boolValue];
    offlineMessage.isMediaMessage = [message.mediaType boolValue];
    offlineMessage.slaTime = [message.messageBody.slaTime integerValue];
    offlineMessage.slaFlag = [message.messageBody.slaFlag boolValue];
    offlineMessage.isConfidential = [message.messageBody.isConfidential boolValue];
    offlineMessage.smsUsers = message.messageBody.smsUsers;
    offlineMessage.messageId = message.messageBody.messageId;
    offlineMessage.messageDateString = message.messageBody.messageDateString;
    
    NSError *error = nil;
    if (![self.managedObjectcontext save:&error]){
        DDLogError(@"Unable to save offline message");
    }
    NSInteger count = [self fetchOfflinePendingMessageCountofRoom:message.roomIDStr];
    
    [self updateOfflineMessageStatus:(message.status == MessageDeliveryFailed) ? true : (count > 0 ?true:false) roomId:message.roomIDStr];
    
}


- (NSInteger)fetchOfflinePendingMessageCountofRoom:(NSString *)roomId{
    NSFetchRequest *fetchRequest = [CMOOfflineMessages fetchRequest];
    NSEntityDescription *messageEntity = [self offlineMessageEntity];
    //If status is failed, then update
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomID == %@ && status == 1",roomId];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    
    NSError *error = nil;
    NSInteger count = [self.managedObjectcontext countForFetchRequest:fetchRequest error:&error];
    return count;
}


- (void)deleteOfflineMessage:(CMOMessage *)message{
    /*if (message.elementID == nil){
        DDLogError(@"Unable to delete the offline message. Reason: elementID is nil");
        return;
    }*/
    //DDLogVerbose(@"DAMAC: 1 %@ %@ %@ %@",THIS_METHOD,THIS_FILE,message.messageBody.body,message.messageBody.messageDateString);
    NSFetchRequest *fetchRequest = [CMOOfflineMessages fetchRequest];
    NSEntityDescription *messageEntity = [self offlineMessageEntity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messageId == %@",message.messageBody.messageId];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        //DDLogVerbose(@"DAMAC: 1 %@ %@",THIS_METHOD,THIS_FILE);
        [_managedObjectcontext deleteObject:result];
    }
    if (![_managedObjectcontext save:&error]){
        //DDLogVerbose(@"DAMAC: 3 %@ %@",THIS_METHOD,THIS_FILE);
        DDLogError(@"Failed to save - Delete message");
    }
    
    //update `isAnyMessageOffline` to display failed icon.
    NSInteger count = [self fetchOfflineMessageCountOfRoom:message.roomIDStr];
    if (count == 0){//no offline
        //DDLogVerbose(@"DAMAC: 4 %@ %@",THIS_METHOD,THIS_FILE);
        [self updateOfflineMessageStatus:false roomId:message.roomIDStr];
    }
}


- (NSArray *)fetchOfflineMessageOfRoom:(NSString *)roomID{
    NSFetchRequest *fetchRequest = [CMOOfflineMessages fetchRequest];
    NSEntityDescription *messageEntity = [self offlineMessageEntity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomID == %@",roomID];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"localTimestamp" ascending:YES];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
}


- (NSInteger)fetchOfflineMessageCountOfRoom:(NSString *)roomId{
    NSFetchRequest *fetchRequest = [CMOOfflineMessages fetchRequest];
    NSEntityDescription *messageEntity = [self offlineMessageEntity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomID == %@",roomId];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    
    NSError *error = nil;
    NSInteger count = [self.managedObjectcontext countForFetchRequest:fetchRequest error:&error];
    return count;
}

- (NSArray *)fetchOfflineMessageOfUser:(NSString *)userName{
    NSFetchRequest *fetchRequest = [CMOOfflineMessages fetchRequest];
    NSEntityDescription *messageEntity = [self offlineMessageEntity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"sender == %@",userName];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"localTimestamp" ascending:YES];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
}

- (NSArray *)fetchAllOfflineMessages{
    NSFetchRequest *fetchRequest = [CMOOfflineMessages fetchRequest];
    NSEntityDescription *messageEntity = [self offlineMessageEntity];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    if (!results){
        return nil;
    }
    return results;
}

/*- (NSArray *)fetchAllPendingOfflineMessages{
    NSFetchRequest *fetchRequest = [CMOOfflineMessages fetchRequest];
    NSEntityDescription *messageEntity = [self offlineMessageEntity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"status == 0"];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    if (!results){
        return nil;
    }
    return results;
}*/

- (CMOOfflineMessages *)fetchOfflineMessage:(NSString *)messageDate{
    NSFetchRequest *fetchRequest = [CMOOfflineMessages fetchRequest];
    NSEntityDescription *messageEntity = [self offlineMessageEntity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messageDateString == %@",messageDate];
    fetchRequest.predicate = predicate;
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    if (!results){
        return nil;
    }
    return [results lastObject];
}


- (CMOOfflineMessages *)fetchOfflineMessageForMessageId:(NSString *)messageId{
    NSFetchRequest *fetchRequest = [CMOOfflineMessages fetchRequest];
    NSEntityDescription *messageEntity = [self offlineMessageEntity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messageId == %@",messageId];
    fetchRequest.predicate = predicate;
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    if (!results){
        return nil;
    }
    return [results lastObject];
}


- (void)clearOfflineMessage{
    NSFetchRequest *fetchRequest = [CMOOfflineMessages fetchRequest];
    NSEntityDescription *messageEntity = [self offlineMessageEntity];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [_managedObjectcontext deleteObject:result];
    }
    if (results.count > 0){
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Delete Offline message");
        }
    }
}



//- (BOOL)isMessageAlreadyInTable:(XMPPMessage *)message{
//    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
//    CMOXMPPManager *xmppManager = [_coreComponents xmppManager];
//    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
//    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:[xmppManager.xmppRoomStorage messageEntityName] inManagedObjectContext:context];
//    fetchRequest.entity = messageEntity;
//    
////    NSPredicate
//    
//}


- (CMOMessageBody *)messageBody:(NSString *)messageString{
    if (messageString == nil){
        return nil;
    }
    NSData *data = [messageString dataUsingEncoding:NSUTF8StringEncoding];
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    CMOMessageBody *messageBody = [[CMOMessageBody alloc]init];
    //If server is sending welcome message, it should be parsed to message body
    if (json == nil && messageString){
        messageBody.body = messageString;
        messageBody.mediaItem = @"0";
        messageBody.mediaType = @"0";

    }
    else{
        messageBody.body = [json valueForKey:@"body"];
        messageBody.mediaItem = [json valueForKey:@"mediaItem"];
        messageBody.mediaType = [json valueForKey:@"mediaType"];

    }
    return messageBody;
}


#pragma mark Save Room Info

- (void)saveChatRoomDetailsAndMessage:(id)chatRoom{
    
    if ([chatRoom valueForKey:@"chatRoom"] == nil){
        //If response is empty, clear rooms
        // [self clearAllRooms];
        return;
    }
    
    NSMutableArray *chatRooms = [[NSMutableArray alloc] init];
    
    if ([chatRoom[@"chatRoom"] isKindOfClass:[NSArray class]]) {
        [chatRooms addObjectsFromArray:chatRoom[@"chatRoom"]];
    } else {
        [chatRooms addObject:chatRoom[@"chatRoom"]];
    }
    
    if (roomNameList.count > 0){
        [roomNameList removeAllObjects];
    }
    
    for (id room in chatRooms){
        [self saveRoomDetailsAndMessage:room offline:false];
    }
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - saveChatRoomDetailsAndMessage %@",error);
    }
    /*[self updateArchiveSyncData];
    
    if (chatRooms.count > 0 && !error) {
        NSDictionary * metadata = [chatRoom valueForKey:@"meta"];
        if (metadata) {
            NSString *lastResponseTime = [metadata valueForKey:@"responseTime"];
            [CMOUtils saveAllRoomsLastSyncTime:lastResponseTime];
            
            NSString *syncVersion = [metadata valueForKey:@"syncVersion"];
            if (syncVersion) {
                [CMOUtils saveDeviceSyncVersion:syncVersion];
            }
        }
        
        NSDictionary *appData = [chatRoom valueForKey:@"appData"];
        if (appData){
            [self processSyncData:appData];
        }
        
        if (appData[@"syncVersion"]){
            [CMOUtils saveDeviceSyncVersion:appData[@"syncVersion"]];
        }
        if (appData[@"syncDate"]){
            [CMOUtils saveDeviceSyncTime:appData[@"syncDate"]];
        }
    }*/
    
    //Process SMS Names from sync.
//    [self processSMSData:appData];
    
    //[self updateOutDatedRooms];
    //[self updateRoomsListArray:roomNameList];
}




- (void)updateOutDatedRooms{
//    if (roomNameList.count > 0){
//        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"NOT roomName IN %@", roomNameList];
//        NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
//        NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
//        fetchRequest.entity = messageEntity;
//        fetchRequest.predicate = predicate;
//        NSError *error = nil;
//        NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
//        for (CMORoomDetails *obj in results) {
//            obj.isRoomDeleted = true;
//            NSLog(@"CMORepositoryService::updateOutDatedRooms deleted Room = (%@)",obj.roomName);
//            //[self.managedObjectcontext deleteObject:obj];
//        }
//        if (![self.managedObjectcontext save:&error]) {
//            // handle error ...
//        }
//    }
}

- (void)processSyncData:(NSDictionary *)appData{
    NSData *d = [appData[@"data"] dataUsingEncoding:NSUTF8StringEncoding];
    id json = [NSJSONSerialization JSONObjectWithData:d options:0 error:nil];
    NSDictionary *data = json;
    if ([data.allKeys count] > 0){
        NSDictionary *rooms = data[@"rooms"];
        if ([[rooms allKeys] count] > 0){
            for (NSString *roomId in [rooms allKeys]){
                [self syncVisitedRoom:roomId readCount:[rooms[roomId] intValue]];
            }
        }
        
        
        NSArray *archivedRooms = data[@"archivedRooms"];
        if (archivedRooms.count > 0){
            NSArray *lArchiveArray = [CMOUtils allArchivedRoomsInfo];
            NSMutableArray *mutableArchivedArray = nil;
            if (lArchiveArray){
                mutableArchivedArray = [lArchiveArray mutableCopy];
            }
            else{
                mutableArchivedArray = [NSMutableArray new];
            }
            for (NSString *roomInfo in archivedRooms){
                NSArray *roomInfoArray = [roomInfo componentsSeparatedByString:@"|"];
                [self makeRoomArchived:roomInfoArray[0] unreadCount:[roomInfoArray[1] integerValue]];
                if (![mutableArchivedArray containsObject:roomInfo]){
                    [mutableArchivedArray addObject:roomInfo];
                }
            }
            [CMOUtils saveArchivedRoomSyncInfo:mutableArchivedArray];
        }
        
        NSArray *deletedRooms = data[@"deletedRooms"];
        if (deletedRooms.count > 0){
            for (NSString *roomName in deletedRooms){
                [self saveDeletedRoom:roomName];
            }
        }
    }
}

- (void)processSMSData:(NSDictionary *)appData{
    NSData *d = [appData[@"data"] dataUsingEncoding:NSUTF8StringEncoding];
    id json = [NSJSONSerialization JSONObjectWithData:d options:0 error:nil];
    NSDictionary *data = json;
    NSDictionary *smsRooms = data[SMS_USER_INFO];
    if ([[smsRooms allKeys] count] > 0){
        for (NSString *roomId in [smsRooms allKeys]){
            [self saveSmsusersToChatRoom:[smsRooms valueForKey:roomId] roomId:roomId];
        }
    }
}



- (void)saveSmsusersToChatRoom:(NSString *)users roomId:(NSString *)roomId{
    if (roomId && users){
        CMORoomDetails *room = [self fetchRoomInfo:roomId];
        if (!room)return;
        if (!room.roomProperty){
            room.roomProperty = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoomProperty" inManagedObjectContext:self.managedObjectcontext];
        }
        room.roomProperty.smsUsers = users;
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Room SMS - Property %@",error);
        }        
    }
}


- (void)saveGroupMember:(id)groups toRoom:(NSString *)roomId{
    if (roomId){
        CMORoomDetails *room = [self fetchRoomInfo:roomId];
        CMOMembersGroup *membersGroup = room.membersGroup;
        if (!membersGroup){
            membersGroup = [NSEntityDescription insertNewObjectForEntityForName:@"CMOMembersGroup" inManagedObjectContext:self.managedObjectcontext];
        }
        room.membersGroup = membersGroup;
        membersGroup.memberGroup = [self toGroupArray:groups];
        
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Room Members %@",error);
        }
    }
}

-(NSArray*)toGroupArray:(NSArray*)groups {
    NSMutableArray *grpArray = [[NSMutableArray alloc] init];
    for (id group in groups) {
        NSString *grpName = nil;
        //check group class as for fist time chat creation group is CMORosterGroup,otherwise a string
        if ([group isKindOfClass:[NSString class]]) {
            grpName = (NSString*)group;
        } else if ([group isKindOfClass:[CMORosterGroup class]]) {
            CMORosterGroup *grp = (CMORosterGroup*)group;
            grpName = grp.name;
        }
        [grpArray addObject:grpName];
    }
    return grpArray;
}

- (void)updateOfflineMessageStatus:(BOOL)isOffline roomId:(NSString *)roomId{
    if (roomId){
        CMORoomDetails *room = [self fetchRoomInfo:roomId];
        if (!room)return;
        if (!room.roomProperty){
            room.roomProperty = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoomProperty" inManagedObjectContext:self.managedObjectcontext];
        }
        room.roomProperty.isAnyMessageOffline = isOffline;
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - isAnyMessageOffline - Property %@",error);
        }
    }
}


#pragma mark - Save groups to Room Property
#pragma This will save groups as temperorary. When a group is added to chatroom (in server). Groups will be removed from `CMORoomProperty` table.

- (void)saveTempGroupsToRoomProperty:(NSMutableArray *)groups roomId:(NSString *)roomId{
    if (roomId){
        CMORoomDetails *room = [self fetchRoomInfo:roomId];
        if (!room)return;
        if (!room.roomProperty){
            room.roomProperty = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoomProperty" inManagedObjectContext:self.managedObjectcontext];
        }
        room.roomProperty.groups = groups;
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Room Temp Groups - Property %@",error);
        }
    }
}

- (void)removeTempGroupsFromRoomProperty:(NSString *)roomId{
    if (roomId){
        CMORoomDetails *room = [self fetchRoomInfo:roomId];
        if (!room)return;
        if (room.roomProperty){
            room.roomProperty.groups = [NSMutableArray new];
            NSError *error = nil;
            if (![_managedObjectcontext save:&error]){
                DDLogError(@"Failed to save - Room SMS - Property %@",error);
            }
        }
    }
}

- (void)saveReadMessageCountToRoom:(NSString *)roomId count:(int64_t)count{
    /*CMORoomDetails *roomDetails = [self fetchRoomInfo:roomId];
    if (roomDetails && roomDetails.readMessageCount < count) {
        roomDetails.readMessageCount = count;
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Visited Room %@",error);
        }
    }*/
}


#pragma mark Visited Rooms - Sync

- (void)saveVisitedRoom:(NSString *)roomName readCount:(int32_t)readCount{
    if (readCount == 0)return;
    
    NSInteger messageCount = [self fetchMessageCountForRooms:roomName];

    CMOVisitedRooms *visitedRoom = [self fetchVisitedRoom:roomName];
    //Don't update the db, if the messageCount < visitedRoom.readCount
    if (visitedRoom && messageCount <= visitedRoom.readCount){
        return;
    }
    if (!visitedRoom){
        visitedRoom = [NSEntityDescription insertNewObjectForEntityForName:@"CMOVisitedRooms" inManagedObjectContext:self.managedObjectcontext];
    }
    visitedRoom.roomName = roomName;
    visitedRoom.readCount = readCount;
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Visited Room %@",error);
    }
}

- (void)syncVisitedRoom:(NSString *)roomName readCount:(int32_t)readCount{
    
    NSInteger messageCount = [self fetchMessageCountForRooms:roomName];
    
    CMOVisitedRooms *visitedRoom = [self fetchVisitedRoom:roomName];
    //Don't update the db, if the messageCount < visitedRoom.readCount
    if (visitedRoom && messageCount > readCount){
        return;
    }
    if (!visitedRoom){
        visitedRoom = [NSEntityDescription insertNewObjectForEntityForName:@"CMOVisitedRooms" inManagedObjectContext:self.managedObjectcontext];
    }
    visitedRoom.roomName = roomName;
    visitedRoom.readCount = readCount;
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Visited Room %@",error);
    }
}


- (CMOVisitedRooms *)fetchVisitedRoom:(NSString *)roomName{
    NSFetchRequest *fetchRequest = [CMOVisitedRooms fetchRequest];
    NSEntityDescription *visitedRoom = [NSEntityDescription entityForName:@"CMOVisitedRooms" inManagedObjectContext:self.managedObjectcontext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomName == %@",roomName];
    fetchRequest.predicate = predicate;
    fetchRequest.entity = visitedRoom;
    fetchRequest.fetchBatchSize = 1;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results.count > 0 ? [results lastObject] : nil;
}

- (NSArray *)fetchAllVisitedRooms{
    NSFetchRequest *fetchRequest = [CMOVisitedRooms fetchRequest];
    NSEntityDescription *visitedRoom = [NSEntityDescription entityForName:@"CMOVisitedRooms" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = visitedRoom;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
}

- (void)deleteAllVisitedRooms{
    NSFetchRequest *fetchRequest = [CMOVisitedRooms fetchRequest];
    NSEntityDescription *visitedRoom = [NSEntityDescription entityForName:@"CMOVisitedRooms" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = visitedRoom;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (CMOVisitedRooms *vRoom in results){
        [self.managedObjectcontext deleteObject:vRoom];
    }

    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Delete Visited Rooms %@",error);
    }
}

#pragma mark Deleted Rooms

- (void)saveDeletedRoom:(NSString *)roomName{
    CMODeletedRooms *deletedRoom = [self fetchDeletedRooms:roomName];
    if (!deletedRoom){
        deletedRoom = [NSEntityDescription insertNewObjectForEntityForName:@"CMODeletedRooms" inManagedObjectContext:self.managedObjectcontext];
    }
    deletedRoom.roomName = roomName;
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Save Deleted Rooms %@",error);
    }
}

- (CMODeletedRooms *)fetchDeletedRooms:(NSString *)roomName{
    NSFetchRequest *fetchRequest = [CMODeletedRooms fetchRequest];
    
    NSEntityDescription *deletedRoom = [NSEntityDescription entityForName:@"CMODeletedRooms" inManagedObjectContext:self.managedObjectcontext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomName == %@",roomName];
    fetchRequest.predicate = predicate;
    fetchRequest.entity = deletedRoom;
    fetchRequest.fetchBatchSize = 1;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results.count > 0 ? [results lastObject] : nil;
}

- (NSArray *)fetchAllDeletedRooms{
    NSFetchRequest *fetchRequest = [CMODeletedRooms fetchRequest];
    NSEntityDescription *deletedRoom = [NSEntityDescription entityForName:@"CMODeletedRooms" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = deletedRoom;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
}

- (void)removeAllDeletedRooms{
    NSFetchRequest *fetchRequest = [CMODeletedRooms fetchRequest];
    NSEntityDescription *deletedRoom = [NSEntityDescription entityForName:@"CMODeletedRooms" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = deletedRoom;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (CMODeletedRooms *vRoom in results){
        [self.managedObjectcontext deleteObject:vRoom];
    }
    
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Remove Deleted Rooms %@",error);
    }
}


#pragma mark Upload Progress of Room

- (void)saveDocumentUploadStatusForRoom:(NSString *)roomId inprogress:(BOOL)status{
    //isUploadProgress
    CMORoomDetails *roomDetails = [self fetchRoomInfo:roomId];
    if (roomDetails){
        CMORoomProperty *roomProperty = roomDetails.roomProperty;
        if (!roomProperty){
            roomProperty = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoomProperty" inManagedObjectContext:self.managedObjectcontext];
        }
        roomProperty.isUploadProgress = status;
        roomDetails.roomProperty = roomProperty;
    }
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Room Property Upload Status %@",error);
    }
}

- (BOOL)documentUploadStatusOfRoom:(NSString *)roomId{
    BOOL uploadInProgress = false;
    CMORoomDetails *roomDetails = [self fetchRoomInfo:roomId];
    if (roomDetails){
        CMORoomProperty *roomProperty = roomDetails.roomProperty;
        if (roomProperty){
            uploadInProgress = roomProperty.isUploadProgress;
        }
    }
    return uploadInProgress;
}

- (void)updateDocumentUploadStatusOfAllRooms{
    NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
    NSEntityDescription *roomPropertyEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomProperty.isUploadProgress == true"];
    fetchRequest.predicate = predicate;
    NSString *relationshipKeyPath = @"roomProperty";
    NSArray *keyPaths = [NSArray arrayWithObject:relationshipKeyPath];
    [fetchRequest setRelationshipKeyPathsForPrefetching:keyPaths];
    fetchRequest.entity = roomPropertyEntity;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (CMORoomDetails *roomDetail in results){
        roomDetail.roomProperty.isUploadProgress = false;
    }
    NSError *saveError = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Room Property Upload Status %@",saveError);
    }
}


- (NSMutableArray *)toArray:(id)obj{
    if (!obj || [obj isEqual:[NSNull null]])return nil;
    NSMutableArray *array = nil;
    if ([obj isKindOfClass:[NSString class]]){
        array = [[NSMutableArray alloc]init];
        [array addObject:obj];
    }
    else{ //NSDictionary
        array = obj;
    }
    return array;
}


- (NSArray *)fetchOfflineChatRooms{
    NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
    NSEntityDescription *roomPropertyEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomProperty.isOffline == true"];
    fetchRequest.predicate = predicate;
    NSString *relationshipKeyPath = @"roomProperty";
    NSArray *keyPaths = [NSArray arrayWithObject:relationshipKeyPath];
    [fetchRequest setRelationshipKeyPathsForPrefetching:keyPaths];
    fetchRequest.entity = roomPropertyEntity;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
}

- (CMORoomDetails *)fetchRoomInfo:(NSString *)roomName{
    NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomName == %@",roomName];
    fetchRequest.predicate = predicate;
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    if (!results){
        return nil;
    }
    return [results lastObject];
}

- (void)updateRoomInfo:(NSString *)roomName withLastMessageDate:(NSDate*)date {
    /*CMORoomDetails *roomInfo = [self fetchRoomInfo:roomName];
    if (roomInfo && ((roomInfo.lastMsgDate == nil) ||([roomInfo.lastMsgDate compare:date] == NSOrderedAscending))) {
        roomInfo.lastMsgDate = date;
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - lastMessageDate Info in Room %@",error);
        }
    }*/
}

- (NSArray *)fetchChatRooms{
    //[self deleteOutDatedRooms];
    NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    
    NSError *error = nil;
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:NO];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
   
    return results;
}

- (NSArray *)fetchChatRoomsForArchivedStatus:(BOOL)archived {
    NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"archived == %d",archived];
    fetchRequest.predicate = predicate;
    
    NSError *error = nil;
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:NO];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    
    return results;
    
}

#pragma mark Hide/UnHide of Messages in Room
- (void)saveHideStatusOfRoom:(NSString *)roomId shouldHide:(BOOL)hide{
    if (!roomId)return;
    CMORoomDetails *roomDetails = [self fetchRoomInfo:roomId];
    CMORoomProperty *roomProperty = roomDetails.roomProperty;
    if (roomDetails){
        if (!roomProperty){
            roomProperty = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoomProperty" inManagedObjectContext:self.managedObjectcontext];
            roomDetails.roomProperty = roomProperty;
        }
        roomProperty.isChatHidden = hide;
        
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Room Property %@",error);
        }
    }
}

//This method return the hide/show status of the room for chairman.
- (BOOL)isRoomMessageHidden:(NSString *)roomId{
    if (!roomId)return NO;
    CMORoomDetails *roomDetails = [self fetchRoomInfo:roomId];
    if (roomDetails){
        CMORoomProperty *roomProperty = roomDetails.roomProperty;
        if (roomProperty){
            return roomProperty.isChatHidden;
        }
    }
    
    //Check later -  As we are already setting the roomProperty which will not be nil so we can remove below code.
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    id <CMORosterClient>rosterClient = [_coreComponents rosterService];
    CMORoster *roster = [rosterClient fetchRoster:owner.username];
    //For Chairman, he can always see the message.
    if ([roster.userPermission.chatInitiation integerValue] == 1){
        return NO;
    }
    else{
        return YES;
    }
}


- (NSInteger )fetchChatRoomCount{
    NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"isRoomDeleted == false"];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    
    NSError *error = nil;
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:NO];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSInteger count = [self.managedObjectcontext countForFetchRequest:fetchRequest error:&error];
    return count;
}


//Rooms contains active and inactive rooms. Inactive rooms are those where the current user is removed as a participant. But it will remain in the app till other user logs in.
- (NSArray *)getActiveRooms{
    NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"isRoomDeleted == %@",[NSNumber numberWithBool:false]];
    
    fetchRequest.predicate = predicate;
    NSError *error = nil;
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:NO];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    
    return results;
}


- (void)updateSLATime:(NSInteger)slaTime slaEnabled:(BOOL)slaEnabled slaClosed:(BOOL)slaClosed confidential:(BOOL)confidential OfRoom:(NSString *)roomName slaRemainingTime:(NSInteger)slaRemainingTime{
    CMORoomDetails *roomInfo = [self fetchRoomInfo:roomName];
    if (roomInfo){
//        roomInfo.slaRemainingTime = slaRemainingTime;
//        roomInfo.slaTime = slaTime;
//        roomInfo.slaEnabled = slaEnabled;
//        roomInfo.confidential = confidential;
//        roomInfo.slaClosed = slaClosed;
    }
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - SLA Info in Room %@",error);
    }
}


#pragma mark Delete OutDated Rooms
- (void)deleteOutDatedRooms{
    if (roomNameList.count > 0){
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"NOT roomName IN %@", roomNameList];
        NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
        NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
        fetchRequest.entity = messageEntity;
        fetchRequest.predicate = predicate;
        NSError *error = nil;
        NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
        for (CMORoomDetails *obj in results) {
            [self.managedObjectcontext deleteObject:obj];
        }
         if (![self.managedObjectcontext save:&error]) {
                // handle error ...
         }
    }
}


//- (NSArray *)getOutDatedRooms{
//    
//}

- (void)clearAllRooms{
    NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [_managedObjectcontext deleteObject:result];
    }
    if (results.count > 0){
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Clear Room Details");
        }
    }
    
}

- (void)clearAllRosters{
    NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [_managedObjectcontext deleteObject:result];
    }
    if (results.count > 0){
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Clear Rosters");
        }
    }
}

- (void)clearAllRosterGroup{
    NSFetchRequest *fetchRequest = [CMORosterGroup fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORosterGroup" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [_managedObjectcontext deleteObject:result];
    }
  
    if (results.count > 0){
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Clear Rosters");
        }
    }
}

- (void)clearArchivedRooms{
    NSFetchRequest *fetchRequest = [CMOArchivedRooms fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMOArchivedRooms" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (id result in results){
        [_managedObjectcontext deleteObject:result];
    }
  
    if (results.count > 0){
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - Clear Archived Rooms");
        }
    }
}

/*#pragma mark Filter Messages - Hide/UnHide Options

- (NSArray *)filterMessagesByVisibility:(BOOL)shouldShow{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
    
    NSString *predicateFormat = [NSString stringWithFormat:@"show == %d",shouldShow];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:predicateFormat];
    //xmppRoomStorage based on current room
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"XMPPRoomMessageCoreDataStorageObject" inManagedObjectContext:context];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
    return results.count > 0 ? results : nil;
}*/


#pragma mark Archive Message

- (void)makeRoomArchived:(NSString *)roomId unreadCount:(NSInteger)msgCount{
    CMOArchivedRooms *archivedRoom = [self fetchArchivedRoom:roomId];
    if (!archivedRoom){
        archivedRoom = [NSEntityDescription insertNewObjectForEntityForName:@"CMOArchivedRooms" inManagedObjectContext:self.managedObjectcontext];
    }
    archivedRoom.roomName = roomId;
    archivedRoom.messageCount = (int32_t)msgCount;
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Archived Rooms");
    }
    
}

- (void)makeRoomUnarchived:(NSString *)roomId{
    CMOArchivedRooms *archivedRoom = [self fetchArchivedRoom:roomId];
    if (archivedRoom){
        [self.managedObjectcontext deleteObject:archivedRoom];
    }
    
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Archived Rooms");
    }
    
}

- (BOOL)isRoomArchived:(NSString *)roomId{
    CMOArchivedRooms *archivedRoom = [self fetchArchivedRoom:roomId];
    if (archivedRoom){
        //room archived
        return YES;
    }
    return NO;
}



- (CMOArchivedRooms *)fetchArchivedRoom:(NSString *)roomName{
    NSFetchRequest *fetchRequest = [CMOArchivedRooms fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMOArchivedRooms" inManagedObjectContext:self.managedObjectcontext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomName == %@",roomName];
    fetchRequest.predicate = predicate;
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results.count > 0 ? [results lastObject] : nil;
}


- (NSArray *)fetchAllArchivedRooms{
    NSFetchRequest *fetchRequest = [CMOArchivedRooms fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMOArchivedRooms" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
}

#pragma mark Save Draft Messages

- (void)saveDraftMessage:(NSString *)message forRoom:(NSString *)roomId{
    //Delete previous draft message if any, even if it is empty text
    [self deleteDraftMessage:roomId];
    
    if (message.length == 0)return;
    
     CMODraftMessages *draftMessages = [NSEntityDescription insertNewObjectForEntityForName:@"CMODraftMessages" inManagedObjectContext:self.managedObjectcontext];
    draftMessages.body = message;
    draftMessages.roomName = roomId;
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Draft Messages");
    }
}

- (CMODraftMessages *)fetchDraftMessageForRoom:(NSString *)roomId{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomName == %@",roomId];
    NSFetchRequest *fetchRequest = [CMODraftMessages fetchRequest];
    fetchRequest.predicate = predicate;
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMODraftMessages" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results.count > 0 ?  [results lastObject] : nil;
}


- (void)deleteDraftMessage:(NSString *)roomId{
    CMODraftMessages *draftMessage = [self fetchDraftMessageForRoom:roomId];
    if (draftMessage){
        NSError *error = nil;
        [_managedObjectcontext deleteObject:draftMessage];
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to Delete - Draft Messages");
        }
    }
}

- (void)clearAllDraftMessages{
    NSFetchRequest *fetchRequest = [CMODraftMessages fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMODraftMessages" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    if (results.count > 0){
        for (CMODraftMessages *draft in results){
            [_managedObjectcontext deleteObject:draft];
        }
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to Delete - Draft Messages");
        }
    }
}

#pragma mark Message Read Status for Rooms
- (void)messageRead:(BOOL)didRead unreadCount:(int32_t)count forRoom:(NSString *)roomId{
    CMOMessageReadStatus *messageReadStatus = [self fetchMessageReadStatusForRoom:roomId];
    if (!messageReadStatus){
         messageReadStatus = [NSEntityDescription insertNewObjectForEntityForName:@"CMOMessageReadStatus" inManagedObjectContext:self.managedObjectcontext];
    }
    messageReadStatus.roomId = roomId;
    messageReadStatus.didReadMessage = didRead;
    messageReadStatus.unReadCount = count;
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to Save - Message Read Status %@",error);
    }
}


- (CMOMessageReadStatus *)fetchMessageReadStatusForRoom:(NSString *)roomId{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomId == %@",roomId];
    NSFetchRequest *fetchRequest = [CMOMessageReadStatus fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMOMessageReadStatus" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    fetchRequest.fetchBatchSize = 1;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    if (results.count > 0){
        return results.lastObject;
    }
    return nil;
}


- (NSArray *)fetchAllUnReadMessagesOfAllRooms{
    NSFetchRequest *fetchRequest = [CMOMessageReadStatus fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMOMessageReadStatus" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
}

- (BOOL)isMessageAlreadyExist:(XMPPRoomMessageCoreDataStorageObject *)message{
    id <CMOXMPPDelegate> xmppManager = [_coreComponents xmppManager];
    
    NSManagedObjectContext *moc = [(CMOXMPPManager *)xmppManager managedObjectContext_rooms];
    NSEntityDescription *messageEntity = [(CMOXMPPManager *)xmppManager roomEntity];
    
    NSString *streamBareJidStr = message.streamBareJidStr;//[[self myJIDForXMPPStream:xmppStream] bare];
    
    XMPPJID *messageJID = [message.message from];
    NSString *messageBody = [[message.message elementForName:@"body"] stringValue];
    NSDate *messageDate = [self toNSDate:[self toJsonDictionary:messageBody][@"date"]];
    
    
    NSDate *minMessageTimestamp = [messageDate dateByAddingTimeInterval:-60];
    NSDate *maxMessageTimestamp = [messageDate dateByAddingTimeInterval: 60];
    
    NSString *predicateFormat = @"    body == %@ "
    @"AND jidStr == %@ "
    @"AND streamBareJidStr == %@ AND messageDate BETWEEN {%@, %@}";
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:predicateFormat,
	                             messageBody, messageJID, streamBareJidStr,minMessageTimestamp,maxMessageTimestamp];
    
    /*   NSString *predicateFormat = @"    body == %@ "
     @"AND jidStr == %@ "
     @"AND streamBareJidStr == %@ "
     @"AND "
     @"(localTimestamp BETWEEN {%@, %@})";
     
     NSPredicate *predicate = [NSPredicate predicateWithFormat:predicateFormat,
     messageBody, messageJID, streamBareJidStr,minLocalTimestamp,maxLocalTimestamp];*/
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    [fetchRequest setEntity:messageEntity];
    [fetchRequest setPredicate:predicate];
    [fetchRequest setFetchLimit:1];
    
    NSError *error = nil;
    NSArray *results = [moc executeFetchRequest:fetchRequest error:&error];
    
    if (error)
    {
       // XMPPLogError(@"%@: %@ - Fetch error: %@", THIS_FILE, THIS_METHOD, error);
    }
    
    return ([results count] > 0);
    
}

- (NSDictionary *)toJsonDictionary:(NSString *)jsonString{
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    return json;
}

- (NSDate *)toNSDate:(NSString *)date{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = MESSAGE_TIME_FORMAT;
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    return [dateFormatter dateFromString:date];
}


#pragma mark Save User Roles and Permissions

- (void)saveUserRolesAndPermissions:(NSDictionary *)jsonDict{
    if (!jsonDict)return;
    CMORoster *roster = [self fetchRoster:jsonDict[@"userName"]];
    if (!roster){
        roster = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    }
    roster.username = jsonDict[@"userName"];
    roster.email = [CMOUtils isNull:jsonDict[@"email"]] ? nil : jsonDict[@"email"];
    roster.phoneNumber = [CMOUtils isNull:jsonDict[@"phoneNumber"]] ? nil : jsonDict[@"phoneNumber"];
    
    NSDictionary *roles = [CMOUtils isNull:jsonDict[@"role"]] ? nil : jsonDict[@"role"];
    if (!roles)return;
    
    CMOUserRoles *userRoles = [self fetchUserRole:roles[@"roleId"]];
    if (!userRoles){
        userRoles = [NSEntityDescription insertNewObjectForEntityForName:@"CMOUserRoles" inManagedObjectContext:self.managedObjectcontext];
    }
    userRoles.roleId = [CMOUtils isNull:roles[@"roleId"]] ? 0 : [roles[@"roleId"] integerValue];
    userRoles.roleName = [CMOUtils isNull:roles[@"roleName"]] ? nil : roles[@"roleName"];
    
    NSDictionary *permissions = [CMOUtils isNull:roles[@"permission"]] ? nil : roles[@"permission"];
    if (!permissions)return;
    
    CMOUserPermissions *userPermissions = [self fetchUserPermissions:permissions[@"permissionId"]];
    if (!userPermissions){
         userPermissions = [NSEntityDescription insertNewObjectForEntityForName:@"CMOUserPermissions" inManagedObjectContext:self.managedObjectcontext];
    }
    userPermissions.permissionId = [CMOUtils isNull:permissions[@"permissionId"]] ? 0 : [permissions[@"permissionId"] integerValue];
    userPermissions.chatInitiation = [CMOUtils isNull:permissions[@"chatinitiation"]] ? nil : permissions[@"chatinitiation"];
    userPermissions.addRecipientInAnOngoingChat = [CMOUtils isNull:permissions[@"addrecpttoongoingchat"]] ? nil : permissions[@"addrecpttoongoingchat"];
    
    userPermissions.canSetSlaTime = [CMOUtils isNull:permissions[@"cansetslatime"]] ? nil : permissions[@"cansetslatime"];
    userPermissions.canSetConfidentiality = [CMOUtils isNull:permissions[@"cansetconfidentiality"]] ? nil : permissions[@"cansetconfidentiality"];
    
    userPermissions.canDeleteRecipients = [CMOUtils isNull:permissions[@"candeleterecipients"]] ? nil : permissions[@"candeleterecipients"];
    
    userPermissions.conversationHistoryAvailable = [CMOUtils isNull:permissions[@"convhistoryavailbl"]] ? nil : permissions[@"convhistoryavailbl"];
    
    userPermissions.canConfigureReminderTimeAndFrequency = [CMOUtils isNull:permissions[@"configremindrtimenfreq"]] ? nil : permissions[@"configremindrtimenfreq"];
    
    userPermissions.canBlockAndProvideAccessToUsers = [CMOUtils isNull:permissions[@"blockandprovidacctouser"]] ? nil : permissions[@"blockandprovidacctouser"];
    
    userPermissions.canDeleteUsers = [CMOUtils isNull:permissions[@"candeleteusers"]] ? nil : permissions[@"candeleteusers"];
    
    userPermissions.canCreateGroups = [CMOUtils isNull:permissions[@"cancreategroups"]] ? nil : permissions[@"cancreategroups"];//permissions[@"canCreateGroups"];
    
    roster.userRoles = userRoles;
    roster.userPermission = userPermissions;
    
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - User Roles & Permissions");
    }
}

- (CMOUserRoles *)fetchUserRole:(NSString *)roleId{
    if (!roleId)return nil;
    NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMOUserRoles" inManagedObjectContext:self.managedObjectcontext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roleId == %@",roleId];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results.count > 0 ? [results lastObject] : nil;
}


- (CMOUserPermissions *)fetchUserPermissions:(NSString *)permissionId{
    if (!permissionId)return nil;
    NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMOUserPermissions" inManagedObjectContext:self.managedObjectcontext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"permissionId == %@",permissionId];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results.count > 0 ? [results lastObject] : nil;
}

#pragma mark Save Users/Rosters

- (void)saveCurrentUserPhoneNumber:(NSString *)phoneNumber
{
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *loggedInUser = [userClient user];
    
    CMORoster *roster = [self fetchRoster:loggedInUser.username];
    if (!roster){
        roster = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    }
    roster.phoneNumber = phoneNumber;
    
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Save Rosters %@",error);
    }
}

#pragma mark Save Users/Rosters

- (void)saveUsers:(NSDictionary *)jsonDict{
    
    id users = jsonDict[@"user"];
    NSMutableArray *array = [[NSMutableArray alloc]init];
    if ([users isKindOfClass:[NSArray class]]){
        [array addObjectsFromArray:users];
    }
    else{
        [array addObject:users];
    }
    
    id <CMOUserClient>client = [_coreComponents userService];
    
    for (id userDict in array){
        NSString *userName = userDict[@"username"];
        if (![usersList containsObject:userName]){
             [usersList addObject:userName];
        }
        CMORoster *roster = [self fetchRoster:userName];
        if (!roster){
            roster = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
        }
        roster.username = userDict[@"username"];
        roster.name = userDict[@"name"];
        roster.email = userDict[@"email"];
        roster.properties = userDict[@"properties"];
        
        CMOUser *vCardUser = [client fetchUservCard:roster.username];
        roster.userType = vCardUser.street;//[vCardUser.street isEqualToString:@"damac321"] ? EXISTINGUSER : vCardUser.street;
        //DDLogInfo(@"User Name is %@ and Name is %@",roster.username,roster.name);
        roster.isSMSUser = [self isSMSGroupMember:roster.username] || [self isSMS2GroupMember:roster.username];
        roster.smsGroupType = [NSNumber numberWithInteger:[self SMSGroupType:roster.username]];
        
        //roster.isSMSUser = [self isSMSGroupMember:roster.username];
    }
    // should be called after usersList is updated
    // [self deleteOutDatedRosters];
    
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Save Rosters");
    }
}



- (void)saveGroups:(NSDictionary *)jsonDict{
    if (jsonDict.allKeys.count <= 0)return;
    id groups = jsonDict[@"group"];
    if (!groups)return;
    
    NSMutableArray *array = [[NSMutableArray alloc]init];
    if ([groups isKindOfClass:[NSArray class]]){
        [array addObjectsFromArray:groups];
    }
    else{
        [array addObject:groups];
    }
    
    for (id groupDict in array){
        NSString *groupName = [groupDict objectForKey:@"name"];
        if (![groupsList containsObject:groupName]) {
            [groupsList addObject:groupName];
        }
        
        CMORosterGroup *roster = [self fetchGroupRoster:groupName];
        if (!roster) {
            roster = [NSEntityDescription insertNewObjectForEntityForName:@"CMORosterGroup" inManagedObjectContext:self.managedObjectcontext];
        }
        roster.name = groupDict[@"name"];
        roster.grpDescription = groupDict[@"description"];
    }
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Save Rosters : saveGroups");
    }

}

- (void)saveGroupsMembers:(NSDictionary *)jsonDict {
    id members = jsonDict[@"members"];
    if ([members isEqual:[NSNull null]]) {
        return;
    }
    id member = members[@"member"];
    
    NSMutableArray *array = [[NSMutableArray alloc]init];
    if ([member isKindOfClass:[NSArray class]]){
        [array addObjectsFromArray:member];
    }
    else{
        [array addObject:member];
    }
    
    NSMutableArray *resArray = [[NSMutableArray alloc]init];
    for (NSString* memberJid in array) {
        NSString* bareID = [memberJid componentsSeparatedByString:@"@"][0];
        [resArray addObject:bareID];
    }
    //get roster group for jsonDict[@"name"]
    //add members to it
    
    NSString * groupName = jsonDict[@"name"];
    CMORosterGroup *roster = [self fetchGroupRoster:groupName];
    if (!roster) {
        roster = [NSEntityDescription insertNewObjectForEntityForName:@"CMORosterGroup" inManagedObjectContext:self.managedObjectcontext];
    }
    roster.name = groupName;

    CMOGroupMembers *membersGroup = roster.grpMembers;
    if (!membersGroup) {
        membersGroup = [NSEntityDescription insertNewObjectForEntityForName:@"CMOGroupMembers" inManagedObjectContext:self.managedObjectcontext];
        roster.grpMembers = membersGroup;
    }
    
    membersGroup.members = resArray;

    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Save Rosters : saveGroups");
    }
    
}

- (NSArray*)fetchMembersForGroup:(NSString*)groupName {
    CMORosterGroup *roster = [self fetchGroupRoster:groupName];
    if (!roster) {
        return nil;
    }
    
    CMOGroupMembers *grpMembers = roster.grpMembers;
    if (!grpMembers) {
        return nil;
    }
    return grpMembers.members;
}


/*- (void)saveFailedGroups:(NSString *)groupName{
    
}*/

- (CMORoster *)fetchRosterForNicname:(NSString *)nicname{
    NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"nicname contains [cd] %@",nicname];
    fetchRequest.predicate = predicate;
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    if (!results){
        return nil;
    }
    return [results lastObject];
}

- (CMORoster *)fetchRoster:(NSString *)userName{
    
    @try {
        NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
        NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"username == %@",userName];
        fetchRequest.predicate = predicate;
        fetchRequest.entity = messageEntity;
        NSError *error = nil;
        NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
        if (results.count == 0){
            return nil;
        }
        return [results lastObject];
    } @catch (NSException *exception) {
        NSLog(@"=============NSException=========: %@, %@", exception, userName);
    } @finally {
        
    }
}

- (CMORosterGroup *)fetchGroupRoster:(NSString *)groupName {
    //call outdated roster
    NSFetchRequest *fetchRequest = [CMORosterGroup fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORosterGroup" inManagedObjectContext:self.managedObjectcontext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@",groupName];
    fetchRequest.predicate = predicate;
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    if (!results){
        return nil;
    }
    return [results lastObject];
}


- (NSArray *)fetchAllRosters{
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    
    NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    //skip logged in user
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"username != %@",owner.username];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
}

- (NSArray *)fetchAllRostersIncludingLoggedInUser {
    NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
    
}

- (NSArray *)fetchAllGroupRosters {
    NSFetchRequest *fetchRequest = [CMORosterGroup fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORosterGroup" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity =messageEntity;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
}

/*
- (NSArray *)fetchCurrentUserRosters{
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    
    NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    //skip logged in user
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"username == %@",owner.username];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    return results;
}
*/




#pragma mark Delete OutDated Roster/User
- (void)deleteOutDatedRosters{
    if (usersList.count > 0){
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"NOT username IN %@", usersList];
        NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
        NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
        fetchRequest.entity = messageEntity;
        fetchRequest.predicate = predicate;
        NSError *error = nil;
        NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
        for (CMORoster *obj in results) {
            [self.managedObjectcontext deleteObject:obj];
        }
        if (![self.managedObjectcontext save:&error]) {
            // handle error ...
        }
        
    }
}

/*
 NSManagedObjectContext *context = [xmppManager managedObjectContext_rooms];
 
 //xmppRoomStorage based on current room
 NSEntityDescription *messageEntity = [NSEntityDescription entityForName:[xmppManager.xmppRoomStorage messageEntityName] inManagedObjectContext:context];
 fetchRequest.entity = messageEntity;
 NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"localTimestamp" ascending:YES];
 fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
 NSError *error = nil;
 NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
 if (error){
 DDLogError(@"Error while fetching Message Archive %@, %@, %@",error,THIS_FILE,THIS_METHOD);
 }
 return results;
 */

- (NSArray *)fetchAllRostersFromXMPPRoster{

    //NSPredicate *predicate = [NSPredicate predicateWithFormat:@"jidStr != %@",[NSString stringWithFormat:@"%@@%@",owner.username,self.serverName]];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    id <CMOXMPPDelegate> xmppManager = [_coreComponents xmppManager];
    NSManagedObjectContext *context = [(CMOXMPPManager *)xmppManager managedObjectContext_roster];
    NSEntityDescription *rosterEntity = [NSEntityDescription entityForName:@"XMPPUserCoreDataStorageObject" inManagedObjectContext:context];
    fetchRequest.entity = rosterEntity;
    //fetchRequest.predicate = predicate;
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
    if (error){
        DDLogError(@"Error while fetching Coredata %@, %@, %@",error,THIS_FILE,THIS_METHOD);
    }
    return results;
}

//This will return the rosters based on the predicate passed
- (NSArray *)fetchRostersWithPredicate:(NSPredicate *)predicate{
    NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
    NSEntityDescription *rosterEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = rosterEntity;
    if (predicate){
        fetchRequest.predicate = predicate;
    }
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    
    if (error){
        DDLogError(@"Error while fetching rosters %@, %@, %@",error,THIS_FILE,THIS_METHOD);
    }
    return results;
}

#pragma mark Filter Message by SMSUsers

- (NSArray *)filterRoomsbySMSUser:(NSString *)userName{

    NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];

    NSEntityDescription *roomEntity = [NSEntityDescription entityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = roomEntity;
    
    NSString *relationshipKeyPath = @"roomProperty";
    NSArray *keyPaths = [NSArray arrayWithObject:relationshipKeyPath];
    [fetchRequest setRelationshipKeyPathsForPrefetching:keyPaths];

    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomProperty.smsUsers CONTAINS[cd] %@",userName];
    fetchRequest.predicate = predicate;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    
    if (error){
        DDLogError(@"Error while fetching Coredata %@, %@, %@",error,THIS_FILE,THIS_METHOD);
    }
    return results;
}

#pragma mark Filter Non Rosters from All Users

/**
 @brief: This function will return the list of rosters which has subscription type of "from", "to", "none".
Note: It will not return rosters having subscription type "both", because the current user is already subscribed. So no need to send the addRoster request again.
 
 **/
- (NSArray *)filterRostersFromXMPPRoster{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    id <CMOXMPPDelegate> xmppManager = [_coreComponents xmppManager];
    NSManagedObjectContext *context = [(CMOXMPPManager *)xmppManager managedObjectContext_roster];
    
    //NSPredicate *predicate = [NSPredicate predicateWithFormat:@"subscription != 'both'"];
    
    NSEntityDescription *rosterEntity = [NSEntityDescription entityForName:@"XMPPUserCoreDataStorageObject" inManagedObjectContext:context];
    fetchRequest.entity = rosterEntity;
   // fetchRequest.predicate = predicate;
    
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
    if (error){
        DDLogError(@"Error while fetching Message Archive %@, %@, %@",error,THIS_FILE,THIS_METHOD);
    }
    return results;
}

- (NSArray *)filterNonRostersfromAllUser{
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    //NSArray *users = [self fetchAllRosters];
    NSArray *rosters = [self fetchAllRostersFromXMPPRoster];
    NSMutableArray *rosterUserNameArray = [[NSMutableArray alloc]init];
    for (XMPPUserCoreDataStorageObject *user in rosters){
        [rosterUserNameArray addObject:[user.jid user]];
    }
    //Add logged in user. he shouldn't be returned in this list
    [rosterUserNameArray addObject:owner.username];
    NSError *error = nil;
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"NOT username IN %@", rosterUserNameArray];
    
    NSEntityDescription *userEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = userEntity;
    fetchRequest.predicate = predicate;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    
    /*NSError *saveError = nil;
    for (CMORoster *cmoroster in results){
        XMPPRosterCoreDataStorage *xmppRoster = [self fetchXMPPRoster:cmoroster.username];
        if(xmppRoster){
            cmoroster.subscription = [xmppRoster valueForKey:@"subscription"];
            if (![self.managedObjectcontext save:&saveError]) {
                // handle error ...
                DDLogError(@"Save Error %@",saveError);
            }
        }
    }*/
    
    if (error){
        DDLogError(@"Error while filtering Rosters %@, %@, %@",error,THIS_FILE,THIS_METHOD);
    }
    return results;
}

//Private method
- (XMPPRosterCoreDataStorage *)fetchXMPPRoster:(NSString *)userName{
    NSError *error = nil;
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"jidStr == %@", [NSString stringWithFormat:@"%@@%@",userName,self.serverName]];
    id <CMOXMPPDelegate> xmppDelegate = [_coreComponents xmppManager];
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)xmppDelegate;
    NSManagedObjectContext *context = [xmppManager managedObjectContext_roster];

    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *userEntity = [NSEntityDescription entityForName:@"XMPPUserCoreDataStorageObject" inManagedObjectContext:context];
    fetchRequest.entity = userEntity;
    fetchRequest.predicate = predicate;
    NSArray *results = [context executeFetchRequest:fetchRequest error:&error];
    return results.count > 0 ? [results lastObject] : nil;
}



- (void)clearAllUnReadMessages{
    NSFetchRequest *fetchRequest = [CMOMessageReadStatus fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMOMessageReadStatus" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    NSError *error = nil;
    NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    if (results.count > 0){
        for (CMOMessageReadStatus *messageReadStatus in results){
            [_managedObjectcontext deleteObject:messageReadStatus];
        }
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to Delete - UnRead Messages");
        }
    }
}


#pragma mark --
#pragma mark Get Phone book contacts

- (void)savePeopleInAddressBook:(ABAddressBookRef)addressBook
{
    NSArray *allPeople = CFBridgingRelease(ABAddressBookCopyArrayOfAllPeople(addressBook));
    NSInteger numberOfPeople = [allPeople count];
    
    for (NSInteger i = 0; i < numberOfPeople; i++) {
        ABRecordRef person = (__bridge ABRecordRef)allPeople[i];
        
        NSString *firstName = CFBridgingRelease(ABRecordCopyValue(person, kABPersonFirstNameProperty));
        NSString *lastName  = CFBridgingRelease(ABRecordCopyValue(person, kABPersonLastNameProperty));
        
        NSString *userName = [NSString stringWithFormat:@"%@ %@", firstName ? firstName : @"", lastName ? lastName: @""];
        
        ABMultiValueRef phoneNumbers = ABRecordCopyValue(person, kABPersonPhoneProperty);
        
        CFIndex numberOfPhoneNumbers = ABMultiValueGetCount(phoneNumbers);
        if (numberOfPhoneNumbers > 0)
        {
            CMORoster *roster = [self fetchRoster:userName];
            if (!roster && ![self isPhoneNumberAlreadyExist:CFBridgingRelease(ABMultiValueCopyValueAtIndex(phoneNumbers, 0))]){
                roster = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
                roster.username = userName;
                roster.phoneNumber = CFBridgingRelease(ABMultiValueCopyValueAtIndex(phoneNumbers, 0));
                roster.name = userName;
                roster.email = @"";
                roster.properties = [[NSDictionary alloc]init];
                roster.isPhoneContact = YES;
            }
            else if(roster && ![roster.phoneNumber isEqualToString:CFBridgingRelease(ABMultiValueCopyValueAtIndex(phoneNumbers, 0))]){
                roster.phoneNumber = CFBridgingRelease(ABMultiValueCopyValueAtIndex(phoneNumbers, 0));
            }
            
            if (roster && ![usersList containsObject:userName]){
                [usersList addObject:userName];
            }
        }
        CFRelease(phoneNumbers);
    }
    
    [self deleteOutDatedRosters];
    
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Save Rosters");
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter]postNotificationName:RELOAD_CONTACT_NOTIFICATION object:nil];
    });
}

- (BOOL) isPhoneNumberAlreadyExist:(NSString *)phoneNumber{
    
    @try {
        NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
        NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
        //skip logged in user
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"phoneNumber==%@ AND isPhoneContact==true",phoneNumber];
        fetchRequest.entity = messageEntity;
        fetchRequest.predicate = predicate;
        NSError *error = nil;
        NSArray *results = [_managedObjectcontext executeFetchRequest:fetchRequest error:&error];
        if (!error && results.count > 0) {
            return true;
        }
        return false;
    } @catch (NSException *exception) {
        NSLog(@"********NSException********: %@, %@", exception, phoneNumber);
    } @finally {
        
    }
}

- (BOOL) isSMSGroupMember:(NSString *)username{
    
    NSArray *groupArray = [self fetchMembersForGroup:CMONonAppUsersGroup];
    
    if ([groupArray containsObject:username]) {
        return true;
    }
    return false;
}


- (BOOL) isSMS2GroupMember:(NSString *)username{
    
    NSArray *groupArray = [self fetchMembersForGroup:CMONonAppSecUsersGroups];
    if ([groupArray containsObject:username]) {
        return true;
    }
    return false;
}

- (SMSTYPE)SMSGroupType:(NSString *)username{
    SMSTYPE smsType = SMSTYPENONE;
    BOOL isSMS1 = [self isSMSGroupMember:username];
    BOOL isSMS2 = [self isSMS2GroupMember:username];
    
    if (isSMS1 && isSMS2){
        smsType = SMSTYPEBOTH;
    }
    else if (isSMS1){
        smsType = SMSTYPEGROUP1;
    }
    else if (isSMS2){
        smsType = SMSTYPEGROUP2;
    }
    else{
        smsType = SMSTYPENONE;
    }
    return smsType;
}



#pragma mark --
#pragma mark Exchange server

- (void)saveExchangeServerUsers:(NSDictionary *)jsonDict{
    id users = jsonDict[@"data"];
    NSMutableArray *array = [[NSMutableArray alloc]init];
    if ([users isKindOfClass:[NSArray class]]){
        [array addObjectsFromArray:users];
    }
    else{
        [array addObject:users];
    }
    
    for (id userDict in array){
        NSString *userName = userDict[@"displayName"];
        NSString *exchangeID = userDict[@"id"];
        NSString *companyName = userDict[@"companyName"];
        
        if ((!userDict[@"businessPhone"] || [userDict[@"businessPhone"] isEqual:[NSNull null]]) && (!userDict[@"mobilePhone"] || [userDict[@"mobilePhone"] isEqual:[NSNull null]])) {
            continue;
        }
        
        CMORoster *roster = [self fetchRosterWithExchangeID:exchangeID];
        
        if (companyName && ![companyName isEqual:[NSNull null]] && [companyName localizedCaseInsensitiveContainsString:COMPANY_NAME]) {
            if (roster) {
                [self removeDamacUserFromExchange:exchangeID];
            }
            continue;
        }
        
        if (![usersList containsObject:userName]){
            [usersList addObject:userName];
        }
        
        if (!roster){
            roster = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
        }
        roster.username = userDict[@"displayName"];
        roster.name = userDict[@"displayName"];
        roster.exchangeID = userDict[@"id"];
        DDLogInfo(@"Roster UserName is %@",roster.username);
        
        if (userDict[@"businessPhone"] && ![userDict[@"businessPhone"] isEqual:[NSNull null]]) {
            roster.phoneNumber = userDict[@"businessPhone"];
        }
        else if (userDict[@"mobilePhone"] && ![userDict[@"mobilePhone"] isEqual:[NSNull null]])
        {
            roster.phoneNumber = userDict[@"mobilePhone"];
        }
        if (companyName && ![companyName isEqual:[NSNull null]]) {
            roster.companyName = companyName;
        }
        
        roster.isFromExchange = true;
    }
    
    NSArray *deleteUsersList = jsonDict[@"deletedContacts"];
    
    if(deleteUsersList && deleteUsersList.count > 0)
    {
//should be called after usersList is updated
        [self deleteRosterWithExchangeID: deleteUsersList];
    }
    
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Save Rosters");
    }
    
    if (array.count > 0 && !error) {
        NSDictionary * metadata = [jsonDict valueForKey:@"meta"];
        if (metadata) {
            NSString *lastResponseTime = [[metadata valueForKey:@"responseTime"] stringValue];
            [CMOUtils saveExchangeContactsLastSyncTime:lastResponseTime];
        }
    }
}

- (CMORoster *)fetchRosterWithExchangeID:(NSString *)exchangeID{
    @try {
        NSFetchRequest *fetchRequest = [CMORoomDetails fetchRequest];
        NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"exchangeID == %@ AND isFromExchange==true",exchangeID];
        fetchRequest.predicate = predicate;
        fetchRequest.entity = messageEntity;
        NSError *error = nil;
        NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
        if (results.count == 0){
            return nil;
        }
        return [results lastObject];
    } @catch (NSException *exception) {
        NSLog(@"=============NSException=========: %@, %@", exception, exchangeID);
    } @finally {
        
    }
}

- (void)deleteRosterWithExchangeID:(NSArray *)exchangeIDs{
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"exchangeID IN %@",exchangeIDs];
    NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
    NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
    fetchRequest.entity = messageEntity;
    fetchRequest.predicate = predicate;
    NSError *error = nil;
    NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
    for (CMORoster *obj in results) {
        [self.managedObjectcontext deleteObject:obj];
    }
    if (![self.managedObjectcontext save:&error]) {
        // handle error ...
    }
}

- (void) removeDamacUserFromExchange:(NSString *)exchangeID
{
    @try {
        if (exchangeID && ![exchangeID isEqualToString:@""]) {
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"exchangeID == %@", exchangeID];
            NSFetchRequest *fetchRequest = [CMORoster fetchRequest];
            NSEntityDescription *messageEntity = [NSEntityDescription entityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
            fetchRequest.entity = messageEntity;
            fetchRequest.predicate = predicate;
            NSError *error = nil;
            NSArray *results = [self.managedObjectcontext executeFetchRequest:fetchRequest error:&error];
            for (CMORoster *obj in results) {
                [self.managedObjectcontext deleteObject:obj];
            }
            if (![self.managedObjectcontext save:&error]) {
                // handle error ...
            }
        }
    } @catch (NSException *exception) {
        NSLog(@"***exception*** : %@", exception);
        
    } @finally {
        
    }
}

- (void)updateJoiningStatusOfUserInRoom:(CMORoomDetails *)roomDetail isJoined:(BOOL)isJoined{
    if (roomDetail) {
        roomDetail.roomProperty.isEligibleToJoin = isJoined;
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - updateJoiningStatusOfUserInRoom %@",error);
        }
    }
}

- (void)updateArchiveStatus:(BOOL)isArchived toRoom:(CMORoomDetails *)roomDetail{
    /*if (roomDetail && roomDetail.archived != isArchived) {
        roomDetail.archived = isArchived;
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - updateJoiningStatusOfUserInRoom %@",error);
        }
        [self updateArchiveSyncData];
        id <CMOChatClient>chatService = [_coreComponents chatService];
        [chatService updateSyncDataonSuccess:^(id result) {
            //DDLogInfo(@"Sync data upload : Success");
        } onFailure:^(NSError *error) {
            DDLogError(@"Sync data upload : Error(%@)",error);
        }];
    }*/
}

//This function is added to save a single room info. If there are multiple room information to be save (for eg)getAllRooms, that will be directly calling `saveRoomDetailsAndMessage` method and save it explicitly to avoid saving every record that has been inserted.
- (void)saveRoomInfo:(NSDictionary *)jsonDict offline:(BOOL)isOffline{
    [self saveRoomDetailsAndMessage:jsonDict offline:isOffline];
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Room Info %@",error);
    }
}

//Map Response from server
//isOffline - to indicate whether the create room request is stored or not. This case happens when the chatroom is successfully created, but the retrieving the chatroom fails. In this case, we need to store the room creation request to db.
- (void)saveRoomDetailsAndMessage:(NSDictionary *)jsonDict offline:(BOOL)isOffline{
    NSString *roomName = jsonDict[@"roomName"];
    if (![roomNameList containsObject:roomName] && roomName != nil){
        [roomNameList addObject:roomName];
    }
    
    //room is not updated.So doesn;t contain room details
    if (jsonDict[@"naturalName"] == nil) {
        return;
    }
    CMORoomDetails *roomInfo = [self fetchRoomInfo:roomName];
    if (!roomInfo){
        roomInfo = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoomDetails" inManagedObjectContext:self.managedObjectcontext];
    }
    roomInfo.roomName = jsonDict[@"roomName"];
    roomInfo.naturalName = jsonDict[@"naturalName"];
    roomInfo.roomDescription = jsonDict[@"description"];
    roomInfo.roomSubject = jsonDict[@"subject"];
    //roomInfo.readMessageCount = (jsonDict[@"readMessageCount"] && [jsonDict[@"readMessageCount"] integerValue] > roomInfo.readMessageCount) ? [jsonDict[@"readMessageCount"] integerValue]:roomInfo.readMessageCount;
    
    roomInfo.creationDate = isOffline ? [CMOUtils toSpecifiedFormatDate:[CMOUtils getServerTime] format:MESSAGE_TIME_FORMAT] : [CMOUtils toDate:jsonDict[@"creationDate"]]; //Date is empty. pls check
    roomInfo.modificationDate = isOffline ? [CMOUtils toSpecifiedFormatDate:[CMOUtils getServerTime] format:MESSAGE_TIME_FORMAT] : [CMOUtils toDate:jsonDict[@"modificationDate"]];
/*
#warning modify lastMsgDate
    if (roomInfo.lastMsgDate == nil) {
        roomInfo.lastMsgDate = roomInfo.modificationDate;
    }
*/
    roomInfo.maxUsers = jsonDict[@"maxUsers"];
    roomInfo.persistent = jsonDict[@"persistent"];
    roomInfo.publicRoom = jsonDict[@"publicRoom"];
    //roomInfo.deleted = [jsonDict[@"deleted"] boolValue];
    //roomInfo.archived = [jsonDict[@"archived"] boolValue];
    roomInfo.registrationEnabled = jsonDict[@"registrationEnabled"];
    roomInfo.canAnyoneDiscoverJID = jsonDict[@"canAnyoneDiscoverJID"];
    roomInfo.canOccupantsChangeSubject = jsonDict[@"canOccupantsChangeSubject"];
    roomInfo.canOccupantsInvite = jsonDict[@"canOccupantsInvite"];
    roomInfo.canChangeNickname = jsonDict[@"canChangeNickname"];
    roomInfo.logEnabled = jsonDict[@"logEnabled"];
    roomInfo.loginRestrictedToNickname = jsonDict[@"loginRestrictedToNickname"];
    roomInfo.membersOnly = jsonDict[@"membersOnly"];
    roomInfo.moderated = jsonDict[@"moderated"];
    //roomInfo.isRoomDeleted = false;
    CMOBroadcastPresenceRoles *broadcastPresenceRoles = roomInfo.broadcastPresence;
    if (!broadcastPresenceRoles){
        broadcastPresenceRoles = [NSEntityDescription insertNewObjectForEntityForName:@"CMOBroadcastPresenceRoles" inManagedObjectContext:self.managedObjectcontext];
        roomInfo.broadcastPresence = broadcastPresenceRoles;
    }
    broadcastPresenceRoles.broadcastPresenceRole = jsonDict[@"broadcastPresenceRoles"];
    
    CMOOwners *owners = roomInfo.owners;
    if (!owners){
        owners = [NSEntityDescription insertNewObjectForEntityForName:@"CMOOwners" inManagedObjectContext:self.managedObjectcontext];
        roomInfo.owners = owners;
    }
    owners.owner = [self toArray:[jsonDict[@"owners"] valueForKey:@"owner"]];
    NSMutableArray *ownerArray = (NSMutableArray*)(owners.owner);
    roomInfo.roomOwner = [ownerArray[0] componentsSeparatedByString:@"@"][0];

    CMOAdmins *admins = roomInfo.admins;
    if (!admins){
        admins = [NSEntityDescription insertNewObjectForEntityForName:@"CMOAdmins" inManagedObjectContext:self.managedObjectcontext];
        roomInfo.admins = admins;
    }
    admins.admins = [self toArray:[jsonDict[@"admins"] valueForKey:@"admin"]];
    
    CMOMembers *members = roomInfo.members;
    if (!members){
        members = [NSEntityDescription insertNewObjectForEntityForName:@"CMOMembers" inManagedObjectContext:self.managedObjectcontext];
    }
    roomInfo.members = members;
    members.members = [self toArray:[jsonDict[@"members"] valueForKey:@"member"]];
    
    
    CMOMembersGroup *membersGroup = roomInfo.membersGroup;
    if (!membersGroup){
        membersGroup = [NSEntityDescription insertNewObjectForEntityForName:@"CMOMembersGroup" inManagedObjectContext:self.managedObjectcontext];
    }
    roomInfo.membersGroup = membersGroup;
    membersGroup.memberGroup = [self toArray:[jsonDict[@"memberGroups"] valueForKey:@"memberGroup"]];
    
    /*CMORoomProperty *roomProperty = roomInfo.roomProperty;
    if (!roomProperty){
        roomProperty = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoomProperty" inManagedObjectContext:self.managedObjectcontext];
        
        id <CMOUserClient>userClient = [_coreComponents userService];
        CMOUser *owner = [userClient user];
        CMORoster *roster = [self fetchRoster:owner.username];
        //For Chairman, he can always see the message.
        if ([roster.userPermission.chatInitiation integerValue] == 1){
            roomProperty.isChatHidden = NO;
        }
        else{
            roomProperty.isChatHidden = YES;
        }
    }
    roomProperty.isOffline = isOffline;
    roomInfo.roomProperty = roomProperty;*/
    /* CMOMembersGroup *membersGroup = roomInfo.membersGroup;
     if (!membersGroup){
     membersGroup = [NSEntityDescription insertNewObjectForEntityForName:@"CMOMembersGroup" inManagedObjectContext:self.managedObjectcontext];
     roomInfo.membersGroup = membersGroup;
     }
     membersGroup.memberGroup = [self toArray:[jsonDict[@"memberGroups"] valueForKey:@"memberGroups"]];*/
    
    /*NSDictionary *messageDetails = jsonDict[@"message"];
    if (messageDetails) {
        
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:[messageDetails[@"lastMsgTimestamp"] doubleValue]/1000];
        
        roomInfo.lastMsgDate = isOffline ? [CMOUtils toSpecifiedFormatDate:[CMOUtils getServerTime] format:MESSAGE_TIME_FORMAT] : [CMOUtils toDate:[CMOUtils dateToString:date]];
        
        roomInfo.slaClosed =  messageDetails[@"SLAClosed"]?[messageDetails[@"SLAClosed"] boolValue]:0;
        if (messageDetails[@"messageCount"]) {
            int64_t newTotalCount = [messageDetails[@"messageCount"] integerValue];
            if (roomInfo.totalMessageCount) {
                if (newTotalCount > roomInfo.totalMessageCount) {
                    roomInfo.totalMessageCount = newTotalCount;
                    if (roomInfo.archived) {
                        roomInfo.archived = false;
                        [self updateArchiveSyncData];
                    }
                }
            } else {
                //new room.totalMessageCount being set for first time.so don't unarchive on count change
                roomInfo.totalMessageCount = newTotalCount;
            }
        } else {
            roomInfo.totalMessageCount = 0;
        }
        
        NSDictionary *messageBody = messageDetails[@"message"];
        
        if (messageBody) {
            roomInfo.confidential = messageBody[@"confidential"]?[messageBody[@"confidential"] boolValue]:0;
            roomInfo.slaEnabled =  messageBody[@"slaFlag"]?[messageBody[@"slaFlag"] boolValue]:0;
            roomInfo.slaTime = messageBody[@"slaTime"]?[messageBody[@"slaTime"]integerValue]:0;
            if (messageBody[@"date"]){
                [self updateFirstMessageDate:[CMOUtils toSpecifiedFormatDate:messageBody[@"date"] format:MESSAGE_TIME_FORMAT] roomId:roomInfo.roomName];
            }
        }
    }*/
}

- (void)updateArchiveSyncData {
    //Update data both in archive and unarchive case.When lasr item is unarchived rooms count will be 0 and need to update list of archived items as 0
//    NSArray *rooms = [self fetchChatRoomsForArchivedStatus:true];
//    NSMutableArray *syncArchivedRoom = [NSMutableArray new];
//    if (rooms.count > 0){
//        for (CMORoomDetails *room in rooms){
//            [syncArchivedRoom addObject:[NSString stringWithFormat:@"%@|%ld",room.roomName,(long)room.readMessageCount]];
//        }
//    }
//    [CMOUtils saveArchivedRoomSyncInfo:syncArchivedRoom];
}


- (void)updateSLATime:(NSInteger)slaTime
         confidential:(BOOL)isConfidential
               roomId:(NSString *)roomId{
    
//    CMORoomDetails *roomDetails = [self fetchRoomInfo:roomId];
//    if (roomDetails){
//        roomDetails.slaTime = slaTime;
//        roomDetails.confidential = isConfidential;
//        NSError *error = nil;
//        if (![_managedObjectcontext save:&error]){
//            DDLogError(@"Failed to save - Room SLA Info %@",error);
//        }
//    }
}

- (void)updateFirstMessageDate:(NSDate *)date
                        roomId:(NSString *)roomId{
    CMORoomDetails *roomDetails = [self fetchRoomInfo:roomId];
    if (roomDetails && !roomDetails.roomProperty.firstMessageDate){
        CMORoomProperty *roomProperty = roomDetails.roomProperty;
        if (!roomProperty){
            roomProperty = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoomProperty" inManagedObjectContext:self.managedObjectcontext];
        }
        roomProperty.firstMessageDate = date;
        roomDetails.roomProperty = roomProperty;
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - First Message Date %@",error);
        }
    }
}

- (void)updateTotalMessageCount:(int64_t)messageCount ofRoom:(NSString *)roomId{
    /*CMORoomDetails *roomDetails = [self fetchRoomInfo:roomId];
    if (roomDetails && messageCount > roomDetails.totalMessageCount){
        roomDetails.totalMessageCount = messageCount;
        roomDetails.readMessageCount = messageCount;
        BOOL archiveNeedUpdate = false;
        if (roomDetails.archived) {
            roomDetails.archived = false;
            archiveNeedUpdate = true;
        }
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - updateTotalMessageCount %@",error);
        }
        if (archiveNeedUpdate) {
            [self updateArchiveSyncData];
            id <CMOChatClient>chatService = [_coreComponents chatService];
            [chatService updateSyncDataonSuccess:^(id result) {
                //DDLogInfo(@"Sync data upload : Success");
            } onFailure:^(NSError *error) {
                DDLogError(@"Sync data upload : Error(%@)",error);
            }];
        }
    }*/
}

- (void)saveUsersAndGroups:(NSDictionary *)jsonDict
{
    id users = jsonDict[@"user"];
    NSMutableArray *usersArray = [[NSMutableArray alloc]init];
    if ([users isKindOfClass:[NSArray class]]){
        [usersArray addObjectsFromArray:users];
    }
    else{
        [usersArray addObject:users];
    }
    if (usersArray.count > 0) {
        [self saveUsersIn:usersArray];
    }
    
    /*id groups = jsonDict[@"groups"];
    NSMutableArray *groupArray = [[NSMutableArray alloc]init];
    if ([groups isKindOfClass:[NSArray class]]){
        [groupArray addObjectsFromArray:groups];
    }
    else{
        [groupArray addObject:users];
    }
    
    if (groupArray.count > 0) {
        [self saveGroupsIn:groupArray];
    }*/
}

- (void)updateUserNicname:(NSString *)nicName forUser:(NSString*)userName
{
    CMORoster *roster = [self fetchRoster:[userName lowercaseString]];
    if (roster){
        roster.nicname = nicName;
        NSError *error = nil;
        if (![_managedObjectcontext save:&error]){
            DDLogError(@"Failed to save - updateUserNicname");
        }
    }
}

- (NSString*)getUsernameForNicname:(NSString *)nicname
{
    NSString *userName = nil;
    CMORoster *roster = [self fetchRosterForNicname:nicname];
    if (roster){
        userName = roster.username;
    }
    return userName;
}


- (void) saveUsersIn:(NSArray *)userList
{
    //int i = 0;
    id <CMOUserClient>client = [_coreComponents userService];
    for (id userDict in userList){
        NSString *userName = userDict[@"username"];
        
        if (![usersList containsObject:userName]){
            [usersList addObject:userName];
        }
        CMORoster *roster = [self fetchRoster:userName];
        if (!roster){
            roster = [NSEntityDescription insertNewObjectForEntityForName:@"CMORoster" inManagedObjectContext:self.managedObjectcontext];
        }
        roster.username = userDict[@"username"];
        roster.name = userDict[@"name"];
        roster.email = userDict[@"email"];
        roster.properties = userDict[@"properties"];
        
      /*  CMOUser *vCardUser = [client fetchUservCard:roster.username];
        roster.userType = vCardUser.street;//[vCardUser.street isEqualToString:@"damac321"] ? EXISTINGUSER : vCardUser.street;
        //DDLogInfo(@"User Name is %@ and Name is %@",roster.username,roster.name);
        roster.isSMSUser = [self isSMSGroupMember:roster.username] || [self isSMS2GroupMember:roster.username];
        roster.smsGroupType = [NSNumber numberWithInteger:[self SMSGroupType:roster.username]];
       */
        //id <CMOUserClient>userClient = [_coreComponents userService];
        //[userClient fetchUservCard:roster.username];
    }

    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Save Rosters %@",error);
    }
}


- (void)updatevCardDetailsToRoster:(CMOUser *)cmoUser{
    id <CMORepositoryClient>repoClient = [_coreComponents repositoryService];
    CMORoster *roster = [repoClient fetchRoster:[cmoUser.username lowercaseString]];
    roster.userType = cmoUser.street;
    
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Save Rosters %@",error);
    }
}


- (void)saveGroupsIn:(NSArray *)groupList{
    
    for (id groupDict in groupList){
        //Save groups
        NSString *groupName = [groupDict objectForKey:@"name"];
        if (![groupsList containsObject:groupName]) {
            [groupsList addObject:groupName];
        }
        
        CMORosterGroup *roster = [self fetchGroupRoster:groupName];
        if (!roster) {
            roster = [NSEntityDescription insertNewObjectForEntityForName:@"CMORosterGroup" inManagedObjectContext:self.managedObjectcontext];
        }
        roster.name = groupDict[@"name"];
        roster.grpDescription = groupDict[@"description"];
        
        //Get group members
        id members = groupDict[@"members"];
        if ([members isEqual:[NSNull null]]) {
            return;
        }
        id member = members[@"member"];
        
        NSMutableArray *array = [[NSMutableArray alloc]init];
        if ([member isKindOfClass:[NSArray class]]){
            [array addObjectsFromArray:member];
        }
        else{
            [array addObject:member];
        }
        
        NSMutableArray *resArray = [[NSMutableArray alloc]init];
        for (NSString* memberJid in array) {
            NSString* bareID = [memberJid componentsSeparatedByString:@"@"][0];
            [resArray addObject:bareID];
        }
        //Save Group members
        CMOGroupMembers *membersGroup = roster.grpMembers;
        if (!membersGroup) {
            membersGroup = [NSEntityDescription insertNewObjectForEntityForName:@"CMOGroupMembers" inManagedObjectContext:self.managedObjectcontext];
            roster.grpMembers = membersGroup;
        }
        
        membersGroup.members = resArray;
        
    }
    NSError *error = nil;
    if (![_managedObjectcontext save:&error]){
        DDLogError(@"Failed to save - Save Rosters : saveGroups");
    }
    
}


@end
