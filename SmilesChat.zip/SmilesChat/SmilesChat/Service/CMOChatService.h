//
//  CMOChatClient.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CMOChatClient.h"
#import "CMOXMPPClient.h"
#import "CMOCoreComponents.h"

@class CMOMessage;

@protocol CMOChatResponseDelegate <NSObject>

- (void)didReceiveMessage:(CMOMessage *)message;

@end

@interface CMOChatService : NSObject<CMOChatClient>{
    //id <CMOXMPPDelegate> delegate;
}
- (instancetype)initWithManager:(id <CMOXMPPDelegate>)manager;

@property (nonatomic, strong) id <CMOChatResponseDelegate>chatResponseDelegate;

@property (nonatomic, strong) NSString *domainName;

@property (nonatomic, strong) CMOCoreComponents *coreComponents;


@end
