//
//  AppDelegate.h
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CMOTabBarController.h"
//#import "CMOCoreComponents.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic)DDFileLogger *fileLogger;
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) CMOTabBarController *rootViewController;
//@property (strong, nonatomic) CMOCoreComponents *corecomponents;

#pragma mark iPad
@property (nonatomic, assign) BOOL isLogout;
@property (nonatomic, assign) BOOL isFromSetting;
@property (nonatomic, assign) BOOL isFromConversation;
@property (nonatomic, assign) BOOL isFromContacts;
@property (nonatomic, assign) BOOL isReloadSplitView;
@property (nonatomic, assign) BOOL isPortrait;
@property (nonatomic, assign) BOOL isConversationReload;
@property (nonatomic, assign) BOOL roomCreationInprogress;
@end

