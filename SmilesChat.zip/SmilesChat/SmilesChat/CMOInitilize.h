//
//  CMOInitilize.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CMOInitilize : NSObject

+ (void)initialize;

@end
