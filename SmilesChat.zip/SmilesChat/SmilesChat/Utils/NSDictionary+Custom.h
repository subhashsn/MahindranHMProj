//
//  NSDictionary+Custom.h
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Custom)

- (id)toJSON;

@end
