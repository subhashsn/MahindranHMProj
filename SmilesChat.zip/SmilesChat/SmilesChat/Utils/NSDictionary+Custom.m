//
//  NSDictionary+Custom.m
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "NSDictionary+Custom.h"

@implementation NSDictionary (Custom)

- (id)toJSON{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSString *jsonString = @"";
    if (! jsonData) {
        DDLogError(@"Got an error: %@", error);
    } else {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    
    return (error == nil ? jsonString : error);
}

@end
