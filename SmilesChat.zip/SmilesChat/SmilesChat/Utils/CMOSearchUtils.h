//
//  SearchUtils.h
//  CMOChat
//
//  Created by Amit Kumar on 06/04/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CMOChatPresentation;

@interface CMOSearchUtils : NSObject

- (instancetype)initWithModel:(CMOChatPresentation*)model;
- (NSArray*)roomsByNameText:(NSString*)searchText fromRooms:(NSArray*)roomList;
- (NSArray*)roomsContainingText:(NSString*)searchText fromRooms:(NSArray*)roomList;
@end
