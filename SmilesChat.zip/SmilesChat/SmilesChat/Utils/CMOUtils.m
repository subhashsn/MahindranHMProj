//
//  Utils.m
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOUtils.h"
#import "KeychainItemWrapper.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <ImageIO/ImageIO.h>
#import <AFNetworking/AFNetworking.h>
#import "CMOAppServerAPIClient.h"
#import "NSData+AES.h"
#import "AppDelegate.h"

#define SERVER_TIME @"serverTime"
#define CLIENT_TIME @"clientTime"
#define LOGGEDIN_USER @"lastLoggedinUser"
#define LOG_UPLOAD_TIME @"lastLogUploadTime"

@implementation CMOUtils

static BOOL netWorkInitialized = false;

//By setting app configurations in plist, we can change the app url dynamically when there is a change such as openfire rest api url change or version change

+ (NSDictionary *)appConfigurations{
    NSURL *plistURL;
//#ifdef DEBUG
    plistURL = [[NSBundle mainBundle] URLForResource:@"Configuration_UAT" withExtension:@"plist"];
//#else
 //   plistURL = [[NSBundle mainBundle] URLForResource:@"Configuration_Prod" withExtension:@"plist"];
//#endif
    
    NSDictionary *configurations = [NSDictionary dictionaryWithContentsOfURL:plistURL];
    return configurations;
}

+ (NSString *)serverName{
    return [CMOUtils appConfigurations][@"ofserver.name"];
}

+ (NSString *)domainName{
    return [CMOUtils appConfigurations][@"ofserver.domain"];
}

+ (NSInteger)serverPort{
    return [[CMOUtils appConfigurations][@"ofserver.port"] integerValue];
}

+ (BOOL)isConnectionSecured{
    return [[CMOUtils appConfigurations][@"secured"] boolValue];
}

+ (NSInteger)appServerPort{
    return [[CMOUtils appConfigurations][kAppServerPort] integerValue];
}


+ (NSString *)getUniqueString
{
    return [[NSUUID UUID] UUIDString];
}

//Sample: Fri, 25 Nov 2016 18:39:55 GMT
+ (NSDate *)GMTToLocal:(NSString *)date{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = SLA_DATE_FORMAT;
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    NSDate *timeStamp = [dateFormatter dateFromString:date];
    return timeStamp;
}


+ (NSDate *)toSpecifiedFormatDate:(NSString *)date format:(NSString *)format{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = format;
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]];
    NSDate *timeStamp = [dateFormatter dateFromString:date];
    return timeStamp;
}

+ (NSString *)toSpecifiedFormatString:(NSDate *)date format:(NSString *)format{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = format;
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]];
    NSString *timeStamp = [dateFormatter stringFromDate:date];
    return timeStamp;
}


//For converting room creation date
+ (NSDate *)toDate:(NSString *)date{
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]];
    [dateFormatter setDateFormat:DATE_FORMAT];
    NSDate *dateConverted = [dateFormatter dateFromString:date];
    return dateConverted;
}

+ (NSString *)dateToString:(NSDate *)date{
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]];
    [dateFormatter setDateFormat:DATE_FORMAT];
    NSString *dateConverted = [dateFormatter stringFromDate:date];
    return dateConverted;
}

//E, d MMM yyyy HH:mm
+ (NSString *)dateToStringForShowCrossedSLA:(NSDate *)date{
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]];
    [dateFormatter setDateFormat:SHOW_CROSSED_SLA_DATE_FORMAT];
    NSString *dateConverted = [dateFormatter stringFromDate:date];
    return dateConverted;
}


#pragma mark Calculate Time
+ (NSInteger)calculateMinsDifference:(NSDate *)date{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:MESSAGE_TIME_FORMAT];
    dateFormatter.timeZone = [NSTimeZone defaultTimeZone];
    NSString *dateString = [dateFormatter stringFromDate:date];
    NSDate *formattedDate = [dateFormatter dateFromString:dateString];
    
    NSString *serverTime = [CMOUtils getServerTime];
    NSDate *formattedServerDate = [dateFormatter dateFromString:serverTime];

    NSTimeInterval timeInterval = [formattedDate timeIntervalSinceDate:formattedServerDate];
    //Added 1 minute to time, because calculate minutes comes with the seconds, which will be stripped and lower boundary value will be taken. For eg, if you set 5 mins, the timer will start, if the time is 4 mins 50 seconds, then the total minutes will come a 4 min (i,e)1 min less. so we are explicity adding 1 min to avoid this.
    NSInteger minutes = timeInterval/60 + 1;
    return minutes;
}


//@"yyyy-MM-dd'T'HH:mm"

#pragma mark Document Type

+ (DocumentType)documentType:(NSString *)body{
    DocumentType docType;
    NSString *docName = [body mutableCopy];
    NSArray *docs = [docName componentsSeparatedByString:@"."];
    if (docs.count > 0){
        NSString *extension = [[docs lastObject] lowercaseString];
        if ([extension isEqualToString:@"png"] || [extension isEqualToString:@"jpg"] || [extension isEqualToString:@"jpeg"]){
            docType = DocumentTypeImage;
        }
        else if ([extension isEqualToString:@"mov"] || [extension isEqualToString:@"mp4"] || [extension isEqualToString:@"m4v"] || [extension isEqualToString:@"mpv"] || [extension isEqualToString:@"3gp"]){
            docType = DocumentTypeVideo;
        }
        else if ([extension isEqualToString:@"aac"] || [extension isEqualToString:@"mp3"] || [extension isEqualToString:@"m4a"] || [extension isEqualToString:@"au"]){
            docType = DocumentTypeAudio;
        }
        else if ([extension isEqualToString:@"pdf"] || [extension isEqualToString:@"docx"] || [extension isEqualToString:@"doc"] || [extension isEqualToString:@"xls"] || [extension isEqualToString:@"xlsx"] || [extension isEqualToString:@"ppt"] || [extension isEqualToString:@"pptx"]){
            docType = DocumentTypeMedia;
        }
        else if ([extension isEqualToString:@"loc"]){
            docType = DocumentTypeLocation;
        }
        else{
            docType = DocumentTypeUnknown;
        }
    }
    return docType;
}


+ (DocumentType)fileType:(NSURL *)url{
    DocumentType docType;
    CFStringRef fileExtension = (__bridge CFStringRef) [url pathExtension];
    CFStringRef fileUTI = UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, fileExtension, NULL);
    
    if (UTTypeConformsTo(fileUTI, kUTTypeImage)) docType = DocumentTypeImage;
    else if (UTTypeConformsTo(fileUTI, kUTTypeMovie)) docType = DocumentTypeVideo;
    else if (UTTypeConformsTo(fileUTI, kUTTypeText)) NSLog(@"It's text");
    
    CFRelease(fileUTI);
    return docType;
}

/*+ (BOOL)isFileExistAtPath:(NSString *)path{
    NSError *error;
    NSData *fileContents = [NSData dataWithContentsOfFile:path options:0 error:&error];
    return fileContents != nil;
}*/

+ (UIImage*)imageWithImage:(UIImage*)image
              scaledToSize:(CGSize)newSize
{
    UIGraphicsBeginImageContext( newSize );
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}

+ (UIImage *)scaleImage:(UIImage *)image toSize:(CGSize)newSize {
    
    float width = newSize.width;
    float height = newSize.height;
    
    UIGraphicsBeginImageContext(newSize);
    CGRect rect = CGRectMake(0, 0, width, height);
    
    float widthRatio = image.size.width / width;
    float heightRatio = image.size.height / height;
    float divisor = widthRatio > heightRatio ? widthRatio : heightRatio;
    
    width = image.size.width / divisor;
    height = image.size.height / divisor;
    
    rect.size.width  = width;
    rect.size.height = height;
    
    //indent in case of width or height difference
    float offset = (width - height) / 2;
    if (offset > 0) {
        rect.origin.y = offset;
    }
    else {
        rect.origin.x = -offset;
    }
    
    [image drawInRect: rect];
    
    UIImage *smallImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return smallImage;
    
}

+ (BOOL)isNetworkError:(NSError *)error{
    return (error.domain == NSURLErrorDomain && (error.code == NSURLErrorNetworkConnectionLost || error.code == NSURLErrorNotConnectedToInternet));
}

/*+ (UIImage *)resizeImage:(UIImage *)image{
    // Create the image source (from path)
    //CGImageSourceRef src = CGImageSourceCreateWithURL((__bridge CFURLRef) [NSURL fileURLWithPath:imagePath], NULL);
 
    // To create image source from UIImage, use this
     NSData* pngData =  UIImagePNGRepresentation(image);
     CGImageSourceRef src = CGImageSourceCreateWithData((CFDataRef)pngData, NULL);
    
    //CGImageSourceRef src = CGImageSourceCreateWithURL((__bridge CFURLRef) [NSURL fileURLWithPath:imagePath], NULL);
    // Create thumbnail options
    CFDictionaryRef options = (__bridge CFDictionaryRef) @{
                                                           (id) kCGImageSourceCreateThumbnailWithTransform : @YES,
                                                           (id) kCGImageSourceCreateThumbnailFromImageAlways : @YES,
                                                           (id) kCGImageSourceThumbnailMaxPixelSize : @(640)
                                                           };
    // Generate the thumbnail
    CGImageRef thumbnail = CGImageSourceCreateThumbnailAtIndex(src, 0, options); 
    CFRelease(src);
    
    UIImage *newImage = [[UIImage alloc]initWithCGImage:thumbnail];
    return newImage;
    // Write the thumbnail at path
    //CGImageWriteToFile(thumbnail, imagePath);
}*/



+ (void)saveUserName:(NSString*)userName password:(NSString*)password {
    KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:@"CMOChatApp" accessGroup:nil];
    [keychain setObject:userName forKey:(__bridge NSString*)kSecAttrAccount];
    [keychain setObject:password forKey:(__bridge NSString*)kSecValueData];
}

+ (NSString*)getUserName {
    KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:@"CMOChatApp" accessGroup:nil];
    NSString* username = [keychain objectForKey:(__bridge NSString*)kSecAttrAccount];
    //NSLog(@"USERNAME = %@ ",username);
    if ([username isEqualToString:@""]) {
        return nil;
    }
    return  username;
}

+ (NSString*)getPassword {
    KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:@"CMOChatApp" accessGroup:nil];
    NSString* password = [[NSString alloc] initWithData:[keychain objectForKey:(__bridge NSString*)kSecValueData]
                                               encoding:NSUTF8StringEncoding];
    //NSLog(@"PASSWORD = %@",password);
    if ([password isEqualToString:@""]) {
        return nil;
    }
    return  password;
}

+ (void)clearUserNamePassword {
    KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:@"CMOChatApp" accessGroup:nil];
    [keychain setObject:@"" forKey:(__bridge NSString*)kSecAttrAccount];
    [keychain setObject:@"" forKey:(__bridge NSString*)kSecValueData];
   // [keychain setObject:@"" forKey:(__bridge NSString*)kSecAttrGeneric];
}

+ (void) setUserDefaultForTouchID: (NSString *)isEnable
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:isEnable forKey:@"TouchEnable"];
}

+ (BOOL) getTouchIDUserDefaultValue
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    if([defaults objectForKey:@"TouchEnable"])
    {
        NSString *touchEnable = [defaults objectForKey:@"TouchEnable"];
        if ([touchEnable isEqualToString:@"YES"])
        {
            return YES;
        }
        return NO;
    }
    else
    {
        [CMOUtils setUserDefaultForTouchID:@"NO"];
        return NO;
    }
}

//Save Server Time
+ (void)saveServerTime:(NSString *)date{
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSDate *serverDate = [CMOUtils GMTToLocal:date];
    //[NSString stringWithFormat:@"%f",[CMOUtils toMilliSeconds:serverDate]]
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = MESSAGE_TIME_FORMAT;
    [dateFormatter setTimeZone:[NSTimeZone defaultTimeZone]];
    
    NSDate *newDate = [dateFormatter dateFromString:[dateFormatter stringFromDate:serverDate]];
    
    [userdefault setValue:newDate forKey:SERVER_TIME];
    [userdefault setValue:[NSDate date] forKey:CLIENT_TIME];
}

//Updated server time
+ (NSString *)getServerTime{
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    if (![userdefault valueForKey:SERVER_TIME])return nil;
    
    NSDate *serverTime = [userdefault valueForKey:SERVER_TIME];
    NSDate *clientTime = [userdefault valueForKey:CLIENT_TIME];
    
    NSTimeInterval secondsBetween = [[NSDate date] timeIntervalSinceDate:clientTime];
    NSDate *newServerTime = [serverTime dateByAddingTimeInterval:secondsBetween];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = MESSAGE_TIME_FORMAT;//DATE_FORMAT
    [dateFormatter setTimeZone:[NSTimeZone defaultTimeZone]];
    
    NSString *timeStamp = [dateFormatter stringFromDate:newServerTime];
    return timeStamp;
}

//Save Server Time
+ (void)saveLogUploadTime:(NSDate *)date{
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    [userdefault setValue:date forKey:LOG_UPLOAD_TIME];
}

//Updated server time
+ (NSDate *)getLogUploadTime{
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    if (![userdefault valueForKey:LOG_UPLOAD_TIME])
        return nil;
    
    NSDate *lastLogUploadTime = [userdefault valueForKey:LOG_UPLOAD_TIME];
    return lastLogUploadTime;
}



//+ (NSTimeInterval)toMilliSeconds:(NSDate *)date{
//    NSTimeInterval seconds = [date timeIntervalSinceReferenceDate];
//    return seconds*1000;
//}

//+ (NSDate *)milliSecondsToDate:(NSTimeInterval)timeInterval{
//    NSDate *date = [NSDate dateWithTimeInterval:<#(NSTimeInterval)#> sinceDate:<#(nonnull NSDate *)#>]
//}



+ (NSDate *)getClientLoggedTime{
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    return [userdefault valueForKey:CLIENT_TIME];
}

+ (BOOL)isNull:(id)obj{
    return [obj isEqual:[NSNull null]];
}

+ (void)setLoggedinUserName:(NSString*)userName {
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    [userdefault setObject:userName forKey:LOGGEDIN_USER];
}

+ (BOOL)isSameasLastLoggedinUser:(NSString*)userName {
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *lastLoggedinUserName = [userdefault valueForKey:LOGGEDIN_USER];
    if ([userName.lowercaseString isEqualToString:lastLoggedinUserName.lowercaseString]) {
        return YES;
    }
    return NO;
}

+ (void)startReachabilityMonitoring {
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status){
        //NSLog(@"status changed");
        if (![AFNetworkReachabilityManager sharedManager].isReachable) {
            [[NSNotificationCenter defaultCenter] postNotificationName: XMPP_NETWORK_OFFLINE_NOTIFICATION object:nil userInfo:nil];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName: XMPP_NETWORK_ONLINE_NOTIFICATION object:nil userInfo:nil];
        }
        netWorkInitialized = true;
    }];
}

+ (void)stopReachabilityMonitoring {
    [[AFNetworkReachabilityManager sharedManager] stopMonitoring];
}

+ (void) checkNetworkReachability{
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        NSLog(@"Reachability: %@", AFStringFromNetworkReachabilityStatus(status));
        
        // Check the reachability status and show an alert if the internet connection is not available
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                // AFNetworkReachabilityStatusUnknown = -1,
                NSLog(@"The reachability status is Unknown");
                break;
            case AFNetworkReachabilityStatusNotReachable:
                // AFNetworkReachabilityStatusNotReachable = 0
                NSLog(@"The reachability status is not reachable");
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                NSLog(@"The reachability status is reachable via wan");
                [[NSNotificationCenter defaultCenter] postNotificationName:NETWORK_CONNECTED object:nil];
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                // AFNetworkReachabilityStatusReachableViaWiFi = 2
                [[NSNotificationCenter defaultCenter] postNotificationName:NETWORK_CONNECTED object:nil];
                break;
                
            default:
                break;
        }
        
    }];
}


+ (BOOL)isVPNConnected
{
    NSDictionary *dict = CFBridgingRelease(CFNetworkCopySystemProxySettings());
    NSArray *keys = [dict[@"__SCOPED__"]allKeys];
    for (NSString *key in keys) {
        if ([key rangeOfString:@"tap"].location != NSNotFound ||
            [key rangeOfString:@"tun"].location != NSNotFound ||
            [key rangeOfString:@"ppp"].location != NSNotFound){
            return YES;
        }
    }
    return NO;
}


+ (BOOL)isInternetAvailable {
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    return ((manager.networkReachabilityStatus == AFNetworkReachabilityStatusUnknown) || [manager isReachable]);
}

+ (BOOL)isNetworkAvailable {
    return [AFNetworkReachabilityManager sharedManager].reachable;
}

+ (BOOL)isNetworkInitialized {
    return netWorkInitialized;
}


+ (void) setUserDefaultForMuteNotification: (NSString *)isEnable
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:isEnable forKey:@"MuteNotificationEnabled"];
}

+ (BOOL) getMuteNotificationUserDefaultValue
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    if([defaults objectForKey:@"MuteNotificationEnabled"])
    {
        NSString *touchEnable = [defaults objectForKey:@"MuteNotificationEnabled"];
        if ([touchEnable isEqualToString:@"YES"])
        {
            return YES;
        }
        return NO;
    }
    else
    {
        [CMOUtils setUserDefaultForMuteNotification:@"NO"];
        return NO;
    }
}

+(void)saveAllRoomsLastSyncTime:(NSString *)syncTime {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:syncTime forKey:@"AllRoomsLastSyncTime"];
}

+(NSString *)getAllRoomsLastSyncTime {
    NSString *lastSyncTime = nil;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"AllRoomsLastSyncTime"]) {
        lastSyncTime = [defaults objectForKey:@"AllRoomsLastSyncTime"];
    }
    return lastSyncTime;
}

+ (void)saveDeviceSyncTime:(NSString *)syncTime{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:syncTime forKey:SYNC_DATE];
}

+ (NSString *)getDeviceSyncTime{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults valueForKey:SYNC_DATE];
}

+ (void)saveDeviceSyncVersion:(NSString *)version{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:version forKey:SYNC_VERSION];
}

+ (void)saveVisitedRoomInfo:(NSString *)roomName count:(NSInteger)count{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    id obj = [CMOUtils allVisitedRoomsInfo];
    if (!obj){
        obj = [[NSMutableDictionary alloc]init];
    }
    else{
        NSMutableDictionary *newDict = [obj mutableCopy];
        obj = newDict;
    }
    if (roomName){
        [obj setValue:[NSString stringWithFormat:@"%ld",(long)count] forKey:roomName];
        [defaults setObject:obj forKey:VISITED_ROOM_INFO];
    }
}

+ (void)saveArchivedRoomSyncInfo:(NSMutableArray *)archiveRoomList{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    id obj = [CMOUtils allArchivedRoomsInfo];
    if (!obj){
        obj = [[NSMutableArray alloc]init];
    }
    obj = archiveRoomList;
    [defaults setObject:obj forKey:ARCHIVED_ROOM_INFO];
}

+ (id)allArchivedRoomsInfo{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults valueForKey:ARCHIVED_ROOM_INFO];
}

+ (void)clearArchivedRoomInfo{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:ARCHIVED_ROOM_INFO];
}

+ (id)allVisitedRoomsInfo{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults valueForKey:VISITED_ROOM_INFO];
}

+ (void)clearVisitedRoomInfo{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:VISITED_ROOM_INFO];
}


+ (void)saveSMSInfo:(NSString *)users roomId:(NSString *)roomId{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    id obj = [CMOUtils allSMSUserRoomsInfo];
    if (!obj){
        obj = [[NSMutableDictionary alloc]init];
    }
    else{
        NSMutableDictionary *newDict = [obj mutableCopy];
        obj = newDict;
    }
    if (roomId){
        [obj setValue:users forKey:roomId];
        [defaults setObject:obj forKey:SMS_USER_INFO];
    }
}

+ (id)allSMSUserRoomsInfo{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults valueForKey:SMS_USER_INFO];
}

+ (void)clearSMSUserRoomInfo{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:SMS_USER_INFO];
}


+ (NSString *)getDeviceSyncVersion{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults valueForKey:SYNC_VERSION];
}

+(void)saveUnreadMessageCountLastSyncTime:(NSString *)syncTime {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:syncTime forKey:@"UnreadMessageCountLastSyncTime"];
}

+(NSString *)getUnreadMessageCountLastSyncTime {
    NSString *lastSyncTime = nil;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"UnreadMessageCountLastSyncTime"]) {
        lastSyncTime = [defaults objectForKey:@"UnreadMessageCountLastSyncTime"];
    }
    return lastSyncTime;
}

+(void)getCMSPasswordFromServer:(id)client {
    id <CMOAppServerAPIClient> _client = client;
    NSString *url = [NSString stringWithFormat:@"getCMSData"];
    [_client GET:url parameters:nil OnProgress:nil OnSuccess:^(id  _Nullable response) {
        //Success
        NSString *encryptedPassword = [response valueForKey:@"cmsData"];
        NSData *encryptedData = [[NSData alloc] initWithBase64EncodedString:encryptedPassword options:NSDataBase64DecodingIgnoreUnknownCharacters];
        NSData *decryptedData = [encryptedData AES128DecryptedDataWithKey:REST_SECRET_KEY];
        NSString *passwordString = [[NSString alloc] initWithData:decryptedData encoding:NSUTF8StringEncoding];
        
        //update password in keychain
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:passwordString forKey:@"DOTCMSPASSWORD"];
    } onFailure:^(NSError * _Nonnull error) {
        //Failure
        DDLogError(@"CMOUtils::getCMSPasswordFromServer failed");
        
    }];
}

+(NSString *)getCMSPassword {
    NSString *dotcmsPassword = nil;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"DOTCMSPASSWORD"]) {
        dotcmsPassword = [defaults objectForKey:@"DOTCMSPASSWORD"];
    }
    return dotcmsPassword;
}

+ (void)setUserEncryptedDataWithName:(NSString *)name andPassword:(NSString *)password{
    //[KeychainItemWrapper]
    //KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:@"CMOChatApp" accessGroup:nil];
    //NSUserDefaults *defaults1 = [NSUserDefaults standardUserDefaults];
  
    
    
    NSString *encryptString = [NSString stringWithFormat:@"%@|%@", name, password];
    NSData *encryptDetails = [encryptString dataUsingEncoding:NSUTF8StringEncoding];
    NSData *encryptedData = [encryptDetails AES128EncryptedDataWithKey:REST_SECRET_KEY];
    NSData *encryptedDetails = [encryptedData base64EncodedDataWithOptions:0];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[NSString stringWithUTF8String:[encryptedDetails bytes]] forKey:ENCRYPTED_USER_DATA];
    
    //[keychain setObject:[NSString stringWithUTF8String:[encryptedDetails bytes]] forKey:(__bridge id)kSecAttrGeneric];

}

+ (NSString *)getUserEncryptedData{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *aes128String = [defaults objectForKey:ENCRYPTED_USER_DATA];
    if (!aes128String) {
        aes128String = @"";
    }
    return aes128String;
}

/*
 
 NSString *e1 = @"Hello Damac";
 NSData *e2 = [e1 dataUsingEncoding:NSUTF8StringEncoding];
 NSData *e3 = [e2 AES128EncryptedDataWithKey:REST_SECRET_KEY];
 NSData *e4 = [e3 base64EncodedDataWithOptions:0];
 
 NSData *d3 = [[NSData alloc]initWithBase64EncodedData:e4 options:0];
 //NSData *d3 = [[NSData alloc]initWithBase64EncodedString:e4 options:0];
 //NSData *d3 = [e4 base64EncodedDataWithOptions:0];
 NSData *d2 = [d3 AES128DecryptedDataWithKey:REST_SECRET_KEY];
 NSString *d1 = [NSString stringWithUTF8String:[d2 bytes]];
 NSLog(@"Name is %@",d1);

 */
+ (NSString *)decryptUserData{
    @autoreleasepool {
       // KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:@"CMOChatApp" accessGroup:nil];
        //NSString* encryptedData = [[NSString alloc] initWithData:[keychain objectForKey:(__bridge NSString*)kSecValueData] encoding:NSUTF8StringEncoding];
        NSString *encryptedData = [self getUserEncryptedData];
        if (encryptedData){
            NSData *encryptedDataBytes = [encryptedData dataUsingEncoding:NSUTF8StringEncoding];
            
            NSData *decryptedData = [[NSData alloc]initWithBase64EncodedData:encryptedDataBytes options:0];
            NSData *decryptedDetails = [decryptedData AES128DecryptedDataWithKey:REST_SECRET_KEY];
            NSString *decryptString = [[NSString alloc] initWithData:decryptedDetails encoding:NSUTF8StringEncoding];
            return decryptString;
        }
        return nil;
    }
}

+(void)saveExchangeContactsLastSyncTime:(NSString *)syncTime {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:syncTime forKey:@"ExchangeContactsLastSyncTime"];
}

+(NSString *)getExchangeContactsLastSyncTime {
    NSString *lastSyncTime = nil;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"ExchangeContactsLastSyncTime"]) {
        lastSyncTime = [defaults objectForKey:@"ExchangeContactsLastSyncTime"];
    }
    else{
        lastSyncTime = @"0";
    }
    return lastSyncTime;
}

+ (NSDictionary *)toJsonDictionary:(NSString *)jsonString{
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    return json;
}

+ (void)saveAppVersion:(NSString *)appVersion{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:appVersion forKey:@"DamacChatAppVersion"];
}

+ (NSString *)getAppVersion{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"DamacChatAppVersion"]) {
        return [defaults objectForKey:@"DamacChatAppVersion"];
    }
    return nil;
}

+ (void) saveDeviceIdentifier:(NSString *)deviceID
{
    KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:@"CMOChatApp" accessGroup:nil];
    [keychain setObject:deviceID forKey:(__bridge NSString*)kSecAttrDescription];
}

+ (NSString *) getDeviceIdentifier
{
    KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:@"CMOChatApp" accessGroup:nil];
    NSString* deviceID = [keychain objectForKey:(__bridge NSString*)kSecAttrDescription];
    NSLog(@"deviceID = %@ ",deviceID);
    if ([deviceID isEqualToString:@""]) {
        return nil;
    }
    return  deviceID;
}

+ (void) saveLastInstalledDate
{
    long epochDate = [@(floor([[NSDate date] timeIntervalSince1970] * 1000)) longLongValue];
    NSString *lastUpdatedDate = [NSString stringWithFormat:@"%ld",epochDate];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:lastUpdatedDate forKey:@"AppUpdatedDate"];
    
}

+ (NSString *) getLastInstalledDate
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *lastUpdatedDate;
    if ([defaults objectForKey:@"AppUpdatedDate"]) {
        lastUpdatedDate = [defaults objectForKey:@"AppUpdatedDate"];
    }
    else{
        lastUpdatedDate = @"";
    }
    
    return lastUpdatedDate;
}





@end
