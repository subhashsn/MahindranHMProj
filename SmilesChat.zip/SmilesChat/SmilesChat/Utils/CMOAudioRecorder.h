//
//  CMOAudioRecorder.h
//  CMOChat
//
//  Created by Amit Kumar on 05/01/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@protocol CMOAudioRecorderDelegate <NSObject>

@required
- (void) recordingStarted;

@optional
- (void) audioRecordingFinished:(NSURL *)recordedUrl;

@end

@interface CMOAudioRecorder : NSObject <AVAudioRecorderDelegate, AVAudioPlayerDelegate>

@property (nonatomic, strong) id <CMOAudioRecorderDelegate>recorderDelegate;

//- (instancetype)initWithDelegate:(id <CMOAudioRecorderDelegate>)delegate;
- (BOOL) startRecording;
- (void) stopRecording;
- (void) pauseRecording;

@end
