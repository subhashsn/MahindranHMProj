//
//  CMOAudioRecorder.m
//  CMOChat
//
//  Created by Amit Kumar on 05/01/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMOAudioRecorder.h"

@interface CMOAudioRecorder(){
    //id <CMOAudioRecorderDelegate> recorderDelegate;
    AVAudioRecorder *recorder;
}
@end


@implementation CMOAudioRecorder

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSArray *pathComponents = [NSArray arrayWithObjects:
                                   [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject],
                                   @"MyAudioMemo.m4a",
                                   nil];
        NSURL *outputFileURL = [NSURL fileURLWithPathComponents:pathComponents];
        
        // Setup audio session
        AVAudioSession *session = [AVAudioSession sharedInstance];
        [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
        [session overrideOutputAudioPort:AVAudioSessionPortOverrideSpeaker error:nil];
        
        // Define the recorder setting
        NSMutableDictionary *recordSetting = [[NSMutableDictionary alloc] init];
        
        [recordSetting setValue:[NSNumber numberWithInt:kAudioFormatMPEG4AAC] forKey:AVFormatIDKey];
        [recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey];
        [recordSetting setValue:[NSNumber numberWithInt: 2] forKey:AVNumberOfChannelsKey];
        
        // Initiate and prepare the recorder
        recorder = [[AVAudioRecorder alloc] initWithURL:outputFileURL settings:recordSetting error:nil];
        recorder.delegate = self;
        recorder.meteringEnabled = YES;
        [recorder prepareToRecord];
    }
    return self;
}

- (instancetype)initWithDelegate:(id <CMOAudioRecorderDelegate>)delegate
{
    self = [super init];
    if (self) {
        _recorderDelegate = delegate;
    }
    return self;
}

- (BOOL) startRecording {
    BOOL  ret = false;
    if (!recorder.recording) {
        [self doStartRecording];
        ret = true;
    }
    return ret;
}

- (void) doStartRecording {
    [[AVAudioSession sharedInstance] setActive:YES error:nil];
    // Start recording
    [recorder record];
    if (self.recorderDelegate) {
        [self.recorderDelegate recordingStarted];
    }
}

- (void) stopRecording {
    if (recorder) {
        [recorder stop];
    }
}
- (void) pauseRecording {
    if (recorder && recorder.recording) {
        [recorder pause];
    }
}


#pragma mark - AVAudioRecorderDelegate

- (void) audioRecorderDidFinishRecording:(AVAudioRecorder *)avrecorder successfully:(BOOL)flag{
    if (self.recorderDelegate) {
        [self.recorderDelegate audioRecordingFinished:avrecorder.url];
    }
}

#pragma mark - AVAudioPlayerDelegate

- (void) audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{
    ////DDLogInfo(@"CMOAudioRecorder::audioPlayerDidFinishPlaying : %d",flag);
}


@end
