//
//  UIImage+Util.h
//  CMOChat
//
//  Created by Administrator on 11/10/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Util)

- (UIImage *)applyBlur;

- (UIImage *)resizeImage;

- (UIImage *)normalizedImage:(CGSize)size;

- (UIImage *) scaleAndRotateImage;

+ (UIImage *)imageFromColor:(UIColor *)color;

@end
