//
//  SearchUtils.m
//  CMOChat
//
//  Created by Amit Kumar on 06/04/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMOSearchUtils.h"
#import "CMORoomDetails+CoreDataClass.h"
#import "CMOChatPresentation.h"
#import "CMORosterClient.h"

@interface CMOSearchUtils() {
    CMOChatPresentation *chatModel;
}

@end

@implementation CMOSearchUtils

- (instancetype)initWithModel:(CMOChatPresentation*)model {
    self = [super init];
    if (self) {
        chatModel = model;
    }
    return self;
}

- (NSArray*)roomsContainingText:(NSString*)searchText fromRooms:(NSArray*)roomList {
    NSMutableArray *resultArray = [[NSMutableArray alloc] init];
    //search room names
    NSPredicate *roomNameResultPredicate = [NSPredicate predicateWithFormat:@"roomSubject contains[c] %@", searchText];
    NSArray *searchResultForRoomNames = [roomList filteredArrayUsingPredicate:roomNameResultPredicate];
    
    NSMutableArray *roomsSearchContainingTextinMessage = [[NSMutableArray alloc] init];
    
    //for efficiency get remaining roomlist and serach only them for search text in message
    NSMutableArray *remainingRooms = [roomList mutableCopy];
    [remainingRooms removeObjectsInArray:searchResultForRoomNames];
    
    //search room message
    for (int i =0; i < remainingRooms.count; i++) {
        CMORoomDetails *roomDetails = remainingRooms[i];
        if ([self room:roomDetails.roomName ConatinsText:searchText]) {
            [roomsSearchContainingTextinMessage addObject:roomDetails];
        }
    }
    
    //Merge searchResultForRoomNames and roomsSearchContainingTextinMessage and return
    [resultArray addObjectsFromArray:searchResultForRoomNames];
    [resultArray addObjectsFromArray:roomsSearchContainingTextinMessage];
    
    return resultArray;
}

- (NSArray*)roomsByNameText:(NSString*)searchText fromRooms:(NSArray*)roomList
{
    NSMutableArray *roomsSearchContainingMembers = [[NSMutableArray alloc] init];
    
    //search room message
    for (int i =0; i < roomList.count; i++) {
        CMORoomDetails *roomDetails = roomList[i];
        if ([self roomConatinsUser:searchText inRoom:roomDetails]) {
            [roomsSearchContainingMembers addObject:roomDetails];
        }
    }
    
    NSArray *roomsList = [chatModel filterRoomsbySMSUser:searchText];
    if (roomsList.count > 0){
        [roomsSearchContainingMembers addObjectsFromArray:roomsList];
    }
    
    return roomsSearchContainingMembers;
}


- (BOOL)room:(NSString*)roomId ConatinsText:(NSString*)searchText {
    NSPredicate *roomMessageResultPredicate = [NSPredicate predicateWithFormat:@"text contains[c] %@", searchText];
    NSArray *allMessages = [chatModel getMessagesForRoom:roomId delegate:self messagesDict:nil];
    NSArray *searchResultForRoomText = [allMessages filteredArrayUsingPredicate:roomMessageResultPredicate];
    if (searchResultForRoomText.count > 0 ) {
        ////DDLogInfo(@"Print matched roomId: (%@) message : (%@)",roomId,searchResultForRoomText);
        return true;
    }
    return false;
}

- (BOOL)roomConatinsUser:(NSString*)user inRoom:(CMORoomDetails*)room
{
    NSArray *predicateArray = [NSArray array];
    
    NSString *userName = [chatModel getUsernameForNicname:user];
    if (userName) {
        NSPredicate *altRroomMessageResultPredicate = [NSPredicate predicateWithFormat:@"participantName contains[c] %@", userName];
        NSPredicate *altRroomMessageResultPredicateJid = [NSPredicate predicateWithFormat:@"jid contains[c] %@", userName];
        predicateArray = [predicateArray arrayByAddingObject:altRroomMessageResultPredicate];
        predicateArray = [predicateArray arrayByAddingObject:altRroomMessageResultPredicateJid];
    }
    
    NSPredicate *roomMessageResultPredicate = [NSPredicate predicateWithFormat:@"participantName contains[c] %@", user];
    NSPredicate *roomMessageResultPredicateJid = [NSPredicate predicateWithFormat:@"jid contains[c] %@", user];
    predicateArray = [predicateArray arrayByAddingObject:roomMessageResultPredicate];
    predicateArray = [predicateArray arrayByAddingObject:roomMessageResultPredicateJid];
    
    NSCompoundPredicate *compoundPredicate = [NSCompoundPredicate orPredicateWithSubpredicates:predicateArray];
    
    NSArray *allMembers = [chatModel clubOwnersAndMembers:room];
    NSArray *searchResultForRoomText = [allMembers filteredArrayUsingPredicate:compoundPredicate];
    if (searchResultForRoomText.count > 0 ) {
        ////DDLogInfo(@"Member (%@) inRoom : (%@)",user,room.naturalName);
        return true;
    }
    return false;
}

@end
