//
//  Utils.h
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CMOUtils : NSObject

+ (NSDictionary *)appConfigurations;

+ (NSString *)serverName;

+ (NSString *)domainName;

+ (NSInteger)serverPort;

+ (BOOL)isConnectionSecured;

+ (NSInteger)appServerPort;

+ (NSString *)getUniqueString;

+ (NSDate *)toDate:(NSString *)date;

+ (NSString *)dateToString:(NSDate *)date;

+ (NSString *)dateToStringForShowCrossedSLA:(NSDate *)date;

+ (NSInteger)calculateMinsDifference:(NSDate *)date;

+ (NSDate *)GMTToLocal:(NSString *)date;

+ (void)saveUserName:(NSString*)userName password:(NSString*)password;

+ (NSString*)getUserName;

+ (NSString*)getPassword;

+ (void)clearUserNamePassword;

+ (DocumentType)documentType:(NSString *)body;

+ (DocumentType)fileType:(NSURL *)url;

//+ (BOOL)isFileExistAtPath:(NSString *)path;

+ (void) setUserDefaultForTouchID: (NSString *)isEnable;

+ (BOOL) getTouchIDUserDefaultValue;

+ (UIImage*)imageWithImage:(UIImage*)image
              scaledToSize:(CGSize)newSize;

+ (UIImage *)scaleImage:(UIImage *)image toSize:(CGSize)newSize;

//+ (UIImage *)resizeImage:(UIImage *)image;

+ (BOOL)isNull:(id)obj;

+ (void)saveServerTime:(NSString *)date;

+ (NSString *)getServerTime;

+ (NSDate *)getClientLoggedTime;

+ (void)setLoggedinUserName:(NSString*)userName;

+ (BOOL)isSameasLastLoggedinUser:(NSString*)userName;

+ (void)startReachabilityMonitoring;

+ (void)stopReachabilityMonitoring;

+ (BOOL)isVPNConnected;

+ (BOOL)isInternetAvailable;

+ (BOOL)isNetworkAvailable;

+ (void) checkNetworkReachability;

+ (BOOL)isNetworkInitialized;

+ (NSDate *)toSpecifiedFormatDate:(NSString *)date format:(NSString *)format;
+ (NSString *)toSpecifiedFormatString:(NSDate *)date format:(NSString *)format;

+ (void) setUserDefaultForMuteNotification: (NSString *)isEnable;

+ (BOOL) getMuteNotificationUserDefaultValue;

+(void)saveAllRoomsLastSyncTime:(NSString *)syncTime;

+(NSString *)getAllRoomsLastSyncTime;

+ (void)saveDeviceSyncTime:(NSString *)syncTime;

+ (NSString *)getDeviceSyncTime;

+ (void)saveDeviceSyncVersion:(NSString *)version;

+ (NSString *)getDeviceSyncVersion;

+ (void)saveVisitedRoomInfo:(NSString *)roomName count:(NSInteger)count;

+ (id)allVisitedRoomsInfo;

+ (void)clearVisitedRoomInfo;

+ (void)saveArchivedRoomSyncInfo:(NSMutableArray *)archiveRoomList;

+ (id)allArchivedRoomsInfo;

+ (void)clearArchivedRoomInfo;

+ (void)saveSMSInfo:(NSString *)users roomId:(NSString *)roomId;

+ (id)allSMSUserRoomsInfo;

+ (void)clearSMSUserRoomInfo;

+(void)saveUnreadMessageCountLastSyncTime:(NSString *)syncTime;

+(NSString *)getUnreadMessageCountLastSyncTime;

+(void)getCMSPasswordFromServer:(id)client;

+(NSString *)getCMSPassword;

//For Exchange service
+ (void)setUserEncryptedDataWithName:(NSString *)name andPassword:(NSString *)password;

+ (NSString *)getUserEncryptedData;

+ (NSString *)decryptUserData;

+ (void)saveExchangeContactsLastSyncTime:(NSString *)syncTime;

+ (NSString *)getExchangeContactsLastSyncTime;

+ (NSDictionary *)toJsonDictionary:(NSString *)jsonString;

+ (BOOL)isNetworkError:(NSError *)error;

+ (void)saveAppVersion:(NSString *)appVersion;

+ (NSString *)getAppVersion;

+ (NSString *) getDeviceIdentifier;

+ (void) saveDeviceIdentifier:(NSString *)deviceID;

+ (void) saveLastInstalledDate;

+ (NSString *) getLastInstalledDate;

+ (void)saveLogUploadTime:(NSDate *)date;

+ (NSDate *)getLogUploadTime;


@end
