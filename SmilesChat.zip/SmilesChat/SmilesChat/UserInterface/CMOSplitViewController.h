//
//  CMOSplitViewController.h
//  CMOChat
//
//  Created by Raju on 11/28/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CMOAssembly;

@interface CMOSplitViewController : UISplitViewController

@property (nonatomic, strong) CMOAssembly *assembly;
@property (nonatomic, assign) BOOL isNewObject;

@end
