//
//  CMOTableViewDelegate.h
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^ConfigureCellDelegateBlock)(NSIndexPath* indexPath,id item);
typedef void(^ConfigureCellArchievedCellNotVisbleBlock)(NSIndexPath* indexPath);
//typedef void(^editActionsCellDelegateBlock)(NSArray *array);
//typedef void(^CellHeightBlock) (CGFloat height);


@interface CMOTableViewDelegate : NSObject <UITableViewDelegate>

@property (strong, nonatomic) ConfigureCellArchievedCellNotVisbleBlock archievedCellNotVisbleBlock;

- (instancetype)initWithItems:(NSArray *)items
                configureCell:(ConfigureCellDelegateBlock)configureCellBlock;

/*
 - (instancetype)initWithItems:(NSArray *)items
 configureCell:(ConfigureCellDelegateBlock)configureCellBlock
 editActionCell:(editActionsCellDelegateBlock)editActionCellBlock;
 */

- (void)setCellHeight:(CGFloat)height;

- (void)updateDelegate:(NSArray *)items;

-(void)setEditAction:(NSArray *)array;

- (void)setAlphbeticalScrollBar;

@end
