//
//  CMOSearchViewController.h
//  CMOChat
//
//  Created by Raju on 12/8/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AdvancedSearchDelegate <NSObject>

- (void) cancelAction;
- (void) searchWithUser:(NSString *)user andKeyword: (NSString *)keyword;

@end

@class CMOAssembly;
@interface CMOSearchViewController : UIViewController

@property (strong, nonatomic) CMOAssembly *assembly;

@property (nonatomic, weak) IBOutlet UITextField *searchName;
@property (nonatomic, weak) IBOutlet UITextField *searchKeyword;

@property (nonatomic, weak) id <AdvancedSearchDelegate> delegate;

@end

