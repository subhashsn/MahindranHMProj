//
//  CMORosterViewController.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMORosterViewController.h"
#import "CMOCoreComponents.h"
#import "CMOUser.h"
#import "CMOChatViewController.h"
#import "CMORosterPresentation.h"
#import "CMOAssembly.h"
#import "CMOTabBarController.h"
#import "CMORoster+CoreDataProperties.h"
#import "CMOChatContainerViewController.h"
#import "CMOUserPresence.h"
#import "CMOParticipantInfo.h"
#import "CMOMyProfileViewController.h"
#import "AppDelegate.h"
#import "CMOConversationsTableViewController.h"
#import "CMOUtils.h"
#import "CMOMessageParam.h"
#import "CMORoomPresentation.h"

#define PROFILE_IMAGE         100
#define PROFILE_NAME          101
#define PROFILE_DESIGNATION   102
#define PROFILE_PRESENCE      103
#define NON_APP_USER_ICON     104
#define ADD_PROFILE_IMAGE     110
#define ADD_PROFILE_PRESENCE  111
#define EXCHANGE_ICON         112
#define NO_CONTENT_AVAILABLE_TAG 2000
#define SEARCH_BAR_HEIGHT      44
#define IMAGE_RADIUS           25

#define ERR_MSG_NO_CONTACT_AVAILABLE @"No Contacts are available to add"
#define ERR_MSG_NO_GROUP_AVAILABLE @"No Groups are available to add"
#define TITLE_ADD_PARTICIPANTS  @"Add Participants"
#define TITLE_CONTACTS @"Contacts"
#define IMAGE_PROFILE_PIC_PLACEHOLDER @"ProfilePic_Placeholder"
#define IMAGE_ONLINE_STATUS @"Status_Online"
#define IMAGE_OFFLINE_STATUS @"Status_Offline"



//static BOOL isPhoneContactLoaded;
static BOOL isExchangeContactLoaded;

@interface CMORosterViewController ()<UISearchBarDelegate, MyProfileDelegate>
{
    CMOChatViewController *chatvc;
    CMORosterPresentation *rosterModel;
    CMOUser *owner;
    
    CMOTabBarController *tabBarController;
    NSArray<CMORoster *> *usersList;
    
    NSMutableArray *alphabetsArray;
    NSMutableArray *dataArray;
    
    //This dictionary will keep track of added participants, if user pressed cancel button, this will not be applied to `participantsDict` else it will be assigned to 'participantsDict'
    NSMutableDictionary *tempParticipantDict;
    NSMutableDictionary *userPresenceDict;
    
    CMOMyProfileViewController *userProfile;
    MBProgressHUD *hudProgress;
    
    BOOL isConnected;
    UIRefreshControl *refreshPhoneContacts;
    NSMutableArray *exestingParticipants;
   

    
}

@end

@implementation CMORosterViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //participantsDict can be passed from different class, so always check for participantsDict not empty
    if (!self.participantsDict){
        self.participantsDict = [[NSMutableDictionary alloc]init];
    }
    
    if (self.rosterDelegate && _chatType == ChatTypeNewChat) {
        _roomModel = [_coreComponents roomPresentation];
        [self addNavigationBarNext];
        self.navigationItem.title = TITLE_ADD_PARTICIPANTS;
    }else if (self.rosterDelegate) {
        [self addNavigationBar];
        self.navigationItem.title = TITLE_ADD_PARTICIPANTS;
    }
    else
    {
        self.navigationItem.title = TITLE_CONTACTS;
    }
    
   // [self addNextButton];
    
    userPresenceDict = [[NSMutableDictionary alloc]init];
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    owner = [userClient user];
    
    //Add pull to refresh on contacts only to CM users
    refreshPhoneContacts = [[UIRefreshControl alloc] init];
    refreshPhoneContacts.tintColor = [UIColor grayColor];
    [refreshPhoneContacts addTarget:self action:@selector(updateAllusersAndGroups) forControlEvents:UIControlEventValueChanged];
    [_rosterTableView addSubview:refreshPhoneContacts];
    
    //[self checkForiPad];
    _rosterTableView.allowsSelection = true;
    _managedObjectContext = [[_coreComponents repositoryService] getManagedObjectContext];
    exestingParticipants = [[NSMutableArray alloc]init];
}




- (void)registerNotifications{
    
    isConnected = true;
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(connectionEstablised:) name:XMPP_CONNECTION_ESTABLISHED object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(connectionInteruppted:) name:XMPP_DISCONNECT object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(connectionInteruppted:) name:XMPP_ACCIDENTAL_DISCONNECT_NOTIFICATION object:nil];
     [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(updatePresence:) name:XMPP_USER_PRESENCE_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(applicationLoggedOut:) name:LOGOUT_NOTIFICATION object:nil];
    
}

- (void)unRegisterNotifications{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_CONNECTION_ESTABLISHED object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_DISCONNECT object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_ACCIDENTAL_DISCONNECT_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_USER_PRESENCE_NOTIFICATION object:nil];
}

- (void)applicationLoggedOut:(NSNotification *)notification{
    
    _rosterFetchedResultsController = nil;
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:LOGOUT_NOTIFICATION object:nil];
}

- (void)connectionEstablised:(NSNotification *)notification{
    isConnected = true;
    [self.rosterTableView reloadData];
}

- (void)connectionInteruppted:(NSNotification *)notification{
    isConnected = false;
    [self.rosterTableView reloadData];
}

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self getUserNames];
    
    NSError *error;
    if (![[self rosterFetchedResultsController] performFetch:&error]) {
        // Update to handle the error appropriately.
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
    }
    
    //NSLog(@"Predicate is %@",[[[self rosterFetchedResultsController] fetchRequest]predicate]);
    
    //NSLog(@"Objects are %@ and count is %lu",[[self rosterFetchedResultsController] fetchedObjects],[[[self rosterFetchedResultsController] fetchedObjects]count]);
    
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    owner = [userClient user];
    
    [self registerNotifications];
    [self.segControlForControl setSelectedSegmentIndex:0];
    [_rosterTableView reloadData];
    
    if (tempParticipantDict.count > 0){
        [tempParticipantDict removeAllObjects];
    }
    tempParticipantDict = [self.participantsDict mutableCopy];
   
    //[self addSearchBar];
    
    AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    appDelegate.isFromContacts = true;
    
    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(popToView:) name:@"popToView" object:nil];
}

- (void)addSearchBar{
    float width = CGRectGetWidth([UIScreen mainScreen].applicationFrame);
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, width, SEARCH_BAR_HEIGHT)];
    _searchBar.delegate = self;
    [[self rosterTableView] setTableHeaderView:_searchBar];
}

- (void) getUserNames{
    
    if (_currentParticipants.count > 0) {
        for (CMOParticipantInfo *info in _currentParticipants) {
            [exestingParticipants addObject:info.participantName];
        }
    }
    else{
        [exestingParticipants removeAllObjects];
    }
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    dispatch_async(dispatch_get_main_queue(), ^(){
        [hudProgress hideAnimated:YES];
        hudProgress = nil;
        [refreshPhoneContacts endRefreshing];
    });
    //reset predicate on switch tabs (Search scenario)
   // _rosterFetchedResultsController.fetchRequest.predicate = [self getContactsPredicate];
    
    [self unRegisterNotifications];
}

- (void)addNavigationBar{
    UIBarButtonItem *leftBarButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(selectedParticipants:)];
    self.navigationItem.leftBarButtonItem = leftBarButton;
}

- (void)addNavigationBarNext {
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithTitle:@"Next" style:UIBarButtonItemStylePlain target:self action:@selector(nextPressed:)];
    self.navigationItem.rightBarButtonItem = rightBarButton;
}

- (void)nextPressed:(id)sender{
    
    if(tempParticipantDict != nil && [tempParticipantDict count] > 0) {
        UIAlertController * alertController = [UIAlertController alertControllerWithTitle:@"" message: @"Enter the group name" preferredStyle:UIAlertControllerStyleAlert];
        
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.placeholder = @"Group name";
            textField.textColor = [UIColor blackColor];
            textField.clearButtonMode = UITextFieldViewModeWhileEditing;
            textField.borderStyle = UITextBorderStyleRoundedRect;
        }];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
        }]];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"Continue" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            NSArray * textfields = alertController.textFields;
            UITextField * groupname = textfields[0];
            NSString *groupStr = [groupname.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            self.participantsDict = [tempParticipantDict mutableCopy];
            if (groupStr.length > 3) {
                [self createRoomWithName:groupStr];
            }
        }]];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
}

-(void)createRoomWithName:(NSString *)groupname {
    
    [self showHUDProgressWithMessage:@"Creating chat..."];
    
    CMOMessageParam *param = [self constructRoomMessageParam:groupname media:nil type:DocumentTypeUnknown fileName:nil roomId:[[CMOUtils getUniqueString]lowercaseString] date:[NSDate date] show:false smsSent:false];
    
    self.chatModel = [_coreComponents chatPresentation];
    
    CMOMessage *message = [self.chatModel constructMessage:param target:self messagesDict:nil];
    
    [_roomModel createRoomWithMessage:message participants:[self roomeligibleParticipants:self.participantsDict smsSent:[message.messageBody.smsUsers length] > 0] onSuccess:^(id result, CMOMessage *message) {
        [self hideHUDProgressIndicator];
        if(self.participantsDict.count > 0) {
            [self.participantsDict removeAllObjects];
        }
        [self.navigationController popViewControllerAnimated:YES];
    } onFailure:^(NSError *error) {
        [self hideHUDProgressIndicator];
        [self displayErrorAlertWithTitle:SERVER_ACCESS_ERROR_MSG];
    }];
}


#pragma mark Common Alert

- (void)displayErrorAlertWithTitle:(NSString *)title{
    if ([UIAlertController class]){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@""
                                    message:title
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* okButton = [UIAlertAction
                                   actionWithTitle:@"OK"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action)
                                   {
                                       
                                   }];
        
        [alert addAction:okButton];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

#pragma mark Construct `CMOMessageParam` from User Defined Action (i.e) From the view

- (CMOMessageParam *)constructRoomMessageParam:(NSString *)body
                                     media:(id)media
                                      type:(DocumentType)documentType
                                  fileName:(NSString *)fileName
                                    roomId:(NSString *)roomId
                                      date:(NSDate *)date
                                      show:(BOOL)show //for hide/show
                                   smsSent:(BOOL)smsSent{
    
    NSString *serverTime = [CMOUtils getServerTime];
    NSDate *serverDate = [CMOUtils toSpecifiedFormatDate:serverTime format:MESSAGE_TIME_FORMAT];
    
    CMOMessageParam *messageParam = [[CMOMessageParam alloc]init];
    messageParam.body = body;
    messageParam.senderId = owner.username;
    messageParam.senderDisplayName = owner.name;
    messageParam.date = serverDate;
    messageParam.roomSubject =body;
    messageParam.roomId = roomId;
    messageParam.isMedia = false;
    messageParam.documentType = DocumentTypeUnknown;
    messageParam.fileName = fileName;
    //Applicable for Document Types
    return messageParam;
}

- (NSMutableDictionary *)roomeligibleParticipants:(NSMutableDictionary *)allParticipants
                                      smsSent:(BOOL)smsSent{
    
    CMORosterPresentation *rosterAddModel = [_coreComponents rosterPresentation];
    NSArray *participants = [rosterAddModel eligibleParticipants:self.participantsDict sent:smsSent];
    NSMutableDictionary *eligibleParticipants = [[NSMutableDictionary alloc]init];
    if (participants.count > 0){
        [eligibleParticipants setObject:participants forKey:MACROS_CONTACTS];
    }
    if ([self.participantsDict objectForKey:MACROS_GROUPS]){
        [eligibleParticipants setObject:[self.participantsDict objectForKey:MACROS_GROUPS] forKey:MACROS_GROUPS];
    }
    return eligibleParticipants;
}


#pragma mark Show/Hide HUD Indicator

- (void)showHUDProgressWithMessage:(NSString *)text{
    if (!hudProgress){
        hudProgress = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    }
    hudProgress.label.text = text;
}


- (void)hideHUDProgressIndicator{
    if (hudProgress){
        [hudProgress hideAnimated:true];
    }
}

- (void)participants:(NSMutableDictionary *)participants{
    
}

- (void)selectedParticipants:(id)sender{
    self.participantsDict = [tempParticipantDict mutableCopy];
    [self.rosterDelegate participants:self.participantsDict];
    [self.navigationController popViewControllerAnimated:true];
}

- (void)goToConversation:(id)sender{
    //Clear Participants List
    if (tempParticipantDict.allKeys.count > 0){
        [tempParticipantDict removeAllObjects];
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    if (_chatType == ChatTypeNewChat && !_rosterDelegate) {
        NSLog(@"-------");
        NSIndexPath *selectedIndexPath = [_rosterTableView indexPathForSelectedRow];
        if (selectedIndexPath == nil) {
            selectedIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
        }
    }
    
    if(_searchBar){
        _searchBar.text = @"";
        [_searchBar resignFirstResponder];
    }
}

- (NSMutableArray *)arrayForDict:(NSString *)key{
    id value = [tempParticipantDict valueForKey:key];
    if (!value){
        value = [[NSMutableArray alloc]init];
        [tempParticipantDict setObject:value forKey:key];
    }
    return value;
}

- (BOOL)isUser:(CMORoster *)roster onList:(NSMutableArray *)contacts{
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *cmoUser = [userClient fetchUservCard:roster.username];
    for(int i=0; i < [contacts count]; i++) {
        if([cmoUser.username isEqualToString:[[contacts objectAtIndex:i] valueForKey:@"username"]]) {
            return true;
        }
    }
    
    return false;
//    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"%@",roster.username];
//    NSArray *filteredArray = [contacts filteredArrayUsingPredicate:predicate];
//    return filteredArray.count > 0 ? true : false;
}

- (void)pushChatView:(CMORoomDetails *)info type:(ChatType)type{
    CMOChatContainerViewController *chatContainerVC = [_assembly chatcontainerviewcontroller];
    chatContainerVC.type = type;
    chatContainerVC.owner = owner;
    chatContainerVC.roomInfo = info;
    chatContainerVC.partcipantsList = tempParticipantDict;
    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
    chatContainerVC.hidesBottomBarWhenPushed = true;
    [navController pushViewController:chatContainerVC];
}

-(void)noContentAvailable:(NSString *)noContent
{
    float width = CGRectGetWidth(self.rosterTableView.frame);
    UILabel *lblNoContent = [[UILabel alloc] initWithFrame:CGRectMake(0, 100, width, 40)];
    lblNoContent.text = noContent;
    lblNoContent.textAlignment = NSTextAlignmentCenter;
    lblNoContent.tag = NO_CONTENT_AVAILABLE_TAG;
    UIView *view = [self.rosterTableView viewWithTag:NO_CONTENT_AVAILABLE_TAG];
    if (!view) {
        [self.rosterTableView addSubview:lblNoContent];
    }
}

#pragma mark - Search Implementation

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    [self filterContentForSearchText:searchText];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    searchBar.text = @"";
    [searchBar resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)isUserOnline:(NSString *)userName{
    BOOL isOnline = false;
    
    if (userName.length > 0)
    {
        CMOUserPresence *presence = [[((CMOTabBarController *)self.tabBarController) getUserPresenceDictonary] valueForKey:userName];
        
        if ([presence.from isEqualToString:owner.username]){
            isOnline = true;
        }
        else {
            if ([presence.type isEqualToString:XMPP_PRESENCE_UNAVAILABLE]){
                isOnline = false;
            }
            else if(!presence)
            {
                isOnline = false;
            }
            else
            {
                isOnline = true;
            }
        }
    }
    return isOnline;
}

- (void)updatePresence:(NSNotification *)notification{
    [_rosterTableView reloadData];
}

- (IBAction)backButtonAction:(id)sender
{
    [self selectedParticipants:sender];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void) updateAllusersAndGroups{
    //Initial call to save all users and groups
    rosterModel = [_coreComponents rosterPresentation];
    [rosterModel fetchAllUsersAndGroupsWithCompletionHandler:^(id users) {
        [refreshPhoneContacts endRefreshing];
    } failure:^(NSError *error) {
        [refreshPhoneContacts endRefreshing];
    }];
}

#pragma mark --
#pragma mark New Implementation


#pragma mark --
#pragma mark TableView data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return [[_rosterFetchedResultsController sections] count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   id  sectionInfo = [[_rosterFetchedResultsController sections] objectAtIndex:section];
   NSInteger rowCount = [sectionInfo numberOfObjects];
   if (rowCount <= 0) {
        [self noContentAvailable:ERR_MSG_NO_CONTACT_AVAILABLE];
   }
    return rowCount;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"rostercell"];
    [self setContactToCell:cell withIndex:indexPath];
    
    UIView *selectedBackgroundView = [[UIView alloc] initWithFrame:cell.bounds];
    selectedBackgroundView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    selectedBackgroundView.backgroundColor = [UIColor colorWithRed:234.0/255.0 green:242.0/255.0 blue:255.0/255.0 alpha:1.0];
    [cell setSelectedBackgroundView:selectedBackgroundView];
    
    CMORoster *roster = [_rosterFetchedResultsController objectAtIndexPath:indexPath];
    
    BOOL cellDisable = NO;
    
    //Check if the Roster is already in participant list, if yes, then show checkmark.
    cell.accessoryType = UITableViewCellAccessoryNone;
    if (self.listOfExistParticpants.count > 0){
        NSMutableArray *contactsList = [self.listOfExistParticpants mutableCopy];
        if (exestingParticipants){
            if ([self isUser:roster onList:contactsList]){
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
                // cell.userInteractionEnabled = false;
                cellDisable = YES;
            }else {
                // cell.userInteractionEnabled = true;
                cellDisable = NO;
            }
        }
    }
    
    if(cellDisable){
        cell.userInteractionEnabled = false;
    }else {
        cell.userInteractionEnabled = true;
    }
    
    //cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}



- (void) setContactToCell:(UITableViewCell *)cell withIndex:(NSIndexPath *)userIndex
{
    CMORoster *roster = [_rosterFetchedResultsController objectAtIndexPath:userIndex];
    
//    BOOL cellDisable = NO;
//    
//    //Check if the Roster is already in participant list, if yes, then show checkmark.
//    cell.accessoryType = UITableViewCellAccessoryNone;
//    if (self.listOfExistParticpants.count > 0){
//        NSMutableArray *contactsList = [self.listOfExistParticpants mutableCopy];
//        if (exestingParticipants){
//            if ([self isUser:roster onList:contactsList]){
//                cell.accessoryType = UITableViewCellAccessoryCheckmark;
//               // cell.userInteractionEnabled = false;
//                cellDisable = YES;
//            }else {
//               // cell.userInteractionEnabled = true;
//                cellDisable = NO;
//            }
//        }
//    }
    
    UIImageView *userNameView = (UIImageView *)[cell viewWithTag:PROFILE_IMAGE];
    userNameView.image = [UIImage imageNamed:IMAGE_PROFILE_PIC_PLACEHOLDER];
    userNameView.layer.cornerRadius = IMAGE_RADIUS;
    userNameView.layer.masksToBounds = YES;
    
    UILabel *userNameLabel = (UILabel *)[cell viewWithTag:PROFILE_NAME];
    userNameLabel.text = !roster.name ? roster.username : roster.name;
    
    UILabel *designateLabel = (UILabel *)[cell viewWithTag:PROFILE_DESIGNATION];
    
    if (roster.username.length > 0 && !roster.isFromExchange) {
        id <CMOUserClient>userClient = [_coreComponents userService];
        CMOUser *cmoUser = [userClient fetchUservCard:roster.username];
        if (cmoUser.userAvatar){
            userNameView.image =  cmoUser.userAvatar;
        }
        designateLabel.text = cmoUser.orgTitle;//@"CMO"
    }
    else
    {
        designateLabel.text = @"";
    }
    
    UIImageView *presenceImageView = (UIImageView *)[cell viewWithTag:PROFILE_PRESENCE];
    
    if (isConnected){
        presenceImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[self isUserOnline:roster.username] ? IMAGE_ONLINE_STATUS : IMAGE_OFFLINE_STATUS]];
    }
    else{
        presenceImageView.image = [UIImage imageNamed:@"Status_Offline.png"];
    }
    
    UIImageView *isNonAppUserIV = (UIImageView *)[cell viewWithTag:NON_APP_USER_ICON];//sms
    
    
    if (roster.isSMSUser || roster.isPhoneContact || roster.isFromExchange) {
        [isNonAppUserIV setHidden:NO];
    }
    else{
        [isNonAppUserIV setHidden:YES];
    }
    
    UIImageView *exchangeIcon = (UIImageView *)[cell viewWithTag:EXCHANGE_ICON];
    [exchangeIcon setHidden:YES];
    [cell setBackgroundColor:[UIColor clearColor]];
    if (roster.isFromExchange){
        [exchangeIcon setHidden:NO];
    }
}

- (NSArray *) sectionIndexTitlesForTableView: (UITableView *) tableView{
        return [_rosterFetchedResultsController sectionIndexTitles];
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index{
    return [_rosterFetchedResultsController sectionForSectionIndexTitle:title atIndex:index];
}

#pragma mark --
#pragma mark TableView delegate


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [self.rosterTableView cellForRowAtIndexPath:indexPath];

    if (self.rosterDelegate){
        [self selectDeselectContactCell:cell andItem:(CMORoster *)[_rosterFetchedResultsController objectAtIndexPath:indexPath]];
    }
    else{
        [self loadSelectedContactWithItem:(CMORoster *)[_rosterFetchedResultsController objectAtIndexPath:indexPath]];
    }
    
}

- (void)selectDeselectContactCell:(UITableViewCell *)cell andItem:(id)item{
    NSMutableArray *values = [self arrayForDict:MACROS_CONTACTS];
    if (cell.accessoryType == UITableViewCellAccessoryNone){
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        if (![self isUser:item onList:values]){
            [values addObject:item];
        }
    }
    else{
        cell.accessoryType = UITableViewCellAccessoryNone;
        if ([self isUser:item onList:values]){
            [values removeObject:item];
        }
    }
}

- (void)selectDeselectGroupCell:(UITableViewCell *)cell andItem:(id)item{
//    NSMutableArray *values = [self arrayForDict:MACROS_GROUPS];
//    if (cell.accessoryType == UITableViewCellAccessoryNone){
//        cell.accessoryType = UITableViewCellAccessoryCheckmark;
//        if (![self isGroup:item onList:values]){
//            [values addObject:item];
//        }
//    }
//    else{
//        cell.accessoryType = UITableViewCellAccessoryNone;
//        if ([self isGroup:item onList:values]){
//            [values removeObject:item];
//        }
//    }
}

- (void) loadSelectedContactWithItem:(CMORoster *)contactItem{
    id <CMOUserClient>userClient = [_coreComponents userService];
        owner = [userClient user];
        id <CMORosterClient>rosterClient = [_coreComponents rosterService];
        CMORoster *roster = [rosterClient fetchRoster:owner.username];
        //check for chairman permition
        if ([roster.userPermission.chatInitiation integerValue] == 1)
        {
            NSMutableArray *values = [self arrayForDict:MACROS_CONTACTS];
            
            if (![self isUser:contactItem onList:values])
            {
                [values addObject:contactItem];
            }
            
            [self pushChatView:nil type:ChatTypeNewChat];
        }
}


#pragma mark --
#pragma mark - fetchedResultsController

- (NSFetchedResultsController *)rosterFetchedResultsController {
    
    if (_rosterFetchedResultsController != nil) {
        return _rosterFetchedResultsController;
    }
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription
                                   entityForName:@"CMORoster" inManagedObjectContext:_managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    
    //fetchRequest.predicate = [self getContactsPredicate];
    
    [fetchRequest setFetchBatchSize:20];
    
    NSFetchedResultsController *theFetchedResultsController =
    [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest
                                        managedObjectContext:_managedObjectContext sectionNameKeyPath:@"name"
                                                   cacheName:nil];
    self.rosterFetchedResultsController = theFetchedResultsController;
    _rosterFetchedResultsController.delegate = self;
    
    return _rosterFetchedResultsController;
    
}


- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller {
    // The fetch controller is about to start sending change notifications, so prepare the table view for updates.
    [_rosterTableView beginUpdates];
}


- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type newIndexPath:(NSIndexPath *)newIndexPath {
    
    UITableView *tableView = _rosterTableView;
    
    switch(type) {
            
        case NSFetchedResultsChangeInsert:
            [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeUpdate:
            //[self configureCell:[tableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
            break;
            
        case NSFetchedResultsChangeMove:
            [tableView deleteRowsAtIndexPaths:[NSArray
                                               arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            [tableView insertRowsAtIndexPaths:[NSArray
                                               arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
    }
}


- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id )sectionInfo atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type {
    
    switch(type) {
            
        case NSFetchedResultsChangeInsert:
            [_rosterTableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [_rosterTableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
        case NSFetchedResultsChangeMove:
            
            break;
        case NSFetchedResultsChangeUpdate:
            
            break;
    }
}


- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    // The fetch controller has sent all current change notifications, so tell the table view to process all updates.
    [_rosterTableView endUpdates];
}


#pragma mark --
#pragma mark Search operation

- (void)filterContentForSearchText:(NSString*)searchText{
    [self searchContactsWithString:searchText];
    [_rosterTableView reloadData];
}

- (void)searchContactsWithString:(NSString *)searchString{
    if (searchString.length > 0) {
        
        NSPredicate *fetchRequest;
        
        //id <CMORosterClient>rosterClient = [_coreComponents rosterService];
        //CMORoster *roster = [rosterClient fetchRoster:owner.username];
        
        //add search based on nicname
       // NSString *userName = [rosterClient getUsernameForNicname:searchString];
        
        fetchRequest = [NSPredicate predicateWithFormat:@"username!=%@ AND (username contains[c] %@ OR name contains[c] %@) AND NOT (name IN %@)",owner.username, searchString, searchString, exestingParticipants];
        
        /*if (userName) {
            if (_chatType == ChatTypeExistingChat)
            {
                fetchRequest = [NSPredicate predicateWithFormat:@"username!=%@ AND (username contains[c] %@ OR name contains[c] %@) AND NOT (name IN %@)",owner.username, searchString, searchString, exestingParticipants];
            }
        } else {
            if (_chatType == ChatTypeExistingChat)
            {
                fetchRequest = [NSPredicate predicateWithFormat:@"username!=%@ AND (isFromExchange!=true AND isSMSUser!=true) AND (username contains[c] %@ OR name contains[c] %@) AND NOT (name IN %@)",owner.username, searchString, searchString, exestingParticipants];
            }
            else if ([roster.userPermission.chatInitiation integerValue] != 1){
                fetchRequest = [NSPredicate predicateWithFormat:@"username!=%@ AND (username contains[c] %@ OR name contains[c] %@ OR nicname contains[c] %@) AND NOT (name IN %@)",owner.username, searchString, searchString, searchString, exestingParticipants];
            }
            else{
                fetchRequest = [self searchPredicate:searchString];//[NSPredicate predicateWithFormat:@"username!=%@ AND (username contains[c] %@ OR name contains[c] %@) AND NOT (name IN %@)", owner.username, searchString, searchString, exestingParticipants];
            }
        }*/
        
        _rosterFetchedResultsController.fetchRequest.predicate = fetchRequest;
    }
   
    
    NSError *error;
    if (![[self rosterFetchedResultsController] performFetch:&error]) {
        // Update to handle the error appropriately.
        DDLogError(@"Unresolved error %@, %@", error, [error userInfo]);
    }
}

@end
