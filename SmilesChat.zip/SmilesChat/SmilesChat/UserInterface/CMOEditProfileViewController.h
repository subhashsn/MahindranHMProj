//
//  CMOEditProfileViewController.h
//  CMOChat
//
//  Created by Administrator on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CMOAssembly;
@class CMOEditProfileViewController;
@class CMORoster;
@class CMOCoreComponents;

#import "CMOCountryCodeViewController.h"


@protocol updateProfileDelegate <NSObject>
- (void)updateProfileData:(CMOEditProfileViewController *)controller didFinishEnteringItem:(NSString *)item;
@end

@interface CMOEditProfileViewController : UIViewController<UINavigationControllerDelegate,CountryCodeDelegate>

@property (nonatomic, weak) IBOutlet UILabel *profileName;
@property (nonatomic, weak)IBOutlet UITextField *LastNameField;
@property (nonatomic, weak)IBOutlet UITextField *FirstNameField;
@property (nonatomic, weak)IBOutlet UITextField *designationField;
@property (nonatomic, weak)IBOutlet UITextField *mobileNumberField;
@property (nonatomic, weak)IBOutlet UITextField *countryCodeField;
@property (nonatomic, weak)IBOutlet UITextField *eMailField;
@property (nonatomic, weak)IBOutlet UIImageView *profilePicture;
@property (nonatomic, weak)IBOutlet UIView *profileDisplayView;
@property (nonatomic, weak)IBOutlet UIImageView *profileOuterPicture;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *MobileViewTop;

@property (nonatomic, weak)IBOutlet UIButton *btnLogin;
@property (nonatomic, weak)IBOutlet UIButton *btnCountryCode;

@property (nonatomic, weak) id <updateProfileDelegate> delegate;

@property (strong, nonatomic) CMOAssembly *assembly;

@property (strong, nonatomic) CMORoster *rosterInfo;
@property (strong, nonatomic) CMOCoreComponents *coreComponents;

@end
