//
//  iPadDetailViewController.h
//  CMOChat
//
//  Created by Raju on 11/29/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CMOAssembly;

@interface CMOiPadDetailViewController : UIViewController

@property (nonatomic, strong) CMOAssembly *assembly;

@end

