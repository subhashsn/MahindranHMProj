//
//  CMOEmptyViewController.h
//  CMOChat
//
//  Created by Raju on 12/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CMOAssembly;

@interface CMOEmptyViewController : UIViewController

@property (nonatomic, strong) CMOAssembly *assembly;

@end
