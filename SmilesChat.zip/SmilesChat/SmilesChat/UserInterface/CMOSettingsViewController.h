//
//  CMOSettingsViewController.h
//  CMOChat
//
//  Created by Subhash on 11/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CMOAssembly;
@class CMOCoreComponents;
@class CMOSplitViewController;

@interface CMOSettingsViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *settingsTableView;
//@property (weak, nonatomic) IBOutlet UILabel *versionLabel;

@property (strong, nonatomic) CMOAssembly *assembly;
@property (strong, nonatomic) CMOCoreComponents *coreComponents;
@property (nonatomic, strong) CMOSplitViewController *splitViewController;

@end
