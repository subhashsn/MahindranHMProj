//
//  CMOFullImageViewController.h
//  CMOChat
//
//  Created by Raju on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CMOAssembly;
@class CMOMessage;
@class CMOChatPresentation;

@protocol FullImageViewDelegate <NSObject>

@optional
- (void) updateAttachmentOnDeletionWithObject:(NSUInteger)message;

@end

@interface CMOFullImageViewController : UIViewController

@property (nonatomic, weak) IBOutlet UICollectionView *fullImageCV;
@property (nonatomic, strong) CMOAssembly *assembly;
@property (nonatomic, strong) NSMutableArray *mediaMessage;
@property (nonatomic, strong) NSIndexPath *selectedIndex;
@property (nonatomic, strong) NSString *roomID;

@property (nonatomic, weak) IBOutlet UILabel *iPadTitle;

@property (nonatomic, weak) IBOutlet UILabel *noAttachments;
@property (nonatomic, weak) id <FullImageViewDelegate> delegate;
@property (nonatomic, strong) CMOChatPresentation *chatModel;


@end
