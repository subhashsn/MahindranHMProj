//
//  SLATimerPopOverViewController.h
//  CMOChat
//
//  Created by Raju on 12/5/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CMOAssembly;

@protocol PopOverViewControllerDelegate <NSObject>

@optional
- (void) saveButtonAction;
- (void) cancelButtonAction;
- (void) resetButtonAction;

@end

@interface CMOSLATimerPopOverViewController : UIViewController

@property (nonatomic, assign) NSInteger totalMinutes;
@property (nonatomic, assign) NSInteger interval;
@property (nonatomic, assign) NSInteger selectedInterval;

@property (nonatomic, strong) CMOAssembly *assembly;
@property (nonatomic, weak) IBOutlet UIDatePicker *datePickerView;

@property (nonatomic, retain) id<PopOverViewControllerDelegate> delegate;

@end

