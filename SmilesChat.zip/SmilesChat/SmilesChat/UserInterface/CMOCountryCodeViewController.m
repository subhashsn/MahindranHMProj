//
//  CMOCountryCodeViewController.m
//  CMOChat
//
//  Created by Subhash on 11/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOCountryCodeViewController.h"
#import "CMOTableViewDatasource.h"
#import "CMOTableViewDelegate.h"
#import "CMOAssembly.h"
#import "CMOCoreComponents.h"
#import "CMOMyInfoViewController.h"
#import <JSQMessagesViewController/JSQMessages.h>

@interface CMOCountryCodeViewController ()
{
    CMOTableViewDatasource *dataSource;
    CMOTableViewDelegate *delegate;
    NSDictionary *countryCodeList;
    BOOL isSearching;
}
@end

@implementation CMOCountryCodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        [self settingNavigationBar];
    }
    
    [self initCountryCode];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)settingNavigationBar
{
    float width = CGRectGetWidth([UIScreen mainScreen].applicationFrame);
    UINavigationBar *myBar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 20, width, 44)];
    [self.view addSubview:myBar];
    
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Back"] style:UIBarButtonItemStylePlain target:self action:@selector(goBack:)];
    UINavigationItem *editItem = [[UINavigationItem alloc] initWithTitle:@"Select Country Code"];
    [editItem setLeftBarButtonItem:backButton animated:YES];
    [myBar setItems:[NSArray arrayWithObject:editItem] animated:YES];
    
    self.navigationItem.backBarButtonItem.target = self;
    self.navigationItem.backBarButtonItem.action = @selector(goBack:);
}

-(void)goBack:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)setTableViewOutlets:(NSArray *)items{
    
    dataSource = [[CMOTableViewDatasource alloc]initWithItems:items identifier:@"countrycodecell" configureCell:^(UITableViewCell *cell, id item,NSIndexPath* indexPath) {
        
        UILabel *countryNameLabel = (UILabel *)[cell viewWithTag:100];
        countryNameLabel.text = [item objectForKey:@"name"];
        
        UILabel *countrycodeLabel = (UILabel *)[cell viewWithTag:101];
        countrycodeLabel.text = [item objectForKey:@"code"];
        
    }];
    
    delegate = [[CMOTableViewDelegate alloc]initWithItems:items configureCell:^(NSIndexPath *indexPath, id item) {
        //NSLog(@"%d row",indexPath.row);
        //NSLog(@"%@ name",[item objectForKey:@"name"]);
        NSString *code = [item objectForKey:@"code"];
        [self pushCountryCode:code];
    }];
    
    [delegate setCellHeight:44.0f];
    self.countrycodeTableView.dataSource = dataSource;
    self.countrycodeTableView.delegate = delegate;
}

-(void)initCountryCode{
    
    countryCodeList = [self readJsonFile];
    //NSArray *countryArray = [NSArray arrayWithObjects:@"India",@"Dubai", nil];
    [self setTableViewOutlets:[countryCodeList objectForKey:@"countries"]];
    ////[[data objectForKey:@"countries"] objectAtIndex:0]
}

-(void)pushCountryCode:(NSString *)countryCode
{
    [self.countryCodeDelegate addItemViewController:self didFinishEnteringItem:countryCode];
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

-(NSDictionary *)readJsonFile
{
    NSError *error = nil;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"CountryCode"
                                                         ofType:@"txt"];
    NSData *dataFromFile = [NSData dataWithContentsOfFile:filePath];
    NSDictionary *data = [NSJSONSerialization JSONObjectWithData:dataFromFile
                                                         options:kNilOptions
                                                           error:&error];
    if (error != nil) {
        ////DDLogInfo(@"Error: was not able to load messages.");
        return nil;
    }
    return data;
}

#pragma mark - Search Implementation

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    ////DDLogInfo(@"Text change - %d",isSearching);
    
    NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"name contains[c] %@", searchText];
    if(![[searchText jsq_stringByTrimingWhitespace] isEqualToString:@""]) {
        NSArray *searchresult = [[countryCodeList objectForKey:@"countries"] filteredArrayUsingPredicate:resultPredicate];
        if (dataSource) {
            [dataSource updateDatasource:searchresult];
        }
        if (delegate) {
            [delegate updateDelegate:searchresult];
        }
    } else {
        if (dataSource) {
            [dataSource updateDatasource:[countryCodeList objectForKey:@"countries"]];
        }
        if (delegate) {
            [delegate updateDelegate:[countryCodeList objectForKey:@"countries"]];
        }
    }
    self.countrycodeTableView.dataSource = nil;
    self.countrycodeTableView.dataSource = dataSource;
    [self performSelectorOnMainThread:@selector(reloadTableView) withObject:nil waitUntilDone:false];
    
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    ////DDLogInfo(@"Cancel clicked");
    
    if (dataSource) {
        [dataSource updateDatasource:[countryCodeList objectForKey:@"countries"]];
        self.countrycodeTableView.dataSource = nil;
        self.countrycodeTableView.dataSource = dataSource;
        [self performSelectorOnMainThread:@selector(reloadTableView) withObject:nil waitUntilDone:false];
    }
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    ////DDLogInfo(@"Search Clicked");
    [searchBar resignFirstResponder];
    //[self searchTableList];
}

- (void) reloadTableView {
    [self.countrycodeTableView reloadData];
}

@end
