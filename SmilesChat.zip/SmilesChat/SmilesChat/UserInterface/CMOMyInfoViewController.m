//
//  CMOMyInfoViewController.m
//  CMOChat
//
//  Created by Subhash on 03/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOMyInfoViewController.h"
#import "CMOAssembly.h"
#import "CMOCoreComponents.h"
#import "CMOTabBarController.h"
#import "CMOUtils.h"
#import "CMOUser.h"
#import "CMOUserPresentation.h"
#import "UIImage+Util.h"
#import "CMORosterPresentation.h"
#import "UIImageEffects.h"
#import "CMORoster+CoreDataProperties.h"
#import "AppDelegate.h"
#import "CMOXMPPManager.h"

#define kOFFSET_FOR_KEYBOARD 180.0
#define MAXLENGTH   14
#define ENTER_MOBILE_NUMBER_ALERT_HEADER    @"Enter Mobile Number"
#define ENTER_MOBILE_NUMBER_ALERT_MESSAGE    @"Please Enter a Mobile number"
#define INVALID_MOBILE_NUMBER_ALERT_HEADER   @"Invalid Mobile Number"
#define INVALID_MOBILE_NUMBER_ALERT_MESSAGE   @"Please Enter a Valid Mobile number."

#define TOUCHID_ENABLED_TITLE @"Touch ID login enabled"
#define TOUCHID_ENABLED_MESSAGE @"Your Touch ID login is now enabled.\nYou can always disable this in the Settings."
#define TOUCHID_FAILED_TITLE @"Touch ID login failed"
#define TOUCHID_FAILED_MESSAGE @"App is not able to detect Touch ID from your device. Go to device settings and enable Touch ID."
#define LOADING_TEXT @"Loading..."
#define MYPROFILE_TITLE @"My Profile"
#define EDITPROFILE_TITLE @"Edit Profile"

@import LocalAuthentication;

@interface CMOMyInfoViewController ()<UIImagePickerControllerDelegate>
{
    CMOOtpViewController *otpViewController;
    CMOTabBarController *tabBarController;
    CMOCountryCodeViewController *countryCodeController;
    UIImagePickerController *imagePickerAlbum;
    id <APIClient>apiClient;
    CMORosterPresentation *rosterModel;
    CMORoster *rosterInfo;
    
    UIImage *gAvatarImage;
    //MBProgressHUD *hudProgress;
    AppDelegate *appDelegate;
    BOOL profilePicSet;
}
@end

@implementation CMOMyInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.leftBarButtonItem=nil;
    
    _bSelectCountryCode = FALSE;
    
    [self setLoginUI];
    [self numpadWithToolbar];

    //Add touchID change event
    [_switchTouchID addTarget:self action:@selector(switchChangedForEnabledTouchID:) forControlEvents:UIControlEventValueChanged];
    [self registerNotifications];
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [self fetchmyvCard];
}


- (void)registerNotifications{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(vCardUpdated:) name:XMPP_UPDATE_VCARD_SUCCESS object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(vCardUpdateFailed:) name:XMPP_UPDATE_VCARD_FAILED object:nil];
}

- (void)unRegisterNotifications{
     [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_UPDATE_VCARD_SUCCESS object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_UPDATE_VCARD_FAILED object:nil];
}

- (void)vCardUpdated:(NSNotification *)notification{
    NSLog(@"VCard Updated");
}

- (void)vCardUpdateFailed:(NSNotification *)notification{
    NSLog(@"vCard Update Failed");
}


- (void)fetchmyvCard{
    id <CMOUserClient>client = [_coreComponents userService];
    CMOUser *user = [client fetchUservCard:[client user].username];
    if (user.userAvatar){
        self.profilePicture.image = user.userAvatar;
        self.profileOuterPicture.image = user.userAvatar;
        //self.profileOuterPicture.image = [self imageByApplyingDarkEffectToImage:self.profileOuterPicture.image];
        self.profileOuterPicture.alpha = 0.3;
        profilePicSet = false;
    } else {
        self.profilePicture.image = [UIImage imageNamed:@"ProfilePic_Placeholder.png"];
        self.profileOuterPicture.image = nil;
        self.profileOuterPicture.alpha = 0.3;
    }
    if (user.orgTitle) {
        self.gDesignation = user.orgTitle;
    }
    NSLog(@"User details %@",user);
}


- (void)fetchmyMobileNumber{
    id <CMOUserClient>client = [_coreComponents userService];
    CMOUser *user = [client user];//[client fetchUservCard:[client user].username];
    if (user.username){
        [self getUsesRolesAndPermissions:user.username];
    }
}


-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self unRegisterNotifications];
    [self.mobileNumberField resignFirstResponder];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //if (!_bEditMobileNumber)
    _bEditMobileNumber = FALSE;
    //_bSelectCountryCode = FALSE;
    //[self fetchmyMobileNumber];
    
    [self getUserInfo];
    [self showAndHideScreenDetails];
    if (!profilePicSet) {
        [self fetchmyvCard];
    }

    
    self.FirstNameField.text = self.gFirstName;
    self.LastNameField.text = self.gLastName;
    self.designationField.text = self.gDesignation;
    //[self.btnCountryCode setTitle:self.countryCode forState:UIControlStateNormal];
    
    //Update touchID change event
    [self updateTouchIDSwitch];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Button Actions

- (IBAction)countryCodeAction:(id)sender
{
    if (!countryCodeController){
        countryCodeController = [_assembly countrycodeviewcontroller];
    }
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        countryCodeController.modalPresentationStyle = UIModalPresentationPopover;
        countryCodeController.preferredContentSize = CGSizeMake(320, 500);
        countryCodeController.countryCodeDelegate = self;
        countryCodeController.popoverPresentationController.sourceView = _profileDisplayView;
        countryCodeController.popoverPresentationController.sourceRect = CGRectMake(220, 200, 5, 5);
        countryCodeController.popoverPresentationController.permittedArrowDirections = UIPopoverArrowDirectionDown;
        [self.navigationController presentViewController:countryCodeController animated:YES completion:nil];
        
    } else {
        CMONavigationController *navController = (CMONavigationController *)self.navigationController;
        if (![navController.viewControllers containsObject:countryCodeController]){
            countryCodeController.countryCodeDelegate = self;
            [navController presentViewController:countryCodeController animated:YES completion:nil];
        }
    }
}

- (IBAction)doneAction:(id)sender
{
    
    //Need to check this flow
    
    if ([_mobileNumberField.text isEqualToString:@""])
    {
        [self alertController:ENTER_MOBILE_NUMBER_ALERT_HEADER body:ENTER_MOBILE_NUMBER_ALERT_MESSAGE];
        
    } else if ([_mobileNumberField.text length] < 7 || [_mobileNumberField.text length] > MAXLENGTH)
    {
        [self alertController:INVALID_MOBILE_NUMBER_ALERT_HEADER body:INVALID_MOBILE_NUMBER_ALERT_MESSAGE];
    }
    else
    {
        if (gAvatarImage) {
            [self saveUserInfo:gAvatarImage];
        }
        
        if (_bMyInfoFlag)
        {
            NSString *mobileNumber = [NSString stringWithFormat:@"%@-%@",self.btnCountryCode.titleLabel.text,self.mobileNumberField.text];
            id <CMOUserClient>client = [_coreComponents userService];
            CMOUser *user = [client user];
            
            if (!otpViewController){
                otpViewController = [_assembly otpviewcontroller:mobileNumber userName:user.username];
            }
            CMONavigationController *navController = (CMONavigationController *)self.navigationController;
            if (![navController.viewControllers containsObject:otpViewController]){
                otpViewController.bSaveFlag = _bEditProfile;
                otpViewController.mobileNumber = mobileNumber;
                otpViewController.userName = user.username;
                otpViewController.cmoOTPDelegate = self;
                [navController pushViewController:otpViewController];
            }
        }
        else
        {
            NSLog(@"rosterInfophonenumber %@",rosterInfo.phoneNumber);
            //if (_bEditMobileNumber || _bSelectCountryCode)
            {
                NSString *mobileNumber = [NSString stringWithFormat:@"%@-%@",self.btnCountryCode.titleLabel.text,self.mobileNumberField.text];
                if ([[mobileNumber stringByTrimming] isEqualToString:[rosterInfo.phoneNumber stringByTrimming]]) {
                    [self myProfileOption];
                }
                else
                {
                    id <CMOUserClient>client = [_coreComponents userService];
                    CMOUser *user = [client user];
                    
                    if (!otpViewController){
                        otpViewController = [_assembly otpviewcontroller:mobileNumber userName:user.username];
                    }
                    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
                    if (![navController.viewControllers containsObject:otpViewController]){
                        otpViewController.bSaveFlag = _bEditProfile;
                        otpViewController.mobileNumber = mobileNumber;
                        otpViewController.userName = user.username;
                        otpViewController.cmoOTPDelegate = self;
                        [navController pushViewController:otpViewController];
                    }
                }
            }
            /*else
            {
                [self myProfileOption];
            }*/
        }
    }
}

- (void)addOTPViewController:(CMOOtpViewController *)controller didFinishEnteringItem:(BOOL)flag
{
    //NSLog(@"This was returned from ViewControllerB %@",item);
    _bSelectCountryCode = FALSE;
    _bEditProfile = flag;
}

#pragma mark AlertController

- (void)alertController:(NSString* )title body:(NSString *)bodyText {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:bodyText  preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //[self deleteUser];
    }];
    
    //[alert addAction:cancel];
    [alert addAction:ok];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)addItemViewController:(CMOCountryCodeViewController *)controller didFinishEnteringItem:(NSString *)item
{
    //NSLog(@"This was returned from ViewControllerB %@",item);
    _bSelectCountryCode = TRUE;
    self.countryCode = item;
    [self.btnCountryCode setTitle:item forState:UIControlStateNormal];
}

-(void)updateInfoScreen
{
    /*if(self.countryCode)
    {
        [self.btnCountryCode setTitle:self.countryCode forState:UIControlStateNormal];
    }
    else
    {
        [self.btnCountryCode setTitle:@"+971" forState:UIControlStateNormal];
    }*/
    
    if(!self.countryCode)
        [self.btnCountryCode setTitle:@"+971" forState:UIControlStateNormal];
    
    /*self.gFirstName = @"Zeeshan";
    self.gLastName = @"Ali";
    self.gDesignation = @"Executive";
    self.emailID = @"Zeeshan@Damac.com";
    */
    
    if (self.gFirstName)
    {
        self.FirstNameField.text = self.gFirstName;
    }
    if (self.gLastName)
    {
        self.LastNameField.text = self.gLastName;
    }
    
    if (self.gDesignation) {
        self.designationField.text = self.gDesignation;
        self.lblDesignationForMyProfile.text = self.gDesignation;
    }
    
    if (self.mobileNumber)
    {
        self.lblMobileForMyProfile.text = self.mobileNumber;
        if (self.mobileNumber && [self.mobileNumber length] > 0)
        {
            NSString *countrycode;
            NSString *mobileNumber;
            
            NSArray *number = [_mobileNumber componentsSeparatedByString:@"-"];
            if (number.count > 1) {
                countrycode = number[0];
                mobileNumber = number[1];
            }
            else{
                mobileNumber = [self.mobileNumber substringFromIndex: [self.mobileNumber length] - 9];
                countrycode = [self.mobileNumber substringToIndex: [self.mobileNumber length] - 9];
            }
            
            if (!_bSelectCountryCode) {
                self.mobileNumberField.text = mobileNumber;
                [self.btnCountryCode setTitle:countrycode forState:UIControlStateNormal];
            }
        }
    }
    
    if (self.emailID)
    {
        self.emailField.text = self.emailID;
        self.lblEmailForMyProfile.text = self.emailID;
    }
}


- (void)getUsesRolesAndPermissions:(NSString*)userName {
    //self.mobileNumberUpdateAD = nil;
    
    id <CMOAppServerAPIClient> client = [_coreComponents appServerAPIHandler];
    NSString *url = [NSString stringWithFormat:@"GetUserRolesAndPermissions/%@",userName];
    [client GET:url parameters:nil OnProgress:nil OnSuccess:^(id  _Nullable response) {
        
        NSLog(@"Success response: %@",response);
        //NSDictionary *res = response;
        //id tmpName =  [res objectForKey:@"userName"];
        
        //id tmmPhoneNumber = [res objectForKey:@"phoneNumber"];
        //self.mobileNumberUpdateAD = [res objectForKey:@"phoneNumber"];
        
        //[self updateInfoScreen];
        
    } onFailure:^(NSError * _Nonnull error) {
        //Failure block
        NSLog(@"getUsesRolesAndPermissions error: %@",error);
    }];
}


- (void)getUserInfo{
    
    //hudProgress = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //hudProgress.label.text = LOADING_TEXT;
    
    rosterModel = [_coreComponents rosterPresentation];
    rosterInfo = [rosterModel getCurrentUserInfoWithCompletionHandler:^(CMORoster *users) {
        dispatch_async(dispatch_get_main_queue(), ^(){
            [self displayUserInfo:users];
        });
    } failure:^(NSError *error) {
        NSLog(@"Error in getting users list");
        NSLog(@"userInfo %@",rosterInfo);
        //[self displayUserInfo:userInfo];
    }];
    
    //NSLog(@"userInfo %@",userInfo);
    [self displayUserInfo:rosterInfo];
}

-(void)displayUserInfo:(CMORoster *)userDisplayInfo
{
    //userInfo = users;
    //[hudProgress hideAnimated:YES];
    self.emailID = userDisplayInfo.email;
    NSString *name = userDisplayInfo.name;
    
    NSMutableArray * array = [[NSMutableArray alloc] initWithArray:[name componentsSeparatedByString:@" "]];
    
    if ([array count] > 0) {
        self.gFirstName = [array objectAtIndex:0];
    }
    
    if ([array count] > 1)
        self.gLastName = [[name componentsSeparatedByString:@" "] objectAtIndex:1];
    else
        self.gLastName = @" ";
    
    self.mobileNumber = [userDisplayInfo.phoneNumber stringByTrimming];
    
    //self.gDesignation = userDisplayInfo.userRoles.roleName;
    _lblProfileDisplayName.text = [NSString stringWithFormat: @"%@", name];
    [self updateInfoScreen];
}

-(void)showAndHideScreenDetails
{
    if (_bMyInfoFlag) {
        
        _myProfileView1.hidden = NO;
        _myProfileView2.hidden = NO;
        _myProfileView3.hidden = NO;
        _myProfileView4.hidden = NO;
        
        _myInfoView1.hidden = YES;
        _myInfoView2.hidden = YES;
        _myInfoView3.hidden = YES;
        _myEditView1.hidden = YES;
        
        _btnLogin.hidden = NO;
//        _cameraButton.hidden = YES;
        _cameraButton.hidden = NO;
        _editProfileButton.hidden = YES;
        _backButton.hidden = NO;
        _lblProfileDisplayName.hidden = YES;
    }
    else
    {
        if (_bEditProfile) {
            
            [self editProfileOption];
        }
        else
        {
            _lblTitleName.text =MYPROFILE_TITLE;
            _myProfileView1.hidden = YES;
            _myProfileView2.hidden = YES;
            _myProfileView3.hidden = YES;
            _myProfileView4.hidden = YES;
            
            _myInfoView1.hidden = NO;
            _myInfoView2.hidden = NO;
            _myInfoView3.hidden = NO;
            
            _myEditView1.hidden = YES;
            
            _btnLogin.hidden = YES;
            _cameraButton.hidden = YES;
            _editProfileButton.hidden = NO;
            _backButton.hidden = NO;
            _lblProfileDisplayName.hidden = NO;
            _bEditProfile = FALSE;
        }
    }
}

#pragma mark - Image Picker Controller delegate methods

-(IBAction)clickCameraIcon:(id)sender
{
    //NSLog(@"clickCameraIcon");
    //disable image update
    [self selectCameraIcon];
}

#pragma mark - Image Picker Controller delegate methods

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    appDelegate.isPortrait = NO;
    UIImage *selectedImage = (picker.sourceType == UIImagePickerControllerSourceTypeCamera) ? info[UIImagePickerControllerEditedImage] :  info[UIImagePickerControllerEditedImage];
    
    self.profilePicture.image = selectedImage;
    self.profilePicture.layer.cornerRadius = 60;
    self.profilePicture.layer.masksToBounds = YES;
    
    //NSLog(@"Size of Image(bytes):%lu",[UIImagePNGRepresentation(selectedImage) length]);
    
    self.profileOuterPicture.image = selectedImage;
    self.profileOuterPicture.alpha = 0.3;
    
    //self.profileOuterPicture.image = [self imageByApplyingDarkEffectToImage:self.profileOuterPicture.image];
    
    //UIImage *avatarImage = [self.profilePicture.image normalizedImage:CGSizeMake(64, 64)];
    gAvatarImage = [self.profilePicture.image normalizedImage:CGSizeMake(256,256)];
    //NSLog(@"Size of Image(bytes):%lu",[UIImagePNGRepresentation(avatarImage) length]);
    
    profilePicSet = true;
    //[self saveUserInfo:avatarImage];
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    appDelegate.isPortrait = NO;
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

-(void)takePhoto
{
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        imagePickerAlbum = [[UIImagePickerController alloc] init];
        imagePickerAlbum.delegate = self;
        imagePickerAlbum.allowsEditing = YES;
        imagePickerAlbum.sourceType = UIImagePickerControllerSourceTypeCamera;
        
        [self.navigationController presentViewController:imagePickerAlbum animated:YES completion:nil];
    }
}

-(void)selectPhoto
{
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum])
    {
        imagePickerAlbum = [[UIImagePickerController alloc] init];
        imagePickerAlbum.delegate = self;
        imagePickerAlbum.allowsEditing = YES;
        imagePickerAlbum.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        {
            imagePickerAlbum.modalPresentationStyle = UIModalPresentationPageSheet;
            appDelegate.isPortrait = YES;
        }
        [self.navigationController presentViewController:imagePickerAlbum animated:YES completion:nil];
    }
}

-(void)selectCameraIcon
{
    UIAlertController *alert;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        alert = [UIAlertController
                 alertControllerWithTitle:nil      //  Must be "nil", otherwise a blank title area will appear above our two buttons
                 message:nil
                 preferredStyle:UIAlertControllerStyleAlert];
        
        alert.popoverPresentationController.sourceView = self.view;
        alert.popoverPresentationController.sourceRect = self.view.frame;
    }
    else
    {
        alert = [UIAlertController
                 alertControllerWithTitle:nil      //  Must be "nil", otherwise a blank title area will appear above our two buttons
                 message:nil
                 preferredStyle:UIAlertControllerStyleActionSheet];
    }
    
    UIAlertAction* btnCancel = [UIAlertAction
                              actionWithTitle:@"Cancel"
                              style:UIAlertActionStyleCancel
                              handler:^(UIAlertAction * action)
                              {
                                  //  UIAlertController will automatically dismiss the view
                              }];
    
    UIAlertAction* btnTakePhoto = [UIAlertAction
                              actionWithTitle:@"Take photo"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  [self takePhoto];
                              }];
    
    UIAlertAction* btnChooseExisting = [UIAlertAction
                              actionWithTitle:@"Choose Existing"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  [self selectPhoto];
                              }];
    
    [alert addAction:btnCancel];
    [alert addAction:btnTakePhoto];
    [alert addAction:btnChooseExisting];
    [self presentViewController:alert animated:YES completion:nil];
}


-(IBAction)editProfile:(id)sender
{
    NSLog(@"EditProfile");
    
    if (self.mobileNumber)
    {
        if (self.mobileNumber && [self.mobileNumber length] > 0)
        {
            NSString *countrycode;
            NSString *mobileNumber;
            
            NSArray *number = [self.mobileNumber componentsSeparatedByString:@"-"];
            if (number.count > 1) {
                countrycode = number[0];
                mobileNumber = number[1];
            }
            else{
                mobileNumber = [self.mobileNumber substringFromIndex: [self.mobileNumber length] - 9];
                countrycode = [self.mobileNumber substringToIndex: [self.mobileNumber length] - 9];
            }
            
//            NSString *mobileNumber = [self.mobileNumber substringFromIndex: [self.mobileNumber length] - 10];
            self.mobileNumberField.text = mobileNumber;
            
//            NSString *countrycode = [self.mobileNumber substringToIndex: [self.mobileNumber length] - 10];
            [self.btnCountryCode setTitle:countrycode forState:UIControlStateNormal];
        }
    }
    
    [self editProfileOption];
}

-(IBAction)backAction:(id)sender
{
    self.profilePicture.image = nil;
    self.profileOuterPicture.image = nil;
    gAvatarImage = nil;
    [self fetchmyvCard];
    [self myProfileOption];
}

-(void)myProfileOption
{
    if (!_bEditProfile)
    {
        if (_bMyInfoFlag) {
            CMOXMPPManager *xmppManager = (CMOXMPPManager *)[_coreComponents xmppManager];
            [xmppManager disconnect];
            [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:@"logout"];
        }
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
    
    if (_bEditProfile) {
        _bEditProfile = FALSE;
    }
    
    _myProfileView1.hidden = YES;
    _myProfileView2.hidden = YES;
    _myProfileView3.hidden = YES;
    _myProfileView4.hidden = YES;
    
    _myInfoView1.hidden = NO;
    _myInfoView2.hidden = NO;
    _myInfoView3.hidden = NO;
    
    _myEditView1.hidden = YES;
    
    _btnLogin.hidden = YES;
    _cameraButton.hidden = YES;
    _editProfileButton.hidden = NO;
    _backButton.hidden = NO;
    
    _lblTitleName.text = MYPROFILE_TITLE;
    _lblProfileDisplayName.hidden = NO;
}

-(void)editProfileOption
{
    if (!_bEditProfile) {
        _bEditProfile = TRUE;
    }
    
    _myProfileView1.hidden = NO;
    _myProfileView2.hidden = NO;
    _myProfileView3.hidden = YES;
    _myProfileView4.hidden = NO;
    
    _myInfoView1.hidden = YES;
    _myInfoView2.hidden = YES;
    _myInfoView3.hidden = YES;
    
    _lblProfileDisplayName.hidden = YES;
    _myEditView1.hidden = NO;
    
    _btnLogin.hidden = NO;
    //disabling edit image
//    _cameraButton.hidden = YES;
    _cameraButton.hidden = NO;
    _editProfileButton.hidden = YES;
    _backButton.hidden = NO;
    
    _lblTitleName.text = EDITPROFILE_TITLE;
    [_btnLogin setTitle:@"Save" forState:UIControlStateNormal];
}

#pragma mark TextField Return

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    NSInteger nextTag = textField.tag + 1;
    // Try to find next responder
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    if (nextResponder) {
        // Found next responder, so set it.
        [nextResponder becomeFirstResponder];
    } else {
        // Not found, so remove keyboard.
        [textField resignFirstResponder];
    }
    return NO; // We do not want UITextField to insert line-breaks.
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        // allow backspace
        if (!string.length)
        {
            return YES;
        }
        // Prevent invalid character input, if keyboard is numberpad
        if (textField.keyboardType == UIKeyboardTypeNumberPad)
        {
            if ([string rangeOfCharacterFromSet:[NSCharacterSet decimalDigitCharacterSet].invertedSet].location != NSNotFound)
            {
                return NO;
            }
        }
        // verify max length has not been exceeded
        NSString *proposedText = [textField.text stringByReplacingCharactersInRange:range withString:string];
        
        if (proposedText.length > MAXLENGTH)
        {
            return NO;
        }
        return YES;
    }
    else{
        NSUInteger length = [textField.text length] ;
        if (length >= MAXLENGTH && ![string isEqualToString:@""]) {
            self.mobileNumberField.text = [textField.text substringToIndex:MAXLENGTH];
            //self.mobileNumber = self.mobileNumberField.text;
            //[self saveUserMobileInfo:self.mobileNumber];
            return NO;
        }
        _bEditMobileNumber = TRUE;
        return YES;
    }
}


#pragma mark Set Login UI

- (void)setLoginUI
{
    self.profilePicture.layer.cornerRadius = 60;
    self.profilePicture.layer.masksToBounds = YES;
}

#pragma mark UITextField Delegates

-(void)setViewMovedUp:(BOOL)movedUp
{
    [UIView beginAnimations:nil context:NULL];
    
    [UIView setAnimationDuration:0.3]; // if you want to slide up the view
    
    CGRect rect = self.view.frame;
    
    if (movedUp)
    {
        // 1. move the view's origin up so that the text field that will be hidden come above the keyboard
        // 2. increase the size of the view so that the area behind the keyboard is covered up.
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        {
            rect.origin.y -= 350;
        }
        else
        {
            rect.origin.y -= kOFFSET_FOR_KEYBOARD;
            rect.size.height += kOFFSET_FOR_KEYBOARD;
        }
        self.continueBtnTop.constant += kOFFSET_FOR_KEYBOARD;
    }
    else
    {
        // revert back to the normal state.
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        {
            rect.origin.y += 350;
        }
        else
        {
            rect.origin.y += kOFFSET_FOR_KEYBOARD;
            rect.size.height -= kOFFSET_FOR_KEYBOARD;
        }
        self.continueBtnTop.constant -= kOFFSET_FOR_KEYBOARD;
    }
    self.view.frame = rect;
    
    [UIView commitAnimations];
    [self.view updateConstraints];
}


-(void)textFieldDidEndEditing:(UITextField *)sender
{
    if  (self.view.frame.origin.y <= 0)
    {
        [self setViewMovedUp:NO];
    }
}

-(void)textFieldDidBeginEditing:(UITextField *)sender
{
    //move the main view, so that the keyboard does not hide it.
    if  (self.view.frame.origin.y >= 0)
    {
        [self setViewMovedUp:YES];
    }
}

#pragma mark Set navigation bar title

- (void)setTitle:(NSString *)title
{
    [super setTitle:title];
    UILabel *titleView = (UILabel *)self.navigationItem.titleView;
    if (!titleView) {
        titleView = [[UILabel alloc] initWithFrame:CGRectZero];
        titleView.backgroundColor = [UIColor clearColor];
        titleView.font = [UIFont boldSystemFontOfSize:20.0];
        titleView.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
        
        titleView.textColor = [UIColor whiteColor];
        
        self.navigationItem.titleView = titleView;
    }
    titleView.text = title;
    [titleView sizeToFit];
}

- (void)settingNavigationBar
{
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new]
                                                  forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.shadowImage = [UIImage new];
    self.navigationController.navigationBar.translucent = YES;
    self.navigationController.view.backgroundColor = [UIColor clearColor];
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
    
    [self setTitle:@"My Info"];
}

#pragma mark Save User Information - XMPP vCard

- (void)saveUserInfo:(UIImage *)avatarImage{
    if (self.profilePicture.image){
        //Owner is the logged in user
        CMOUserPresentation *userPresentation = [_coreComponents userPresentation];

        CMOUser *owner = [userPresentation user];
        
        CMOUser *user = [[CMOUser alloc]init];
        user.username = owner.username;
        user.userAvatar = avatarImage;
        
        [userPresentation setUserInformation:user];
    }
}

- (void)saveUserMobileInfo:(NSString *)mobileNumber{
    if ([mobileNumber isEqualToString:@""] > 0){
        //Owner is the logged in user
        CMOUserPresentation *userPresentation = [_coreComponents userPresentation];
        
        CMOUser *owner = [userPresentation user];
        
        CMOUser *user = [[CMOUser alloc]init];
        user.username = owner.username;
        //user.mobileNumber = mobileNumber;
        
        [userPresentation setUserInformation:user];
    }
}

#pragma mark Numpad with Toolbar

-(void)numpadWithToolbar
{
    float width = CGRectGetWidth([UIScreen mainScreen].applicationFrame);
    UIToolbar *accessoryView = [[UIToolbar alloc]
                                initWithFrame:CGRectMake(0, 0, width, 50)];
    UIBarButtonItem *space = [[UIBarButtonItem alloc]
                              initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                              target:nil
                              action:nil];
    UIBarButtonItem *done = [[UIBarButtonItem alloc]
                             initWithBarButtonSystemItem:UIBarButtonSystemItemDone
                             target:self
                             action:@selector(selectDoneButton)];
    accessoryView.items = @[space, done, space];
    self.mobileNumberField.inputAccessoryView = accessoryView;
}

- (void)selectDoneButton {
    [self.mobileNumberField resignFirstResponder];
}

#pragma mark touch ID functionality

- (void) switchChangedForEnabledTouchID:(id)sender
{
    UISwitch* switchControl = sender;
    
    if([switchControl isOn])
    {
        [self canEvaluatePolicy];
    }
    else
    {
        [CMOUtils setUserDefaultForTouchID:@"NO"];
    }
}

- (void) updateTouchIDSwitch
{
    BOOL isTouchEnable = [CMOUtils getTouchIDUserDefaultValue];
    [_switchTouchID setOn:isTouchEnable];
}

- (void)canEvaluatePolicy
{
    LAContext *context = [[LAContext alloc] init];
    NSString *message;
    NSString *title;
    NSError *error;
    BOOL success;
    
    // test if we can evaluate the policy, this test will tell us if Touch ID is available and enrolled
    success = [context canEvaluatePolicy: LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error];
    
    if (success)
    {
        title = TOUCHID_ENABLED_TITLE;
        message = TOUCHID_ENABLED_MESSAGE;
        
        [_switchTouchID setOn:YES];
        [CMOUtils setUserDefaultForTouchID:@"YES"];
    }
    else
    {
        title = TOUCHID_FAILED_TITLE;
        message = TOUCHID_FAILED_MESSAGE;
        
        [_switchTouchID setOn:NO];
        [CMOUtils setUserDefaultForTouchID:@"NO"];
    }
    [self showTouchAlertWithSuccess:success andMessage:message andTitle:title];
}

- (void) showTouchAlertWithSuccess:(BOOL) success andMessage:(NSString *)message andTitle:(NSString *)title
{
#warning all touch ID image as per UI
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okButton = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];
                }];
    [alert addAction:okButton];
    
    [self presentViewController:alert animated:YES completion:nil];

}

- (UIImage *)imageByApplyingDarkEffectToImage:(UIImage*)inputImage
{
    UIColor *tintColor = [UIColor colorWithWhite:0.21 alpha:0.11];
    return [UIImageEffects imageByApplyingBlurToImage:inputImage withRadius:10 tintColor:tintColor saturationDeltaFactor:1.8 maskImage:nil];
}

- (IBAction)closeView:(id)sender
{
    gAvatarImage = nil;
    _profilePicture.image = nil;
    _profileOuterPicture.image = nil;
    
    [self fetchmyvCard];
    
    CMOXMPPManager *xmppManager = (CMOXMPPManager *)[_coreComponents xmppManager];
    [xmppManager disconnect];
    [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:@"logout"];
    
    [self.navigationController popViewControllerAnimated:YES];
}

@end
