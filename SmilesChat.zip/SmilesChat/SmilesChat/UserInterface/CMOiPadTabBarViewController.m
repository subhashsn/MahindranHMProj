//
//  CMOiPadTabBarViewController.m
//  CMOChat
//
//  Created by Raju on 11/28/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOiPadTabBarViewController.h"
#import "CMOUtils.h"
#import "CMOUserPresence.h"
#import "AppDelegate.h"

@interface CMOiPadTabBarViewController ()
{
    NSMutableDictionary *userPresenceDict;
    AppDelegate *appDelegate;
}

@end

@implementation CMOiPadTabBarViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [[UITabBar appearance] setSelectionIndicatorImage:[[UIImage imageNamed:@"TabImageSelectedBG"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    
    [CMOUtils checkNetworkReachability];
    UIImage* tabBarBackground = [UIImage imageNamed:@""];
    [[UITabBar appearance] setBackgroundImage:tabBarBackground];
    
    //Set selected background image based on width
    UIImage *selTab = [[UIImage imageNamed:@"TabImageSelectedBG"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    CGSize tabSize = CGSizeMake(([UIScreen mainScreen].bounds.size.width * 0.38)/3, 49);
    UIGraphicsBeginImageContext(tabSize);
    [selTab drawInRect:CGRectMake(0, 0, tabSize.width, tabSize.height)];
    UIImage *reSizeImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    
    [[UITabBar appearance] setSelectionIndicatorImage:reSizeImage];
    
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont
                                                                           fontWithName:@"Helvetica-Regular" size:20], NSFontAttributeName,
                                [UIColor whiteColor], NSForegroundColorAttributeName, nil];
    
    [[UINavigationBar appearance] setTitleTextAttributes:attributes];
    
    [[UITabBar appearance] setBarTintColor:[UIColor colorWithRed:(0.0/255.0) green:(0.0/255.0) blue:(0.0/255.0) alpha:1.0]];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor] }
                                             forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor] }
                                             forState:UIControlStateSelected];
    //self.delegate = self;
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        userPresenceDict = [[NSMutableDictionary alloc]init];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(userPresenceUpdated:) name:XMPP_PRESENCE_NOTIFICATION object:nil];
    }
    
//    [self setDelegate:self];
//    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//    _oldSelection = @"Conversation";
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [self setDelegate:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillLayoutSubviews {
    
    CGRect tabFrame = self.view.frame; //self.TabBar is IBOutlet of your TabBar
    tabFrame.size.width = [UIScreen mainScreen].bounds.size.width * 0.38;
    self.view.frame = tabFrame;
}

#pragma mark User Presence

- (void)userPresenceUpdated:(NSNotification *)notification{
    CMOUserPresence *presence = (CMOUserPresence *)[notification.userInfo valueForKey:@"presence"];
    if (presence && presence.from && !presence.isMUC)
    {
        [userPresenceDict setValue:presence forKey:presence.from];
        [[NSNotificationCenter defaultCenter] postNotificationName:XMPP_USER_PRESENCE_NOTIFICATION object:nil];
    }
}

- (NSMutableDictionary *) getUserPresenceDictonary
{
    return userPresenceDict;
}

- (void) removeUserPresence
{
    if (userPresenceDict)
    {
        [userPresenceDict removeAllObjects];
    }
}

/*
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{

    NSString *selectedItem = tabBar.selectedItem.title;
    NSLog(@"item : %@", tabBar.selectedItem.title);
    if (!appDelegate.isReloadSplitView && [_oldSelection isEqualToString:@"Conversation"] && ![_oldSelection isEqualToString:tabBar.selectedItem.title])
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"Do you want to discard the changes?" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *cancelButton = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                       {
                                           [self setSelectedIndex:0];
                                       }];
        UIAlertAction *yesButton = [UIAlertAction actionWithTitle:@"Yes" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                    {
                                        _oldSelection = tabBar.selectedItem.title;
                                        appDelegate.isReloadSplitView = YES;
                                        
                                        if ([selectedItem isEqualToString:@"Contacts"]) {
                                            [self setSelectedIndex:1];
                                        }
                                        else if ([selectedItem isEqualToString:@"Settings"]) {
                                            [self setSelectedIndex:2];
                                        }

                                    }];
        [alertController addAction:cancelButton];
        [alertController addAction:yesButton];
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else{
        _oldSelection = tabBar.selectedItem.title;
    }
}
*/
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController {
    appDelegate.isReloadSplitView= YES;
    appDelegate.isConversationReload = YES;
    return viewController != tabBarController.selectedViewController;
}


@end
