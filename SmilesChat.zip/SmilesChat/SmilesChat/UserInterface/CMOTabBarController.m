//
//  CMORootViewController.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOTabBarController.h"
#import "CMOAssembly.h"
#import "CMOUtils.h"
#import "CMOUserPresence.h"

@interface CMOTabBarController (){
    CMOAssembly *_assembly;
    NSMutableDictionary *userPresenceDict;
}

@end

@implementation CMOTabBarController

- (id)initWithAssembly:(CMOAssembly *)assembly{
    self = [super init];
    if (self){
        _assembly = assembly;
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //[[UITabBar appearance] setTintColor:[UIColor redColor]];
    //[[UITabBar appearance] setBarTintColor:[UIColor yellowColor]];
    
    [CMOUtils checkNetworkReachability];
    [self setDelegate:self];
    
    UIImage* tabBarBackground = [UIImage imageNamed:@""];
    [[UITabBar appearance] setBackgroundImage:tabBarBackground];
    
    UIImage *selTab = [[UIImage imageNamed:@"TabImageSelectedBG"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    CGSize tabSize = CGSizeMake(([UIScreen mainScreen].bounds.size.width)/3, 49);
    UIGraphicsBeginImageContext(tabSize);
    [selTab drawInRect:CGRectMake(0, 0, tabSize.width, tabSize.height)];
    UIImage *reSizeImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();

    [[UITabBar appearance] setSelectionIndicatorImage:reSizeImage];
    
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont
                                                                           fontWithName:@"Helvetica-Regular" size:20], NSFontAttributeName,
                                [UIColor whiteColor], NSForegroundColorAttributeName, nil];
    
    [[UINavigationBar appearance] setTitleTextAttributes:attributes];
    
    [[UITabBar appearance] setBarTintColor:[UIColor colorWithRed:(0.0/255.0) green:(0.0/255.0) blue:(0.0/255.0) alpha:1.0]];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor] }
                                             forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor] }
                                             forState:UIControlStateSelected];
    //self.delegate = self;
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        userPresenceDict = [[NSMutableDictionary alloc]init];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(userPresenceUpdated:) name:XMPP_PRESENCE_NOTIFICATION object:nil];
    }
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setTabBarItem:(UITabBarItem *)tabBarItem
{
    NSLog(@"setTabBarItem");
}

-(void)setHidden:(BOOL)flag
{
    if (flag)
        [self.tabBar setHidden:YES];
    else
        [self.tabBar setHidden:NO];
    
    return;
}

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController {
    return viewController != tabBarController.selectedViewController;
}

#pragma mark User Presence

- (void)userPresenceUpdated:(NSNotification *)notification{
    CMOUserPresence *presence = (CMOUserPresence *)[notification.userInfo valueForKey:@"presence"];
    if (presence && presence.from && !presence.isMUC)
    {
        [userPresenceDict setValue:presence forKey:presence.from];
        [[NSNotificationCenter defaultCenter] postNotificationName:XMPP_USER_PRESENCE_NOTIFICATION object:nil];
    }
}

- (NSMutableDictionary *) getUserPresenceDictonary
{
    return userPresenceDict;
}

- (void) removeUserPresence
{
    if (userPresenceDict)
    {
        [userPresenceDict removeAllObjects];
    }
}

@end
