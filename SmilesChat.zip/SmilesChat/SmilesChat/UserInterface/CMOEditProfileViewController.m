//
//  CMOEditProfileViewController.m
//  CMOChat
//
//  Created by Administrator on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOEditProfileViewController.h"
#import "CMOAssembly.h"
#import "CMORoster+CoreDataProperties.h"
#import "CMOCoreComponents.h"
#import "CMOUser.h"
#import "CMOOtpViewController.h"
#import "UIImage+Util.h"
#import "CMOUserPresentation.h"
#import "AppDelegate.h"

#define kOFFSET_FOR_KEYBOARD 180.0
#define MAXLENGTH   14

@interface CMOEditProfileViewController ()<UIImagePickerControllerDelegate, MyOTPViewDelegate>
{
    UIImagePickerController *imagePickerAlbum;
    CMOCountryCodeViewController *countryCodeController;
    
    CMOOtpViewController *otpViewController;
    BOOL updateProfileImage;
    UIImage *avtImage;
    MBProgressHUD *hudProgress;
    AppDelegate *appDelegate;
}
@end

@implementation CMOEditProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self numpadWithToolbar];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        [self fetchmyvCard];
    }
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.profilePicture.layer.cornerRadius = 60;
    self.profilePicture.layer.masksToBounds = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Country Code Action

- (IBAction)countryCodeAction:(id)sender
{
    if (!countryCodeController){
        countryCodeController = [_assembly countrycodeviewcontroller];
    }
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        countryCodeController.modalPresentationStyle = UIModalPresentationPopover;
        countryCodeController.preferredContentSize = CGSizeMake(320, 500);
        countryCodeController.countryCodeDelegate = self;
        countryCodeController.popoverPresentationController.sourceView = _profileDisplayView;
        countryCodeController.popoverPresentationController.sourceRect = CGRectMake(80, 150, 5, 5);
        countryCodeController.popoverPresentationController.permittedArrowDirections = UIPopoverArrowDirectionDown;
        //        countryCodeController.popoverPresentationController.delegate = self;
        [self.navigationController presentViewController:countryCodeController animated:YES completion:nil];
        
    } else {
        CMONavigationController *navController = (CMONavigationController *)self.navigationController;
        if (![navController.viewControllers containsObject:countryCodeController]){
            countryCodeController.countryCodeDelegate = self;
            [navController presentViewController:countryCodeController animated:YES completion:nil];
        }
    }
}

- (void)addItemViewController:(CMOCountryCodeViewController *)controller didFinishEnteringItem:(NSString *)item
{
    //NSLog(@"This was returned from ViewControllerB %@",item);
    [self.btnCountryCode setTitle:item forState:UIControlStateNormal];
}

#pragma mark - save Action

- (IBAction)saveAction:(id)sender
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        
        BOOL isUpdated = NO;
        
        NSString *mobileNumber = [NSString stringWithFormat:@"%@-%@",self.btnCountryCode.titleLabel.text,self.mobileNumberField.text];
        if (![mobileNumber isEqualToString:_rosterInfo.phoneNumber])
        {
            if (_mobileNumberField.text.length < 7 || _mobileNumberField.text.length > 14) {
                UIAlertController *alert = [UIAlertController
                         alertControllerWithTitle:nil      //  Must be "nil", otherwise a blank title area will appear above our two buttons
                         message:@"Please Enter a Valid Mobile number."
                         preferredStyle:UIAlertControllerStyleAlert];
            
                UIAlertAction* btnCancel = [UIAlertAction
                                            actionWithTitle:@"OK"
                                            style:UIAlertActionStyleCancel
                                            handler:^(UIAlertAction * action)
                                            {
                                                //  UIAlertController will automatically dismiss the view
                                            }];
                
                [alert addAction:btnCancel];
                [self presentViewController:alert animated:YES completion:nil];
                return;
            }
            
            isUpdated = YES;
            id <CMOUserClient>client = [_coreComponents userService];
            CMOUser *user = [client user];
            
            if (!otpViewController){
                otpViewController = [_assembly otpviewcontroller:mobileNumber userName:user.username];
            }
            CMONavigationController *navController = (CMONavigationController *)self.navigationController;
            if (![navController.viewControllers containsObject:otpViewController]){
                otpViewController.mobileNumber = mobileNumber;
                otpViewController.userName = user.username;
                otpViewController.cmoOTPDelegate = self;
                otpViewController.bSaveFlag = YES;
                [navController pushViewController:otpViewController];
            }
        }
        if (updateProfileImage) {
            updateProfileImage = NO;
            isUpdated = YES;
            [self saveUserInfo:avtImage];
            UIWindow *frontWindow = [[[UIApplication sharedApplication] windows]lastObject];
            hudProgress = [MBProgressHUD showHUDAddedTo:frontWindow.rootViewController.view animated:YES];
            hudProgress.label.text = @"Loading...";
            
            dispatch_async(dispatch_get_main_queue(),^{
                [self performSelector:@selector(goBack:) withObject:self afterDelay:5.0f];
            });
        }
        if(!isUpdated)
        {
            [self goBack:self];
        }
    }
    else{
        ////DDLogInfo(@"saveAction");
        NSString *mobileNumber = [NSString stringWithFormat:@"%@%@",self.btnCountryCode.titleLabel.text,self.mobileNumberField.text];
        [self.delegate updateProfileData:self didFinishEnteringItem:mobileNumber];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - Image Picker Controller delegate methods

-(IBAction)clickCameraIcon:(id)sender
{
    //NSLog(@"clickCameraIcon");
    
    [self selectCameraIcon];
}

#pragma mark - Image Picker Controller delegate methods

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    appDelegate.isPortrait = NO;
    UIImage *selectedImage;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        updateProfileImage = YES;
        selectedImage = info[UIImagePickerControllerEditedImage];
    }
    else{
        selectedImage = info[UIImagePickerControllerEditedImage];
    }
    
    self.profilePicture.image = selectedImage;
    self.profilePicture.layer.cornerRadius = 60;
    self.profilePicture.layer.masksToBounds = YES;
    
    self.profileOuterPicture.image = selectedImage;
    self.profileOuterPicture.alpha = 0.3;
    //[self.profileDisplayView addSubview:self.profilePicture];
    //self.profileDisplayView.alpha = 0.5;
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        avtImage = [_profilePicture.image normalizedImage:CGSizeMake(128, 128)];
    }
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    appDelegate.isPortrait = NO;
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

-(void)takePhoto
{
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        imagePickerAlbum = [[UIImagePickerController alloc] init];
        imagePickerAlbum.delegate = self;
        imagePickerAlbum.allowsEditing = YES;
        imagePickerAlbum.sourceType = UIImagePickerControllerSourceTypeCamera;
        
        [self.navigationController presentViewController:imagePickerAlbum animated:YES completion:nil];
    }
}

-(void)selectPhoto
{
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum])
    {
        imagePickerAlbum = [[UIImagePickerController alloc] init];
        imagePickerAlbum.delegate = self;
        imagePickerAlbum.allowsEditing = YES;
        imagePickerAlbum.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        
        //Show image list in landscape
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        {
            imagePickerAlbum.modalPresentationStyle = UIModalPresentationPageSheet;
            appDelegate.isPortrait = YES;
        }
        
        [self.navigationController presentViewController:imagePickerAlbum animated:YES completion:nil];
    }
}

-(void)selectCameraIcon
{
    
    UIAlertController *alert;
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        alert = [UIAlertController
                 alertControllerWithTitle:nil      //  Must be "nil", otherwise a blank title area will appear above our two buttons
                 message:nil
                 preferredStyle:UIAlertControllerStyleAlert];
        
        alert.popoverPresentationController.sourceView = self.view;
        alert.popoverPresentationController.sourceRect = self.view.frame;
    }
    else
    {
        alert = [UIAlertController
                 alertControllerWithTitle:nil      //  Must be "nil", otherwise a blank title area will appear above our two buttons
                 message:nil
                 preferredStyle:UIAlertControllerStyleActionSheet];
    }
    
    UIAlertAction* btnCancel = [UIAlertAction
                              actionWithTitle:@"Cancel"
                              style:UIAlertActionStyleCancel
                              handler:^(UIAlertAction * action)
                              {
                                  //  UIAlertController will automatically dismiss the view
                              }];
    
    UIAlertAction* btnTakePhoto = [UIAlertAction
                              actionWithTitle:@"Take photo"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  [self takePhoto];
                              }];
    
    UIAlertAction* btnChooseExisting = [UIAlertAction
                              actionWithTitle:@"Choose Existing"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  [self selectPhoto];
                              }];
    
    [alert addAction:btnCancel];
    [alert addAction:btnTakePhoto];
    [alert addAction:btnChooseExisting];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark TextField Return

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    NSInteger nextTag = textField.tag + 1;
    // Try to find next responder
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    if (nextResponder) {
        // Found next responder, so set it.
        [nextResponder becomeFirstResponder];
    } else {
        // Not found, so remove keyboard.
        [textField resignFirstResponder];
    }
    return NO; // We do not want UITextField to insert line-breaks.
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        // allow backspace
        if (!string.length)
        {
            return YES;
        }
        // Prevent invalid character input, if keyboard is numberpad
        if (textField.keyboardType == UIKeyboardTypeNumberPad)
        {
            if ([string rangeOfCharacterFromSet:[NSCharacterSet decimalDigitCharacterSet].invertedSet].location != NSNotFound)
            {
                return NO;
            }
        }
        // verify max length has not been exceeded
        NSString *proposedText = [textField.text stringByReplacingCharactersInRange:range withString:string];
        
        if (proposedText.length > MAXLENGTH) // 10 was chosen for SSN verification
        {
            return NO;
        }
        return YES;
    }
    else{
        NSUInteger length = [textField.text length] ;
        if (length >= MAXLENGTH && ![string isEqualToString:@""]) {
            //textField.text = [textField.text substringToIndex:MAXLENGTH];
            self.mobileNumberField.text = [textField.text substringToIndex:MAXLENGTH];
            return NO;
        }
        return YES;
    }
}

#pragma mark UITextField Delegates

-(void)setViewMovedUp:(BOOL)movedUp
{
    [UIView beginAnimations:nil context:NULL];
    
    [UIView setAnimationDuration:0.3]; // if you want to slide up the view
    
    CGRect rect = self.view.frame;
    
    if (movedUp)
    {
        // 1. move the view's origin up so that the text field that will be hidden come above the keyboard
        // 2. increase the size of the view so that the area behind the keyboard is covered up.
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        {
            rect.origin.y -= 280;
        }
        else
        {
            rect.origin.y -= kOFFSET_FOR_KEYBOARD;
            rect.size.height += kOFFSET_FOR_KEYBOARD;
        }
        self.MobileViewTop.constant += kOFFSET_FOR_KEYBOARD;
    }
    else
    {
        // revert back to the normal state.
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        {
            rect.origin.y += 280;
        }
        else
        {
            rect.origin.y += kOFFSET_FOR_KEYBOARD;
            rect.size.height -= kOFFSET_FOR_KEYBOARD;
        }
        self.MobileViewTop.constant -= kOFFSET_FOR_KEYBOARD;
    }
    self.view.frame = rect;
    
    [UIView commitAnimations];
    [self.view updateConstraints];
}


-(void)textFieldDidEndEditing:(UITextField *)sender
{
    if  (self.view.frame.origin.y <= 0)
    {
        [self setViewMovedUp:NO];
    }
}

-(void)textFieldDidBeginEditing:(UITextField *)sender
{
    //move the main view, so that the keyboard does not hide it.
    if  (self.view.frame.origin.y >= 0)
    {
        [self setViewMovedUp:YES];
    }
}

#pragma mark Numpad with Toolbar

-(void)numpadWithToolbar
{
    float appWidth = 640;//CGRectGetWidth([UIScreen mainScreen].applicationFrame);
    UIToolbar *accessoryView = [[UIToolbar alloc]
                                initWithFrame:CGRectMake(0, 0, appWidth, 50)];
    UIBarButtonItem *space = [[UIBarButtonItem alloc]
                              initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                              target:nil
                              action:nil];
    UIBarButtonItem *done = [[UIBarButtonItem alloc]
                             initWithBarButtonSystemItem:UIBarButtonSystemItemDone
                             target:self
                             action:@selector(selectDoneButton)];
    accessoryView.items = @[space, done, space];
    self.mobileNumberField.inputAccessoryView = accessoryView;
}

- (void)selectDoneButton {
    [self.mobileNumberField resignFirstResponder];
}

//For iPad
- (void)fetchmyvCard
{
    NSString *userName;
    if (_rosterInfo)
    {
        userName = _rosterInfo.username;
        
        _FirstNameField.text = _rosterInfo.name;
        _LastNameField.text = @"";
        _eMailField.text = _rosterInfo.email;
        _designationField.text = _rosterInfo.userRoles.roleName;
        _countryCodeField = nil;
        _profileName.text = _rosterInfo.username;
        [_profileName setHidden:YES];
        
        
        if (_rosterInfo.phoneNumber && [_rosterInfo.phoneNumber length] > 0)
        {
            
            NSString *countrycode;
            NSString *mobileNumber;
            
            NSArray *number = [_rosterInfo.phoneNumber componentsSeparatedByString:@"-"];
            if (number.count > 1) {
                countrycode = number[0];
                mobileNumber = number[1];
            }
            else{
                mobileNumber = [_rosterInfo.phoneNumber substringFromIndex: [_rosterInfo.phoneNumber length] - 9];
                countrycode = [_rosterInfo.phoneNumber substringToIndex: [_rosterInfo.phoneNumber length] - 9];
            }
            
            _mobileNumberField.text = mobileNumber;
            [_btnCountryCode setTitle:countrycode forState:UIControlStateNormal];
        }
    }
    
    if (userName.length > 0)
    {
        id <CMOUserClient>userClient = [_coreComponents userService];
        CMOUser *cmoUser = [userClient fetchUservCard:userName];
        if (cmoUser.userAvatar)
        {
            _profilePicture.image = cmoUser.userAvatar;
            _profileOuterPicture.image = cmoUser.userAvatar;
            _profileOuterPicture.alpha = 0.3;
        }
        
        if (cmoUser.orgTitle) {
            _designationField.text = cmoUser.orgTitle;
        }
    }
}

- (IBAction)goBack:(id)sender
{
    [hudProgress hideAnimated:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)addOTPViewController:(CMOOtpViewController *)controller didFinishEnteringItem:(BOOL)flag
{
    dispatch_async(dispatch_get_main_queue(),^{
        [self.navigationController popViewControllerAnimated:NO];
    });
}

#pragma mark Save User Information - XMPP vCard

- (void)saveUserInfo:(UIImage *)avatarImage{
    if (self.profilePicture.image){
        //Owner is the logged in user
        CMOUserPresentation *userPresentation = [_coreComponents userPresentation];
        CMOUser *owner = [userPresentation user];
        CMOUser *user = [[CMOUser alloc]init];
        user.username = owner.username;
        user.userAvatar = avatarImage;
        
        [userPresentation setUserInformation:user];
    }
}

@end
