//
//  CMOConversationsTableViewController.m
//  CMOChat
//
//  Created by Amit Kumar on 05/04/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMOConversationsTableViewController.h"
#import "CMOChatViewController.h"
#import "CMORoomDetails+CoreDataClass.h"
#import "CMOChatPresentation.h"
#import "CMOParticipantInfo.h"
#import "CMOUtils.h"
#import "CMOChatContainerViewController.h"
#import "CMOConstant.h"
#import "CMORoomPresentation.h"
#import "UIImage+Util.h"
#import "CMOSettingsViewController.h"
#import "CMORosterPresentation.h"
//Common
#import "CMOCoreComponents.h"
#import "CMOUser.h"
#import "CMOAssembly.h"

#define PRESENCE_VIEW         100
#define CONVERSATION_TEXT     101
#define PARTICIPANT_IMAGE     102
#define PARTICIPANT_TEXT      103
#define TIMELEFT_TEXT         104
#define CONFIDIENTIAL_IMAGE   105
#define ARCHIVE_VIEW          106
#define CREATED_DATE_VIEW     108
#define PARTICIPANT_COUNT     109
#define ERROR_ICON            110
#define MESSAGE_COUNT_LABEL   411
#define ARCHIVEUNDO_BUTTON    1000
#define DISCARD_BUTTON        1010
#define NO_CONTENT_AVAILABLE_TAG    2000
#define ERR_MSG_NO_CONTENT_AVAILABLE @"No Content Available"


@interface CMOConversationsTableViewController () <RosterListDelegate>{
    CMOUser *owner;
    UIRefreshControl *pullToRefresh;
    BOOL isLoggedOut;
    CMOChatContainerViewController *chatContainerVC;
    CMORosterViewController *roasterVC;
}
@end


@implementation CMOConversationsTableViewController

@synthesize fetchedResultsController = _fetchedResultsController;

#pragma mark - View methods

- (void)viewDidLoad {
    [super viewDidLoad];

    //searchUtils = [[CMOSearchUtils alloc] initWithModel:self.chatModel];
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    owner = [userClient user];
    
    [self loadUI];
    
    [self getAllContacts];
    
    [self getAllRoomsonSuccess:^(id result) {
        
    } onFailure:^(NSError *error) {
        
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSError *error;
    if (![[self fetchedResultsController] performFetch:&error]) {
        // Update to handle the error appropriately.
        DDLogError(@"Unresolved error %@, %@", error, [error userInfo]);
    }
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    id  sectionInfo = [[_fetchedResultsController sections] objectAtIndex:section];
    NSInteger rowCount = [sectionInfo numberOfObjects];
    return rowCount;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"conversationcell" forIndexPath:indexPath];

    UIView *selectedBackgroundView = [[UIView alloc] initWithFrame:cell.bounds];
    selectedBackgroundView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    selectedBackgroundView.backgroundColor = [UIColor colorWithRed:234.0/255.0 green:242.0/255.0 blue:255.0/255.0 alpha:1.0];
    [cell setSelectedBackgroundView:selectedBackgroundView];
    
    [self configureCell:cell atIndexPath:indexPath];
    
    return cell;
}

#pragma mark - Table view delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100.0f;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    CMORoomDetails *roomInfo = [_fetchedResultsController objectAtIndexPath:indexPath];
    [self pushChatView:roomInfo type:ChatTypeExistingChat];
}


//- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
//    return !newConversation;
//}


#pragma mark - Fetch Result controller and Delegate Methods

- (NSFetchedResultsController *)fetchedResultsController {
    
    if (_fetchedResultsController != nil) {
        return _fetchedResultsController;
    }
    
    self.managedObjectContext = [[_coreComponents repositoryService] getManagedObjectContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription
                                   entityForName:@"CMORoomDetails" inManagedObjectContext:_managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"modificationDate" ascending:NO];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];

    //fetchRequest.predicate = [self getDefaultPredicate];
    
    [fetchRequest setFetchBatchSize:20];
    
    NSFetchedResultsController *theFetchedResultsController =
    [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest
                                        managedObjectContext:_managedObjectContext sectionNameKeyPath:nil
                                                   cacheName:nil];
    self.fetchedResultsController = theFetchedResultsController;
    _fetchedResultsController.delegate = self;
    
    return _fetchedResultsController;
    
}


- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller {
    // The fetch controller is about to start sending change notifications, so prepare the table view for updates.
    //if (self.viewLoaded && self.view.window) {
        [self.conversationsTableView beginUpdates];
    //}
}


- (void)controller:(NSFetchedResultsController *)controller
   didChangeObject:(id)anObject
       atIndexPath:(NSIndexPath *)indexPath
     forChangeType:(NSFetchedResultsChangeType)type
      newIndexPath:(NSIndexPath *)newIndexPath {
    
        UITableView *tableView = self.conversationsTableView;
        switch(type) {
            case NSFetchedResultsChangeInsert:
                [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
                break;
            case NSFetchedResultsChangeDelete:
                [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
                break;
            case NSFetchedResultsChangeUpdate:
                [self configureCell:[tableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
                break;
            case NSFetchedResultsChangeMove:
                [tableView deleteRowsAtIndexPaths:[NSArray
                                                   arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
                [tableView insertRowsAtIndexPaths:[NSArray
                                                   arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
                break;
        }
}

/*- (NSIndexPath *)newIndexFor:(NSIndexPath*)oldPath newPath:(NSIndexPath*)newPath {
    NSIndexPath *retPath = [NSIndexPath indexPathForRow:(selectedIndexPathTest.row) inSection:selectedIndexPathTest.section];
    if (newPath.row <= selectedIndexPathTest.row && oldPath.row > selectedIndexPathTest.row) {
        retPath = [NSIndexPath indexPathForRow:(selectedIndexPathTest.row+1) inSection:selectedIndexPathTest.section];
    } else if (oldPath.row == selectedIndexPathTest.row) {
        retPath = [NSIndexPath indexPathForRow:(newPath.row) inSection:newPath.section];
    }
    return retPath;
}*/


- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id )sectionInfo atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type {
    
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [self.conversationsTableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [self.conversationsTableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
        case NSFetchedResultsChangeMove:
        case NSFetchedResultsChangeUpdate:
        default:
            break;
    }
}


- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    [self.conversationsTableView endUpdates];
}

- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    CMORoomDetails *roomInfo = [_fetchedResultsController objectAtIndexPath:indexPath];

    //Set Subject Label
    UILabel *subjectLabel = (UILabel *)[cell viewWithTag:CONVERSATION_TEXT];
    subjectLabel.text = [roomInfo.roomSubject length] == 0 ? roomInfo.naturalName : roomInfo.roomSubject;
    
    //Set Created date
    UILabel *createdDateLabel = (UILabel *)[cell viewWithTag:CREATED_DATE_VIEW];
    createdDateLabel.text = [self getCreatedDateFromDate:roomInfo.creationDate];
    
    // show all participants first name
    NSString *participantList = @"";
    NSMutableArray *participants = [_chatModel clubOwnersAndMembers:roomInfo];
    for (CMOParticipantInfo *participantInfo in participants) {
        NSArray* firstLastStrings = [participantInfo.participantName ? participantInfo.participantName : participantInfo.jid componentsSeparatedByString:@" "];
        NSString* firstName = [firstLastStrings objectAtIndex:0];
        if ([participantInfo.jid isEqualToString:CMOGroupName]) {
            firstName = CMOGroupDisplayName;
        }
        participantList = [NSString stringWithFormat:@"%@, %@",participantList, firstName];
    }
    if (participantList.length > 2){
        participantList = [participantList substringFromIndex:2];
    }
    
    UILabel *participantLabel = (UILabel *)[cell viewWithTag:PARTICIPANT_TEXT];
    participantLabel.text = participantList;
    
    //Set errorIcon image
    UIImageView *errIconImgView = (UIImageView *)[cell viewWithTag:ERROR_ICON];
    errIconImgView.hidden = !roomInfo.roomProperty.isAnyMessageOffline;
}


- (NSString *) getCreatedDateFromDate:(NSDate *)createdDate
{
    return [[[JSQMessagesTimestampFormatter sharedFormatter] attributedTimestampForDate:createdDate] string];
}


#pragma mark - Get All Rooms

- (void)getAllRoomsonSuccess:(void (^)(id result))success
                   onFailure:(void (^)(NSError *error))failure{
    dispatch_async(dispatch_get_main_queue(), ^(){
        [self showLoadingIndicator];
    });
    [self.roomModel getAllRooms:owner.username onSuccess:^(id result) {
        //DDLogInfo(@"In Success");
        [self hideLoadingIndicator];
        success(result);
    } onFailure:^(NSError *error) {
        //DDLogInfo(@"In Failure");
        [self hideLoadingIndicator];
        failure(error);
    }];
}


#pragma mark Get All Contacts

- (void)getAllContacts{
    [self.rosterModel fetchAllUsersAndGroupsWithCompletionHandler:^(id users) {
        DDLogInfo(@"Roster Details Fetched");
    } failure:^(NSError *error) {
        DDLogInfo(@"Unable to fetch rosters %@",error);
    }];
}



-(void)goBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}


//- (void)applicationLoggedOut:(NSNotification *)notification{
//    isLoggedOut = true;
//    //[self unregisterNotifications];
//    [[NSNotificationCenter defaultCenter]removeObserver:self name:LOGOUT_NOTIFICATION object:nil];
//
//    //if in search screen while logging out set predicate to nil and update left nav button.
//    _fetchedResultsController.delegate = nil;
//    _fetchedResultsController = nil;
//
//    [self.conversationsTableView reloadData];
//    self.conversationsTableView.dataSource = nil;
//    self.conversationsTableView.delegate =  nil;
//    self.managedObjectContext = nil;
//}


- (void)networkReachable:(NSNotification *)notification{
    //[self performSelector:@selector(scheduleUnReadMessageNotification:) withObject:nil afterDelay:0];
}


- (void)pushChatView:(CMORoomDetails *)info type:(ChatType)type{
    if (chatContainerVC) {
        chatContainerVC = nil;
    }
    chatContainerVC = [_assembly chatcontainerviewcontroller];
    chatContainerVC.type = type; //New Chat or Existing Chat
    chatContainerVC.owner = owner;
    chatContainerVC.roomInfo = info;

    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
    chatContainerVC.hidesBottomBarWhenPushed = true;
    [navController pushViewController:chatContainerVC];
}

#pragma mark New Conversation

- (void)showChatScreen:(id)sender{
    //[self pushChatView:nil type:ChatTypeNewChat];
    //[self.conversationsTableView reloadData];
    
//    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
//    roasterVC.hidesBottomBarWhenPushed = true;
//    [navController pushViewController:roasterVC];
    
//    if (!roasterVC){
//        roasterVC = [_assembly rosterviewcontroller];
//    }
//    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
//    roasterVC.hidesBottomBarWhenPushed = true;
//    if (![navController.viewControllers containsObject:roasterVC]){
//        [navController pushViewController:roasterVC];
//    }
    

    if (!roasterVC){
        roasterVC = [_assembly rosterviewcontroller];
    }
    
    roasterVC.rosterDelegate = self;//Chat view controller
    roasterVC.chatType = ChatTypeNewChat;
    roasterVC.hidesBottomBarWhenPushed = true;
    //participantsDict is already available
    
//    if(_partcipantsList.count)
//    {
//        _rosterView.participantsDict = _partcipantsList;
//    }
    
    [self.navigationController pushViewController:roasterVC animated:true];
}

- (void)participants:(id)participants{
    ////DDLogInfo(@"Users = %@",[self userNameList:participants]);
    //[self addUsersToChatRoom:participants];
    //[self addGroupToChatRoom:participants];
    
}

- (void)pullToRefresh:(id)sender{
    [self getAllRoomsonSuccess:^(id result) {
        [pullToRefresh endRefreshing];
    } onFailure:^(NSError *error) {
        [pullToRefresh endRefreshing];
    }];
}


#pragma mark UI Elements

- (void)loadUI{
    [self configUI];
    [self addPlusButton];
    [self addPullToRefresh];
}

- (void)configUI{
    self.title = @"Conversation";
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.leftBarButtonItem = nil;
    
    self.conversationsTableView.multipleTouchEnabled = NO;
    self.conversationsTableView.dataSource = self;
    self.conversationsTableView.delegate =  self;
}


- (void)addPlusButton{
     UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(showChatScreen:)];
    self.navigationItem.rightBarButtonItem = addButton;
}

- (void)addPullToRefresh{
    if (!pullToRefresh){
        pullToRefresh = [[UIRefreshControl alloc] init];
        pullToRefresh.tintColor = [UIColor grayColor];
        [pullToRefresh addTarget:self action:@selector(pullToRefresh:) forControlEvents:UIControlEventValueChanged];
        [self.conversationsTableView addSubview:pullToRefresh];
    }
}

#pragma mark UI - Util Methods

- (void)showLoadingIndicator{
    if (!self.hudProgress){
        self.hudProgress = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        self.hudProgress.label.text = @"Loading...";
    }
}

- (void)hideLoadingIndicator{
    if (self.hudProgress){
        [self.hudProgress hideAnimated: true];
        self.hudProgress = nil;
    }
}

@end
