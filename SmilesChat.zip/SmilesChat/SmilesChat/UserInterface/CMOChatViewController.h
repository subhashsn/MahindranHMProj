//
//  FirstViewController.h
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <JSQMessagesViewController/JSQMessages.h>
#import "CMOChatService.h"
#import "CMOChatPresentation.h"
#import "CMOCoreComponents.h"
#import "CMORosterViewController.h"
#import "CMODocumentPreviewViewController.h"


@class CMOAssembly;
@class CMORoomDetails;
@class CMOiPadTabBarViewController;

@interface CMOChatViewController : JSQMessagesViewController <ChatPresentationDelegate, RosterListDelegate, DocumentPreiewViewDelegate>

@property(nonatomic, weak)IBOutlet UIView *topContainerView;

@property (weak, nonatomic) IBOutlet UITextField *messageTextField;

@property(nonatomic, strong)NSString *receiverId;

@property(nonatomic, assign)BOOL isFromParent;

@property(nonatomic, strong)CMORoomDetails *roomInfo;

@property(nonatomic, strong)NSString *receiverDisplayName;

@property (weak, nonatomic) CMOAssembly *assembly;

@property (weak, nonatomic) CMOChatPresentation *chatModel;

@property (strong, nonatomic) CMORoomPresentation *roomModel;

@property (strong, nonatomic) id target;

//@property (strong, nonatomic) NSString *imageName;

@property(nonatomic, weak)CMOCoreComponents *coreComponents;

@property(nonatomic, assign)ChatType chatType;

@property(nonatomic, assign)id<CMOSLAClient> slaDelegate;

@property (strong, nonatomic) NSMutableDictionary *partcipantsList;

@property (assign, nonatomic) BOOL isNewMessageSent;

- (void) gotoAttachmentScreen;

- (void)resignJSQTextView;

- (void) leaveRoomiPad;

- (void)toggleHideShowMessages;

- (void)updateVisitedRoom;

- (void)displayAlertWithTitle:(NSString *)title;

-(void)reloadChatViewData;

@end

