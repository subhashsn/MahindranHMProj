//
//  CMOSMSViewController.m
//  CMOChat
//
//  Created by Administrator on 4/1/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMOSMSViewController.h"
#import "CMOChatViewController.h"
#import "CMOChatContainerViewController.h"

@interface CMOSMSViewController () <MFMessageComposeViewControllerDelegate>{
    id <MessageControllerDelegate> messageViewInitiatorDelegate; //CMOChatViewController
    NSString *lMessage;
}

@end

@implementation CMOSMSViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (id)initWithDelegate:(id <MessageControllerDelegate>)delegate{
    self = [super init];
    if (self){
        messageViewInitiatorDelegate = delegate;
    }
    return self;
}


- (void)sendSMSTo:(NSMutableArray *)phoneNumbers withMessage:(NSString *)message{
    self.messageComposeDelegate = self;
    lMessage = message;
    [self setRecipients:phoneNumbers];
    [self setBody:message];
    
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    CMOChatContainerViewController *chatContainer = (CMOChatContainerViewController *)((CMOChatViewController *)messageViewInitiatorDelegate).parentViewController;
    [chatContainer presentViewController:self animated:YES completion:nil];
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult) result
{
    [messageViewInitiatorDelegate messageComposeDidFinishWithResult:result andMessage:lMessage];
    
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    CMOChatContainerViewController *chatContainer = (CMOChatContainerViewController *)((CMOChatViewController *)messageViewInitiatorDelegate).parentViewController;
    [chatContainer dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
