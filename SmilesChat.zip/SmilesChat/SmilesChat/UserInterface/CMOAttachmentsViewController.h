//
//  CMOAttachmentsViewController.h
//  CMOChat
//
//  Created by Raju on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CMOFullImageViewController.h"
#import "CMODocumentPreviewViewController.h"

@class CMOAssembly;


@interface CMOAttachmentsViewController : UIViewController <FullImageViewDelegate, DocumentPreiewViewDelegate>

@property (nonatomic, strong) CMOAssembly *assembly;
@property (nonatomic, strong) NSString *roomID;
@property (nonatomic, strong) NSMutableArray *messagesArray;
@property (nonatomic, strong) NSMutableArray *docsArray;
@property (nonatomic, weak) IBOutlet UICollectionView *imageCollection;
@property (nonatomic, weak) IBOutlet UILabel *noAttachments;
@property (nonatomic, weak) IBOutlet UISegmentedControl *fileTypeSegment;
@property (nonatomic, weak) IBOutlet UITableView *docsTableView;

- (IBAction)fileTypeButtonAction:(id)sender;

@end
