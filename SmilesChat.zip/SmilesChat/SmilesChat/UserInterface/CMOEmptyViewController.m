//
//  CMOEmptyViewController.m
//  CMOChat
//
//  Created by Raju on 12/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOEmptyViewController.h"

@interface CMOEmptyViewController ()

@end

@implementation CMOEmptyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear: YES];
    self.navigationItem.leftBarButtonItem=nil;
    self.navigationItem.hidesBackButton=YES;
}

@end
