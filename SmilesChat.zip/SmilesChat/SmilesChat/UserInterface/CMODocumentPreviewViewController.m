//
//  CMODocumentPreviewViewController.m
//  CMOChat
//
//  Created by Raju on 1/6/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMODocumentPreviewViewController.h"
#import "CMOChatPresentation.h"
#import "CMOMessage.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "CMOAudioMediaItem.h"
#import "CMOVideoMediaItem.h"

@interface CMODocumentPreviewViewController ()
{
    AVPlayerViewController *playerController;
    AVPlayer *player;
}

@end

@implementation CMODocumentPreviewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self addNavigationBar];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    if (_isDocument) {
        [self loadDocument];
    }
    else{
        [self loadMedia];
    }
    [self setTitleInfo];
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
}

- (void) loadDocument
{
    QLPreviewController *previewController = [[QLPreviewController alloc] init];
    
    previewController.dataSource = self;
    previewController.delegate = self;
    previewController.view.frame = _containerView.bounds;
    previewController.currentPreviewItemIndex = 1;
    
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 10.0 && [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        [self addChildViewController:previewController];
    }
    previewController.navigationController.navigationBar.hidden = YES;
    [previewController didMoveToParentViewController:self];
    [_containerView addSubview:previewController.view];

}

- (void) loadMedia
{
    if (player) {
        [player pause];
        player = nil;
    }
    if (playerController) {
        playerController = nil;
    }
    
    player = [AVPlayer playerWithURL:_docURL];
    playerController = [[AVPlayerViewController alloc] init];
//    playerController.showsPlaybackControls = NO;
    playerController.allowsPictureInPicturePlayback = NO;
    playerController.view.frame = _containerView.bounds;
    [_containerView addSubview:playerController.view];
    playerController.player = player;
    [player play];
    
}

- (void)addNavigationBar
{
    UIImage *image = [UIImage imageNamed:@"Delete"];
    UIButton *deleteButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
    [deleteButton setImage:image forState:UIControlStateNormal];
    [deleteButton addTarget:self action:@selector(deleteAction:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:deleteButton];
    
    UIButton *backButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    [backButton setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(goBack:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
}

- (void) setTitleInfo{

    NSDate *date = _message.date;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd, MMM YY, hh:mma"];

    NSString *stringWithFormat = [NSString stringWithFormat:@"%@\n%@",_message.senderDisplayName, [formatter stringFromDate:date]];

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 480, 44)];
    label.backgroundColor = [UIColor clearColor];
    label.numberOfLines = 2;
    label.font = [UIFont systemFontOfSize: 10.0f];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blackColor];
    label.text = stringWithFormat;
    _iPadTitle.text = label.text;
    self.navigationItem.titleView = label;
}

#pragma mark - QLPreviewControllerDataSource

// Returns the number of items that the preview controller should preview
- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)previewController
{
    return 1;
}

- (void)previewControllerDidDismiss:(QLPreviewController *)controller
{
    // if the preview dismissed (done button touched), use this method to post-process previews
}

// returns the item that the preview controller should preview

- (id <QLPreviewItem>)previewController:(QLPreviewController *)controller previewItemAtIndex:(NSInteger)index
{
    return _docURL;
}

//Button action for iPad
- (IBAction) backButtonAction:(id)sender
{
    [self dismissPlayer];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)goBack:(id)sender
{
    [self dismissPlayer];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) dismissPlayer
{
    if (playerController) {
        [playerController dismissViewControllerAnimated:YES completion:nil];
        playerController = nil;
    }
    if (player) {
        [player pause];
        player = nil;
    }
}

- (IBAction)deleteButtonAction:(id)sender
{
    [self deleteAction:sender];
}

- (void)deleteAction:(id)MACH_NOTIFY_NO_SENDERS
{
    
    UIAlertController *alert;
    
    alert = [UIAlertController
             alertControllerWithTitle:@""
             message:@"Are you sure you want to delete?"
             preferredStyle:UIAlertControllerStyleAlert];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        alert.popoverPresentationController.sourceView = self.view;
        alert.popoverPresentationController.sourceRect = self.view.frame;
    }
    
    UIAlertAction* btnCancel = [UIAlertAction
                                actionWithTitle:@"Cancel"
                                style:UIAlertActionStyleCancel
                                handler:^(UIAlertAction * action)
                                {
                                    //  UIAlertController will automatically dismiss the view
                                }];
    
    UIAlertAction* deleteBtn = [UIAlertAction
                                actionWithTitle:@"Delete"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
                                {
                                    [self deleteDocument];
                                }];
    
    [alert addAction:btnCancel];
    [alert addAction:deleteBtn];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void) deleteDocument
{
    [self dismissPlayer];
    BOOL isFileDeleted = [_chatModel deleteDocument:_message.messageBody.body roomID:_roomID];
    if (isFileDeleted)
    {
        if ([[_message media] isKindOfClass:[CMOAudioMediaItem class]] ||[[_message media] isKindOfClass:[CMOVideoMediaItem class]]) {
            [_delegate updateAttachmentOnDeletionWithObjectFromPreview:_selectedIndex.row];
        } else {
            [_delegate updateDocumentListOnDeletionWithObject:_selectedIndex.row];
        }
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        {
            [self backButtonAction:self];
        }
        else{
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}

@end
