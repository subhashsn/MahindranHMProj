//
//  CMONavigationController.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMONavigationController.h"
#import "CMOLoginViewController.h"
#import "CMOMyInfoViewController.h"
#import "CMOOtpViewController.h"
#import "CMOChatViewController.h"
#import "CMOChatContainerViewController.h"
#import "CMOAttachmentsViewController.h"
#import "CMOCountryCodeViewController.h"
#import "CMOFullImageViewController.h"
#import "CMOMyProfileViewController.h"
#import "CMOCountryCodeViewController.h"
#import "CMOEditProfileViewController.h"
#import "CMOConversationSettingsViewController.h"
#import "CMODocumentPreviewViewController.h"
#import "CMOConversationsTableViewController.h"

@interface CMONavigationController (){
    UILabel *titleLabel;
    UIStatusBarStyle barStyle;
}

@end

@implementation CMONavigationController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.delegate = self;
   

    //NSArray *viewControllers = self.viewControllers;
    
    //UIImage *collection = [UIImage imageNamed:@"collection-tab"];
    //self.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"Conversation" image:collection tag:1];    // Do any additional setup after loading the view.
  
    
   
}


/*- (void)notifyPresence:(NSNotification *)notification{
    if ([notification.name isEqualToString:XMPP_PRESENCE_NOTIFICATION]){
        NSLog(@"Conversations Screen: Presence is %@",notification.userInfo[kPresence]);
    }
}*/

- (void)loadActivityView:(NSString *)message{
    UIView *containerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,self.navigationBar.frame.size.width - 50,30)];
    
    UIActivityIndicatorView *activityIndicatorView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    activityIndicatorView.frame = CGRectMake(0, 0, 30, 30);
    
    titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(activityIndicatorView.frame), 0, CGRectGetWidth(containerView.frame) - CGRectGetWidth(activityIndicatorView.frame), 30)];
    titleLabel.text = message;
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.font = [UIFont fontWithName:@"Helvetica" size:14.0f];
    
    [containerView addSubview:activityIndicatorView];
    [containerView addSubview:titleLabel];
    
    self.navigationItem.titleView = containerView;
}

- (void)loadStatus:(NSString *)message{
    if (!titleLabel){
        titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,0,self.navigationBar.frame.size.width - 50,30)];
        
        titleLabel.textColor = [UIColor blackColor];
        titleLabel.font = [UIFont fontWithName:@"Helvetica" size:14.0f];
        self.navigationItem.titleView = titleLabel;
    }
    titleLabel.text = message;
}


- (void)dismissActivityView{
    self.navigationItem.titleView = nil;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)pushViewController:(UIViewController *)controller{
//    if ([controller isKindOfClass:[CMOOtpViewController class]] ||
//        [controller isKindOfClass:[CMOMyInfoViewController class]] ||
//        [controller isKindOfClass:[CMOChatViewController class]] ||
//        [controller isKindOfClass:[CMOCountryCodeViewController class]])
//    {
//        [self.tabBarController.tabBar setHidden:YES];
//    }
//    else
//    {
//        [self.tabBarController.tabBar setHidden:NO];
//    }
    [self pushViewController:controller animated:true];

}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    //NSLog(@"willShowViewController");
    self.tabBarController.tabBar.hidden = FALSE;
    id vc = viewController;

    if ([vc isKindOfClass:[CMOLoginViewController class]] || [vc isKindOfClass:[CMOOtpViewController class]] || [vc isKindOfClass:[CMOMyInfoViewController class]] || [vc isKindOfClass:[CMOChatViewController class]] || [vc isKindOfClass:[CMOChatContainerViewController class]] || [vc isKindOfClass:[CMOMyProfileViewController class]] || [vc isKindOfClass:[CMOEditProfileViewController class]] || [vc isKindOfClass:[CMOAttachmentsViewController class]] || [vc isKindOfClass:[CMOFullImageViewController class]] || [vc isKindOfClass:[CMOConversationSettingsViewController class]] || [vc isKindOfClass:[CMODocumentPreviewViewController class]]){
            self.tabBarController.tabBar.hidden = TRUE;
    }
   
    self.navigationBar.hidden = FALSE;
    
    if ([vc isKindOfClass:[CMOLoginViewController class]] || [vc isKindOfClass:[CMOMyInfoViewController class]] || [vc isKindOfClass:[CMOMyProfileViewController class]] ||[vc isKindOfClass:[CMOEditProfileViewController class]]){
        self.navigationBar.hidden = TRUE;
    }
    
    
    if ([vc isKindOfClass:[CMOLoginViewController class]] || [vc isKindOfClass:[CMOMyInfoViewController class]]){
        barStyle = UIStatusBarStyleLightContent;
    }
    else{
         barStyle = UIStatusBarStyleDefault;
    }
      [self setNeedsStatusBarAppearanceUpdate];
    
}

- (UIStatusBarStyle) preferredStatusBarStyle {
    return barStyle;
}

- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad && [viewController isKindOfClass:[CMOConversationsTableViewController class]]) {
        _controller = viewController;
    }
    //NSLog(@"didShowViewController");
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
