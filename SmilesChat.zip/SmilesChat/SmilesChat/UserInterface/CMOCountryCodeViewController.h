//
//  CMOCountryCodeViewController.h
//  CMOChat
//
//  Created by Subhash on 11/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CMOAssembly;
@class CMOCoreComponents;
@class CMOCountryCodeViewController;

@protocol CountryCodeDelegate <NSObject>
- (void)addItemViewController:(CMOCountryCodeViewController *)controller didFinishEnteringItem:(NSString *)item;
@end

@interface CMOCountryCodeViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *countrycodeTableView;

@property (strong, nonatomic) CMOAssembly *assembly;
@property (strong, nonatomic) CMOCoreComponents *coreComponents;

@property (nonatomic, weak) id <CountryCodeDelegate> countryCodeDelegate;

@end
