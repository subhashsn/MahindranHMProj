//
//  CMOSettingsViewController.m
//  CMOChat
//
//  Created by Subhash on 11/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOSettingsViewController.h"
#import "CMOAssembly.h"
#import "CMOCoreComponents.h"
#import "CMOXMPPManager.h"
#import "CMOUtils.h"
#import "CMOMyProfileViewController.h"
#import "CMOConversationsTableViewController.h"
#import "AppDelegate.h"
#import "CMOSplitViewController.h"
#import "CMOMyInfoViewController.h"
#import "CMOUser.h"
#import "CMORoster+CoreDataProperties.h"
#import "CMOChatPresentation.h"

@import LocalAuthentication;

@interface CMOSettingsViewController ()
{
    CMOMyProfileViewController *myProfileViewController;
    CMOMyInfoViewController *myinfoViewController;
    
    NSArray *settingsIcons;
    UISwitch *switchTouchID;
    UISwitch *switchMuteNotification;
    CMOConversationsTableViewController *conversationViewController;
    
    NSArray *settingsTitles;
    NSIndexPath *selectedIndex;
    MBProgressHUD *hudProgress;
    
    CMOChatPresentation *chatModel;
}
@end

@implementation CMOSettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    chatModel = [_coreComponents chatPresentation];
    self.navigationItem.title = @"Settings";
    [self initSettings];
    self.settingsTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
   // NSString *versionNumber = [[NSBundle mainBundle] objectForInfoDictionaryKey:(NSString *)kCFBundleVersionKey];
   // self.versionLabel.text = [NSString stringWithFormat:@"Version %@",versionNumber];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [_settingsTableView reloadData];
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    appDelegate.isFromSetting = YES;
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad && (appDelegate.isFromContacts || appDelegate.isFromConversation))
    {
        appDelegate.isFromContacts = appDelegate.isFromConversation = NO;
        if (!selectedIndex) {
            selectedIndex = [NSIndexPath indexPathForRow:0 inSection:0];
        }
        [_settingsTableView selectRowAtIndexPath:selectedIndex animated:NO scrollPosition:UITableViewScrollPositionNone];
        [self pushToMyProfileViewController];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)initSettings
{
    settingsTitles = [NSArray arrayWithObjects:@"My Profile",@"Archive",@"Enable Touch ID",@"Mute Notification",@"Version No : ", @"Sync",@"Logout", nil];
    //NSDictionary *settingsDic = [NSDictionary dictionaryWithObjectsAndKeys:settingsArr1,@"0",@"Mute Nofication for all conversation",@"1", @"Logout",@"2",nil];
    
    settingsIcons = [NSArray arrayWithObjects:@"Settings_MyProfile.png",@"Settings_Archive.png",@"Settings_EnableTouchID.png",@"", @" ",@"Sync.png", @"Settings_LogOut.png", nil];
    
    [_settingsTableView reloadData];
    
//    [self setTableViewOutlets:settingsTitles];
}


- (void) switchChangedForMuteNotification:(id)sender {
    UISwitch* switchControl = sender;
    NSLog( @"The switch is for switchChangedForMuteNotification %@", switchControl.on ? @"ON" : @"OFF" );
    if (switchControl.on) {
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeNone categories:nil]];
        [[UIApplication sharedApplication] unregisterForRemoteNotifications];
        [[NSUserDefaults standardUserDefaults] setValue:nil forKey:@"APNSDeviceToken"];

        [CMOUtils setUserDefaultForMuteNotification:@"YES"];
    } else {
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(updateDeviceTokenOnserver:) name:DID_UPDATE_DEVICE_TOKEN_NOTIFICATION object:nil];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
        [CMOUtils setUserDefaultForMuteNotification:@"NO"];
    }
}

- (void)updateDeviceTokenOnserver:(NSNotification *)notification{
    NSString *deviceToken = [[NSUserDefaults standardUserDefaults] valueForKey:@"APNSDeviceToken"];
    
    if (deviceToken != nil) {
        [[NSNotificationCenter defaultCenter] removeObserver:self name:DID_UPDATE_DEVICE_TOKEN_NOTIFICATION object:nil];
       
        id <CMOUserClient>userClient = [_coreComponents userService];
        CMOUser *owner = [userClient user];
        
        id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
        CMORoster *roster = [repositoryClient fetchRoster:owner.username];
    
        NSString* mobileNumber = [roster phoneNumber];
        
        id <CMOAppServerAPIClient> client = [_coreComponents appServerAPIHandler];
        NSString *url = [NSString stringWithFormat:@"UpdateUserInfo/%@/%@/%@",owner.username,mobileNumber,deviceToken];
        [client GET:url parameters:nil OnProgress:nil OnSuccess:^(id  _Nullable response) {
            //Success block
            NSLog(@"UpdateUserInfo Success response: %@",response);
        } onFailure:^(NSError * _Nonnull error) {
            //Failure block
            NSLog(@"UpdateUserInfo Failure error: %@",error);
            //setting first launch to YES to register device token on next launch
            [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:@"firstLaunch"];
        }];
    }
    
}

- (void)pushToMyProfileViewController{

    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        if (!myProfileViewController)
        {
            myProfileViewController = [_assembly myprofileviewcontroller];
        }
        
        id <CMOUserClient>userClient = [_coreComponents userService];
        CMOUser *owner = [userClient user];
        
        myProfileViewController.rosterInfo = nil;
        myProfileViewController.userInfo = owner;
        CMONavigationController *navVC = _splitViewController.viewControllers[1];
        [navVC popToRootViewControllerAnimated:NO];
        myinfoViewController.bMyInfoFlag = FALSE;
        [navVC pushViewController: myProfileViewController animated:NO];
    }
    else
    {
        if (!myinfoViewController){
            myinfoViewController = [_assembly myinfoviewcontroller:nil];
        }
        CMONavigationController *navController = (CMONavigationController *)self.navigationController;
        if (![navController.viewControllers containsObject:myinfoViewController]){
            myinfoViewController.bMyInfoFlag = FALSE;
            [navController pushViewController:myinfoViewController];
        }
    }
}

#pragma mark touch ID functionality

- (void) switchChangedForEnabledTouchID:(id)sender
{
    UISwitch* switchControl = sender;
    
    if([switchControl isOn])
    {
        [self canEvaluatePolicy];
    }
    else
    {
        [CMOUtils setUserDefaultForTouchID:@"NO"];
    }
    
}

- (void) updateTouchIDSwitch
{
    BOOL isTouchEnable = [CMOUtils getTouchIDUserDefaultValue];
    [switchTouchID setOn:isTouchEnable];
}

- (void)canEvaluatePolicy
{
    LAContext *context = [[LAContext alloc] init];
    NSString *message;
    NSString *title;
    NSError *error;
    BOOL success;
    
    // test if we can evaluate the policy, this test will tell us if Touch ID is available and enrolled
    success = [context canEvaluatePolicy: LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error];
    
    if (success)
    {
        title = @"Touch ID login enabled";
        message = @"Your Touch ID login is now enabled.\nYou can always disable this in the Settings.";
        
        [switchTouchID setOn:YES];
        [CMOUtils setUserDefaultForTouchID:@"YES"];
    }
    else
    {
        title = @"Touch ID login failed";
        message = @"App is not able to detect Touch ID from your device. Go to device settings and enable Touch ID.";
        
        [switchTouchID setOn:NO];
        [CMOUtils setUserDefaultForTouchID:@"NO"];
    }
    [self showTouchAlertWithSuccess:success andMessage:message andTitle:title];
}

- (void) showTouchAlertWithSuccess:(BOOL) success andMessage:(NSString *)message andTitle:(NSString *)title
{
#warning all touch ID image not as per UI
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okButton = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
        [alert dismissViewControllerAnimated:YES completion:nil];
    }];
    [alert addAction:okButton];
    
    [self presentViewController:alert animated:YES completion:nil];
    
}


- (void)pushToConversatiosViewController{
    if (!conversationViewController){
        conversationViewController = [_assembly conversationsviewcontroller];
    }
//    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
//    {
//        conversationViewController.splitViewController = _splitViewController;
//    }
//    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
//    if (![navController.viewControllers containsObject:conversationViewController]){
//        conversationViewController.archiveFlag = TRUE;
//        [navController pushViewController:conversationViewController];
//    }
}


#pragma mark --
#pragma mark UITableView data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        return 3;
    }
    else
    {
        return 1;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        if (section == 0)
        {
            return 3;
        }
        else if(section == 1)
        {
            return 2;
        }
        else
        {
            return 2;
        }
    }
    else
    {
        return 7;
    }

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        if (indexPath.section == 0 || indexPath.section == 2)
        {
            cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"settingcell"];
            if(cell == nil){
                
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"settingcell"];
            }
            UIImageView *imageView = (UIImageView *)[cell viewWithTag:100];
            imageView.image = [UIImage imageNamed:[settingsIcons objectAtIndex:indexPath.row]];
            
            UILabel *label = (UILabel *)[cell viewWithTag:101];
            label.text = [settingsTitles objectAtIndex:indexPath.row];
            
            if (indexPath.section == 0 && indexPath.row == 2)
            {
                switchTouchID = [[UISwitch alloc] initWithFrame:CGRectZero];
                [cell addSubview:switchTouchID];
                cell.accessoryView = switchTouchID;
                [switchTouchID addTarget:self action:@selector(switchChangedForEnabledTouchID:) forControlEvents:UIControlEventValueChanged];
                [self updateTouchIDSwitch];
            }
            else if(indexPath.section == 2 && indexPath.row == 0)
            {
                label.text = [settingsTitles objectAtIndex:5];
                imageView.image = [UIImage imageNamed:[settingsIcons objectAtIndex:5]];
            }
            else if(indexPath.section == 2 && indexPath.row == 1)
            {
                label.text = [settingsTitles objectAtIndex:6];
                imageView.image = [UIImage imageNamed:[settingsIcons objectAtIndex:6]];
            }
        }
        else
        {
            cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"muteNotification"];
            if(cell == nil){
                
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"muteNotification"];
            }
            
            UILabel *label = (UILabel *)[cell viewWithTag:103];
            label.minimumScaleFactor = 0.8;
            label.text = [settingsTitles objectAtIndex:3];
            
            if(indexPath.row == 1)
            {
                label.text = [NSString stringWithFormat:@"%@%@", [settingsTitles objectAtIndex:4], [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]];
            }
            else
            {
                switchMuteNotification = [[UISwitch alloc] initWithFrame:CGRectZero];
                [cell addSubview:switchMuteNotification];
                cell.accessoryView = switchMuteNotification;
                BOOL isMutenotificationEnable = [CMOUtils getMuteNotificationUserDefaultValue];
                [switchMuteNotification setOn:isMutenotificationEnable];
                [switchMuteNotification addTarget:self action:@selector(switchChangedForMuteNotification:) forControlEvents:UIControlEventValueChanged];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
    }
    else
    {
        if(indexPath.row != 3 && indexPath.row != 4)
        {
            cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"settingcell"];
            if(cell == nil){
                
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"settingcell"];
            }
            UIImageView *imageView = (UIImageView *)[cell viewWithTag:100];
            imageView.image = [UIImage imageNamed:[settingsIcons objectAtIndex:indexPath.row]];
            
            UILabel *label = (UILabel *)[cell viewWithTag:101];
            label.text = [settingsTitles objectAtIndex:indexPath.row];
            if (indexPath.row == 2)
            {
                switchTouchID = [[UISwitch alloc] initWithFrame:CGRectZero];
                [cell addSubview:switchTouchID];
                cell.accessoryView = switchTouchID;
                [switchTouchID addTarget:self action:@selector(switchChangedForEnabledTouchID:) forControlEvents:UIControlEventValueChanged];
                [self updateTouchIDSwitch];
            }
        }
        else
        {
            cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"muteNotification"];
            if(cell == nil){
                
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"muteNotification"];
            }
            
            UILabel *label = (UILabel *)[cell viewWithTag:103];
            if(indexPath.row == 4)
            {
                label.text = [NSString stringWithFormat:@"%@%@", [settingsTitles objectAtIndex:indexPath.row], [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]];
            }
            else{
                switchMuteNotification = [[UISwitch alloc] initWithFrame:CGRectZero];
                [cell addSubview:switchMuteNotification];
                cell.accessoryView = switchMuteNotification;
                [switchMuteNotification setOn:[CMOUtils getMuteNotificationUserDefaultValue]];
                [switchMuteNotification addTarget:self action:@selector(switchChangedForMuteNotification:) forControlEvents:UIControlEventValueChanged];
                
                label.text = [settingsTitles objectAtIndex:indexPath.row];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        
    }
    
    
    //set selection background color
    UIView *selectedBackgroundView = [[UIView alloc] initWithFrame:cell.bounds];
    selectedBackgroundView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    selectedBackgroundView.backgroundColor = [UIColor colorWithRed:234.0/255.0 green:242.0/255.0 blue:255.0/255.0 alpha:1.0];
    cell.selectedBackgroundView = selectedBackgroundView;
    
    return cell;
}

#pragma mark --
#pragma mark UITableViewdelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    selectedIndex = indexPath;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone || indexPath.row == 2 || indexPath.row == 3 || indexPath.row == 6)
    {
        [_settingsTableView deselectRowAtIndexPath:indexPath animated:NO];
    }

    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        if (indexPath.section == 0 && indexPath.row == 0)
        {
            [self pushToMyProfileViewController];
        }
        else if (indexPath.section == 0 && indexPath.row == 1)
        {
            [self pushToConversatiosViewController];
        }
        else if (indexPath.section == 2 && indexPath.row == 1)
        {
            [self syncDataToServerWithIndicator:false];
            [self logoutAction];
        }
        else if (indexPath.section == 2 && indexPath.row == 0)
        {
            [self syncDataToServerWithIndicator:true];
        }
    }
    else
    {
        if (indexPath.row == 0)
        {
            [self pushToMyProfileViewController];
        }
        else if (indexPath.row == 1)
        {
            selectedIndex = [NSIndexPath indexPathForRow:0 inSection:0];
            [self pushToConversatiosViewController];
        }
        else if (indexPath.row == 6)
        {
            [self syncDataToServerWithIndicator:false];
            [self logoutAction];
        }
        else if (indexPath.row == 4) {
            selectedIndex = [NSIndexPath indexPathForRow:0 inSection:0];
            [_settingsTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionNone];
        }
        else if (indexPath.row == 5) {
            [self syncDataToServerWithIndicator:true];
        }
        else
        {
            selectedIndex = [NSIndexPath indexPathForRow:0 inSection:0];
            [_settingsTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionNone];
        }
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 12;
}

- (void) logoutAction
{
    NSLog(@"Logout selected");
    id <CMOXMPPDelegate>xmppManager = [_coreComponents xmppManager];
    [xmppManager disconnect];
    
    [[NSNotificationCenter defaultCenter]postNotificationName:LOGOUT_NOTIFICATION object:nil];
    
    [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:@"logout"];
//        [CMOUtils clearUserNamePassword];
    
    //remove user touch enable
//            [CMOUtils setUserDefaultForTouchID:@"NO"];
    //Empty user presence dictonary
    [((CMOTabBarController *)self.tabBarController) removeUserPresence];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        appDelegate.isLogout = YES;
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];
        CMONavigationController *navController = [[[[appDelegate window]rootViewController] childViewControllers]objectAtIndex:0];
        navController.navigationBar.hidden = true;
        [navController popToRootViewControllerAnimated:true];
    }
    else{
        //swich to first tab / tab navigation pop to root
        self.tabBarController.selectedIndex = 0 ;
        UINavigationController *navController = self.tabBarController.viewControllers[0];
        [navController popToRootViewControllerAnimated:true];
    }
    //reset last message sync time on logut
    [CMOUtils saveUnreadMessageCountLastSyncTime:@"0"];
}

- (void) syncDataToServerWithIndicator:(BOOL)showIndicator{
    NSLog(@"Data sync to server");
    if (showIndicator){
        UIWindow *window = [[[UIApplication sharedApplication] windows] lastObject];
        hudProgress = [MBProgressHUD showHUDAddedTo:[window.subviews lastObject] animated:YES];
        hudProgress.label.text = @"Sync in progress..";
    }
    
    //Code to sync the data to server.
    [chatModel updateSyncDataonSuccess:^(id result) {
        ////DDLogInfo(@"Manual Data Sync Success");
        if (showIndicator){
            [hudProgress hideAnimated:YES];
            hudProgress = nil;
        }
    } onFailure:^(NSError *error) {
        ////DDLogInfo(@"Manual Data Sync Failed");
        if (showIndicator){
            [hudProgress hideAnimated:YES];
            hudProgress = nil;
        }
    }];
}


@end
