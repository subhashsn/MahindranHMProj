//
//  CMOMoreDetailViewController.m
//  CMOChat
//
//  Created by Administrator on 10/30/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOConversationSettingsViewController.h"
#import "CMOTableViewDatasource.h"
#import "CMOTableViewDelegate.h"
#import "CMOChatPresentation.h"
#import "CMOParticipantInfo.h"
#import "CMOCoreComponents.h"
#import "APIClient.h"
#import "CMORosterViewController.h"
#import "CMOAssembly.h"
#import "CMOUser.h"
#import "CMORoomDetails+CoreDataClass.h"
#import "CMORoster+CoreDataProperties.h"
#import "CMORosterGroup+CoreDataProperties.h"
#import "CMOParticipantInfo.h"
#import "CMOUtils.h"
#import "CMOUserPresence.h"
#import "CMOTabBarController.h"

#define PARTICIPANT_IMAGE         100
#define PARTICIPANT_NAME          101
#define PARTICIPANT_DESIGNATION   102
#define PARTICIPANT_ADMIN         103
#define PARTICIPANT_UNDO          1000
#define OFFSET_CELLMOVE             82
#define NETWORK_ERROR @"Please check network connection."
#define TITLE_PARTICIPANTS @"Participants"
#define IMAGE_ONLINE_STATUS @"Status_Online"
#define IMAGE_OFFLINE_STATUS @"Status_Offline"

void (^deleteHandler)(NSIndexPath * indexPath);

@interface CMOConversationSettingsViewController ()<RosterListDelegate, NSFetchedResultsControllerDelegate>{
    
    CMOTableViewDatasource *dataSource;
    CMOTableViewDelegate *delegate;
    CMORosterViewController *rosterViewController;
    NSIndexPath *indexToBeDeleted;
    NSMutableArray *deletedItems;
    NSMutableArray *undoItem;
    NSMutableArray *participants;
    CMOTabBarController *tabBarController;
    BOOL isConnected;
}

@end

@implementation CMOConversationSettingsViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    id <CMORepositoryClient>client = [_coreComponents repositoryService];
    self.roomDetails = [client fetchRoomInfo:self.roomIdentifier];
    
    
    participants = [_chatModel clubOwnersAndMembers:self.roomDetails];
    
    NSLog(@"Participants %@",participants);
    
    [self.conversationSettingsTableview reloadData];
   
    
    //[self setTableViewOutlets:[_chatModel clubOwnersAndMembers:self.roomDetails]];
    
    /*[self.chatModel occupantsOfRooms:self.roomIdentifier completionHandler:^(NSMutableArray *items,NSError *error) {
     if (error){
     //Handle occupants error
     return ;
     }
     dispatch_async(dispatch_get_main_queue(), ^(){
     [self setTableViewOutlets:items];
     [self.conversationSettingsTableview reloadData];
     });
     }];*/
    deleteHandler = nil;
    deletedItems = [[NSMutableArray alloc]init];
    undoItem = [[NSMutableArray alloc]init];
    [self addNavigationBar];
    
    self.navigationItem.title = TITLE_PARTICIPANTS;
}

-(void) viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    /*if (deletedItems.count)
    {
        for (NSIndexPath *index in deletedItems)
        {
            [self removeUndoParticipants:index];
            [self deleteUser:index];
        }
    }
    
    [undoItem removeAllObjects];
    [deletedItems removeAllObjects];*/
    
    
    [self unRegisterNotifications];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
   /* [deletedItems removeAllObjects];
    [undoItem removeAllObjects];
    //////DDLogInfo(@"CMOConversationSettingsViewController::viewWillAppear called");
    [self refreshView];
    */
    NSError *error;
    if (![[self fetchedResultsController] performFetch:&error]) {
        // Update to handle the error appropriately.
        DDLogError(@"Unresolved error %@, %@", error, [error userInfo]);
    }
    
    [self registerNotifications];
    
}

- (void)addNavigationBar{
//    UIBarButtonItem* roomButton = [[UIBarButtonItem alloc] initWithTitle:@"Add user" style:UIBarButtonItemStylePlain target:self
//                                                                  action:@selector(addUser:)];
//    self.navigationItem.rightBarButtonItem = roomButton;
    //Add_Participants
   // if(self.roomDetails.roomProperty.isEligibleToJoin){
         UIButton *rightButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 20, 22)];
         [rightButton setImage:[UIImage imageNamed:@"Add_Participants"] forState:UIControlStateNormal];
         [rightButton addTarget:self action:@selector(addUser:) forControlEvents:UIControlEventTouchUpInside];
         self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
   // }
    
    UIButton *backButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    [backButton setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(goBack:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
}

- (void)participants:(id)participantslist{
    ////DDLogInfo(@"Users = %@",[self userNameList:participants]);
    [self addUsersToChatRoom:participantslist];
    //[self addGroupToChatRoom:participants];
    
}


- (void)registerNotifications{
    
    isConnected = true;
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(connectionEstablised:) name:XMPP_CONNECTION_ESTABLISHED object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(connectionInteruppted:) name:XMPP_DISCONNECT object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(connectionInteruppted:) name:XMPP_ACCIDENTAL_DISCONNECT_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(updatePresence:) name:XMPP_USER_PRESENCE_NOTIFICATION object:nil];
  
    
}

- (void)unRegisterNotifications{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_CONNECTION_ESTABLISHED object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_DISCONNECT object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_ACCIDENTAL_DISCONNECT_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_USER_PRESENCE_NOTIFICATION object:nil];
}



- (void)connectionEstablised:(NSNotification *)notification{
    isConnected = true;
    [self.conversationSettingsTableview reloadData];
}

- (void)connectionInteruppted:(NSNotification *)notification{
    isConnected = false;
    [self.conversationSettingsTableview reloadData];
}


- (void)updatePresence:(NSNotification *)notification{
    [self.conversationSettingsTableview reloadData];
}

- (BOOL)isUserOnline:(NSString *)userName{
    BOOL isOnline = false;
    
    if (userName.length > 0)
    {
        CMOUserPresence *presence = [[((CMOTabBarController *)self.tabBarController) getUserPresenceDictonary] valueForKey:[userName lowercaseString]];
   
            if ([presence.type isEqualToString:XMPP_PRESENCE_UNAVAILABLE]){
                isOnline = false;
            }
            else if(!presence)
            {
                isOnline = false;
            }
            else
            {
                isOnline = true;
            }
        
    }
    return isOnline;
}

//- (void)removeUser:(NSString *)userId {
//    //REST API
//    if (!userId){
//        DDLogError(@"USER ID IS NIL %@ %@",THIS_METHOD,THIS_FILE);
//        return;
//    }
//    [_chatModel removeUser:userId fromChatRoom:self.roomDetails.roomName onSuccess:^(id result) {
//        ////DDLogInfo(@"Successfully removed user from room");
//        [self refreshView];
//    } onFailure:^(NSError *error) {
//        DDLogError(@"Unable to remove user from Room. Error: %@",error);
//    }];
//}
//
//- (void)addGroupToChatRoom:(NSArray *)participants
//{
//    if (participants.count > 0)
//    {
//        id groupParticipants = participants;
//        NSMutableArray *groupList = [self groupNameList:groupParticipants];
//    
//        for (id group in groupList)
//            [self addGroup:group toChatRoom:self.roomDetails.roomName];
//    }
//}
//
//- (void)addGroup:(NSString *)groupId toChatRoom:(NSString *)roomId {
//    //REST API
//    [[_coreComponents roomPresentation]addGroups:[[NSMutableArray alloc]initWithObjects:groupId, nil] toChatRoom:roomId onSuccess:^(id response) {
//        ////DDLogInfo(@"Successfully added group to room and Inviting Users with Affiliation None");
//    } onFailure:^(NSError *error) {
//        DDLogError(@"Unable to add group to Room. Error: %@",error);
//
//    }];
//}

- (void)addUsersToChatRoom:(id)participantslist{
    //self.roomDetails.creationDate
    __block NSInteger callCount = 0;
    //__block Person *aPerson = nil;
    if ([[participantslist allKeys]count] > 0){
        NSArray *members = [self userNameList:participantslist];
       // callCount = members.count;
        __weak typeof(self) weakSelf = self;
        if (members.count > 0){
            for (NSString *member in members){
                 [_chatModel addUser:member toChatRoom:self.roomDetails.roomName onSuccess:^(id result) {
                        [weakSelf.chatModel inviteUsersToJoinTheRoom:members forRoom:weakSelf.roomDetails.roomName withAffiliation:AffiliationMember];
                        ////DDLogInfo(@"Successfully createad or Joined room");
                         callCount++;
                        //Call this only all calls in the for..loo are completed.
                         if (callCount == members.count){
                             [weakSelf retrieveChatRoom:weakSelf.roomDetails.roomName];
                         }
                         //////DDLogInfo(@"Result is %@",result);
                     } onFailure:^(NSError *error) {
                         DDLogError(@"Unable to get Rooms Error: %@",error);
                         callCount++;
                         //Call this only all calls in the for..loo are completed.
                         if (callCount == members.count){
                             [weakSelf retrieveChatRoom:weakSelf.roomDetails.roomName];
                         }
                }];
            }
        }
    }
}

- (void)retrieveChatRoom:(NSString *)roomName{
    
    ////DDLogInfo(@"Successfully createad or Joined room");
    //REST API
    [_chatModel retreiveChatRoom:self.roomDetails.roomName onSuccess:^(id result) {
        dispatch_async(dispatch_get_main_queue(), ^(){
            id <CMORepositoryClient>client = [_coreComponents repositoryService];
            self.roomDetails = [client fetchRoomInfo:self.roomIdentifier];
//            self.roomDetails = result;
         //   self.title = [self.roomDetails.roomSubject length] == 0 ? self.roomDetails.naturalName : self.roomDetails.roomSubject;
            // update datasource
            
            participants = [_chatModel clubOwnersAndMembers:self.roomDetails];
            
         //   [dataSource updateDatasource:[_chatModel clubOwnersAndMembers:self.roomDetails]];
            //self.conversationSettingsTableview.dataSource = nil;
           // self.conversationSettingsTableview.dataSource = dataSource;
            [self.conversationSettingsTableview reloadData];
        });
    }
    onFailure:^(NSError *error) {
        
    }];
}

//- (void)refreshView {
//    //REST API
//    self.roomDetails = [_chatModel retreiveChatRoom:self.roomIdentifier onSuccess:^(id result) {
//        
//        dispatch_async(dispatch_get_main_queue(), ^(){
//            self.roomDetails = result;
//            self.title = [self.roomDetails.roomSubject length] == 0 ? self.roomDetails.naturalName : self.roomDetails.roomSubject;
//            // update datasource
//            [self populateTableView];
//        });
//        //////DDLogInfo(@"Result is %@",result);
//    } onFailure:^(NSError *error) {
//        DDLogError(@"Unable to get Rooms Error: %@",error);
//    }];
//    
//    self.title = [self.roomDetails.roomSubject length] == 0 ? self.roomDetails.naturalName : self.roomDetails.roomSubject;
//    [self populateTableView];
//}
//
//- (void)populateTableView {
//    // update datasource
//    if(dataSource) {
//        [dataSource updateDatasource:[_chatModel clubOwnersAndMembers:self.roomDetails]];
//    }
//    else {
//        // Define the block.
//        delegate = nil;
//        if ([self canDeleteParticipants])
//        {
//            deleteHandler = ^(NSIndexPath * indexPath) {
//                indexToBeDeleted = indexPath;
//                //[self confirmUserDelete:@"ABC"];
//                [self undoParticipants:indexPath];
//            };
//        }
//        
//        dataSource = [[CMOTableViewDatasource alloc]initWithItems:[_chatModel clubOwnersAndMembers:self.roomDetails] identifier:@"conversationsettingcell" configureCell:^(UITableViewCell *cell, id item,NSIndexPath* indexPath) {
//            
//            [self updateDataSourceForTable:cell item:item indexPath:indexPath];
//            
//        } deleteHandler:deleteHandler];
//        dataSource.coreComponents = _coreComponents;
//    }
//    [delegate setCellHeight:87.0f];
//    self.conversationSettingsTableview.dataSource = nil;
//    self.conversationSettingsTableview.dataSource = dataSource;
//    [self performSelectorOnMainThread:@selector(reloadTableView) withObject:nil waitUntilDone:NO];
//}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
   // id  sectionInfo = [[_fetchedResultController sections] objectAtIndex:section];
   // NSInteger rowCount = [sectionInfo numberOfObjects];
    return [participants count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"conversationsettingcell" forIndexPath:indexPath];
    
    UIView *selectedBackgroundView = [[UIView alloc] initWithFrame:cell.bounds];
    selectedBackgroundView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    selectedBackgroundView.backgroundColor = [UIColor colorWithRed:234.0/255.0 green:242.0/255.0 blue:255.0/255.0 alpha:1.0];
    [cell setSelectedBackgroundView:selectedBackgroundView];
    
    [self configureCell:cell atIndexPath:indexPath];
    
    return cell;
}

- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    // show all participants first name
    CMOParticipantInfo *participantInfo = [participants objectAtIndex:indexPath.row];
    
    NSString *participantList = @"";
    
    NSArray* firstLastStrings = [participantInfo.participantName ? participantInfo.participantName : participantInfo.jid componentsSeparatedByString:@" "];
    NSString* firstName = [firstLastStrings objectAtIndex:0];
    if ([participantInfo.jid isEqualToString:CMOGroupName]) {
        firstName = CMOGroupDisplayName;
    }
    participantList = [NSString stringWithFormat:@"%@, %@",participantList, firstName];
    
    if (participantList.length > 2){
        participantList = [participantList substringFromIndex:2];
    }
    
    UILabel *participantLabel = (UILabel *)[cell viewWithTag:101];
    participantLabel.text = participantList;
    
    UILabel *participantDescLabel = (UILabel *)[cell viewWithTag:102];
    participantDescLabel.text = participantInfo.partcipantDesc;
    
    UIImageView *presenceImageView = (UIImageView *)[cell viewWithTag:105];
    
    NSString* bareId = [participantInfo.jid componentsSeparatedByString:@"@"][0];
    
    if (isConnected){
        presenceImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[self isUserOnline:bareId] ? IMAGE_ONLINE_STATUS : IMAGE_OFFLINE_STATUS]];
    }
    else{
        presenceImageView.image = [UIImage imageNamed:@"Status_Offline.png"];
    }
}


#pragma mark - Fetch Result controller and Delegate Methods

- (NSFetchedResultsController *)fetchedResultsController {
    
    if (self.fetchedResultController != nil) {
        return self.fetchedResultController;
    }
    
    self.managedObjectContext = [[_coreComponents repositoryService] getManagedObjectContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription
                                   entityForName:@"CMORoster" inManagedObjectContext:_managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"name" ascending:NO];
    fetchRequest.sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    
    //fetchRequest.predicate = [self getDefaultPredicate];
    
    [fetchRequest setFetchBatchSize:20];
    
    NSFetchedResultsController *theFetchedResultsController =
    [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest
                                        managedObjectContext:_managedObjectContext sectionNameKeyPath:nil
                                                   cacheName:nil];
    self.fetchedResultController = theFetchedResultsController;
    self.fetchedResultController.delegate = self;
    return _fetchedResultController;
}


- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller {
    // The fetch controller is about to start sending change notifications, so prepare the table view for updates.
    //if (self.viewLoaded && self.view.window) {
    [self.conversationSettingsTableview beginUpdates];
    //}
}


- (void)controller:(NSFetchedResultsController *)controller
   didChangeObject:(id)anObject
       atIndexPath:(NSIndexPath *)indexPath
     forChangeType:(NSFetchedResultsChangeType)type
      newIndexPath:(NSIndexPath *)newIndexPath {
    
    UITableView *tableView = self.conversationSettingsTableview;
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
        case NSFetchedResultsChangeDelete:
            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
        case NSFetchedResultsChangeUpdate:
            //[self configureCell:[tableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
            break;
        case NSFetchedResultsChangeMove:
            [tableView deleteRowsAtIndexPaths:[NSArray
                                               arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            [tableView insertRowsAtIndexPaths:[NSArray
                                               arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
    }
}

- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id )sectionInfo atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type {
    
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [self.conversationSettingsTableview insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [self.conversationSettingsTableview deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
        case NSFetchedResultsChangeMove:
        case NSFetchedResultsChangeUpdate:
        default:
            break;
    }
}


- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    [self.conversationSettingsTableview endUpdates];
}



-(void)goBack:(id)MACH_NOTIFY_NO_SENDERS{
    //NSLog(@"goBack");
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)pushToRosterViewController{
    if (rosterViewController)
    {
        rosterViewController = nil;
    }
    /*if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        rosterViewController = [_assembly ipadrosterviewcontroller];
        rosterViewController.iPadTabBarViewController = (CMOiPadTabBarViewController *)_iPadTabBarViewController;

    } else {*/
        rosterViewController = [_assembly rosterviewcontroller];
    //}
    
    rosterViewController.rosterDelegate = self;
    //get current participants list
    rosterViewController.chatType = ChatTypeExistingChat;
    
    NSArray *currentParticipants = [_chatModel clubOwnersAndMembers:self.roomDetails];
    rosterViewController.currentParticipants = currentParticipants;
    
    NSMutableArray *listofParticipants = [[NSMutableArray alloc]init];
    
    for (CMOParticipantInfo *info in participants) {
        NSString *jidStr = [info.jid stringByReplacingOccurrencesOfString:@"@10.0.0.4" withString:@""];
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setObject:jidStr forKey:@"username"];
        [listofParticipants addObject:dict];
    }
    rosterViewController.listOfExistParticpants = [listofParticipants mutableCopy];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        [self presentViewController:rosterViewController animated:YES completion:nil];
    } else {
        CMONavigationController *navController = (CMONavigationController *)self.navigationController;
        if (![navController.viewControllers containsObject:rosterViewController]){
            [navController pushViewController:rosterViewController];
        }
    }
}


- (void)addUser:(id)sender{
    if ([CMOUtils isNetworkAvailable]) {
        [self pushToRosterViewController];
    } else {
        [self showErrorAlertWithMessage:NETWORK_ERROR];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)confirmUserDelete:(NSString* )userId {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Delete Participant" message:@"Are you sure you want to Delete Participant from this conversation?"  preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"No" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //do nothing
    }];
    
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Yes" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //[self deleteUser];
        
    }];
    
    [alert addAction:cancel];
    [alert addAction:ok];
    
    [self presentViewController:alert animated:YES completion:nil];
}

//- (void)deleteUser: (NSIndexPath *)index
//{
//    //call delete user here
//    CMOParticipantInfo *participant = [_chatModel clubOwnersAndMembers:self.roomDetails][index.row];
//    NSLog(@"item = %@",participant.jid);
//    [self removeUser:[[XMPPJID jidWithString:participant.jid] user]];
//}

//- (void)deleteUser {
//    //call delete user here
//    CMOParticipantInfo *participant = [_chatModel clubOwnersAndMembers:self.roomDetails][indexToBeDeleted.row];
//    NSLog(@"item = %@",participant.jid);
//    [self removeUser:participant.jid];
//}

- (void) reloadTableView {
    [self.conversationSettingsTableview reloadData];
}

- (BOOL) canDeleteParticipants {
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *loggedInUser = [userClient user];
    
    id <CMORosterClient>rosterClient = [_coreComponents rosterService];
    CMORoster *roster = [rosterClient fetchRoster:loggedInUser.username];
    ////DDLogInfo(@"can delete = %ld",[roster.userPermission.canDeleteRecipients integerValue]);
    id <CMORepositoryClient> repositoryClient = [_coreComponents repositoryService];
    return ([loggedInUser.username isEqualToString:[repositoryClient fetchRoomInfo:self.roomIdentifier].roomOwner]);
}
/*- (void)setTableViewOutlets:(id)items{
    
    // Define the block.
    delegate = nil;
    if ([self canDeleteParticipants])
    {
        deleteHandler = ^(NSIndexPath * indexPath) {
            indexToBeDeleted = indexPath;
            //[self confirmUserDelete:@"ABC"];
            [self undoParticipants:indexPath];
        };
    }

    dataSource = [[CMOTableViewDatasource alloc]initWithItems:items identifier:@"conversationsettingcell" configureCell:^(UITableViewCell *cell, id item,NSIndexPath* indexPath) {
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        [self updateDataSourceForTable:cell item:item indexPath:indexPath];
        
    } deleteHandler:deleteHandler];
    dataSource.coreComponents = _coreComponents;
    
    delegate = [[CMOTableViewDelegate alloc]initWithItems:items configureCell:^(NSIndexPath *indexPath, id item) {
        
    }];
    [delegate setCellHeight:87.0f];
    
    self.conversationSettingsTableview.dataSource = dataSource;
    self.conversationSettingsTableview.delegate = delegate;
}

-(void)updateDataSourceForTable:(UITableViewCell *)cell item:(id)item indexPath:(NSIndexPath *)indexPath
{
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *loggedInUser = [userClient user];
    
    CMOParticipantInfo *participant = item;
    
    NSString *participantName =  participant.participantName ? participant.participantName:participant.jid;
    ////DDLogInfo(@"loginInUser %@",loggedInUser.username);
    ////DDLogInfo(@"participantName %@",participantName);
    if (![loggedInUser.username isEqualToString:participantName] ) {
        
        UIImageView *userNameView = (UIImageView *)[cell viewWithTag:PARTICIPANT_IMAGE];
        //userNameView.image = [UIImage imageNamed:@"114.png"];
        userNameView.layer.cornerRadius = 25;//35
        userNameView.layer.masksToBounds = YES;
        
        UILabel *userNameLabel = (UILabel *)[cell viewWithTag:PARTICIPANT_NAME];
        if ([participantName isEqualToString:CMOGroupName]) {
            participantName = CMOGroupDisplayName;
        }
        userNameLabel.text = participantName;
        
        UILabel *designateLabel = (UILabel *)[cell viewWithTag:PARTICIPANT_DESIGNATION];
        designateLabel.text = @"";//@"Designation"
        
        UILabel *adminLabel = (UILabel *)[cell viewWithTag:PARTICIPANT_ADMIN];
        adminLabel.text = @"";//@"Admin"
        
        if ([undoItem containsObject:indexPath]) {
            
            cell = [self customCellMove:cell movement:1];
        }
        else
        {
            UIView *view = [cell viewWithTag:PARTICIPANT_UNDO];
            if (view) {
                [cell viewWithTag:PARTICIPANT_UNDO].hidden = NO;
            }
            else
                [cell viewWithTag:PARTICIPANT_UNDO].hidden = YES;
        }
    }
}*/


//When delete button is selected
/*-(void)undoParticipants:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [self.conversationSettingsTableview cellForRowAtIndexPath:indexPath];
    
    UIView *view = [cell viewWithTag:PARTICIPANT_UNDO];
    if (view) {
        [view removeFromSuperview];
    }
    float width;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        width = CGRectGetWidth(_conversationSettingsTableview.frame);
    }
    else{
        width = CGRectGetWidth([UIScreen mainScreen].applicationFrame);
    }
    UIButton *undoButton = [[UIButton alloc] initWithFrame:CGRectMake(width - OFFSET_CELLMOVE, 0, OFFSET_CELLMOVE, cell.contentView.frame.size.height)];
    [undoButton setBackgroundColor:[UIColor colorWithRed:245.0/255.0 green:33.0/255.0 blue:38.0/255.0 alpha:1.0]];
    [undoButton setTitle:@"Undo" forState:UIControlStateNormal];
    [undoButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [undoButton setTag:PARTICIPANT_UNDO];
    [undoButton addTarget:self action:@selector(undoParticipantsAction:) forControlEvents:UIControlEventTouchUpInside];
    [cell addSubview:undoButton];
    
    if (![deletedItems containsObject:indexPath]) {
        [deletedItems addObject:indexPath];
    }
    [undoItem removeAllObjects];
    [undoItem addObject:indexPath];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    //[dataSource setdeleteItems:deletedItems];
    [self.conversationSettingsTableview reloadData];
}

//When undo button is selected
-(IBAction)undoParticipantsAction:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.conversationSettingsTableview];
    NSIndexPath *indexPath = [self.conversationSettingsTableview indexPathForRowAtPoint:buttonPosition];
    UITableViewCell *cell = [self.conversationSettingsTableview cellForRowAtIndexPath:indexPath];
    
    //[cell viewWithTag:PARTICIPANT_UNDO].hidden = YES;
    [cell viewWithTag:PARTICIPANT_IMAGE].hidden = NO;
    [cell viewWithTag:PARTICIPANT_NAME].hidden = NO;
    [cell viewWithTag:PARTICIPANT_DESIGNATION].hidden = NO;
    [cell viewWithTag:PARTICIPANT_ADMIN].hidden = NO;
    
    UIView *view = [cell viewWithTag:PARTICIPANT_UNDO];
    if (view) {
        [view removeFromSuperview];
    }
    
    cell = [self customCellMove:cell movement:2];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    [undoItem removeObject:indexPath];
    [deletedItems removeObject:indexPath];
    //[dataSource setdeleteItems:deletedItems];
}


//When navigating out of this screen
-(void)removeUndoParticipants:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [self.conversationSettingsTableview cellForRowAtIndexPath:indexPath];
    
    UIView *view = [cell viewWithTag:PARTICIPANT_UNDO];
    if (view) {
        [view removeFromSuperview];
    }
    
    cell = [self customCellMove:cell movement:2];
    
}

//Displaying the cell items when different options are selected
-(UITableViewCell *)customCellMove:(UITableViewCell *)cell movement:(NSInteger)movement
{
    UIImageView *userNameView = (UIImageView *)[cell viewWithTag:PARTICIPANT_IMAGE];
    UILabel *userNameLabel = (UILabel *)[cell viewWithTag:PARTICIPANT_NAME];
    UILabel *designateLabel = (UILabel *)[cell viewWithTag:PARTICIPANT_DESIGNATION];
    UILabel *adminLabel = (UILabel *)[cell viewWithTag:PARTICIPANT_ADMIN];
    
    if (movement == 1)//Left Movement
    {
        [userNameView setFrame:CGRectMake(userNameView.frame.origin.x - OFFSET_CELLMOVE,
                                          userNameView.frame.origin.y,
                                          userNameView.frame.size.width,
                                          userNameView.frame.size.height)];
        [userNameLabel setFrame:CGRectMake(userNameLabel.frame.origin.x - OFFSET_CELLMOVE,
                                           userNameLabel.frame.origin.y,
                                           userNameLabel.frame.size.width,
                                           userNameLabel.frame.size.height)];
        [designateLabel setFrame:CGRectMake(designateLabel.frame.origin.x - OFFSET_CELLMOVE,
                                            designateLabel.frame.origin.y,
                                            designateLabel.frame.size.width,
                                            designateLabel.frame.size.height)];
        [adminLabel setFrame:CGRectMake(adminLabel.frame.origin.x - OFFSET_CELLMOVE,
                                        adminLabel.frame.origin.y,
                                        adminLabel.frame.size.width,
                                        adminLabel.frame.size.height)];
    }
    else if(movement == 2)//Right Movement
    {
        [userNameView setFrame:CGRectMake(userNameView.frame.origin.x + OFFSET_CELLMOVE,
                                          userNameView.frame.origin.y,
                                          userNameView.frame.size.width,
                                          userNameView.frame.size.height)];
        [userNameLabel setFrame:CGRectMake(userNameLabel.frame.origin.x + OFFSET_CELLMOVE,
                                           userNameLabel.frame.origin.y,
                                           userNameLabel.frame.size.width,
                                           userNameLabel.frame.size.height)];
        [designateLabel setFrame:CGRectMake(designateLabel.frame.origin.x + OFFSET_CELLMOVE,
                                            designateLabel.frame.origin.y,
                                            designateLabel.frame.size.width,
                                            designateLabel.frame.size.height)];
        [adminLabel setFrame:CGRectMake(adminLabel.frame.origin.x + OFFSET_CELLMOVE,
                                        adminLabel.frame.origin.y,
                                        adminLabel.frame.size.width,
                                        adminLabel.frame.size.height)];
    }
    return cell;
    
}

//Button Action in iPad
- (IBAction)addUserButtonAction:(id)sender
{
    [self addUser:sender];
}*/

- (IBAction)backButtonAction:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

/*- (void)getAllOccupants{
    id<APIClient>client = [_coreComponents networkHandler];
    [client GET:@"" parameters:nil OnProgress:^(id  _Nullable progress) {
        
    } OnSuccess:^(id  _Nullable response) {
        
    } onFailure:^(NSError * _Nonnull error) {
        
    }];
}*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark --
#pragma mark Error Messages

- (void) showErrorAlertWithMessage: (NSString *)errorMessage
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:errorMessage preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //Handle Ok button action
    }];
    [alertController addAction:ok];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (NSMutableArray *)groupNameList:(NSMutableDictionary *)participants{
    
    NSMutableArray *groupNameArray = [[NSMutableArray alloc]init];
    if (participants.allKeys.count > 0){
        NSMutableArray *array = [participants valueForKey:MACROS_GROUPS];
        if (array){
            for (id roster in array){
                if ([roster isKindOfClass:[CMORosterGroup class]]){
                    CMORosterGroup *userRoster = (CMORosterGroup *)roster;
                    [groupNameArray addObject:userRoster.name];
                }
            }
        }
    }
    return groupNameArray;
}

- (NSMutableArray *)userNameList:(NSMutableDictionary *)participants{
    
    NSMutableArray *userNameArray = [[NSMutableArray alloc]init];
    if (participants.allKeys.count > 0){
        NSMutableArray *userRosterArray = [participants valueForKey:MACROS_CONTACTS];
        if ([userRosterArray count]){
            for (id roster in userRosterArray){
                if ([roster isKindOfClass:[CMORoster class]]){
                    CMORoster *userRoster = (CMORoster *)roster;
                    [userNameArray addObject:[NSString stringWithFormat:@"%@@%@",userRoster.username,[CMOUtils domainName]]];
                    ////DDLogInfo(@"userNameList::Name : %@",userRoster.name);
                    ////DDLogInfo(@"userNameList::UserName : %@",userRoster.username);
                }
            }
        }
    }
    return userNameArray;
}


@end
