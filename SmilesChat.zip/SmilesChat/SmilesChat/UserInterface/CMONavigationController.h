//
//  CMONavigationController.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CMONavigationController : UINavigationController<UINavigationControllerDelegate>

- (void)pushViewController:(UIViewController *)controller;

- (void)loadActivityView:(NSString *)message;

- (void)dismissActivityView;

- (void)loadStatus:(NSString *)message;

//Added to get CMOConversationsTableViewController object
@property (nonatomic, strong) UIViewController *controller;

@end
