//
//  CMOMyInfoViewController.h
//  CMOChat
//
//  Created by Subhash on 03/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CMOCountryCodeViewController.h"
#import "CMOOtpViewController.h"
@class CMOMyInfoViewController;
@class CMOAssembly;
@class CMOCoreComponents;


@interface CMOMyInfoViewController : UIViewController<UINavigationControllerDelegate,CountryCodeDelegate,MyOTPViewDelegate>


@property (nonatomic, weak)IBOutlet UIImageView *profilePicture;
@property (nonatomic, weak)IBOutlet UIView *profileDisplayView;
@property (nonatomic, weak)IBOutlet UIImageView *profileOuterPicture;
@property (nonatomic, weak)IBOutlet UILabel *lblProfileDisplayName;
@property (nonatomic, weak)IBOutlet UILabel *lblTitleName;

//Button
@property (nonatomic, weak)IBOutlet UIButton *btnLogin;
@property (nonatomic, weak)IBOutlet UIButton *btnCountryCode;
@property (nonatomic, weak)IBOutlet UISwitch *switchTouchID;

//View that need to handled
@property (nonatomic, weak)IBOutlet UIView *myProfileView1;//nameView
@property (nonatomic, weak)IBOutlet UIView *myProfileView2;//designationView;
@property (nonatomic, weak)IBOutlet UIView *myProfileView3;//enableTouchIDView;
@property (nonatomic, weak)IBOutlet UIView *myProfileView4;//mobileView;
@property (nonatomic, weak)IBOutlet UIView *myInfoView1;//designationMyInfoView;
@property (nonatomic, weak)IBOutlet UIView *myInfoView2;//mobileMyInfoView;
@property (nonatomic, weak)IBOutlet UIView *myInfoView3;//eMailMyInfoView;
@property (nonatomic, weak)IBOutlet UIView *myEditView1;//eMailForEditView;

//Button
@property (nonatomic, weak)IBOutlet UIButton *editProfileButton;
@property (nonatomic, weak)IBOutlet UIButton *cameraButton;
@property (nonatomic, weak)IBOutlet UIButton *backButton;


//NameView
@property (nonatomic, weak)IBOutlet UITextField *LastNameField;
@property (nonatomic, weak)IBOutlet UITextField *FirstNameField;

@property (nonatomic, weak)IBOutlet UILabel *lblDesignationForMyProfile;

//designationView
@property (nonatomic, weak)IBOutlet UITextField *designationField;

@property (nonatomic, weak)IBOutlet UILabel *lblMobileForMyProfile;


//Mobile View
@property (nonatomic, weak)IBOutlet UITextField *mobileNumberField;
@property (nonatomic, weak)IBOutlet UITextField *countryCodeField;

@property (nonatomic, weak)IBOutlet UILabel *lblEmailForMyProfile;

//Email
@property (nonatomic, weak)IBOutlet UITextField *emailField;


@property (nonatomic, weak)IBOutlet UIImageView *emailImgForenableTouchIDView;
@property (nonatomic, weak)IBOutlet UILabel *lblEmailForenableTouchIDView1;
@property (nonatomic, weak)IBOutlet UILabel *lblEmailForenableTouchIDView2;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *continueBtnTop;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *mobileBtnTop;

@property (strong, nonatomic) NSString *gFirstName;
@property (strong, nonatomic) NSString *gLastName;
@property (strong, nonatomic) NSString *gDesignation;
@property (strong, nonatomic) NSString *countryCode;
@property (strong, nonatomic) NSString *emailID;
@property (strong, nonatomic) NSString *mobileNumber;

@property (strong, nonatomic) CMOAssembly *assembly;
@property (strong, nonatomic) NSString *userName;

@property (readwrite, nonatomic) BOOL bMyInfoFlag;
@property (readwrite, nonatomic) BOOL bEditProfile;
@property (readwrite, nonatomic) BOOL bEditMobileNumber;

@property (readwrite, nonatomic) BOOL bSelectCountryCode;

@property (strong, nonatomic) CMOCoreComponents *coreComponents;

- (IBAction)closeView:(id)sender;
@end
