//
//  CMOChatContainerViewController.h
//  CMOChat
//
//  Created by Administrator on 11/15/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CMOUser.h"
#import "CMORoomInfo.h"
#import "CMOChatPresentation.h"
#import "CMORoomDetails+CoreDataClass.h"
#import "CMOCoreComponents.h"

@class CMOAssembly;
@class CMOiPadTabBarViewController;
@class CMOChatViewController;
@class CMORosterViewController;

@interface CMOChatContainerViewController : UIViewController


@property (nonatomic, weak)IBOutlet UIView *containerView;


@property (nonatomic, weak)CMOAssembly *assembly;


@property (nonatomic, strong)CMOUser *owner;
@property (nonatomic, strong)CMORoomDetails *roomInfo;
@property (nonatomic, assign)ChatType type;

@property(nonatomic, weak)CMOCoreComponents *coreComponents;

@property (weak, nonatomic) CMOChatPresentation *chatModel;
@property (strong, nonatomic) NSMutableDictionary *partcipantsList;
@property (strong, nonatomic) CMOChatViewController *chatvc;


@property (nonatomic, assign)BOOL isConfidential;

@property (strong, nonatomic) CMORosterViewController *rosterView;

- (IBAction)showParticipantList:(id)sender;

- (void)setNavigationTitle:(NSString *)title;

- (void)setParticipantCount:(NSInteger)count;

- (void) addRightNavigationBarItems;

- (void)refreshChatContainerview;

@end
