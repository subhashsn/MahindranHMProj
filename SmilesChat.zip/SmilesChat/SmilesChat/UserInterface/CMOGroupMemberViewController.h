//
//  CMOGroupMemberViewController.h
//  CMOChat
//
//  Created by Administrator on 11/28/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CMOAssembly;
@class CMOCoreComponents;

@class CMOTabBarController;
@class CMOiPadTabBarViewController;

@interface CMOGroupMemberViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *groupTableView;

@property (strong, nonatomic) CMOAssembly *assembly;
@property (strong, nonatomic) CMOCoreComponents *coreComponents;
@property (strong, nonatomic) NSString *groupName;

@property (nonatomic, strong) CMOTabBarController *tabBarController;
@property (nonatomic, strong) CMOiPadTabBarViewController *iPadTabBarController;

@end
