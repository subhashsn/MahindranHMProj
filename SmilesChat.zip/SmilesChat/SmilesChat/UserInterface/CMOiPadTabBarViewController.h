//
//  CMOiPadTabBarViewController.h
//  CMOChat
//
//  Created by Raju on 11/28/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CMOAssembly;

@interface CMOiPadTabBarViewController : UITabBarController<UITabBarControllerDelegate>

@property (nonatomic, strong) CMOAssembly *assembly;
//@property (nonatomic, strong) NSString *oldSelection;

- (NSMutableDictionary *) getUserPresenceDictonary;

- (void) removeUserPresence;

@end
