//
//  CMOLoginViewController.m
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOLoginViewController.h"
#import "CMOLoginPresentation.h"
#import "CMOLoginService.h"
#import "CMOChatService.h"
#import "CMORosterViewController.h"
#import "CMOAssembly.h"
#import "CMOCoreComponents.h"
#import "CMORosterService.h"
#import "APIClient.h"
#import "CMOUserClient.h"
#import "CMOConversationsTableViewController.h"
#import "CMORepositoryClient.h"
#import "CMOMyInfoViewController.h"
#import "CMOTabBarController.h"
#import "CMOUtils.h"
#import "CMOAppServerAPIClient.h"
#import "UIImageEffects.h"
#import <AFNetworking/AFNetworking.h>
#import "CMOXMPPManager.h"
#import "CMORosterPresentation.h"
#import "AppDelegate.h"

#define kOFFSET_FOR_KEYBOARD 120.0
#define USERNAME_FIELD      100
#define PASSWORD_FIELD      101

#define ERR_MSG_INVALID_USER_PASSWORD @"Invalid email or password. Try again."
#define ERR_MSG_USER_NOT_REGISTERED @"User not registerd"
#define LOADING_TEXT @"Loading..."
#define NETWORK_ERROR @"Please check network connection."

@import LocalAuthentication;

@interface CMOLoginViewController () <UITextFieldDelegate>{
    CMORosterViewController *rosterViewController;
    CMOConversationsTableViewController *conversationViewController;
    CMOMyInfoViewController *myinfoViewController;
    CMOLoginPresentation *loginModel;
    CMOAssembly *_assembly;
    CMOTabBarController *tabBarController;
    BOOL rememberPasswordFlag;
    BOOL showPasswordFlag;
    
    MBProgressHUD *hudProgress;
    CMOSplitViewController *splitViewController;
    
    BOOL isTouchEnable;
}

@end

@implementation CMOLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    self.userNameField.delegate = self;
    self.passwordField.delegate = self;
    
    //_backgroundImg.image = [self imageByApplyingDarkEffectToImage:_backgroundImg.image];
    [CMOUtils getCMSPasswordFromServer:[_coreComponents appServerAPIHandler]];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.userNameField resignFirstResponder];
    [self.passwordField resignFirstResponder];
    [self unregisterNotification];
    //[self.navigationController.navigationBar setHidden:NO];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    if(appDelegate.isLogout) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [hudProgress hideAnimated:YES];
        });
    }

    //fetching all group details to be used later
    //CMORosterPresentation * rosterModel = [_coreComponents rosterPresentation];
    //fetchAllUsersAndGroupsWithCompletionHandler
    /*[rosterModel fetchAllUsersAndGroupsWithCompletionHandler:^(id users) {
        
    } failure:^(NSError *error) {
        
    }];*/
    /*[rosterModel getGroupsWithCompletionHandler:^(NSArray *groups) {
        //nothing to handle
        ////DDLogInfo(@"Login: getting group list success");
    } failure:^(NSError *error) {
        ////DDLogInfo(@"Error in getting group list");
    }];*/
    
    [self registerNotification];
//    tabBarController = [_assembly tabBarController];
//    [tabBarController setHidden:YES];
//    
    bool firstLaunch = ([[NSUserDefaults standardUserDefaults] valueForKey:@"firstLaunch"] == nil);
    if (firstLaunch) {
        [CMOUtils clearUserNamePassword];
        rememberPasswordFlag = false;
    }
    
    [self.textFieldView bringSubviewToFront:self.btnShowPassword];
    showPasswordFlag = FALSE;
    [self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_disable.png"] forState:UIControlStateNormal];
    self.passwordField.secureTextEntry = YES;

    //Handle remember password
    rememberPasswordFlag = ([CMOUtils getUserName] != nil);
    if (rememberPasswordFlag)
    {
        [self.btnForgotPassword setImage:[UIImage imageNamed:@"Remember-Password-enable.png"] forState:UIControlStateNormal];
        
        self.userNameField.text = [CMOUtils getUserName];
        self.passwordField.text = [CMOUtils getPassword];
    }
    
    if ([CMOUtils getTouchIDUserDefaultValue])
    {
        [self evaluatePolicy];
    }
    else
    {
        if (![CMOUtils isNetworkInitialized]) {
            ////DDLogInfo(@"Network not initailized. wait.. ");
            double delayInSeconds = 2.0;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                [self loadLoginScreen];
            });
        } else {
            [self loadLoginScreen];
        }

    }
    
    _errorView.hidden = YES;
    
}

- (void) loadLoginScreen
{
    if (rememberPasswordFlag) {
        bool nilcheck = ([[NSUserDefaults standardUserDefaults] valueForKey:@"logout"] == nil);
        bool loggedin = [[[NSUserDefaults standardUserDefaults] valueForKey:@"logout"] isEqualToString:@"NO"];
        bool loggedInOrFirstTime = (nilcheck || loggedin);
        if ( loggedInOrFirstTime || isTouchEnable) {
            if (isTouchEnable) {
                isTouchEnable = NO;
            }
            [self login:self];
        }
    } else {
        [self.btnForgotPassword setImage:[UIImage imageNamed:@"Remember-Password-disable.png"] forState:UIControlStateNormal];
        
        self.userNameField.text = nil;
        self.passwordField.text = nil;
    }
    
    //Handle showPassword
    if ([self.passwordField.text length] > 0) {
        showPasswordFlag = TRUE;
        //[self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_disable.png"] forState:UIControlStateNormal];
    }
    else
    {
        showPasswordFlag = FALSE;
        //[self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_enable.png"] forState:UIControlStateNormal];
    }
    
    [self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_disable.png"] forState:UIControlStateNormal];
    
    //[self.backgroundImg setAlpha:0.8];
    //[self addBlurredImage];
}


- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    //[self.userNameField resignFirstResponder];
    //[self.passwordField resignFirstResponder];
   /* if (loginModel){
        if ([loginModel disconnect]){
            NSLog(@"********User Connection Termintated********");
            id <CMORepositoryClient>client = [_coreComponents repositoryService];
            [client clearAllData];
            [client clearAllRooms];
            
            id <CMOChatClient>chatClient = [_coreComponents chatService];
            [chatClient removeAllFiles];
        }
    } */
}

- (void)registerNotification {
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(connectionFailed:) name:XMPP_CONNECTION_FAILED object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(applicationBackground:) name:UIApplicationWillResignActiveNotification object:nil];
}

- (void)unregisterNotification {
    [[NSNotificationCenter defaultCenter] removeObserver:XMPP_CONNECTION_FAILED];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIApplicationWillResignActiveNotification object:nil];
}

- (void)connectionFailed:(NSNotification *)notification{
    ////DDLogInfo(@"Connection Failed");
    [self showErrorMessage:@"Connection failed. Please try again"];
}

- (void)showErrorMessage:(NSString *)errorText
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [hudProgress hideAnimated:YES];
    });
    if ([errorText length] > 0) {
        _errorView.hidden = NO;
        [_errorView setAlpha:0.5];
        [self.lblLoginError setText:errorText];
    }
    else
    {
        [self.lblLoginError setText:@""];
    }
    
}

- (UIImage *)imageByApplyingDarkEffectToImage:(UIImage*)inputImage
{
    UIColor *tintColor = [UIColor colorWithWhite:0.21 alpha:0.11];
    return [UIImageEffects imageByApplyingBlurToImage:inputImage withRadius:10 tintColor:tintColor saturationDeltaFactor:1.8 maskImage:nil];
}

#pragma mark Active Directory Login

- (IBAction)login:(id)sender{
    
    [_passwordField resignFirstResponder];
    [_userNameField resignFirstResponder];
    
    if ((![CMOUtils isNetworkAvailable]) &&
        (![CMOUtils isSameasLastLoggedinUser:[self.userNameField.text stringByTrimming]] || [[[NSUserDefaults standardUserDefaults] valueForKey:@"logout"] isEqualToString:@"YES"])
        ) {
        //no network
        [self showErrorMessage:NETWORK_ERROR];
        return;
    }
    
    if (![CMOUtils isNetworkAvailable] && ([CMOUtils getUserName] != nil) ) {
        [self pushToConversationsViewController];
        return;
    }
    
    //MVVM - Presentation layer can be used for test cases.
    loginModel = [_coreComponents loginPresentationWithUser:self.userNameField.text clientId:@"dhaskjhdjksahkh3232"];//[[CMOLoginPresentation alloc]initWithUser:self.userNameField.text clientId:@"dhaskjhdjksahkh3232"];
    
    if (loginModel.userName == nil){
        ////DDLogInfo(@"Error");

        //[self.lblLoginError setText:@"Invalid email or password. Try again"];

        [self showErrorMessage:ERR_MSG_INVALID_USER_PASSWORD];
        //[self.lblLoginError setText:ERR_MSG_INVALID_USER_PASSWORD];

        return;
    }
    else
        //[self showErrorMessage:@" "];
        [self.lblLoginError setText:@" "];
    
    _errorView.hidden = YES;
    hudProgress = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hudProgress.label.text = LOADING_TEXT;
    
    //Active Directory Login
    id <CMOLoginClient>login = [_coreComponents loginService];
    [login login:loginModel onSuccess:^(CMOUser *user) {
        //Login Success. Connect/Register with XMPP
        dispatch_async(dispatch_get_main_queue(), ^(){
            //[self connect:user password:@"123456"];
            [self connect:user password:self.passwordField.text];
        });
    } onError:^(NSError *error) {
        //Login Failed. Show Alert
    }];
}

- (IBAction)forgotPassword:(id)sender
{
    ////DDLogInfo(@"forgotPassword");
    if (!rememberPasswordFlag) {
        rememberPasswordFlag = TRUE;
        [self.btnForgotPassword setImage:[UIImage imageNamed:@"Remember-Password-enable.png"] forState:UIControlStateNormal];
    }
    else
    {
        rememberPasswordFlag = FALSE;
        [self.btnForgotPassword setImage:[UIImage imageNamed:@"Remember-Password-disable.png"] forState:UIControlStateNormal];
        [CMOUtils clearUserNamePassword];

    }
}

- (IBAction)showPassword:(id)sender
{
    ////DDLogInfo(@"showPassword");
    
    if ([self.passwordField.text length] > 0) {
        if (showPasswordFlag) {
            showPasswordFlag = FALSE;
            [self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_enable.png"] forState:UIControlStateNormal];
            self.passwordField.secureTextEntry = NO;
        }
        else
        {
            showPasswordFlag = TRUE;
            [self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_disable.png"] forState:UIControlStateNormal];
            self.passwordField.secureTextEntry = YES;
        }
    }
}
- (void)connect:(CMOUser *)user password:(NSString *)password{
    [loginModel connect:user andPassword:password completionHandler:^(id success, NSError *error) {
        if (error){
            //Show Authentication or Connection Error
            //[self.lblLoginError setText:@"Invalid username or password. Try again"];
            [self showErrorMessage:ERR_MSG_INVALID_USER_PASSWORD];
        }
        else{
            //getRoles and validate user in App Server
            //commenting call to getUsesRolesAndPermissions.Enable after demo
            //[self getUsesRolesAndPermissions:user.username password:password];
            id <CMORepositoryClient>client = [_coreComponents repositoryService];
            [client clearAllData];
            dispatch_async(dispatch_get_main_queue(), ^{
                [hudProgress hideAnimated:YES];
            });
            [self pushToConversationsViewController];
            //START
            //Login success.So add username,password to keychain if remember password selected
            /*[[NSUserDefaults standardUserDefaults] setValue:@"NO" forKey:@"logout"];
            if (rememberPasswordFlag) {
                //save data to keychain
                [CMOUtils saveUserName:[user.username lowercaseString] password:password];
            }
            //Handle navigation to conversations view here
            if ([self mobileNumberVerified]) {
                
             
            } else {
                [self pushToMyInfoViewController];
            }*/
            //END
            
            [CMOUtils setUserEncryptedDataWithName:_userNameField.text andPassword:_passwordField.text];
            if (!rememberPasswordFlag) {
                _userNameField.text = @"";
                _passwordField.text = @"";
            }
        }
    }];
}

/*
- (void)getUsesRolesAndPermissions:(NSString*)userName password:(NSString*)password {
    id <CMOAppServerAPIClient> client = [_coreComponents appServerAPIHandler];
    NSString *url = [NSString stringWithFormat:@"GetUserRolesAndPermissions/%@",userName];
    [client GET:url parameters:nil OnProgress:nil OnSuccess:^(id  _Nullable response) {
        //Success block
        //////DDLogInfo(@"Success response: %@",response);
        NSDictionary *res = response;
        id tmpName =  [res objectForKey:@"userName"];
        if ((tmpName != [NSNull null]) && [[[res objectForKey:@"userName"] lowercaseString] isEqualToString:[userName lowercaseString]]) {
            id <CMORepositoryClient>client = [_coreComponents repositoryService];
            //cleanup old user data in case user changes
            //[client clearAllPendingXMPPMessages];
            [client compareOfflineAndRemoveXMPPMessages];
            [client updateAllOfflineMessages];
            if (![CMOUtils isSameasLastLoggedinUser:[[userName stringByTrimming]lowercaseString]]) {
                //do db cleanup here
                //Call clear repositeries
                [client clearAllData];
                
                id <CMOChatClient>chatClient = [_coreComponents chatService];
                [chatClient removeAllFiles];
                [CMOUtils setUserDefaultForTouchID:@"NO"];
                [CMOUtils clearUserNamePassword];
                //Save logged in user
                [CMOUtils setLoggedinUserName:userName];
                [CMOUtils saveAllRoomsLastSyncTime:@"0"];
                [CMOUtils saveDeviceSyncVersion:@"0"];
                [CMOUtils clearVisitedRoomInfo];
                [CMOUtils clearArchivedRoomInfo];
                [CMOUtils clearSMSUserRoomInfo];
                [CMOUtils saveExchangeContactsLastSyncTime:@"0"];
            }
            
            if ([self versionCheck]) {
                [client clearDataOnVersionUpdate];
                
                [CMOUtils saveAllRoomsLastSyncTime:@"0"];
                [CMOUtils saveDeviceSyncVersion:@"0"];
                [CMOUtils saveExchangeContactsLastSyncTime:@"0"];
            }
            
            NSString *appVersion = [CMOUtils getAppVersion];
            NSString *presentVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
            
            if (!appVersion || ![presentVersion isEqualToString:appVersion]) {
                [CMOUtils saveAppVersion:presentVersion];
                [CMOUtils saveLastInstalledDate];
            }

            [client saveUserRolesAndPermissions:response];
            
            //First time after login,need to fetch all rooms
           
            //First time after login,need to fetch all room message count
            [CMOUtils saveUnreadMessageCountLastSyncTime:@"0"];
            
            //Valid user.Proceed
            //Login success.So add username,password to keychain if remember password selected
            if (rememberPasswordFlag) {
                //save data to keychain
                [CMOUtils saveUserName:[userName lowercaseString] password:password];
            }
            [[NSUserDefaults standardUserDefaults] setValue:@"NO" forKey:@"logout"];
            id tmmPhoneNumber = [res objectForKey:@"phoneNumber"];

            bool firstLaunch = (([[NSUserDefaults standardUserDefaults] valueForKey:@"firstLaunch"] == nil) || ([[[NSUserDefaults standardUserDefaults] valueForKey:@"firstLaunch"] isEqualToString:@"YES"]));
            
            if (firstLaunch) {
                //update device token to server if user registered.checking for phoneNumber for resgistered user
                if ((tmmPhoneNumber != [NSNull null]) &&  ![[tmmPhoneNumber stringByTrimming] isEqualToString:@""]) {
                    [self updateUserInfo:userName mobileNumber:[tmmPhoneNumber stringByTrimming]];
                }
                
                [[NSUserDefaults standardUserDefaults] setValue:@"NO" forKey:@"firstLaunch"];
            } else {
                if (tmmPhoneNumber == [NSNull null]) {
                    tmmPhoneNumber = @" ";
                }
                [[NSUserDefaults standardUserDefaults] setValue:@"NO" forKey:@"APNSDeviceTokenChanged"];
                [self updateUserInfo:userName mobileNumber:[tmmPhoneNumber stringByTrimming]];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [hudProgress hideAnimated:YES];
            });
            //Handle navigation to conversations view here
            if (tmmPhoneNumber == [NSNull null] || [[tmmPhoneNumber stringByTrimming] isEqualToString:@""] || [tmmPhoneNumber stringByTrimming].length == 0) {
                [self pushToMyInfoViewController];
            } else {
                //To check any updates available
                [self updateAppVersionDetailsToServerWithUser:tmpName];
            }
            
        } else {
            
            id<CMOXMPPDelegate> xmppManager = [_coreComponents xmppManager];
            [xmppManager disconnect];
            //[self.lblLoginError setText:@"User not registerd"];
            [self showErrorMessage:ERR_MSG_USER_NOT_REGISTERED];

            //[self.lblLoginError setText:ERR_MSG_USER_NOT_REGISTERED];

            ////DDLogInfo(@"User not registerd in App Server");
        }
    } onFailure:^(NSError * _Nonnull error) {
        //Failure block
        ////DDLogInfo(@"getUsesRolesAndPermissions error: %@",error);
        dispatch_async(dispatch_get_main_queue(), ^{
            [hudProgress hideAnimated:YES];
        });
    }];
}
*/

- (void)updateUserInfo:(NSString*)userName mobileNumber:(NSString*)mobileNumber {
    //update device token to server
    NSString *deviceToken = [[NSUserDefaults standardUserDefaults] valueForKey:@"APNSDeviceToken"];
    
    if (deviceToken != nil) {
        id <CMOAppServerAPIClient> client = [_coreComponents appServerAPIHandler];
        NSString *url = [NSString stringWithFormat:@"UpdateUserInfo/%@/%@/%@",userName,mobileNumber,deviceToken];
        [client GET:url parameters:nil OnProgress:nil OnSuccess:^(id  _Nullable response) {
            //Success block
           // ////DDLogInfo(@"UpdateUserInfo Success response: %@",response);
        } onFailure:^(NSError * _Nonnull error) {
            //Failure block
            ////DDLogInfo(@"UpdateUserInfo Failure error: %@",error);
            //setting first launch to YES to register device token on next launch
            [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:@"firstLaunch"];
        }];
    }
}


- (BOOL)mobileNumberVerified {
    return true;
}

- (void)pushToConversationsViewController{
    if (conversationViewController){
        conversationViewController = nil;
    }
    conversationViewController = [_assembly conversationsviewcontroller];
    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
    if (![navController.viewControllers containsObject:conversationViewController]){
        self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@""                                                                                style:UIBarButtonItemStylePlain target:nil action:nil];
        [navController pushViewController:conversationViewController];
    }
}

- (void)pushToRosterViewController{
    if (!rosterViewController){
        rosterViewController = [_assembly rosterviewcontroller];
    }
    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
    if (![navController.viewControllers containsObject:rosterViewController]){
        [navController pushViewController:rosterViewController];
    }
}

- (void)pushToMyInfoViewController{
    
    if (!myinfoViewController){
        myinfoViewController = [_assembly myinfoviewcontroller:self.userNameField.text];
    }
    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
    if (![navController.viewControllers containsObject:myinfoViewController]){
        myinfoViewController.bMyInfoFlag = YES;
        [navController pushViewController:myinfoViewController];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    //[textField resignFirstResponder];
    //return  true;
    
    NSInteger nextTag = textField.tag + 1;
    // Try to find next responder
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    if (nextResponder) {
        // Found next responder, so set it.
        [nextResponder becomeFirstResponder];
    } else {
        // Not found, so remove keyboard.
        [textField resignFirstResponder];
    }
    
    if (textField.returnKeyType == UIReturnKeyDone) {
        [_passwordField resignFirstResponder];
        [self login:self];
    }
    
    return NO; // We do not want UITextField to insert line-breaks.
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}
#pragma mark XMPP Register

- (void)registerUser{
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Setting NavigationBar

- (void)settingNavigationBar
{
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new]
                                                  forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.shadowImage = [UIImage new];
    self.navigationController.navigationBar.translucent = YES;
    self.navigationController.view.backgroundColor = [UIColor clearColor];
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
    
    /*NSArray *ver = [[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."];
    if ([[ver objectAtIndex:0] intValue] >= 7) {
        self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:1.0f];
        self.navigationController.navigationBar.translucent = NO;
    }else{
        self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:1.0f];
    }
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
    
    self.navigationItem.title = @"Login";
     */
}

#pragma mark Set Login UI

-(void)alertMessage:(NSString*)message
{
    UIAlertController* alert = [UIAlertController
                                alertControllerWithTitle:@"Touch ID for CMO"
                                message:message
                                preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction
                                    actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {}];
    
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark UITextField Delegates

-(void)setViewMovedUp:(BOOL)movedUp
{
    [UIView beginAnimations:nil context:NULL];
    
    [UIView setAnimationDuration:0.3]; // if you want to slide up the view
    
    CGRect rect = self.view.frame;
    
    if (movedUp)
    {
        // 1. move the view's origin up so that the text field that will be hidden come above the keyboard
        // 2. increase the size of the view so that the area behind the keyboard is covered up.
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            rect.origin.y -= 250;
        }
        else{
            rect.origin.y -= kOFFSET_FOR_KEYBOARD;
            rect.size.height += kOFFSET_FOR_KEYBOARD;
        }
        
        self.backgroundTop.constant -= (2 * kOFFSET_FOR_KEYBOARD);
        self.loginbtnTop.constant += kOFFSET_FOR_KEYBOARD;
    }
    else
    {
        // revert back to the normal state.
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            rect.origin.y += 250;
        } else {
            rect.origin.y += kOFFSET_FOR_KEYBOARD;
            rect.size.height -= kOFFSET_FOR_KEYBOARD;
        }
        self.loginbtnTop.constant -= kOFFSET_FOR_KEYBOARD;
        self.backgroundTop.constant += (2 * kOFFSET_FOR_KEYBOARD);
    }
    self.view.frame = rect;
    
    [UIView commitAnimations];
    [self.view updateConstraints];
}


-(void)textFieldDidEndEditing:(UITextField *)sender
{
    if  (self.view.frame.origin.y <= 0)
    {
        [self setViewMovedUp:NO];
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //NSLog(@"shouldChangeCharactersInRange");
    if (textField.tag == PASSWORD_FIELD)
    {
        if ([textField.text length] > 0) {
            
            if (self.passwordField.secureTextEntry) {
                if ([textField.text length] == 1 && [string isEqualToString:@""]) {
                    showPasswordFlag = FALSE;
                    [self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_enable.png"] forState:UIControlStateNormal];
                }
                else
                {
                    showPasswordFlag = TRUE;
                    [self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_disable.png"] forState:UIControlStateNormal];
                }
            }
            else
            {
                if ([textField.text length] == 1 && [string isEqualToString:@""]) {
                    showPasswordFlag = TRUE;
                    [self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_disable.png"] forState:UIControlStateNormal];
                }
                else
                {
                    showPasswordFlag = FALSE;
                    [self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_enable.png"] forState:UIControlStateNormal];
                }
            }
        }
        else
        {
            if (self.passwordField.secureTextEntry)
            {
                if ([string length] > 0) {
                    showPasswordFlag = TRUE;
                    [self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_disable.png"] forState:UIControlStateNormal];
                }
            }
            else
            {
                if ([string length] > 0) {
                    showPasswordFlag = FALSE;
                    [self.btnShowPassword setImage:[UIImage imageNamed:@"ViewPassword_enable.png"] forState:UIControlStateNormal];
                }
            }
        }
    }
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)sender
{
    //move the main view, so that the keyboard does not hide it.
    if  (self.view.frame.origin.y >= 0)
    {
        [self setViewMovedUp:YES];
    }
}

#pragma mark Email Validation Check

-(BOOL) validateEmail:(NSString*) emailString
{
    NSString *regExPattern = @"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}$";
    NSRegularExpression *regEx = [[NSRegularExpression alloc] initWithPattern:regExPattern options:NSRegularExpressionCaseInsensitive error:nil];
    NSUInteger regExMatches = [regEx numberOfMatchesInString:emailString options:0 range:NSMakeRange(0, [emailString length])];
    //////DDLogInfo(@"%ld", regExMatches);
    if (regExMatches == 0) {
        return NO;
    }
    else
        return YES;
}

- (void)evaluatePolicy
{
    LAContext *context = [[LAContext alloc] init];
    // Show the authentication UI with our reason string.
    context.localizedFallbackTitle = @"";

    [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:@"Place your finger on the Home button to login." reply:^(BOOL success, NSError *authenticationError) {
        if (success) {
            
            dispatch_async(dispatch_get_main_queue(), ^(void){                
                isTouchEnable = YES;
                [self loadLoginScreen];
            });
        }
        else {
           // NSLog(@"authenticationError : %@",authenticationError);
            UIAlertController* alert = [UIAlertController
                                        alertControllerWithTitle:@"Touch ID for \"Damac Reach\" Failed"
                                        message:@"App not able to recognize Touch id. Login using email id and password"
                                        preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *okButton = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
//                [self evaluatePolicy];
                dispatch_async(dispatch_get_main_queue(), ^(void){
                    [self.btnForgotPassword setImage:[UIImage imageNamed:@"Remember-Password-disable.png"] forState:UIControlStateNormal];
                    self.userNameField.text = nil;
                    self.passwordField.text = nil;
                    rememberPasswordFlag = false;
                });
            }];
            [alert addAction:okButton];
            
            [self presentViewController:alert animated:YES completion:nil];
        }
    }];
}

#pragma mark --
#pragma mark Error Messages

- (void) showErrorAlertWithMessage: (NSString *)errorMessage
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:errorMessage preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //Handle Ok button action
    }];
    [alertController addAction:ok];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)applicationBackground:(NSNotification *)notification{
    [self.userNameField resignFirstResponder];
    [self.passwordField resignFirstResponder];
}

- (BOOL) versionCheck{
    
    BOOL result = false;
    NSString *appVersion = [CMOUtils getAppVersion];
    if (!appVersion || [appVersion doubleValue] < APP_VERSION) {
        result = true;
    }
    return result;
}

#pragma mark --
#pragma mark version update to server
     
/*- (void) updateAppVersionDetailsToServerWithUser:(NSString *)user{
    
     [loginModel updateAppVersionWithUser:user onSuccess:^(CMOVersionInfo *versionInfo) {
         if (versionInfo) {
             BOOL isVersionUpdated = [self checkVersionUpdateWithInfo:versionInfo];
             BOOL isUpdateRequired = [self isServerTime:versionInfo.forceUpdateBy graterThanLocalTime:[NSDate date]];
             dispatch_async(dispatch_get_main_queue(), ^{
                 if (isVersionUpdated && isUpdateRequired && versionInfo.forceUpdate && versionInfo.downloadUrl && ![versionInfo.downloadUrl isEqualToString:@""]) {
                     [self showForceDownloadAlertWithURL:versionInfo.downloadUrl];
                 }
                 else if(isVersionUpdated && isUpdateRequired && versionInfo.downloadUrl && ![versionInfo.downloadUrl isEqualToString:@""]){
                     [self showUpdateAvailableAlertWithURL:versionInfo.downloadUrl];
                 }
                 else{
                     NSLog(@"isUpdateAvailable : %d -- isForceUpdate : %d -- url : %@", isVersionUpdated, versionInfo.forceUpdate, versionInfo.downloadUrl);
                     [self pushToConversatiosOnMainThread];
                 }
             });
         }
         else{
             [self pushToConversatiosOnMainThread];
         }
     } onFailure:^(NSError *error) {
         [self pushToConversatiosOnMainThread];
         //DDLogInfo(@"Failed to get version details: %@", error);
     }];
}

- (BOOL) checkVersionUpdateWithInfo:(CMOVersionInfo *) info{
    
    NSString *currentAppVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    
    if ([currentAppVersion doubleValue] < [info.appVersion doubleValue]) {
        return true;
    }
    
    return false;
}*/

- (void)pushToConversatiosOnMainThread
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self pushToConversationsViewController];
    });
}

/*- (void)showForceDownloadAlertWithURL:(NSString *)newAppURL{

    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"Mandatory update available. Please install the update." preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okButton = [UIAlertAction actionWithTitle:@"Update Now !" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
    {
        [self loadBrowserWithURL:newAppURL];
    }];
    [alertController addAction:okButton];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)showUpdateAvailableAlertWithURL:(NSString *)newAppURL{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"Update available. Do you want to continue?" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancelButton = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
   {
       [self pushToConversationsViewController];
   }];
    UIAlertAction *okButton = [UIAlertAction actionWithTitle:@"Update !" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
   {
       [self loadBrowserWithURL:newAppURL];
   }];
    [alertController addAction:cancelButton];
    [alertController addAction:okButton];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void) loadSafariWithURL: (NSString *)updatedAppURL{
    
    NSURL *appURL = [NSURL URLWithString:updatedAppURL];
    if (![[UIApplication sharedApplication] openURL:appURL]) {
        //DDLogInfo(@"%@%@",@"Failed to open url:",[appURL description]);
    }
}

- (void) loadBrowserWithURL:(NSString *)newAppURL{
    //Stop loading
    [loginModel disconnect];
    [self loadSafariWithURL:newAppURL];
}

- (BOOL)isServerTime:(NSInteger)serverTime graterThanLocalTime:(NSDate *)date
{
    NSDate *serverDate = [NSDate dateWithTimeIntervalSince1970: serverTime/1000];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [dateFormatter setTimeZone:timeZone];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *localDateString = [dateFormatter stringFromDate:date];
    NSDate *localDateUTC = [dateFormatter dateFromString:localDateString];
    
    NSLog(@"Time: %lli", [@(floor([localDateUTC timeIntervalSince1970] * 1000)) longLongValue]);
    
    if([serverDate compare: localDateUTC] == NSOrderedAscending)
    {
        return true;
    }
    return false;
}*/

@end
