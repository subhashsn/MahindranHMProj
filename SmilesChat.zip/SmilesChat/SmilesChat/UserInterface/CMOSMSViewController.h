//
//  CMOSMSViewController.h
//  CMOChat
//
//  Created by Administrator on 4/1/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <MessageUI/MessageUI.h>
@class CMOMessage;
@class CMOChatPresentation;
@protocol MessageControllerDelegate <NSObject>

- (void)messageComposeDidFinishWithResult:(MessageComposeResult)result andMessage:(NSString *)message;

@end

@interface CMOSMSViewController : MFMessageComposeViewController

@property (nonatomic, strong)CMOChatPresentation *chatModel;

- (id)initWithDelegate:(id <MessageControllerDelegate>)delegate;

- (void)sendSMSTo:(NSMutableArray *)phoneNumbers withMessage:(NSString *)message;

@end
