//
//  CMODocumentPreviewViewController.h
//  CMOChat
//
//  Created by Raju on 1/6/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuickLook/QuickLook.h>

@class CMOChatPresentation;
@class CMOMessage;
@class CMOAssembly;

@protocol DocumentPreiewViewDelegate <NSObject>

@optional
- (void) updateDocumentListOnDeletionWithObject:(NSUInteger)index;
- (void) updateAttachmentOnDeletionWithObjectFromPreview:(NSUInteger)index;

@end

@interface CMODocumentPreviewViewController : UIViewController <QLPreviewControllerDataSource, QLPreviewControllerDelegate>

@property (nonatomic, weak) IBOutlet UIView *containerView;

@property (nonatomic, strong) CMOAssembly *assembly;
@property (nonatomic, strong) NSURL *docURL;
@property (nonatomic, strong) NSIndexPath *selectedIndex;
@property (nonatomic, strong) CMOChatPresentation *chatModel;
@property (nonatomic, strong) NSString *roomID;
@property (nonatomic, strong) CMOMessage *message;
@property (nonatomic, assign) BOOL isDocument; // Check Document or Media file
@property (nonatomic, weak) IBOutlet UILabel *iPadTitle;

@property (nonatomic, weak) id <DocumentPreiewViewDelegate> delegate;

@end
