//
//  CMORosterViewController.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

#import "CMOChatPresentation.h"
#import "CMOCoreComponents.h"

@class CMOAssembly;
@class CMOCoreComponents;
@class CMOParticipantInfo;
@class CMOSplitViewController;
@class CMOiPadTabBarViewController;

@protocol RosterListDelegate <NSObject>

- (void)participants:(id)participants;

@end


@interface CMORosterViewController : UIViewController <RosterListDelegate,UISearchBarDelegate, NSFetchedResultsControllerDelegate,ChatPresentationDelegate>

@property (weak, nonatomic) IBOutlet UITableView *rosterTableView;
@property (weak, nonatomic) IBOutlet UIImageView *selectedUser;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *RosterTableHeight;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segControlForControl;
//@property (weak, nonatomic) IBOutlet UIImageView *statusOnline;

@property (strong, nonatomic) UISearchBar *searchBar;

@property (assign, nonatomic) ChatType chatType;

@property (strong, nonatomic) NSMutableDictionary *participantsDict;


//This will be applicatble for new room
@property (assign, nonatomic) BOOL isChatConfidential;

@property (nonatomic, weak) IBOutlet UICollectionView *profileCollection;

//@property (strong, nonatomic) IBOutlet UISearchDisplayController *searchBarController;

//@property (nonatomic, strong) IBOutlet UISearchController *searchController;

@property (weak, nonatomic) id<RosterListDelegate>rosterDelegate;
@property (weak, nonatomic) CMOAssembly *assembly;
@property (weak, nonatomic) CMOCoreComponents *coreComponents;
@property (strong, nonatomic) NSArray<CMOParticipantInfo *> *currentParticipants;

@property (nonatomic, strong) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain) NSFetchedResultsController *rosterFetchedResultsController;

@property (strong, nonatomic) CMORoomPresentation *roomModel;
@property (weak, nonatomic) CMOChatPresentation *chatModel;
@property (strong, nonatomic)NSArray *listOfExistParticpants;


@end
