//
//  CMOMoreDetailViewController.h
//  CMOChat
//
//  Created by Administrator on 10/30/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CMORoomInfo.h"
#import <CoreData/CoreData.h>

@class CMOChatPresentation;
@class CMOAssembly;
@class CMOCoreComponents;
@class CMORoomDetails;
@class CMORoomPresentation;

@interface CMOConversationSettingsViewController : UIViewController

@property (nonatomic, weak)IBOutlet UITableView *conversationSettingsTableview;

@property (strong, nonatomic) CMOAssembly *assembly;

@property (strong, nonatomic) CMOCoreComponents *coreComponents;

@property (strong, nonatomic) CMOChatPresentation *chatModel;

@property (nonatomic, strong)NSString *roomIdentifier;

@property (nonatomic, strong)NSManagedObjectContext *managedObjectContext;

@property (nonatomic, strong)NSFetchedResultsController *fetchedResultController;

//Room participants can be from existing chat or new chat.
@property (nonatomic, strong)NSMutableArray *roomParticipants;

@property (nonatomic, strong)CMORoomDetails *roomDetails;

//- (id)initWithRoomId:(NSString *)roomIdentifier;

@end
