//
//  CMOTableViewDatasource.h
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CMOCoreComponents;

typedef void(^ConfigureCellDataSourceBlock)(UITableViewCell* cell,id item,NSIndexPath* indexPath);
typedef void(^deleteCellDataSourceBlock)(NSIndexPath *indexPath);

@interface CMOTableViewDatasource : NSObject <UITableViewDataSource>

@property (strong, nonatomic) CMOCoreComponents *coreComponents;
//@property (readwrite, nonatomic) BOOL undoButton;
@property (strong, nonatomic) NSArray *deleteItemsArray;

- (instancetype)initWithItems:(NSArray *)items
                   identifier:(NSString *)identifier
                configureCell:(ConfigureCellDataSourceBlock)configureCellBlock;

- (instancetype)initWithItems:(NSArray *)items
                   identifier:(NSString *)identifier
                configureCell:(ConfigureCellDataSourceBlock)configureCellBlock
                deleteHandler:(deleteCellDataSourceBlock _Nullable )deleteBlock;

- (void)setdeleteItems:( NSArray * _Nullable )deleteItems;
- (void)setNumberOfSection:(NSInteger)section;
- (void)updateDatasource:(NSArray * _Nullable)items;
@end
