//
//  CMOFullImageViewController.m
//  CMOChat
//
//  Created by Raju on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOFullImageViewController.h"
#import "CMOMessage.h"
#import "CMOPhotoMediaItem.h"
#import "CMOChatPresentation.h"
#import "CMOVideoMediaItem.h"
#import "CMOAudioMediaItem.h"
#import <AVFoundation/AVFoundation.h>
#import "AppDelegate.h"
#import <AVKit/AVKit.h>



#define IMAGE_TAG 99
#define VIDEO_TAG 98
#define VIDEO_PREVIEW_TAG 97
#define SCROLL_VIEW_TAG 2

@interface CMOFullImageViewController ()
{
    AppDelegate *appDelegate;
    BOOL isReload;
    AVPlayerViewController *playerController;
    AVPlayer *player;
}

@end

@implementation CMOFullImageViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self addNavigationBar];
    [_noAttachments setHidden:YES];
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    if (!isReload) {
        [_fullImageCV reloadData];
        if(_selectedIndex.row != 0)
        {
            dispatch_async(dispatch_get_main_queue(), ^(){
                [_fullImageCV selectItemAtIndexPath:_selectedIndex animated:NO scrollPosition:UICollectionViewScrollPositionCenteredHorizontally];
            });
        }
        isReload = YES;
    }
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) dealloc
{
    _mediaMessage = nil;
    _assembly = nil;
}

#pragma mark - Collection view data source

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (_mediaMessage.count > 0)
    {
        [_noAttachments setHidden:YES];
        return _mediaMessage.count;
    }
    else
    {
        [_noAttachments setHidden:NO];
        return 0;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"fullImageCell";
    
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    CMOMessage *message = _mediaMessage[indexPath.row];
    
    if ([message.media isKindOfClass:[CMOPhotoMediaItem class]])
    {
        CMOPhotoMediaItem *mediaItem = (CMOPhotoMediaItem *)message.media;

        UIImageView *imageView = (UIImageView *)[cell viewWithTag:IMAGE_TAG];
        imageView.image = mediaItem.image;
        [imageView setHidden:NO];
        
        UIImageView *videoPlayView = (UIImageView *)[cell viewWithTag:VIDEO_PREVIEW_TAG];
        [videoPlayView setHidden:YES];

        UIImageView *videoPlayIconView = (UIImageView *)[cell viewWithTag:VIDEO_TAG];
        [videoPlayIconView setHidden:YES];
        
        //image zoom configuration
        UIScrollView *scrollView = (UIScrollView *)[cell viewWithTag:SCROLL_VIEW_TAG];
        [scrollView setHidden:NO];
        scrollView.zoomScale = 1.0;
        cell.layer.shouldRasterize = YES;
        cell.layer.rasterizationScale = [UIScreen mainScreen].scale;
        
        UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTapRecognized:)];
        [doubleTap setNumberOfTapsRequired:2];
        [scrollView addGestureRecognizer:doubleTap];
    }
    else if ([message.media isKindOfClass:[CMOVideoMediaItem class]])
    {
        CMOVideoMediaItem *mediaItem = (CMOVideoMediaItem *)message.media;
        
        UIImageView *videoPlayView = (UIImageView *)[cell viewWithTag:VIDEO_PREVIEW_TAG];
        videoPlayView.image = [self generateVideoThumbnail:mediaItem.fileURL];
        [videoPlayView setHidden:NO];
        
        UIImageView *videoPlayIconView = (UIImageView *)[cell viewWithTag:VIDEO_TAG];
        [videoPlayIconView setHidden:NO];
        
        UIImageView *imageView = (UIImageView *)[cell viewWithTag:IMAGE_TAG];
        [imageView setHidden:YES];
        
        UIScrollView *scrollView = (UIScrollView *)[cell viewWithTag:SCROLL_VIEW_TAG];
        [scrollView setHidden:YES];
    }
    else if ([message.media isKindOfClass:[CMOAudioMediaItem class]])
    {
        UIImageView *videoPlayView = (UIImageView *)[cell viewWithTag:VIDEO_PREVIEW_TAG];
        videoPlayView.image= [UIImage imageNamed:@"audio-fullBackground"];
        [videoPlayView setHidden:NO];
        
        UIImageView *videoPlayIconView = (UIImageView *)[cell viewWithTag:VIDEO_TAG];
        [videoPlayIconView setHidden:YES];
        
        UIImageView *imageView = (UIImageView *)[cell viewWithTag:IMAGE_TAG];
        [imageView setHidden:YES];
        
        UIScrollView *scrollView = (UIScrollView *)[cell viewWithTag:SCROLL_VIEW_TAG];
        [scrollView setHidden:YES];
        
    }
    
    return cell;
}


-(UIImage *)generateVideoThumbnail : (NSURL *)filepath
{
    AVAsset *asset = [AVAsset assetWithURL:filepath];
    AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc]initWithAsset:asset];
    imageGenerator.appliesPreferredTrackTransform = YES;
    CMTime time = [asset duration];
    time.value = 0;
    CGImageRef imageRef = [imageGenerator copyCGImageAtTime:time actualTime:NULL error:NULL];
    UIImage *thumbnail = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);  // CGImageRef won't be released by ARC
    
    return thumbnail;
}

#pragma mark - Collection view Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    CMOMessage *message = _mediaMessage[indexPath.row];
    
    if ([message.media isKindOfClass:[CMOVideoMediaItem class]])
    {
        CMOVideoMediaItem *mediaItem = (CMOVideoMediaItem *)message.media;
        [self loadMediaWithURL:mediaItem.fileURL];
    }
    else if ([message.media isKindOfClass:[CMOAudioMediaItem class]])
    {
        CMOAudioMediaItem *mediaItem = (CMOAudioMediaItem *)message.media;
        [self loadMediaWithURL:mediaItem.audioUrl];
    }
}

- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    CMOMessage *message = _mediaMessage[indexPath.row];
    
    NSDate *date = message.date;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd, MMM YY, hh:mma"];
    
    NSString *stringWithFormat = [NSString stringWithFormat:@"%@\n%@",message.senderDisplayName, [formatter stringFromDate:date]];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 480, 44)];
    label.backgroundColor = [UIColor clearColor];
    label.numberOfLines = 2;
    label.font = [UIFont systemFontOfSize: 10.0f];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blackColor];
    label.text = stringWithFormat;
    
    _iPadTitle.text = label.text;
    
    self.navigationItem.titleView = label;
}

- (void) loadMediaWithURL:(NSURL *)url
{
    appDelegate.isReloadSplitView = NO;
    
    player = [AVPlayer playerWithURL:url];
    playerController = [[AVPlayerViewController alloc] init];
    //    playerController.showsPlaybackControls = NO;
    playerController.allowsPictureInPicturePlayback = NO;
    playerController.view.frame = self.view.bounds;
    [self presentViewController:playerController animated:YES completion:nil];
    playerController.player = player;
    [player play];
}

#pragma mark - Collection view delegate flow layout

- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewFlowLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
}

#pragma mark - Navigation bar button

- (void)addNavigationBar
{
    UIImage *image = [UIImage imageNamed:@"Delete"];
    UIButton *deleteButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
    [deleteButton setImage:image forState:UIControlStateNormal];
    [deleteButton addTarget:self action:@selector(deleteAction:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:deleteButton];
    
    UIButton *backButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    [backButton setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(goBack:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
}

-(void)goBack:(id)MACH_NOTIFY_NO_SENDERS
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)deleteAction:(id)MACH_NOTIFY_NO_SENDERS
{
    
    UIAlertController *alert;
    
    alert = [UIAlertController
             alertControllerWithTitle:@""
             message:@"Are you sure you want to delete?"
             preferredStyle:UIAlertControllerStyleAlert];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        alert.popoverPresentationController.sourceView = self.view;
        alert.popoverPresentationController.sourceRect = self.view.frame;
    }
    
    UIAlertAction* btnCancel = [UIAlertAction
                                actionWithTitle:@"Cancel"
                                style:UIAlertActionStyleCancel
                                handler:^(UIAlertAction * action)
                                {
                                    //  UIAlertController will automatically dismiss the view
                                }];
    
    UIAlertAction* deleteBtn = [UIAlertAction
                                actionWithTitle:@"Delete"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
                                {
                                    [self deleteImage];
                                }];
    
    [alert addAction:btnCancel];
    [alert addAction:deleteBtn];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void) deleteImage
{
    if (_mediaMessage.count > 0)
    {
        UICollectionViewCell *cell = [[_fullImageCV visibleCells] firstObject];
        NSIndexPath *indexPath = [_fullImageCV indexPathForCell:cell];
        
        CMOMessage *message = _mediaMessage[indexPath.row];
        
        BOOL isFileDeleted = [_chatModel deleteDocument:message.messageBody.body roomID:_roomID];
        if (isFileDeleted)
        {
            [[NSNotificationCenter defaultCenter]postNotificationName:DELETE_DOCUMENT_NOTIFICATION object:nil userInfo:@{@"message":message}];
            [_mediaMessage removeObjectAtIndex:indexPath.row];
            [_fullImageCV reloadData];
            [_delegate updateAttachmentOnDeletionWithObject:indexPath.row];
        }
    }
}

#pragma mark - Image zoom

- (void)doubleTapRecognized:(UITapGestureRecognizer*)recognizer
{
    UICollectionViewCell *cell = [[_fullImageCV visibleCells] firstObject];
    UIScrollView *scrollView = (UIScrollView *)[cell viewWithTag:SCROLL_VIEW_TAG];
    
    if(scrollView.zoomScale > scrollView.minimumZoomScale)
    {
        //Zoom in image
        [scrollView setZoomScale:scrollView.minimumZoomScale animated:YES];
    }
    else
    {
        //Zoom out image
        [self zoomToPoint:[recognizer locationInView:scrollView] withScrollObject:scrollView];
    }
}

- (void)zoomToPoint:(CGPoint)zoomPoint withScrollObject:(UIScrollView *)scrollView
{
    
    //Normalize current content size back to content scale of 1.0f
    CGSize contentSize;
    contentSize.width = (scrollView.contentSize.width / scrollView.zoomScale);
    contentSize.height = (scrollView.contentSize.height / scrollView.zoomScale);
    
    //translate the zoom point to relative to the content rect
    zoomPoint.x = (zoomPoint.x / scrollView.bounds.size.width) * contentSize.width;
    zoomPoint.y = (zoomPoint.y / scrollView.bounds.size.height) * contentSize.height;
    
    //derive the size of the region to zoom to
    CGSize zoomSize;
    zoomSize.width = scrollView.bounds.size.width / 2.0f;
    zoomSize.height = scrollView.bounds.size.height / 2.0f;
    
    //offset the zoom rect so the actual zoom point is in the middle of the rectangle
    CGRect zoomRect;
    zoomRect.origin.x = zoomPoint.x - zoomSize.width / 2.0f;
    zoomRect.origin.y = zoomPoint.y - zoomSize.height / 2.0f;
    zoomRect.size.width = zoomSize.width;
    zoomRect.size.height = zoomSize.height;
    
    //apply the resize
    [scrollView zoomToRect: zoomRect animated: YES];
}

-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    //locate scroll view for zoom
    for (UIView *v in scrollView.subviews)
    {
        if ([v isKindOfClass:[UIImageView class]])
        {
            return v;
        }
    }
    return nil;
}

//Button action for iPad
- (IBAction) backButtonAction:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)deleteButtonAction:(id)sender
{
    [self deleteAction:sender];
}


@end
