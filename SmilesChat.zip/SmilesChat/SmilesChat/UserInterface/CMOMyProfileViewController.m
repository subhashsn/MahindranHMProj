//
//  CMOMyProfileViewController.m
//  CMOChat
//
//  Created by Administrator on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOMyProfileViewController.h"
#import "CMOEditProfileViewController.h"
#import "CMOAssembly.h"
#import "CMOCoreComponents.h"
#import "CMOUser.h"
#import "CMORoster+CoreDataProperties.h"
#import "CMORosterPresentation.h"

@interface CMOMyProfileViewController ()
{
    CMOEditProfileViewController *editProfileViewController;
    CMORosterPresentation *rosterModel;
    CMORoster *userInfo;
}
@end

@implementation CMOMyProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        _startConversationButton.layer.borderWidth = 2.0f;
        _startConversationButton.layer.borderColor = [UIColor colorWithRed:211.0/255.0 green:219.0/255.0 blue:252.0/255.0 alpha:1].CGColor;
        [_backButton setHidden:YES];
    }
    else
    {
        [_startConversationButton setHidden:YES];
    }
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        if (!_delegate)
        {
            [_startConversationButton setHidden:YES];
        }
        else{
            [_titleLabel setHidden:YES];
        }
        if (_isEditEnable)
        {
            [_editProfileButton setHidden:YES];
        }
        
        if (!_rosterInfo) {
            [self getUserInfo];
        }
        else{
            [self fetchmyvCard];
        }
    }
    self.profilePicture.layer.cornerRadius = 60;
    self.profilePicture.layer.masksToBounds = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)editProfile:(id)sender
{
    [self pushToEditProfileViewController];
}


- (void)pushToEditProfileViewController{
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        if (editProfileViewController){
            editProfileViewController = nil;
        }
        editProfileViewController = [_assembly editProfileviewcontroller];
        editProfileViewController.rosterInfo = _rosterInfo;
    }
    else{
        if (!editProfileViewController){
            editProfileViewController = [_assembly editProfileviewcontroller];
        }
    }
    
    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
    if (![navController.viewControllers containsObject:editProfileViewController]){
        editProfileViewController.delegate = self;
        [navController pushViewController:editProfileViewController];
    }
    
}

- (void)updateProfileData:(CMOEditProfileViewController *)controller didFinishEnteringItem:(NSString *)item
{
    self.mobileNumber.text = item;
}


//iPad
- (void)fetchmyvCard
{
    NSString *userName;
    if (_rosterInfo)
    {
        userName = _rosterInfo.username;
        
        _profileName.text = _rosterInfo.name;
        _emailId.text = _rosterInfo.email;
        _designation.text = _rosterInfo.userRoles.roleName;
        _mobileNumber.text = @"";
    }
    if (userName.length > 0)
    {
        id <CMOUserClient>userClient = [_coreComponents userService];
        CMOUser *cmoUser = [userClient fetchUservCard:userName];
        if (cmoUser.userAvatar)
        {
            _profilePicture.image = cmoUser.userAvatar;
            _profileOuterPicture.image = cmoUser.userAvatar;
            _profileOuterPicture.alpha = 0.3;
        }
        
        if (cmoUser.orgTitle) {
            _designation.text = cmoUser.orgTitle;
        }

    }
}

- (IBAction)startConversationAction:(id)sender
{
    if(_delegate)
    {
        [_delegate gotoConversationScreenWithUser: _rosterInfo];
    }
}

- (void)getUserInfo{
    
    rosterModel = [_coreComponents rosterPresentation];
    _rosterInfo = [rosterModel getCurrentUserInfoWithCompletionHandler:^(CMORoster *users) {
        dispatch_async(dispatch_get_main_queue(), ^(){
            [self fetchmyvCard];
        });
    } failure:^(NSError *error) {
    }];
}


@end
