//
//  CMOGroupMemberViewController.m
//  CMOChat
//
//  Created by Administrator on 11/28/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOGroupMemberViewController.h"
#import "CMOTableViewDatasource.h"
#import "CMOTableViewDelegate.h"
#import "CMORepositoryClient.h"
#import "CMOCoreComponents.h"
#import "CMOTabBarController.h"
#import "CMOUserPresence.h"
#import "CMOiPadTabBarViewController.h"
#import "CMOUser.h"

@interface CMOGroupMemberViewController ()
{
    CMOTableViewDatasource *dataSource;
    CMOTableViewDelegate *delegate;
}
@end

#define PROFILE_IMAGE         100
#define PROFILE_NAME          101
#define PROFILE_DESIGNATION   102
#define PROFILE_PRESENCE      103

@implementation CMOGroupMemberViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    id<CMORepositoryClient>client = [_coreComponents repositoryService];
    NSArray *groupArray = [client fetchMembersForGroup:self.groupName];
    [self setTableViewOutlets:groupArray];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        self.navigationItem.leftBarButtonItem = nil;
        self.navigationItem.hidesBackButton = YES;
    }
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(updatePresence:) name:XMPP_USER_PRESENCE_NOTIFICATION object:nil];

}

- (void) viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_USER_PRESENCE_NOTIFICATION object:nil];
}

- (void)setTableViewOutlets:(NSArray *)items{
    {
        dataSource = [[CMOTableViewDatasource alloc]initWithItems:items identifier:@"groupcell" configureCell:^(UITableViewCell *cell, id item,NSIndexPath* indexPath) {
            
                //CMOUser *user = item;
                //cell.textLabel.text = user.username;
                
                UIImageView *userNameView = (UIImageView *)[cell viewWithTag:PROFILE_IMAGE];
                userNameView.layer.cornerRadius = 25;
                userNameView.layer.masksToBounds = YES;
            
                UILabel *userNameLabel = (UILabel *)[cell viewWithTag:PROFILE_NAME];
                userNameLabel.text = item;
            
                UIImageView *presenceImageView = (UIImageView *)[cell viewWithTag:PROFILE_PRESENCE];
            
                BOOL isOnline = [self isUserOnline:item];
                presenceImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",isOnline ? @"Status_Online" : @"Status_Offline"]];
            
                id <CMOUserClient>userClient = [_coreComponents userService];
                CMOUser *cmoUser = [userClient fetchUservCard:item];
                if (cmoUser.userAvatar){
                    userNameView.image =  cmoUser.userAvatar;
                }
            
                UILabel *designateLabel = (UILabel *)[cell viewWithTag:PROFILE_DESIGNATION];
                designateLabel.text = cmoUser.orgTitle;//@"Designation";
        }];
    }
    
    delegate = [[CMOTableViewDelegate alloc]initWithItems:items configureCell:^(NSIndexPath *indexPath, id item) {
        
    }];
    
    [delegate setCellHeight:87.0f];
    self.groupTableView.dataSource = dataSource;
    self.groupTableView.delegate = delegate;
    self.groupTableView.allowsSelection = TRUE;
    
}


- (BOOL)isUserOnline:(NSString *)userName{
    BOOL isOnline = false;
    
    NSMutableDictionary *userPresenceDictionary;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        userPresenceDictionary = [_iPadTabBarController getUserPresenceDictonary];
    }
    else
    {
        userPresenceDictionary = [_tabBarController getUserPresenceDictonary];
    }
    
    if ([userPresenceDictionary valueForKey:userName]){
        CMOUserPresence *presence = [userPresenceDictionary valueForKey:userName];
        if ([presence.type isEqualToString:XMPP_PRESENCE_UNAVAILABLE]){
            isOnline = false;
        }
        else if (!presence){
            isOnline = false;
        }
        else{
            isOnline = true;
        }
        
    }
    return isOnline;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)updatePresence:(NSNotification *)notification{
    [_groupTableView reloadData];
}


@end
