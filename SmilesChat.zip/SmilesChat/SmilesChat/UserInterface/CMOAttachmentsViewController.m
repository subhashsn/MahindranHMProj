//
//  CMOAttachmentsViewController.m
//  CMOChat
//
//  Created by Raju on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOAttachmentsViewController.h"
#import "CMOAssembly.h"
#import "CMOMessage.h"
#import "CMOPhotoMediaItem.h"
#import "CMOVideoMediaItem.h"
#import "CMOAudioMediaItem.h"
#import "UIImage+Util.h"
#import <AVFoundation/AVFoundation.h>
#import "AppDelegate.h"
#import "CMODocumentItem.h"
#import "JSQMessagesTimestampFormatter.h"

#define MEDIA_TYPE_DOCUMENT @"Document"
#define MEDIA_TYPE_PPT @"ppt"
#define MEDIA_TYPE_PDF @"pdf"
#define MEDIA_TYPE_XLS @"xls"
#define MEDIA_TYPE_UNKNOWN @"Unknown"

@interface CMOAttachmentsViewController ()
{
    CMOFullImageViewController *fullimageVC;
    BOOL isDeleted;
    BOOL isDeletedDocs;
    AppDelegate *appDelegate;
    CMODocumentPreviewViewController *documentPreview;
}

@end

@implementation CMOAttachmentsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self addNavigationBar];
    [_noAttachments setHidden:YES];
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [_docsTableView setHidden:YES];
    _docsTableView.tableFooterView = [UIView new];
    
    [_imageCollection setHidden:NO];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.navigationItem.title = @"Attachments";
    
    if (isDeleted)
    {
        isDeleted = NO;
    }
    if (![_docsTableView isHidden])
    {
        [_docsTableView reloadData];
    }
    else if(![_imageCollection isHidden])
    {
        [_imageCollection reloadData];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) dealloc
{
    fullimageVC = nil;
    _messagesArray = nil;
    _assembly = nil;
}

#pragma mark - Collection view data source

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if(_messagesArray.count > 0)
    {
        if(!_imageCollection.hidden)
        {
            [_noAttachments setHidden:YES];
        }
        return _messagesArray.count;
    }
    else
    {
        if(!_imageCollection.hidden)
        {
            [_noAttachments setHidden:NO];
        }
        return 0;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier;
    UICollectionViewCell *cell;
    
    CMOMessage *message = _messagesArray[indexPath.row];
    
    if ([message.media isKindOfClass:[CMOPhotoMediaItem class]])
    {
        identifier = @"attachmentCell";
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
        CMOPhotoMediaItem *mediaItem = (CMOPhotoMediaItem *)message.media;
        
        UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
        recipeImageView.image = [mediaItem.image normalizedImage:CGSizeMake(128, 128)];
    }
    else if ([message.media isKindOfClass:[CMOVideoMediaItem class]])
    {
        identifier = @"attachmentCellVideo";
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
        CMOVideoMediaItem *mediaItem = (CMOVideoMediaItem *)message.media;
        
        UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
        recipeImageView.image = [[self generateVideoThumbnail:mediaItem.fileURL] normalizedImage:CGSizeMake(128, 128)]; ;
        
        UILabel *titleLabel = (UILabel *)[cell viewWithTag:101];
        titleLabel.text = [self getMediaDuration:mediaItem.fileURL];
    }
    else if ([message.media isKindOfClass:[CMOAudioMediaItem class]])
    {
        identifier = @"attachmentCellAudio";
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
        CMOAudioMediaItem *mediaItem = (CMOAudioMediaItem *)message.media;
        
        UILabel *titleLabel = (UILabel *)[cell viewWithTag:101];
        titleLabel.text = [self getMediaDuration:mediaItem.audioUrl];
    }
    
    return cell;
}

#pragma mark - Collection view delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    CMOMessage *message = _messagesArray[indexPath.row];
    
    if ([message.media isKindOfClass:[CMOPhotoMediaItem class]]) {
        [self loadImageWithIndex:indexPath];
    }
    else if ([message.media isKindOfClass:[CMOVideoMediaItem class]])
    {
        CMOVideoMediaItem *mediaItem = (CMOVideoMediaItem *)message.media;
        [self loadMediaWithURL:mediaItem.fileURL andIndex:indexPath];
    } else if ([message.media isKindOfClass:[CMOAudioMediaItem class]]) {
        CMOAudioMediaItem *audioItem = (CMOAudioMediaItem *)message.media;
        [self loadMediaWithURL:audioItem.audioUrl andIndex:indexPath];
    }
}

- (void) loadImageWithIndex:(NSIndexPath *)indexPath
{
    if (fullimageVC)
    {
        fullimageVC = nil;
    }
    fullimageVC = [_assembly fullimageviewcontroller];//Need to add roomInfo
    fullimageVC.delegate = nil;
    fullimageVC.delegate = self;
    fullimageVC.roomID = _roomID;
    fullimageVC.selectedIndex = indexPath;
    [fullimageVC.mediaMessage removeAllObjects];
    fullimageVC.mediaMessage = [NSMutableArray arrayWithArray: _messagesArray];
    
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        appDelegate.isReloadSplitView = NO;
        [self.navigationController presentViewController:fullimageVC animated:YES completion:nil];
    } else {
        CMONavigationController *navController = (CMONavigationController *)self.navigationController;
        [navController pushViewController:fullimageVC];
    }
}

- (void) loadMediaWithURL:(NSURL *)url andIndex:(NSIndexPath *)indexPath
{
    appDelegate.isReloadSplitView = NO;
    
    if (documentPreview)
    {
        documentPreview = nil;
    }
    
    documentPreview = [_assembly documentpreviewviewcontroller];
    documentPreview.delegate = self;
    documentPreview.docURL = url;
    documentPreview.selectedIndex = indexPath;
    documentPreview.roomID = _roomID;
    documentPreview.isDocument = NO;
    documentPreview.message = [_messagesArray objectAtIndex:indexPath.row];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        appDelegate.isReloadSplitView = NO;
        [self.navigationController presentViewController:documentPreview animated:YES completion:nil];
    } else {
        CMONavigationController *navController = (CMONavigationController *)self.navigationController;
        [navController pushViewController:documentPreview];
    }
}


#pragma mark - Collection view delegate flow layout

- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewFlowLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGSize contentSize;
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        contentSize.width = (self.view.frame.size.width / 5) - 25;
        contentSize.height = (self.view.frame.size.width / 5) - 25;
    } else {
        contentSize.width = ([UIScreen mainScreen].bounds.size.width / 3) - 15;
        contentSize.height = ([UIScreen mainScreen].bounds.size.width / 3) - 15;
    }
    
    return contentSize;
}

- (void) updateAttachmentOnDeletionWithObject:(NSUInteger)index
{
    isDeleted = YES;
    [_messagesArray removeObjectAtIndex:index];
}

#pragma mark - Back button

- (void)addNavigationBar
{
    UIButton *backButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    [backButton setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(goBack:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
}

-(void)goBack:(id)MACH_NOTIFY_NO_SENDERS
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(UIImage *)generateVideoThumbnail : (NSURL *)filepath
{
    AVAsset *asset = [AVAsset assetWithURL:filepath];
    AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc]initWithAsset:asset];
    imageGenerator.appliesPreferredTrackTransform = YES;
    CMTime time = [asset duration];
    time.value = 0;
    CGImageRef imageRef = [imageGenerator copyCGImageAtTime:time actualTime:NULL error:NULL];
    UIImage *thumbnail = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);  // CGImageRef won't be released by ARC
    
    return thumbnail;
}

- (NSString *) getMediaDuration:(NSURL *)filepath
{
    AVURLAsset *sourceAsset = [AVURLAsset URLAssetWithURL:filepath options:nil];
    CMTime duration = sourceAsset.duration;
    int seconds = CMTimeGetSeconds(duration);
    
    if (seconds < 60) {
        ////DDLogInfo(@"duration: %@", [NSString stringWithFormat:@"00.%02d", seconds]);
        return [NSString stringWithFormat:@"00.%02d", seconds];
    }
    else{
        int min = seconds / 60;
        int sec = seconds % 60;
        
        return [NSString stringWithFormat:@"%02d.%02d", min, sec];
    }
    
    return nil;
}

- (void)updateDocumentListOnDeletionWithObject:(NSUInteger)index
{
    isDeletedDocs = YES;
    [_docsArray removeObjectAtIndex:index];
}

- (void) updateAttachmentOnDeletionWithObjectFromPreview:(NSUInteger)index {
    isDeleted = YES;
    [_messagesArray removeObjectAtIndex:index];
}


- (IBAction)fileTypeButtonAction:(id)sender
{
    UISegmentedControl *segmentedControl = (UISegmentedControl *) sender;
    NSInteger selectedSegment = segmentedControl.selectedSegmentIndex;
    
    if (selectedSegment == 0)
    {
        [_imageCollection setHidden:NO];
        [_docsTableView setHidden:YES];
        [_imageCollection reloadData];
    }
    else if (selectedSegment == 1)
    {
        [_imageCollection setHidden:YES];
        [_docsTableView setHidden:NO];
        [_docsTableView reloadData];
    }
}

#pragma mark - Table view Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(_docsArray.count > 0)
    {
        if(!_docsTableView.hidden)
        {
            [_noAttachments setHidden:YES];
        }
        return _docsArray.count;
    }
    else
    {
        if(!_docsTableView.hidden)
        {
            [_noAttachments setHidden:NO];
        }
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"documentCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    CMOMessage *message = _docsArray[indexPath.row];
    CMODocumentItem *document = (CMODocumentItem *) message.media;
    
    UIImageView *presenceImgView = (UIImageView *)[cell viewWithTag:101];
    presenceImgView.image = [UIImage imageNamed:[self getFilePlaceHolder:document.docUrl]];
    
    UILabel *titleLabel = (UILabel *)[cell viewWithTag:102];
    titleLabel.text = document.fileName;
    
    UILabel *docSizeLabel = (UILabel *)[cell viewWithTag:103];
    docSizeLabel.text = [self getFileSizeWithURL:document.docUrl];
    
    UILabel *dateLabel = (UILabel *)[cell viewWithTag:104];
    dateLabel.text = [self getTimeFromData:message.date];
    
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self loadDocumentWithIndex:indexPath];
}

#pragma mark Documents information and actions


- (void) loadDocumentWithIndex:(NSIndexPath *)indexPath
{
    if (documentPreview)
    {
        documentPreview = nil;
    }
    
    CMOMessage *message = _docsArray[indexPath.row];
    CMODocumentItem *document = (CMODocumentItem *) message.media;
    
    documentPreview = [_assembly documentpreviewviewcontroller];
    documentPreview.delegate = self;
    documentPreview.docURL = document.docUrl;
    documentPreview.selectedIndex = indexPath;
    documentPreview.roomID = _roomID;
    documentPreview.isDocument = YES;
    documentPreview.message = _docsArray [indexPath.row];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        appDelegate.isReloadSplitView = NO;
        [self.navigationController presentViewController:documentPreview animated:YES completion:nil];
    } else {
        CMONavigationController *navController = (CMONavigationController *)self.navigationController;
        [navController pushViewController:documentPreview];
    }
}


#pragma mark get file details

- (NSString *) getFilePlaceHolder: (NSURL *)url
{
    NSString *extension;
    NSArray *docs = [url.lastPathComponent componentsSeparatedByString:@"."];
    
    if (docs.count > 1){
        extension = [[docs lastObject] lowercaseString];
    }
    else{
        return @"preview-unknown";
    }
    
    if ([extension isEqualToString:@"doc"] || [extension isEqualToString:@"docx"]){
        return @"preview-doc";
    }
    else if ([extension isEqualToString:@"ppt"] || [extension isEqualToString:@"pptx"] ){
        return @"preview-ppt";
    }
    else if ([extension isEqualToString:@"xls"] || [extension isEqualToString:@"xlsx"] ){
        return @"preview-xls";
    }
    else if ([extension isEqualToString:@"pdf"]){
        return @"preview-pdf";
    }
    
    return @"preview-unknown";
}

- (NSString *)getFileSizeWithURL:(NSURL *)filepath
{
    NSString *path = [filepath path];
    NSDictionary *fileAttributes = [[NSFileManager defaultManager] attributesOfItemAtPath:path error:nil];
    
    NSNumber *fileSizeNumber = [fileAttributes objectForKey:NSFileSize];
    long long fileSize = [fileSizeNumber longLongValue];
    
    if(fileSize < 1024 * 1024)
    {
        return [NSString stringWithFormat:@"%lld KB", (fileSize/1024)];
    }
    else
    {
        return [NSString stringWithFormat:@"%lld MB", (fileSize/(1024*1024))];
    }
}

- (NSString *)getFileNameWithURL:(NSURL *)filepath
{
    return [filepath lastPathComponent];
}

- (NSString *)getTimeFromData:(NSDate *) date
{
    NSAttributedString *stringDate = [[JSQMessagesTimestampFormatter sharedFormatter] attributedTimestampForDate:date];
    
    if ([[stringDate string] isEqualToString:@"Today"]) {
        
    }
    
    return [stringDate string];
}


@end
