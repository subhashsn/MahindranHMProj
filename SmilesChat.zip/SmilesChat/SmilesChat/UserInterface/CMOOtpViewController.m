//
//  CMOOtpViewController.m
//  CMOChat
//
//  Created by Subhash on 03/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOOtpViewController.h"
#import "CMOAssembly.h"
#import "CMOConversationsTableViewController.h"
#import "CMOTabBarController.h"
#import "CMOAppServerAPIClient.h"
#import <stdlib.h>
#import "CMOUtils.h"
#import "CMOSplitViewController.h"

#define OTP_EXPIRE_TIME 120.0   //duration in seconds


#define OTP_TEXT @"Please enter OTP code below to verify your mobile number '%@'"

//#define OTP_TEXT @"Please enter OTP code below which have sent to your registered mobile number '%@'"

#define SUCCESS_MSG_OTP_SEND @"Please enter the OTP sent your mobile"
#define ERROR_MSG_OTP_SEND_FAILED @"OTP Send failed. Try sending again!"
#define ERROR_MSG_OTP_INVALID_EXPIRED @"OTP is invalid or expired. Try again!"
#define ERROR_MSG_OTP_NO_INTERNET @"No internet available.Try again later!"


@interface CMOOtpViewController ()
{
    CMOConversationsTableViewController *conversationViewController;
    CMOTabBarController *tabBarController;
    NSString *otpSent;
    NSDate *otpSendTime;
    
    CMOSplitViewController *splitViewController;
}
@end

@implementation CMOOtpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self settingNavigationBar];
    //[self.navigationController.navigationBar setHidden:YES];
    self.navigationItem.title = @"Authentication";
    //self.navigationItem.hidesBackButton = NO;
    //self.navigationItem.leftBarButtonItem=nil;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

    [self setErrorMessage:@""];
    [self.lblVerifyMobileNumber setText:[NSString stringWithFormat:OTP_TEXT,(self.mobileNumber?self.mobileNumber:@"")]];
    [self clearOTPTextField];
    [self sendOTPRequest];
}

- (void)sendOTPRequest {
    NSLog(@"Sending OTP Request mob number:%@",self.mobileNumber);
    NSString *number = [self.mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    number = [number stringByReplacingOccurrencesOfString:@"+" withString:@""];
    [self generateOTP];
    NSLog(@"OTP = %@",otpSent);
    if (![CMOUtils isInternetAvailable]) {
        [self setErrorMessage:ERROR_MSG_OTP_NO_INTERNET];
        return;
    }
    
    otpSendTime = [NSDate date]; //set time to current time
    id <CMOAppServerAPIClient> client = [_coreComponents appServerAPIHandler];
    NSString *url = [NSString stringWithFormat:@"SendOtp/%@/%@",number,otpSent];
    [client GET:url parameters:nil OnProgress:nil OnSuccess:^(id  _Nullable response) {
        //Success block
        NSLog(@"SendOtp Success response: %@",response);
        //[self setErrorMessage:SUCCESS_MSG_OTP_SEND];
    } onFailure:^(NSError * _Nonnull error) {
        //Failure block
        NSLog(@"SendOtp Failure error: %@",error);
        //[self setErrorMessage:ERROR_MSG_OTP_SEND_FAILED];
    }];
}

- (void)generateOTP {
    NSLog(@"generate OTP");
    NSString *otpString = @"";
    int randNum;
    for (int i = 0; i < 4; i++) {
        randNum = arc4random_uniform(9);
        otpString = [otpString stringByAppendingFormat:@"%d",randNum];
    }
    otpSent = otpString;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)pushToConversatiosViewController{
    
    if (!conversationViewController){
        conversationViewController = [_assembly conversationsviewcontroller];
    }
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        if (splitViewController)
        {
            splitViewController = nil;
        }
//        conversationViewController.fromLogin = true;
        splitViewController = [_assembly ipadsplitviewcontroller];
        //        splitViewController.viewControllers = [NSArray arrayWithObjects:[_assembly ipadtabbarcontroller],[_assembly attachmentsviewcontroller], nil];
        CMONavigationController *navController = (CMONavigationController *)self.navigationController;
        if (![navController.viewControllers containsObject:conversationViewController]){
           // conversationViewController.archiveFlag = FALSE;
            [self.navigationController presentViewController:splitViewController animated:YES completion:nil];
        }
        
    }
    else{
//        conversationViewController.fromLogin = true;
        CMONavigationController *navController = (CMONavigationController *)self.navigationController;
        if (![navController.viewControllers containsObject:conversationViewController]){
            //conversationViewController.archiveFlag = FALSE;
            [navController pushViewController:conversationViewController];
        }
    }
}

- (void)settingNavigationBar
{
    self.navigationController.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.backgroundColor = [UIColor whiteColor];
    
    UIButton *backButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    [backButton setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(goBack:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
}

-(void)goBack:(id)sender
{
    [self.cmoOTPDelegate addOTPViewController:self didFinishEnteringItem:_bSaveFlag];//TRUE
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)editMobileNumber:(id)sender
{
    //NSLog(@"editMobileNumber");
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)resendOTP:(id)sender
{
    NSLog(@"resendOTP");
    //remove error text
    [self setErrorMessage:@""];
    
    otpSent = @"";
    [self clearOTPTextField];
    [self sendOTPRequest];
}

#pragma mark UITextField Delegates

-(BOOL)textFieldShouldReturn:(UITextField*)textField;
{
    if (textField == self.txtOTP1)
    {
        [self.txtOTP2 becomeFirstResponder];
    }
    else if (textField == self.txtOTP2)
    {
        [self.txtOTP3 becomeFirstResponder];
    }
    else if (textField == self.txtOTP3)
    {
        [self.txtOTP4 becomeFirstResponder];
    }
    
    return NO;
}

- (BOOL)keyboardInputShouldDelete:(UITextField *)textField
{
    //NSLog(@"keyboardInputShouldDelete");
    
    if (textField == self.txtOTP4)
    {
        [self performSelector:@selector(setNextResponder:) withObject:self.txtOTP3 afterDelay:0.1];
    }
    else if (textField == self.txtOTP3)
    {
        [self performSelector:@selector(setNextResponder:) withObject:self.txtOTP2 afterDelay:0.1];
    }
    else if (textField == self.txtOTP2)
    {
        [self performSelector:@selector(setNextResponder:) withObject:self.txtOTP1 afterDelay:0.1];
    }
    return FALSE;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    // This allows numeric text only, but also backspace for deletes
    if (string.length > 0 && ![[NSScanner scannerWithString:string] scanInt:NULL])
        return NO;
    
    NSUInteger oldLength = [textField.text length];
    NSUInteger replacementLength = [string length];
    NSUInteger rangeLength = range.length;
    
    NSUInteger newLength = oldLength - rangeLength + replacementLength;
    
    // This 'tabs' to next field when entering digits
    if (newLength == 1) {
        if (textField == self.txtOTP1)
        {
            [self performSelector:@selector(setNextResponder:) withObject:self.txtOTP2 afterDelay:0.2];
        }
        else if (textField == self.txtOTP2)
        {
            [self performSelector:@selector(setNextResponder:) withObject:self.txtOTP3 afterDelay:0.2];
        }
        else if (textField == self.txtOTP3)
        {
            [self performSelector:@selector(setNextResponder:) withObject:self.txtOTP4 afterDelay:0.2];
        }
        else if(textField == self.txtOTP4)
        {
            //call verify OTP request
            NSString *otp = [NSString stringWithFormat:@"%@%@%@%@",self.txtOTP1.text,self.txtOTP2.text,self.txtOTP3.text,string];
            if ([self verifyOTPRequest:otp]) {
                //update user info on server and go to next view
                [self setErrorMessage:@""];
                [self updateUserInfo];
                /*if (_bSaveFlag) {
                    [self.cmoOTPDelegate addOTPViewController:self didFinishEnteringItem:FALSE];
                    [self.navigationController popViewControllerAnimated:YES];
                }
                else
                    [self pushToConversatiosViewController];
                 */
            }
            else
            {
                [self setErrorMessage:ERROR_MSG_OTP_INVALID_EXPIRED];
            }
        }
    }
    //this goes to previous field as you backspace through them, so you don't have to tap into them individually
    else if (oldLength > 0 && newLength == 0) {
        if (textField == self.txtOTP4)
        {
            [self performSelector:@selector(setNextResponder:) withObject:self.txtOTP3 afterDelay:0.1];
        }
        else if (textField == self.txtOTP3)
        {
            [self performSelector:@selector(setNextResponder:) withObject:self.txtOTP2 afterDelay:0.1];
        }
        else if (textField == self.txtOTP2)
        {
            [self performSelector:@selector(setNextResponder:) withObject:self.txtOTP1 afterDelay:0.1];
        }
    }
    
    return newLength <= 1;
}

- (BOOL)verifyOTPRequest:(NSString*)otp {
    NSTimeInterval secondsBetween = [[NSDate date] timeIntervalSinceDate:otpSendTime];
    NSLog(@"TIME diff = %f",secondsBetween);
    //For testing only.Comment below line when otp send starts working
    //otpSent = @"1111";
    if (secondsBetween <= OTP_EXPIRE_TIME && [otp isEqualToString:otpSent]) {
        otpSent = @"";
        return true;
    }
    return false;
}

- (void)updateUserInfo {
    
    [[NSUserDefaults standardUserDefaults] setValue:@"NO" forKey:@"APNSDeviceTokenChanged"];
    //update device token to server
    NSString *deviceToken = [[NSUserDefaults standardUserDefaults] valueForKey:@"APNSDeviceToken"];
    if (deviceToken != nil) {
        id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
        
        id <CMOAppServerAPIClient> client = [_coreComponents appServerAPIHandler];
        NSString *url = [NSString stringWithFormat:@"UpdateUserInfo/%@/%@/%@",self.userName,self.mobileNumber,deviceToken];
        [client GET:url parameters:nil OnProgress:nil OnSuccess:^(id  _Nullable response) {
            //Success block
            NSLog(@"UpdateUserInfo Success response: %@",response);
            [repositoryClient saveCurrentUserPhoneNumber:self.mobileNumber];
            if (_bSaveFlag) {
                [self.cmoOTPDelegate addOTPViewController:self didFinishEnteringItem:FALSE];
                if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad){
                    [self.navigationController popViewControllerAnimated:NO];
                }
                else{
                    [self.navigationController popViewControllerAnimated:YES];
                }
            }
            else
                [self pushToConversatiosViewController];
        } onFailure:^(NSError * _Nonnull error) {
            //Failure block
            NSLog(@"UpdateUserInfo Failure error: %@",error);
        }];
    }
}

- (void)setNextResponder:(UITextField *)nextResponder
{
    [nextResponder becomeFirstResponder];
}

- (void)setErrorMessage:(NSString*)errorMessage {
    [self.lblOTPError setHidden:(errorMessage.length == 0)];
    [self.lblOTPError setText:errorMessage];
}

- (void)clearOTPTextField {
    self.txtOTP1.text = @"";
    self.txtOTP2.text = @"";
    self.txtOTP3.text = @"";
    self.txtOTP4.text = @"";

    [self.txtOTP1 becomeFirstResponder];
}

@end
