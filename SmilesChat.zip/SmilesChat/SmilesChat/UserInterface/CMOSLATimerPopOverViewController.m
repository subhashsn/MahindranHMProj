//
//  SLATimerPopOverViewController.m
//  CMOChat
//
//  Created by Raju on 12/5/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOSLATimerPopOverViewController.h"
#import "CMOUtils.h"

@interface CMOSLATimerPopOverViewController ()

@end

@implementation CMOSLATimerPopOverViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.frame = CGRectMake(0, 0, 200, 300);
    [self setServerTimeToDatePicker:0];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [self setServerTimeToDatePicker:_selectedInterval];
//    [_pickerView reloadAllComponents];
    [self setServerTimeToDatePicker:_selectedInterval];
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear: YES];
//    [_pickerView reloadAllComponents];
}

- (void)viewDidLayoutSubviews
{
    CGRect frame = self.view.frame;
    frame.size.width = frame.size.width;
    frame.size.height = 275;
    frame.origin.x = 0;
    frame.origin.y = 0;
    
    self.view.frame = frame;
}

#pragma mark Picker View Delegate Methods

- (void)setServerTimeToDatePicker:(NSInteger)minutes{
    
    NSDate *referenceDate = nil;
    NSString *servertime = [CMOUtils getServerTime];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:MESSAGE_TIME_FORMAT];
    NSDate *formattedDate = [dateFormatter dateFromString:servertime];
    if (minutes == 0){
        referenceDate = [formattedDate dateByAddingTimeInterval:5*60];
    }
    else{
        referenceDate = [formattedDate dateByAddingTimeInterval:minutes*60];
    }
    self.datePickerView.minimumDate = [formattedDate dateByAddingTimeInterval:5*60];
    
    self.datePickerView.timeZone = [NSTimeZone systemTimeZone];
    //self.datePickerView.minimumDate = referenceDate;
    self.datePickerView.date = referenceDate;
}

- (IBAction)cancelButtonClicked:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
    [_delegate cancelButtonAction];
}

- (IBAction)doneButtonClicked:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
    [_delegate saveButtonAction];
}

- (IBAction)resetButtonClicked:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
    [_delegate resetButtonAction];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return _totalMinutes/_interval + 1;//including 0
}

- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    NSInteger val = _interval*row;
    return [NSString stringWithFormat:@"%ld %@",(long)val, (val == 0 ? @"min" : @"mins")];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    NSLog(@"Selected time is %ld",_interval*row);
    _selectedInterval = _interval*row;
}

@end
