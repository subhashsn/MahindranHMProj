//
//  CMOChatContainerViewController.m
//  CMOChat
//
//  Created by Administrator on 11/15/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOChatContainerViewController.h"
#import "CMOChatViewController.h"
#import "CMOConversationSettingsViewController.h"
#import "CMOConversationsTableViewController.h"
#import "CMORosterViewController.h"
#import "CMOAssembly.h"
#import "AppDelegate.h"
#import "CMOUtils.h"
#import "CMORoster+CoreDataClass.h"

#define BUFFER_HEIGHT 50.0f
#define MORE @"More"
#define CANCEL_BUTTON @"Cancel"
#define VIEW_ATTACHMENTS @"View Attachments"
#define MUTE_NOTIFICATION @"Mute Notification"

@interface CMOChatContainerViewController ()<UIPickerViewDelegate, UIPickerViewDataSource>{
    BOOL toggle;
    NSInteger totalMinutes;
    NSInteger interval;
    NSInteger selectedInterval;
    CMOConversationSettingsViewController *conversationSettingsVC;
    
    BOOL showPicker;
    
    CMOConversationSettingsViewController *participantView;
    
//    CMOChatViewController *chatvc;
    
    AppDelegate *appDelegate;
    
    CMORoster *roster;
    //UserType userType;
}

@end

@implementation CMOChatContainerViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    totalMinutes = 120;
    interval = 5;
    
    self.tabBarController.tabBar.hidden = true;
   // self.pickerContainerView.hidden = true;
    [self addNavigationBar];
    
    
    //self.tabBarController.tabBar.hidden = true;
    // Do any additional setup after loading the view.
    
    
    id <CMOUserClient>userClient = [_coreComponents userService];
    CMOUser *owner = [userClient user];
    id <CMORosterClient>rosterClient = [_coreComponents rosterService];
    roster = [rosterClient fetchRoster:owner.username];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self addNavigationTitleView];
    //[self addSwipeGesture];
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
}



- (void)addNavigationTitleView{
    CGRect screensize = [[UIScreen mainScreen]applicationFrame];
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, screensize.size.width - 100, 30)];
    titleLabel.textColor = [UIColor blackColor];
    //titleLabel.backgroundColor = [UIColor redColor];
    titleLabel.font = [UIFont fontWithName:@"Helvetica" size:16.0f];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = titleLabel;
}

- (void)setNavigationTitle:(NSString *)title{
    if (self.navigationItem.titleView){
        CGRect screensize = [[UIScreen mainScreen]applicationFrame];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        //The frame width should be dynamic
        [button setFrame:CGRectMake(10, 0, screensize.size.width - 60, 50)];
        [button setTitle:title forState:UIControlStateNormal];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //[button setBackgroundColor:[UIColor greenColor]];
        [button addTarget:self action:@selector(onTapNavigationBar:) forControlEvents:UIControlEventTouchUpInside];
        self.navigationItem.titleView = button;
    }
}

- (void)onTapNavigationBar:(id)sender{
    DDLogInfo(@"Navigation Bar Tapped");
    [self gotoConversationSettingsView];
}


- (void)refreshChatContainerview {
    [self.view layoutIfNeeded];

    
    //reset roster view data
    [_rosterView.participantsDict removeAllObjects];
    _rosterView.currentParticipants = nil;

    [self updateChatVCData];
    //DDLogInfo(@"\n%@ %@ invoke reloadChatViewData  000132",THIS_METHOD,THIS_FILE);
    [self.chatvc reloadChatViewData];
}

-(void)updateChatVCData {
    _chatvc.target = self; //Pass current viewcontroller
    _chatvc.senderId = self.owner.username;
    id <CMORosterClient>rosterClient = [_coreComponents rosterService];
    CMORoster *roster = [rosterClient fetchRoster:self.owner.name];
    if (roster && roster.name) {
        _chatvc.senderDisplayName = roster.name;
    } else {
        _chatvc.senderDisplayName = self.owner.name;
    }
    _chatvc.chatType = _type;
    _chatvc.isFromParent = true; //TO avoid loading messages from db in
    _chatvc.roomInfo = self.roomInfo;
    if (_partcipantsList) {
        _chatvc.partcipantsList = _partcipantsList;
    } else {
        [_chatvc.partcipantsList removeAllObjects];
    }
    
    if (_type == ChatTypeExistingChat){
        _chatvc.roomInfo = self.roomInfo;
        _chatvc.receiverId = self.roomInfo.roomName;
    }
    else{ //New Room Id will be passed
        _chatvc.receiverId = [[CMOUtils getUniqueString]lowercaseString];
    }
    
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //[self.view layoutIfNeeded];
    
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

- (void)setParticipantCount:(NSInteger)count{
    //self.participantLabel.text = (count == 0) ?  @"" : [NSString stringWithFormat:@"%ld Participants",(long)count];
}


- (void)updateNavigationBar{
    
    if (_type == ChatTypeExistingChat){
        [self addRightNavigationBarItems];
    } else {
        self.navigationItem.rightBarButtonItem = nil;
    }
}

- (void)addNavigationBar{
    UIImage *backButtonImage = [UIImage imageNamed:@"Back"];
    UIButton *backButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 2*backButtonImage.size.width, 1.5*backButtonImage.size.height)];
    [backButton setImage:backButtonImage forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(leftBarButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    
    if (_type == ChatTypeExistingChat){
        [self addRightNavigationBarItems];
    }

}

- (void) addRightNavigationBarItems
{
    if (!self.navigationItem.rightBarButtonItem) {
        UIImage *moreButtonImage = [UIImage imageNamed:@"moreOption"];
        UIButton *moreButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, moreButtonImage.size.width, moreButtonImage.size.height)];
        [moreButton setImage:moreButtonImage forState:UIControlStateNormal];
        [moreButton addTarget:self action:@selector(moreDetails:) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *moreBarButton = [[UIBarButtonItem alloc]initWithCustomView:moreButton];
        self.navigationItem.rightBarButtonItem = moreBarButton;
    }
}

- (void)leftBarButtonAction:(id)sender{
    
    NSMutableArray *contacts = [_chatvc.partcipantsList objectForKey:MACROS_CONTACTS];
    NSMutableArray *groups = [_chatvc.partcipantsList objectForKey:MACROS_GROUPS];
    
    
    if (_type == ChatTypeNewChat && (contacts.count > 0 || groups.count > 0 || _chatvc.inputToolbar.contentView.textView.text.length > 0)){
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"Do you want to discard the changes?" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *cancelButton = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                       {
                                           //Discard alert
                                       }];
        UIAlertAction *yesButton = [UIAlertAction actionWithTitle:@"Yes" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                    {
                                       [self.navigationController popViewControllerAnimated:true];

                                    }];
        [alertController addAction:cancelButton];
        [alertController addAction:yesButton];
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else{
        [self.navigationController popViewControllerAnimated:true];
        
    }
}

- (void)moreDetails:(id)sender
{
    //Show action sheet
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:MORE message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        alertController.popoverPresentationController.sourceView = self.view;
        alertController.popoverPresentationController.sourceRect = CGRectMake([UIScreen mainScreen].bounds.size.width - 350, 30, 30, 30);
        [alertController.popoverPresentationController setPermittedArrowDirections:UIPopoverArrowDirectionUp];
    }
    UIAlertAction *viewAttachments = [UIAlertAction actionWithTitle:VIEW_ATTACHMENTS style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                      {
                                          [_chatvc gotoAttachmentScreen];
                                      }];
    [alertController addAction:viewAttachments];
 
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:CANCEL_BUTTON style:UIAlertActionStyleCancel handler:^(UIAlertAction * action)
                             {
                                 [alertController dismissViewControllerAnimated:YES completion:nil];
                             }];
    [alertController addAction:cancel];
    
    [self presentViewController:alertController animated:YES completion:nil];
}


//Participants List
- (void)gotoConversationSettingsView{
    if (!conversationSettingsVC){
        conversationSettingsVC = [_assembly conversationsettingsviewcontroller:nil];//Need to add roomInfo
    }
    conversationSettingsVC.roomIdentifier = self.roomInfo.roomName;
    CMONavigationController *navController = (CMONavigationController *)self.navigationController;
    [navController pushViewController:conversationSettingsVC];
    
}

//Contacts List
- (void)goToRosters{
    CMOChatViewController *chatViewController = self.childViewControllers.count > 0 ? self.childViewControllers[0] : nil;
    if (!_rosterView){
            _rosterView = [_assembly rosterviewcontroller];
    }
    
    _rosterView.rosterDelegate = chatViewController;//Chat view controller
    _rosterView.chatType = _type;
    //participantsDict is already available
    
    if(_partcipantsList.count)
    {
        _rosterView.participantsDict = _partcipantsList;
    }
 
    [self.navigationController pushViewController:_rosterView animated:true];
    
}

- (IBAction)showParticipantList:(id)sender{
    if (_type == ChatTypeNewChat) {
        [self goToRosters];
       
    } else {
        //existing chat. So go to conversation settings view
        [self gotoConversationSettingsView];
    }
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    //Chat seague is set on container view and chatview connection.
    if ([[segue identifier] isEqualToString:@"EmbedChatSeague"]) {
        if ([segue.destinationViewController isKindOfClass:[CMOChatViewController class]]){
            _chatvc = segue.destinationViewController;
           
            _chatvc.target = self; //Pass current viewcontroller
            _chatvc.senderId = self.owner.username;
            id <CMORosterClient>rosterClient = [_coreComponents rosterService];
            CMORoster *roster = [rosterClient fetchRoster:self.owner.name];
            if (roster && roster.name) {
                _chatvc.senderDisplayName = roster.name;
            } else {
                _chatvc.senderDisplayName = self.owner.name;
            }
            _chatvc.chatType = _type;
            _chatvc.isFromParent = true; //TO avoid loading messages from db in 
            if (_partcipantsList) {
                _chatvc.partcipantsList = _partcipantsList;
            }
            NSArray *viewControllers = [[segue.sourceViewController navigationController]viewControllers];
            //If previous viewcontroller is CMOConversationsTableViewController, then assign sla delegate to get the sla time if any.
            id vc = viewControllers[viewControllers.count-2];
            if ([vc isKindOfClass:[CMOConversationsTableViewController class]]){
                _chatvc.slaDelegate = vc;
            }
            //chatvc.slaDelegate = segue.sourceViewController;
            
            if (_type == ChatTypeExistingChat){
                _chatvc.roomInfo = self.roomInfo;
                _chatvc.receiverId = self.roomInfo.roomName;
            }
            else{ //New Room Id will be passed
                _chatvc.receiverId = [[CMOUtils getUniqueString]lowercaseString];
            }
        }
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
