//
//  CMOLoginViewController.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CMOAssembly;
@class CMOCoreComponents;

@interface CMOLoginViewController : UIViewController<UITextFieldDelegate,UINavigationControllerDelegate>

@property (nonatomic, weak)IBOutlet UITextField *userNameField;
@property (nonatomic, weak)IBOutlet UITextField *passwordField;
//@property (nonatomic, weak)IBOutlet UITextField *domainField;
//@property (nonatomic, weak)IBOutlet UIView *profilePicture;
@property (nonatomic, weak)IBOutlet UIButton *btnLogin;
@property (nonatomic, weak)IBOutlet UIButton *btnShowPassword;
@property (nonatomic, weak)IBOutlet UILabel *lblLoginError;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *loginbtnTop;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *backgroundTop;
@property (nonatomic, weak)IBOutlet UIButton *btnForgotPassword;
@property (weak, nonatomic)IBOutlet UIImageView *backgroundImg;
@property (weak, nonatomic)IBOutlet UIView *errorView;
@property (weak, nonatomic)IBOutlet UIView *textFieldView;

@property (strong, nonatomic) CMOAssembly *assembly;
@property (strong, nonatomic) CMOCoreComponents *coreComponents;

- (IBAction)login:(id)sender;
- (IBAction)forgotPassword:(id)sender;

@end
