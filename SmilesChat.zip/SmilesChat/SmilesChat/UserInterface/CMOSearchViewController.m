//
//  CMOSearchViewController.m
//  CMOChat
//
//  Created by Raju on 12/8/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOSearchViewController.h"

@interface CMOSearchViewController ()

@end

@implementation CMOSearchViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    //[textField resignFirstResponder];
    //return  true;
    
    NSInteger nextTag = textField.tag + 1;
    // Try to find next responder
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    if (nextResponder) {
        // Found next responder, so set it.
        [nextResponder becomeFirstResponder];
    } else {
        // Not found, so remove keyboard.
        [textField resignFirstResponder];
    }
    return NO; // We do not want UITextField to insert line-breaks.
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}

- (IBAction)searchButtonAction:(id)sender
{
    if (_delegate)
    {
        //Dont search if search string is not available
        if ([_searchName.text isEqualToString:@""] && [_searchKeyword.text isEqualToString:@""]) {
            [_delegate cancelAction];
        }
        else{
            [_delegate searchWithUser:_searchName.text andKeyword:_searchKeyword.text];
        }
    }
}

- (IBAction)cancelButtonAction:(id)sender
{
    if (_delegate)
    {
        [_delegate cancelAction];
    }
}

@end
