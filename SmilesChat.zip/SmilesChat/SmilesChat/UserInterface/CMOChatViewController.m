//
//  FirstViewController.m
//  CMOChat
//
//  Created by Anish on 10/17/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOChatViewController.h"
#import "CMOCoreComponents.h"
#import "CMOMessageBuilder.h"
#import "CMOMessage.h"
#import "CMOCoreComponents.h"
#import "CMOChatClient.h"
#import "CMOConversationSettingsViewController.h"
#import "CMOAssembly.h"
#import "CMORoomDetails+CoreDataClass.h"
#import "CMOMembers+CoreDataClass.h"
#import "CMOAdmins+CoreDataClass.h"
#import "CMOOwners+CoreDataClass.h"
#import "CMOAttachmentsViewController.h"
#import "CMORosterPresentation.h"
#import "CMORoomPresentation.h"


#import "CMOTabBarController.h"
#import "CMOUtils.h"

#import "UIImage+Util.h"
#import "UIImageEffects.h"
#import "JSQMessagesMediaPlaceholderView.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "CMOPhotoMediaItem.h"
#import "CMOVideoMediaItem.h"
#import "CMOAudioMediaItem.h"
#import "CMODocumentItem.h"
#import "CMOMediaItem.h"
#import "CMOParticipantInfo.h"
#import "CMOUserClient.h"
#import "CMORosterGroup+CoreDataProperties.h"

/* Testing purpos. should remove */
#import "CMOXMPPClient.h"

#import "CMOAttachmentsViewController.h"
#import "CMOChatContainerViewController.h"

#import "CMORoster+CoreDataProperties.h"
#import "CMOUserRoles+CoreDataProperties.h"
#import "CMOUserPermissions+CoreDataProperties.h"
#import "CMOUserPresence.h"

#import "XMPPRoomCoreDataStorage+CMORoomCoreDataStorage.h"
#import "CMOArchivedRooms+CoreDataProperties.h"

#import "AppDelegate.h"
#import "CMOAudioRecorder.h"
#import <AVFoundation/AVFoundation.h>
//#import <MessageUI/MessageUI.h>
#import "CMOMessageParam.h"


//#import "UIImagePickerController+OrientationFix.h"
#define MAX_ALLOWED_CHARS 50
#define MAX_ALLOWED_CHARS_ROOM_SUBJECT 150
#define MAX_ALLOWED_CHARS_TEXT_MESSAGE 3000

#define NETWORK_ERROR @"Please check network connection."
#define DOCUMENT_SUBJECT @"Document"

typedef NS_ENUM (NSInteger, MessageType){
    MessageTypeText = 1,
    MessageTypeDocument
};


typedef NS_ENUM(NSInteger, RoomStatus){
    RoomNotCreated,
    RoomCreating,
    RoomCreated,
    RoomFailed,
    RoomMessageFailed,
};


//typedef NS_ENUM(NSInteger, MessageComposeResult);

@interface CMOChatViewController () <JSQMessagesCollectionViewDataSource, JSQMessagesCollectionViewDelegateFlowLayout, UIImagePickerControllerDelegate,UINavigationControllerDelegate, UIDocumentPickerDelegate, CMOAudioRecorderDelegate> {
   // NSMutableArray *messages;
    JSQMessagesBubbleImage *outgoingBubbleImageView;
    JSQMessagesBubbleImage *incomingBubbleImageView;
    CMOConversationSettingsViewController *conversationSettingsVC;
    
    //CMORoomInfo *roomInfo;
    
    NSMutableArray *sortedMessages;
    //allMessages & filteredMessages contains the array of messages based on show/hide option.
    NSMutableArray *allMessages;
    
    MessageType messageType;
   // NSMutableArray *indexArray;
    
    //UIImagePickerController *imagePickerAlbum;
    
    //We are keep tracking of Picker dismiss event. so that code in viewWillAppear: will not executed every time when picker is dismissed
    BOOL isPickerDismissed;
    
    BOOL isConnected, isJoined;
    BOOL isJoining;
    
    
    CMONavigationController *navigationController;
    UIImagePickerController *imagePickerController;
   
    CMOChatContainerViewController * parentVC;
    CMOAttachmentsViewController *attachmentsVC;
    CMOFullImageViewController *fullimageVC;
    NSTimer *scheduleChatNotification;
    
    CMORoster *ownerRoster;
  //  NSMutableArray *vCardArray;
    NSMutableDictionary *userPresenceDict;
    
    id <CMOUserClient>userService;
    NSDate *oldDate;
    
    MBProgressHUD *hudProgress;
    AppDelegate *appDelegate;
    
    //This will be updated when document is uploaded or failed. This is to avoid retry button while image/document is uploading.
    BOOL documentProcessed;
    
    //This BOOL value is to avoid multiple room creation when user taps send button.
    //BOOL isRoomCreated;
    RoomStatus roomStatus;
    CMODocumentPreviewViewController *documentPreview;
    CMOAudioRecorder *recorder;
    BOOL recordingCancelled;
    dispatch_queue_t uploadQueue;
    dispatch_queue_t downloadQueue;
    
    NSMutableArray *messageQueueArray;
    
    ChatTypStatus _chatTypeStatus;

    JSQMessagesAvatarImage *defaultProfileAvatarImage;
    JSQMessagesAvatarImage *errorProfileAvatarImage;
    NSMutableDictionary *userAvatarImages;
    
    NSString *textMessageTitle;
    
    MBProgressHUD *hudIndicator;
    
    NSMutableDictionary *cmoMessagesDictionary;
    
    NSTimer *reloadTimer;
    //This timer will run once the room is joined and have the time of 30seconds. This is to avoid pressing retry option while joining.
    BOOL shouldEnableRetry;
    
}
@end

@implementation CMOChatViewController

- (instancetype)init{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        //chatModel = [_coreComponents chatPresentation];
    }
    return self;
}

- (void)dealloc{
    //DDLogInfo(@"DEalloc is calling");
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
   // [self addNavigationBar];
    //It should be true. bcoz when you come to this chat screen, all documents were already processed.
    
    _roomModel = [_coreComponents roomPresentation];
    
    documentProcessed = true;
    uploadQueue = dispatch_queue_create("uploadQueue", DISPATCH_QUEUE_SERIAL);
    downloadQueue = dispatch_queue_create("downloadQueue", DISPATCH_QUEUE_SERIAL);
    
    navigationController = (CMONavigationController *)self.navigationController;
    userService = [_coreComponents userService];
    
    sortedMessages = [[NSMutableArray alloc]init];
    allMessages = [[NSMutableArray alloc]init];
    userPresenceDict = [[NSMutableDictionary alloc]init];
    cmoMessagesDictionary = [[NSMutableDictionary alloc]init];
   
    //`messageQueueArray` - keep track of an messages which is the send queue (i.e)message is being sent.
    messageQueueArray = [[NSMutableArray alloc]init];
    //vCardArray = [[NSMutableArray alloc]init];
   
    //self.collectionView.collectionViewLayout.incomingAvatarViewSize = CGSizeZero;
    //self.collectionView.collectionViewLayout.outgoingAvatarViewSize = CGSizeZero;
    self.collectionView.backgroundColor = [UIColor colorWithRed:255.0f/255.0f green:255.0f/255.0f blue:255.0f/255.0f alpha:1.0f];
    self.collectionView.collectionViewLayout.messageBubbleFont = [UIFont fontWithName:@"Helvetica" size:21];
    
    //[self saveMessageStatusForRoom:self.receiverId];
    [self registerNotifications];
    [self setupBubbles];
    //[self addGestureToNavigation];
    //[self fetchUsersvCard];
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    defaultProfileAvatarImage = [JSQMessagesAvatarImageFactory avatarImageWithImage:[UIImage imageNamed:@"ProfilePic_Placeholder.png"] diameter:100.0];
    errorProfileAvatarImage = [JSQMessagesAvatarImageFactory avatarImageWithImage:[UIImage imageNamed:@"errorIcon.png"] diameter:100.0];
    userAvatarImages = [NSMutableDictionary dictionary];
    
    //NSLog(@"Decrypted data %@",decryptedData);
}




- (void)scheduleJoinedTimer{
    //[self invalidateJoinedTimer];
    //joinedTimer = [NSTimer scheduledTimerWithTimeInterval:30.0f target:self selector:@selector(enableRetry:) userInfo:nil repeats:NO];
    [self performSelector:@selector(enableRetry:) withObject:nil afterDelay:5.0f];
}

/*- (void)invalidateJoinedTimer{
    if (joinedTimer){
        [joinedTimer invalidate];
        joinedTimer = nil;
    }
}*/

- (void)enableRetry:(id)sender{
    shouldEnableRetry = true;
}

- (void)scheduldedSortMessages {
    if (reloadTimer) {
        [reloadTimer invalidate];
        reloadTimer = nil;
    }
    reloadTimer = [NSTimer scheduledTimerWithTimeInterval:5.0
                                                   target:self
                                                 selector:@selector(sortMessagesByDate:)
                                                 userInfo:nil
                                                  repeats:NO];
}

- (void)sortMessagesByDate:(id)sender{
    NSSortDescriptor *descriptor = [[NSSortDescriptor alloc] initWithKey:@"messageBody.messageDate" ascending:true];
    [sortedMessages sortedArrayUsingDescriptors:@[descriptor]];
    [self.collectionView reloadData];
}


-(void)reloadChatViewData {
    //DDLogInfo(@"\n%@ %@ 000129",THIS_METHOD,THIS_FILE);
    [sortedMessages removeAllObjects];
    [allMessages removeAllObjects];
    [userPresenceDict removeAllObjects];
    self.inputToolbar.contentView.textView.text = @"";
    self.inputToolbar.contentView.textView.placeHolder = @"New Message";
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        [self registerNotifications];
    }
    
    [self.collectionView reloadData];
    
    isPickerDismissed = false;
    
    isJoined = false;
    isJoining = false;
    isConnected = [self.chatModel isConnectedToXMPP];

    [self prepareChatRoom:true];
    
    if (_chatType == ChatTypeExistingChat){
        //DDLogInfo(@"\n%@ %@ existing chat  000130",THIS_METHOD,THIS_FILE);
        //CMOChatContainerViewController *chatContainerVC = (CMOChatContainerViewController *)self.parentViewController;
        NSUInteger participantsCount = [[_chatModel clubOwnersAndMembers:self.roomInfo] count];
        [parentVC setParticipantCount:(long)participantsCount];
        //Update draft message in this method. Don't update on viewWillAppear or viewDidLoad
        NSString *draftMessage = [_chatModel fetchDraftMessagesForRoom:self.receiverId];
        if ([draftMessage length] > 0){
            self.inputToolbar.contentView.textView.text = draftMessage;
        }
       
        [self scrollCollectionViewToBottom];
    }
    else if(_chatType == ChatTypeNewChat)
    {
        //DDLogInfo(@"\n%@ %@ new chat  000131",THIS_METHOD,THIS_FILE);
        [self updateParticipantCount];
    }
    
}

- (void)checkXmppConnection{
    isConnected = [self.chatModel isConnectedToXMPP];
    if (!isConnected){
        NSString *decryptedData = [CMOUtils decryptUserData];
        if ([decryptedData length] > 0){
            NSArray *credentials = [decryptedData componentsSeparatedByString:@"|"];
            if (credentials.count == 2){
                id <CMOXMPPDelegate>client = [_coreComponents xmppManager];
                [client connectWithJID:credentials[0] password:credentials[1] completionHandler:^(XMPPStream *stream, DDXMLElement *error) {
                    if (error){
                        DDLogError(@"XMPP Connection Failed %@ %@",THIS_FILE,THIS_METHOD);
                    }
                }];
            }
        }
    }
}

- (void)prepareChatRoom:(BOOL)shouldJoin {
    
    [self checkXmppConnection];
    
    //////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (!self.receiverId){
        //////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        DDLogError(@"receiverId is NIL");
        return;
    }
    [self setNavigationTitle:_chatType == ChatTypeNewChat ? @"New Conversation" : self.roomInfo.roomSubject];
    
    if (_chatType == ChatTypeNewChat && self.isFromParent){
        self.isFromParent = false;
        [self shouldEnableInputField:true];
        
        if (!parentVC){
            parentVC = (CMOChatContainerViewController *)self.parentViewController;
        }
        id <CMOUserClient>userClient = [_coreComponents userService];
        //////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
        return;
    }
    
    if (self.roomInfo){
        self.partcipantsList = [self.chatModel getRoomParticipants:self.roomInfo];
    }
    if (self.roomInfo && ![self.roomInfo.roomName isEqualToString:self.receiverId]){
        //////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
        DDLogError(@"Room Name is not matching. Please check the room Id");
        return;
    }
    if (!isJoined && _chatType == ChatTypeExistingChat && !self.roomInfo.roomProperty.isOffline){
        [self setNavigationTitle:@"Connecting..."];
    }
    if (shouldJoin && self.roomInfo && !self.roomInfo.roomProperty.isOffline){
        //[self setNavigationTitle:!isConnected ? @"Connecting..." : self.roomInfo.roomSubject];

        //////DDLogInfo(@"%@ %@ 4-1",THIS_METHOD,THIS_FILE);
         [self shouldEnableInputField:false];
         [self showHUDWithMessage:@"Loading..."];
         [self hideHUDIndicator];
        if (isConnected && !isJoining){
            [self joinToRoom:self.roomInfo onSuccess:^(BOOL result) {
                [self shouldEnableInputField:true];
            } onFailure:^(NSError *error) {
                DDLogError(@"Failed to Join the room %@",error);
                ////////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
                //DDLogInfo(@"\n%@ %@ 00020",THIS_METHOD,THIS_FILE);
            }];
        }
    }
    
    if (self.isFromParent && _chatType == ChatTypeExistingChat){
       // [self setNavigationTitle:!isConnected ? @"Connecting..." : self.roomInfo.roomSubject];

        //////DDLogInfo(@"%@ %@ 7",THIS_METHOD,THIS_FILE);
        self.isFromParent = false;
        [self getAllMessages];
        
        
        [self joinToRoom:_roomInfo onSuccess:^(BOOL result) {
            ////////DDLogInfo(@"Joined in room %@ %@",THIS_METHOD,THIS_FILE);
            ////////DDLogInfo(@"%@ %@ 9",THIS_METHOD,THIS_FILE);
            //DDLogInfo(@"\n%@ %@ 00021\n",THIS_METHOD,THIS_FILE);
        } onFailure:^(NSError *error) {
            DDLogError(@"Failed to Join the room %@",error);
            //////DDLogInfo(@"%@ %@ 10",THIS_METHOD,THIS_FILE);
        }];
        
        
        
        
        //SLA & Confidential Button Enabled
        
        //NSInteger count = [self.chatModel getMessageCountForRoom:self.receiverId];
        //NSInteger offlineCount = [self.chatModel getOfflineMessageCountOfRoom:self.receiverId];
        //Load Participant from model to dictionary.
        
        //[self setNavigationTitle:self.roomInfo.roomSubject];
        
        //[self shouldEnableInputField:false];
        /*if (_roomInfo.totalMessageCount == 0 && offlineCount > 0){
            //////DDLogInfo(@"%@ %@ 8",THIS_METHOD,THIS_FILE);
            [self displayAlertWithTitle:RESEND_FIRST_MSG];
            if (self.roomInfo && !self.roomInfo.roomProperty.isOffline && isConnected && !isJoining){
                [self joinToRoom:_roomInfo onSuccess:^(BOOL result) {
                    ////////DDLogInfo(@"Joined in room %@ %@",THIS_METHOD,THIS_FILE);
                    ////////DDLogInfo(@"%@ %@ 9",THIS_METHOD,THIS_FILE);
                    //DDLogInfo(@"\n%@ %@ 00021\n",THIS_METHOD,THIS_FILE);
                } onFailure:^(NSError *error) {
                    DDLogError(@"Failed to Join the room %@",error);
                    //////DDLogInfo(@"%@ %@ 10",THIS_METHOD,THIS_FILE);
                }];
            }
        }
        else if (_roomInfo.totalMessageCount == 0 && offlineCount == 0){
            //////DDLogInfo(@"%@ %@ 11",THIS_METHOD,THIS_FILE);
            //[self displayAlertWithTitle:OFFLINE_MESSAGE_NOT_AVAILBLE];
            if (self.roomInfo && !self.roomInfo.roomProperty.isOffline && isConnected && !isJoining){
                [self joinToRoom:_roomInfo onSuccess:^(BOOL result) {
                    ////////DDLogInfo(@"Joined in room %@ %@",THIS_METHOD,THIS_FILE);
                    ////////DDLogInfo(@"%@ %@ 12",THIS_METHOD,THIS_FILE);
                    //DDLogInfo(@"\n%@ %@ 00022\n",THIS_METHOD,THIS_FILE);
                } onFailure:^(NSError *error) {
                    DDLogError(@"Failed to Join the room %@",error);
                    //////DDLogInfo(@"%@ %@ 13",THIS_METHOD,THIS_FILE);
                }];
            }
        }
        else{
            //////DDLogInfo(@"%@ %@ 14",THIS_METHOD,THIS_FILE);
            [self shouldEnableInputField:true];
            NSMutableArray *groups = self.roomInfo.roomProperty.groups;
            if ([groups count] > 0){
                //////DDLogInfo(@"%@ %@ 15",THIS_METHOD,THIS_FILE);
                [self.roomModel addGroups:groups toChatRoom:self.roomInfo.roomName onSuccess:^(id response) {
                    //////DDLogInfo(@"Add Groups to chatroom success");
                    //////DDLogInfo(@"%@ %@ 16",THIS_METHOD,THIS_FILE);
                } onFailure:^(NSError *error) {
                    //////DDLogInfo(@"Add Groups to chatroom failed %@",error);
                    //////DDLogInfo(@"%@ %@ 17",THIS_METHOD,THIS_FILE);
                }];
                //Retrieve chat room - To update MembersGroup info.
                [self.roomModel retreiveChatRoom:self.roomInfo.roomName onSuccess:^(id result) {
                    //////DDLogInfo(@"Retrieve chatroom success");
                    //////DDLogInfo(@"%@ %@ 18",THIS_METHOD,THIS_FILE);
                    //DDLogInfo(@"\n%@ %@ retreiveChatRoom::Succcess: 000123\n",THIS_METHOD,THIS_FILE);
                } onFailure:^(NSError *error) {
                     //DDLogInfo(@"\n%@ %@ retreiveChatRoom::failed: 000124\n",THIS_METHOD,THIS_FILE);
                    //////DDLogInfo(@"Retrieve chatroom Failed");
                    //////DDLogInfo(@"%@ %@ 19",THIS_METHOD,THIS_FILE);
                }];
            }
            //////DDLogInfo(@"%@ %@ 20",THIS_METHOD,THIS_FILE);
            //Join the room when connection is establised.
            if (isConnected && !isJoining){
                [self joinToRoom:_roomInfo onSuccess:^(BOOL result) {
                    ////////DDLogInfo(@"Joined in room %@ %@",THIS_METHOD,THIS_FILE);
                    ////////DDLogInfo(@"%@ %@ 21",THIS_METHOD,THIS_FILE);
                    //DDLogInfo(@"\n%@ %@ 00023\n",THIS_METHOD,THIS_FILE);
                } onFailure:^(NSError *error) {
                    DDLogError(@"Failed to Join the room %@",error);
                    ////////DDLogInfo(@"%@ %@ 22",THIS_METHOD,THIS_FILE);
                    //DDLogInfo(@"\n%@ %@ 00024\n",THIS_METHOD,THIS_FILE);
                }];
            }
            
        }*/
        //////DDLogInfo(@"%@ %@ 23",THIS_METHOD,THIS_FILE);
        
    }
    [self.collectionView reloadData];
    
    //////DDLogInfo(@"%@ %@ 99",THIS_METHOD,THIS_FILE);
    
}


- (void)shouldEnableInputField:(BOOL)enable{
    self.inputToolbar.contentView.textView.userInteractionEnabled = enable;
    self.inputToolbar.contentView.leftBarButtonItem.enabled = enable;
}


/*- (void) leaveRoomiPad
{
    CMOChatContainerViewController *chatvc = (CMOChatContainerViewController *)self.parentViewController;
//    [self unRegisterNotifications];
    [self.inputToolbar.contentView.textView resignFirstResponder];
    [self.chatModel leaveRoom];
    
    NSString *lastRoomId = [self.receiverId copy];
    //#warning Leak
    dispatch_async(dispatch_get_main_queue(), ^{
        NSInteger count = [self.chatModel getMessageCountForRoom:lastRoomId];
        
        [self.chatModel saveVisitedRoom:lastRoomId count:(int32_t)count];
        
        [self updateLastMessageDate:[sortedMessages lastObject]];
    });
    [self updateDraftMessage];
    //[self invalidateJoinedTimer];
}
*/

- (void)updateLastMessageDate:(CMOMessage *)message{
    //CMOMessage *cmoMessage = [sortedMessages lastObject];
    if (message){
        [self.roomModel updateRoomInfo:message.roomIDStr withLastMessageDate:message.messageBody.messageDate];
    }
}



#pragma mark Update Visited Room
//This will called from conversationviewcontroller
/*- (void)updateVisitedRoom{
    if (_chatType == ChatTypeExistingChat && self.receiverId){
        NSInteger count = [self.chatModel getMessageCountForRoom:self.receiverId];
        [self.chatModel saveVisitedRoom:self.receiverId count:(int32_t)count];
    }
}

- (void)saveMessageStatusForRoom:(NSString *)roomId{
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        if (![_chatModel isMessageReadForRoom:roomId]){
            [_chatModel saveMessageReadStatus:true unReadCount:0 forRoom:roomId];
        }
    });
}
*/

#pragma mark Register Notifications

- (void)registerNotifications{
   // [self unRegisterNotifications];
    //XMPP_ROOM_SELF_JOINED_NOTIFICATION

    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(registrationRequiredToJoin:) name:XMPP_REGISTRATION_REQUIRED_NOTIFICATION object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(connectionEstablised:) name:XMPP_CONNECTION_ESTABLISHED object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(connectionInteruppted:) name:XMPP_DISCONNECT object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(connectionInteruppted:) name:XMPP_ACCIDENTAL_DISCONNECT_NOTIFICATION object:nil];
    
     [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(userTypingStatus:) name:XMPP_USER_TYPING_NOTIFICATION object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(receivedUserPresence:) name:XMPP_PRESENCE_NOTIFICATION object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(updatePresence:) name:XMPP_USER_PRESENCE_NOTIFICATION object:nil];
    
    //DID_RECEIVED_MESSAGE_NOTIFICATION
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(didReceiveMessage:) name:DID_RECEIVED_MESSAGE_NOTIFICATION object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadMessages:) name:DELETE_DOCUMENT_NOTIFICATION object:nil];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(applicationLoggedOut:) name:LOGOUT_NOTIFICATION object:nil];
    }
    
}

- (void)reloadMessages:(NSNotification *)notification {
    //[self getAllMessages];
    CMOMessage *msg = notification.userInfo[@"message"];
    if([self.chatModel isOfflineMessage:msg]){
        [self.chatModel removeOfflineMessage:msg];
        [self getAllMessages];
    }
    
}

#pragma mark UnRegister Notifications


- (void)unRegisterNotifications {
    

    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_CONNECTION_ESTABLISHED object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_DISCONNECT object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_ACCIDENTAL_DISCONNECT_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_ROOM_JOINED_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_ROOM_LEFT_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_USER_TYPING_NOTIFICATION object:nil];
    
   // [[NSNotificationCenter defaultCenter]removeObserver:self name:DID_MESSAGE_INSERT_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_PRESENCE_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:XMPP_USER_PRESENCE_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:DID_RECEIVED_MESSAGE_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:DELETE_DOCUMENT_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:APP_WILL_RESIGN_ACTIVE_NOTIFICATION object:nil];

}

#pragma mark XMPP Notification Methods

- (void)connectionEstablised:(NSNotification *)notification{
    //////DDLogInfo(@"Connection Established");
    isConnected = true;
    [self prepareChatRoom:true];
}

- (void)connectionInteruppted:(NSNotification *)notification{
    ////////DDLogInfo(@"Connection Interuppted");
    isConnected = false;
    isJoined = false;
    shouldEnableRetry = false; //When connection interrupted, retry will be disabled
    [self setNavigationTitle:@"Connecting..."];
    //[self saveLastMessage];
    //Reloading to update online/offline status
    [self.collectionView reloadData];
    //self.inputToolbar.contentView.rightBarButtonItem.enabled = isConnected;
}

- (void)registrationRequiredToJoin:(NSNotification *)notification{
    self.inputToolbar.contentView.textView.placeHolder = @"You are no longer participant of this chat";
    self.inputToolbar.contentView.textView.userInteractionEnabled = false;
    self.inputToolbar.contentView.leftBarButtonItem.enabled = false;
}


#pragma mark - User Typing Status

- (void)userTypingStatus:(NSNotification *)notification{
    XMPPMessage *message = notification.userInfo[@"message"];
    if (![[message.from user] isEqualToString:self.receiverId])return;
    NSString *sender = [message.from resource];
    if (![sender isEqualToString:self.senderId]){
        NSString *titleMessage = @"";
        if ([message hasComposingChatState]){
            titleMessage = [NSString stringWithFormat:@"%@ typing...",sender];
        }
        else if ([message hasActiveChatState]){
            titleMessage = @"";
            
        }
        else if ([message hasInactiveChatState]){
            titleMessage = @"";
        }
        else if ([message hasPausedChatState]){
            titleMessage = @"";
        }
        else{
            titleMessage = @"";
        }
        
        if (titleMessage.length == 0){
            [self setNavigationTitle:_roomInfo.roomSubject];
        }
        else{
            [self setNavigationTitle:titleMessage];
        }
    }
}


- (void)setNavigationTitle:(NSString *)title {
    //Because chatviewcontroller is a child vc of CMOContainerViewController
    CMOChatContainerViewController *chatContainer = (CMOChatContainerViewController *)self.parentViewController;
    [chatContainer setNavigationTitle:title];
}

#pragma mark User Presence
- (void)receivedUserPresence:(NSNotification *)notification{
    CMOUserPresence *presence = (CMOUserPresence *)[notification.userInfo valueForKey:@"presence"];
    if (presence && presence.from){
        [userPresenceDict setValue:presence forKey:presence.from];
    }
    
    if (presence.ownPresence){
        CMOOccupant *occupant = presence.user;
        if ([occupant.username isEqualToString:self.senderId] && [occupant.affiliation isEqualToString:@"none"]){
            [self restrictChat];
            
        }
    }
    
    [self.collectionView reloadData];
}


- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    NSArray *vc = [self.navigationController viewControllers];
    //Chat view controller is inside chat container view
    //Remote notification only when poping view controller
    CMOChatContainerViewController *chatvc = (CMOChatContainerViewController *)self.parentViewController;
    BOOL isbackPressed = ![vc containsObject:self.parentViewController] && [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone;
    if (isbackPressed){
        [self unRegisterNotifications];
    }
    
    if(_chatType == ChatTypeExistingChat){
        if (isbackPressed){

            //#warning TODO:AN Update Message failed property of room details if any offline messages are present. This needs to be done here. Also update the case for iPad.
            //#warning TODO:AN Updated the Total Message count
            
            [self.inputToolbar.contentView.textView resignFirstResponder];
            [self.chatModel leaveRoom];
            NSInteger count = [self.chatModel getMessageCountForRoom:self.receiverId];
            [self.chatModel saveVisitedRoom:self.receiverId count:(int32_t)count];
            
            CMOMessage *cmoMessage = [sortedMessages lastObject];
            if (cmoMessage){
                [self.roomModel updateRoomInfo:cmoMessage.roomIDStr withLastMessageDate:cmoMessage.messageBody.messageDate];
            }
            
            [self updateDraftMessage];
            //[self invalidateJoinedTimer];
        }
       
    }
}

- (void)updateDraftMessage {
    NSString *messageText = self.inputToolbar.contentView.textView.text;
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        //update even if message text is empty.This will remove old draft message for room
        if ([self.receiverId length] > 0){
            [_chatModel saveDraftMessage:messageText forRoom:self.receiverId];
        }
    });
}


- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    parentVC = (CMOChatContainerViewController *)self.parentViewController;
    [self prepareChatRoom:false];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    if (_chatType == ChatTypeExistingChat){
        //CMOChatContainerViewController *chatContainerVC = (CMOChatContainerViewController *)self.parentViewController;
        NSUInteger participantsCount = [[_chatModel clubOwnersAndMembers:self.roomInfo] count];
        [parentVC setParticipantCount:(long)participantsCount];
        //Update draft message in this method. Don't update on viewWillAppear or viewDidLoad
        NSString *draftMessage = [_chatModel fetchDraftMessagesForRoom:self.receiverId];
        if ([draftMessage length] > 0){
            self.inputToolbar.contentView.textView.text = draftMessage;
        }
        [self.inputToolbar.contentView.textView resignFirstResponder];
    }
    else if(_chatType == ChatTypeNewChat)
    {
        [self updateParticipantCount];
    }
    
}

- (void)updateParticipantCount
{
    int count = 0;
    for (NSString *key in self.partcipantsList.allKeys){
        NSMutableArray *values = [self.partcipantsList valueForKey:key];
        count += values.count;
    }
    CMOChatContainerViewController *chatContainerVC = (CMOChatContainerViewController *)self.parentViewController;
    [chatContainerVC setParticipantCount:count];
}


- (void)getAllMessages{
    //Messages are already sorted by message.messagebody.messageDate. No need to sort by localTimeStamp
    NSMutableArray *xmppMessages = [self.chatModel getMessagesForRoom:self.receiverId delegate:self messagesDict:cmoMessagesDictionary];
    if (xmppMessages.count > 0){
        //If the status is in pending state, then remove from XMPP Table bcoz it is already in offline table.
   
         NSArray *predicateArray = [NSArray array];
         NSPredicate *noMessageID = [NSPredicate predicateWithFormat:@"messageBody.messageId == nil"];
         NSPredicate *status = [NSPredicate predicateWithFormat:@"status == 2"];
         predicateArray = [predicateArray arrayByAddingObject:noMessageID];
         
         NSArray *uniqueMsgIDs = [xmppMessages valueForKeyPath:[NSString stringWithFormat:@"@distinctUnionOfObjects.%@", @"messageBody.messageId"]];
         NSPredicate *uniqueIDs = [NSPredicate predicateWithFormat:@"messageBody.messageId IN %@", uniqueMsgIDs];
         predicateArray = [predicateArray arrayByAddingObject:uniqueIDs];
        
         NSCompoundPredicate *orPredicate = [NSCompoundPredicate orPredicateWithSubpredicates:predicateArray];
        NSArray *andArray = [NSArray arrayWithObjects:status,orPredicate, nil];
        NSCompoundPredicate *andPredicate = [NSCompoundPredicate andPredicateWithSubpredicates:andArray];
        
         NSArray *resultArray = [xmppMessages filteredArrayUsingPredicate:andPredicate];
        if (resultArray.count > 0){
            [sortedMessages addObjectsFromArray:resultArray];
        }
    }
    //SLA Logic
    //NSArray *messages = [self.chatModel getMessagesForRoom:self.receiverId delegate:self];
    
    /* Add offline messages to sorted array */
    NSArray *offlineMessages = [self.chatModel getOfflineMessageOfRoom:self.receiverId delegate:self messagesDict:cmoMessagesDictionary];
    
    //status == 2 - Success
    if (offlineMessages.count > 0){
        /*for (CMOMessage *offlineMessage in offlineMessages){
            if (offlineMessage.messageBody.messageId){
                NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messageBody.messageId == %@ && status == 2",offlineMessage.messageBody.messageId];
                NSArray *list = [sortedMessages filteredArrayUsingPredicate:predicate];
                for (CMOMessage *msg in list){
                    [self.chatModel removeOfflineMessage:msg];
                    [sortedMessages removeObject:msg];
                }
            }
            else{
                NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messageBody.messageDateString == %@ && status == 2",offlineMessage.messageBody.messageDateString];
                NSArray *list = [sortedMessages filteredArrayUsingPredicate:predicate];
                for (CMOMessage *msg in list){
                    [self.chatModel removeOfflineMessage:msg];
                    [sortedMessages removeObject:msg];
                }
            }
        }*/
        
        //offlineMessages = [self.chatModel getOfflineMessageOfRoom:self.receiverId delegate:self messagesDict:cmoMessagesDictionary];
        
        for (CMOMessage *oMessage in offlineMessages){
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"messageBody.messageId == %@",oMessage.messageBody.messageId];
            NSArray *list = [sortedMessages filteredArrayUsingPredicate:predicate];
            if (list.count > 0 && sortedMessages.count > 0){
                //[sortedMessages replaceObjectAtIndex:[sortedMessages indexOfObjectIdenticalTo:list[0]] withObject:oMessage];
                [self replaceObjectInSortedArrayWithMessage:list[0]];
                /*NSUInteger index = [sortedMessages indexOfObjectPassingTest:^BOOL(id obj, NSUInteger idx, BOOL *stop) {
                    
                    if ([((CMOMessage *)obj).messageBody.messageId isEqualToString:((CMOMessage *)list[0]).messageBody.messageId]){
                        *stop = YES;
                        return YES;
                    }
                    return NO;
                }];
                if (index != NSNotFound){
                    [sortedMessages replaceObjectAtIndex:index withObject:oMessage];
                }*/
            }
            else{
                [sortedMessages addObject:oMessage];
            }
        }
        //[sortedMessages addObjectsFromArray:offlineMessages];
    }
    
    //To keep track of all messages during hide & unhide option.
    allMessages = [sortedMessages mutableCopy];
    
    //[self checkIfCMOGroupAddedForNonConfidential];
    //[self checkDeletedImages:sortedMessages];
    
}


#pragma mark Sort Message Offline

- (void)sortMessages:(NSArray *)messages byDate:(BOOL)ascending{
    if (messages.count > 0){
        //NSSortDescriptor *descriptor = [[NSSortDescriptor alloc] initWithKey:@"localTimeStamp" ascending:ascending];
        sortedMessages =  [_chatModel sortCMOMessages:messages ascending:true];//[NSMutableArray arrayWithArray:[messages sortedArrayUsingDescriptors:@[descriptor]]];
    }
}



#pragma mark - Roster View Delegate Method
- (void)participants:(NSMutableDictionary *)participants{
    //NSLog(@"participant list %@",participants);
    self.partcipantsList = participants;
    
    int count = 0;
    for (NSString *key in self.partcipantsList.allKeys){
        NSMutableArray *values = [self.partcipantsList valueForKey:key];
        count += values.count;
    }
    
    CMOChatContainerViewController *chatContainerVC = (CMOChatContainerViewController *)self.parentViewController;
    [chatContainerVC setParticipantCount:count];
    
}


- (void)setupBubbles{
    JSQMessagesBubbleImageFactory *factory = [[JSQMessagesBubbleImageFactory alloc]init];
    outgoingBubbleImageView = [factory outgoingMessagesBubbleImageWithColor:[UIColor jsq_messageBubbleGreenColor]];
    incomingBubbleImageView = [factory incomingMessagesBubbleImageWithColor:[UIColor darkGrayColor]];
}

#pragma mark Join the Room 

- (void)joinToRoom:(CMORoomDetails *)roomInfo
         onSuccess:(void (^)(BOOL result))success
         onFailure:(void (^)(NSError *error))failure {
    
    //////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (![CMOUtils isNetworkAvailable]){
        //////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        [self displayAlertWithTitle:NETWORK_ERROR];
        return;
    }
    
    //CMOChatContainerViewController *chatContainerVC = (CMOChatContainerViewController *)self.parentViewController;
    //#warning Update LastMessageDate in `CMORoomDetails` property.
    NSArray *messages = [self.chatModel getMessagesForRoom:self.receiverId delegate:self messagesDict:nil];
    BOOL isConfidential = false;
    if (messages.count > 0){
        CMOMessage *firstMessage = messages[0];
        if ([firstMessage.messageBody.isConfidential boolValue] == true){
            isConfidential = true;
        }
    }
    
    //id <CMORepositoryClient>repositoryClient = [_coreComponents repositoryService];
    CMOMessage *lastMessage = [messages lastObject];//[repositoryClient fetchLastMessageOfRoom:roomName];
    NSString *startDateString = nil;
    if (lastMessage){
        if (lastMessage.messageBody.messageDate){
            NSDate *startDate = lastMessage.messageBody.messageDate;
            startDateString = [CMOUtils toSpecifiedFormatString:startDate format:DATE_FORMAT];
        }
    }
    [self showHUDWithMessage:@"Loading..."];
    [self shouldEnableInputField:false];
    //////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
    isJoining = true;
    
    __weak typeof(self) weakSelf = self;
    [self.roomModel joinToRoom:roomInfo history:lastMessage.messageBody.messageDate onSuccess:^(BOOL result) {
        //DDLogInfo(@"\n%@ %@ 0003\n",THIS_METHOD,THIS_FILE);
        ////////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
        DDLogError(@"Joined success");
        isJoined = true;
        isJoining = false;
        //isConnected = true;
        [self setNavigationTitle:self.roomInfo.roomSubject ? self.roomInfo.roomSubject : @""];
        [self hideHUDIndicator];
        [self shouldEnableInputField:true];
        [weakSelf scheduleJoinedTimer];
        success(result);
    } onFailure:^(NSError *error) {
        //DDLogInfo(@"\n%@ %@ 0004\n",THIS_METHOD,THIS_FILE);
        ////////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
        DDLogError(@"Unable to Join the Room %@",error);
        isJoining = false;
        [self setNavigationTitle:self.roomInfo.roomSubject ? self.roomInfo.roomSubject : @""];
        [self hideHUDIndicator];
        if (error.code == XMPP_REGISTRATION_REQUIRED_CODE){//Not allowed to join
            [self displayAlertWithTitle:NOT_A_PARTICIPANT_MSG];
            [self restrictChat];
        }
        else{
            [self shouldEnableInputField:true];
        }
        isJoined = false;
        failure(error);
    }];
}

- (void)restrictChat{
    self.inputToolbar.contentView.textView.placeHolder = @"You are no longer participant of this chat";
    self.inputToolbar.contentView.textView.userInteractionEnabled = false;
    self.inputToolbar.contentView.leftBarButtonItem.enabled = false;
    //[self.chatModel leaveRoom];
}

#pragma mark Show/Hide HUD Indicator

- (void)showHUDWithMessage:(NSString *)text{
    if (!hudIndicator){
        hudIndicator = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    }
    hudIndicator.label.text = text;
}


- (void)hideHUDIndicator{
    if (hudIndicator){
        [hudIndicator hideAnimated:true];
    }
}

/* Required Parameters
 {
 "roomName": "global",
 "naturalName": "global-2",
 "description": "Global chat room"
 }
 */


- (void)createRoomWithMessage:(CMOMessage *)message
                 participants:(NSMutableDictionary *)participants
                     document:(id)document{
    //DDLogInfo(@"\n%@ %@ 00060\n",THIS_METHOD,THIS_FILE);

   //////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    BOOL isiPad = [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad;

    [self showHUDWithMessage:@"Creating chat..."];
    
    if (isiPad){
        //DDLogInfo(@"\n%@ %@ 000200\n",THIS_METHOD,THIS_FILE);
        appDelegate.roomCreationInprogress = YES;
        //This will refresh the conversations screen (Left screen) in the iPad.
        [[NSNotificationCenter defaultCenter]postNotificationName:DID_RECEIVED_UPDATE_TABLE_NOTIFICATION object:nil userInfo:nil];
    }
    
    [_roomModel createRoomWithMessage:message
                         participants:participants
                            onSuccess:^(id result, CMOMessage *message) {
        //DDLogInfo(@"\n%@ %@ 00061\n",THIS_METHOD,THIS_FILE);
        [self performSelector:@selector(allowFocusChange:) withObject:Nil afterDelay:3];
        if (isiPad){
            //This will refresh the conversations screen (Left screen) in the iPad.
             [[NSNotificationCenter defaultCenter]postNotificationName:DID_RECEIVED_UPDATE_TABLE_NOTIFICATION object:nil userInfo:nil];
        }
                                
        //////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        //Update Room Details once room is created. This will populate `participants`
        self.roomInfo = [self.chatModel fetchRoomInfo:self.receiverId];
        parentVC.roomInfo = self.roomInfo;
        
        //self.receiverId = message.roomIDStr;
        [self updateLastMessageDate:message];
        [self updateChatType:ChatTypeExistingChat];
        if (!isConnected){
            //DDLogInfo(@"\n%@ %@ 00062\n",THIS_METHOD,THIS_FILE);
            message.status = MessageDeliveryFailed;
            [self.chatModel saveMessageOffline:message];
            [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
            [self hideHUDIndicator];
            return;
        }
                                
        [self showHUDWithMessage:@"Sending Message...."];
        ////////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
        [self joinToRoom:self.roomInfo onSuccess:^(BOOL result) {
            //DDLogInfo(@"\n%@ %@ 0005\n",THIS_METHOD,THIS_FILE);
            ////////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
            [self setNavigationTitle:message.isMediaMessage ? @"Document" : message.messageBody.body];
            [self.roomModel inviteUsersToJoinTheRoom:participants forRoom:self.receiverId withAffiliation:AffiliationMember];
            
            //If Media Message, then upload document and send message.
            [self showHUDWithMessage:@"Sending Message..."];
            if (message.isMediaMessage){
                //DDLogInfo(@"\n%@ %@ 0006\n",THIS_METHOD,THIS_FILE);
                ////////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
                #warning Verify this method
                [self processDocumentWithMessage:message document:document];
            }
            else{
                //////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
                [self handleSendMessageProcess:message onSuccess:^(id result) {
                    //Hide HUD
                    //////DDLogInfo(@"%@ %@ 7",THIS_METHOD,THIS_FILE);
                    [self hideHUDIndicator];
                } onFailure:^(NSError *error) {
                    //Hide HUD
                    ////////DDLogInfo(@"%@ %@ 8",THIS_METHOD,THIS_FILE);
                    message.status = MessageDeliveryFailed;
                    //To update the status `MessageDeliveryStatus` in Offline Message
                    [self.chatModel saveMessageOffline:message];
                    [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];

                    [self hideHUDIndicator];
                }];
            }
        } onFailure:^(NSError *error) {
            ////////DDLogInfo(@"%@ %@ 9",THIS_METHOD,THIS_FILE);
            //DDLogInfo(@"\n%@ %@ 0001\n",THIS_METHOD,THIS_FILE);
            //DDLogInfo(@"\n%@ %@ 000201\n",THIS_METHOD,THIS_FILE);
            appDelegate.roomCreationInprogress = NO;
            message.status = MessageDeliveryFailed;
            [self.chatModel saveMessageOffline:message];
            [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
            [self hideHUDIndicator];
#warning Handle Network Errors Logic
            [self displayAlertWithTitle:SERVER_ACCESS_ERROR_MSG];
        }];
    } onFailure:^(NSError *error) {
        //DDLogInfo(@"\n%@ %@ 00064\n",THIS_METHOD,THIS_FILE);
        if (isiPad){
            //DDLogInfo(@"\n%@ %@ 000202\n",THIS_METHOD,THIS_FILE);
            appDelegate.roomCreationInprogress = NO;
            //This will refresh the conversations screen (Left screen) in the iPad.
            [[NSNotificationCenter defaultCenter]postNotificationName:DID_RECEIVED_UPDATE_TABLE_NOTIFICATION object:nil userInfo:nil];
        }
        [self updateLastMessageDate:message];
        [self updateChatType:ChatTypeExistingChat];
        #warning TODO:AN Check for Network Failure & Room Creation Failure
        ////////DDLogInfo(@"%@ %@ 10",THIS_METHOD,THIS_FILE);
        self.roomInfo = [self.chatModel fetchRoomInfo:self.receiverId];
        message.status = MessageDeliveryFailed;
        [self.chatModel saveMessageOffline:message];
        [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
        //DDLogInfo(@"\n%@ %@ 0002\n",THIS_METHOD,THIS_FILE);
        if ([CMOUtils isNetworkError:error]){
            //////DDLogInfo(@"%@ %@ 11",THIS_METHOD,THIS_FILE);
            [self displayAlertWithTitle:SERVER_ACCESS_ERROR_MSG];
        }
        
        [self hideHUDIndicator];
    }];

}


- (void)allowFocusChange:(NSNotification *)notification{
    appDelegate.roomCreationInprogress = NO;
    //DDLogInfo(@"\n%@ %@ 000207\n",THIS_METHOD,THIS_FILE);
}
#pragma mark - Update Chat Type
- (void)updateChatType:(ChatType)type{
    _chatType = type;
    parentVC.type = type;
}

#pragma mark Construct `CMOMessageParam` from User Defined Action (i.e) From the view

- (CMOMessageParam *)constructMessageParam:(NSString *)body
                                     media:(id)media
                                      type:(DocumentType)documentType
                                  fileName:(NSString *)fileName
                                    roomId:(NSString *)roomId
                                      date:(NSDate *)date
                                      show:(BOOL)show //for hide/show
                                   smsSent:(BOOL)smsSent{
    
    //////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    NSString *serverTime = [CMOUtils getServerTime];
    NSDate *serverDate = [CMOUtils toSpecifiedFormatDate:serverTime format:MESSAGE_TIME_FORMAT];
    CMOMessageParam *messageParam = [[CMOMessageParam alloc]init];
    messageParam.body = body;
    messageParam.roomSubject = media ? DOCUMENT_SUBJECT : body;
    messageParam.senderId = self.senderId;
    messageParam.senderDisplayName = self.senderDisplayName;
    messageParam.roomId = roomId;
    messageParam.date = serverDate;
    messageParam.messageDateString = serverTime;
    messageParam.isMedia = media ? true : false;
    messageParam.media = media;
    messageParam.documentType = media ? documentType : DocumentTypeUnknown;
    messageParam.status = MessageDeliveryPending;

    //NSInteger epochTime = [serverDate timeIntervalSince1970];
    messageParam.messageId = [NSString stringWithFormat:@"%@_%f",self.senderId,[serverDate timeIntervalSince1970]];
    messageParam.isFirstMessage = (_chatType == ChatTypeNewChat) ? true : false;
    messageParam.fileName = fileName; //Applicable for Document Types
    return messageParam;
}


- (void)handleSendMessageProcess:(CMOMessage *)message
                       onSuccess:(void (^)(id result))success
                       onFailure:(void (^)(NSError *error))failure{

    
    //DDLogInfo(@"\n%@ %@ 00015\n",THIS_METHOD,THIS_FILE);
    ////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (![CMOUtils isNetworkAvailable]){
        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        //DDLogInfo(@"\n%@ %@ no network while sending message 00016\n",THIS_METHOD,THIS_FILE);
        [self displayAlertWithTitle:NETWORK_ERROR];
        message.status = MessageDeliveryFailed;
        //To update the status `MessageDeliveryStatus` in Offline Message
        [self.chatModel saveMessageOffline:message];
        [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
        NSError *err = [NSError errorWithDomain:@"CMOChat" code:111 userInfo:nil];
        failure(err);
        return;
    }
    
    
    if (![message.roomIDStr isEqualToString:self.receiverId]){
        DDLogError(@"Message not belongs to this room");
        message.status = MessageDeliveryFailed;
        [self.chatModel saveMessageOffline:message];
        [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
        NSError *err = [NSError errorWithDomain:@"CMOChat" code:112 userInfo:nil];
        failure(err);
        return;
    }

    
    if (![self.roomModel isJoinedInRoom:message.roomIDStr]){
        if (isConnected){
            if (!isJoining){
                [self joinToRoom:self.roomInfo onSuccess:^(BOOL result) {
                    [self sendMessageTo:message onSuccess:^(id result) {
                        ////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
                        //DDLogInfo(@"\n%@ %@ send message success 000203\n",THIS_METHOD,THIS_FILE);
                        appDelegate.roomCreationInprogress = NO;
                        success(result);
                    } onFailure:^(NSError *error) {
                        ////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
                        //DDLogInfo(@"\n%@ %@ send message failed 000206\n",THIS_METHOD,THIS_FILE);
                        failure(error);
                    }];
                } onFailure:^(NSError *error) {
                    message.status = MessageDeliveryFailed;
                    //To update the status `MessageDeliveryStatus` in Offline Message
                    [self.chatModel saveMessageOffline:message];
                    [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
                    NSError *err = [NSError errorWithDomain:@"CMOChat::Room Not Joined" code:111 userInfo:nil];
                    failure(err);
                }];
            }
            else{
                message.status = MessageDeliveryFailed;
                //To update the status `MessageDeliveryStatus` in Offline Message
                [self.chatModel saveMessageOffline:message];
                [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
                NSError *err = [NSError errorWithDomain:@"CMOChat::Room Not Joined" code:111 userInfo:nil];
                failure(err);
            }
        }
        else{
            message.status = MessageDeliveryFailed;
            //To update the status `MessageDeliveryStatus` in Offline Message
            [self.chatModel saveMessageOffline:message];
            [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
            NSError *err = [NSError errorWithDomain:@"CMOChat::Room Not Joined" code:111 userInfo:nil];
            failure(err);
            [self checkXmppConnection];
        }
    }
    else{
        [self sendMessageTo:message onSuccess:^(id result) {
            ////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
            //DDLogInfo(@"\n%@ %@ send message success 000203\n",THIS_METHOD,THIS_FILE);
            appDelegate.roomCreationInprogress = NO;
            success(result);
        } onFailure:^(NSError *error) {
            ////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
            //DDLogInfo(@"\n%@ %@ send message failed 000206\n",THIS_METHOD,THIS_FILE);
            failure(error);
        }];
    }
}


//New - Anish

- (void)sendMessageTo:(CMOMessage *)cmoMessage
            onSuccess:(void (^)(id result))success
            onFailure:(void (^)(NSError *error))failure{
     DDLogInfo(@"%@ %@ 1 %@",THIS_METHOD,THIS_FILE,cmoMessage);
  
    [self.chatModel sendMessage:cmoMessage roomId:self.receiverId completionHandler:^(XMPPMessage *message, NSError *error) {
        if (error){
             DDLogInfo(@"%@ %@ 2 %@",THIS_METHOD,THIS_FILE,error);
            cmoMessage.status = MessageDeliveryFailed;
            [self reloadCollectionViewCellWithIdentifier:cmoMessage.messageBody.messageDateString];
            failure(error);
        }
        else{
             DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
            cmoMessage.status = MessageDeliverySuccess;
            [self reloadCollectionViewCellWithIdentifier:cmoMessage.messageBody.messageDateString];
            success(cmoMessage);
        }
    }];
     DDLogInfo(@"%@ %@ 77",THIS_METHOD,THIS_FILE);
}


#pragma mark Add Messages to Chat Room

- (void)addMessagesToChatScreen:(CMOMessage *)message{
    //#warning Verify `isMessageAlreadyLoaded` method
    //////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (![self isMessageAlreadyLoaded:message]){
        //////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        [sortedMessages addObject:message];
        [allMessages addObject:message];
    }
    //////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
    [self.chatModel saveMessageOffline:message];
    
    [JSQSystemSoundPlayer jsq_playMessageSentSound];
    [self finishSendingMessage];
}

//messageId - Unique id (i.e) messageDate
- (void)reloadCollectionViewCellWithIdentifier:(NSString *)messageId{
    dispatch_async(dispatch_get_main_queue(), ^{
        
    NSArray *messages = [sortedMessages filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"messageBody.messageDateString == %@",messageId]];
    if (messages.count > 0){
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:[sortedMessages indexOfObject:[messages lastObject]] inSection:0];
        if (indexPath.row < sortedMessages.count){
            //DDLogInfo(@"Message object found %@ and Indexpath is %@",[messages lastObject],indexPath);
            [self.collectionView reloadItemsAtIndexPaths:@[indexPath]];
            }
        }
    });
}

- (void)didPressRetry:(id)sender {
    //DDLogInfo(@"\n%@ %@ 00026\n",THIS_METHOD,THIS_FILE);
    ////////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (![CMOUtils isNetworkAvailable]){
        //////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        [self displayAlertWithTitle:NETWORK_ERROR];
        //DDLogInfo(@"\n%@ %@ 00027\n",THIS_METHOD,THIS_FILE);
        return;
    }
    //////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.collectionView];
    NSIndexPath *indexPath = [self.collectionView indexPathForItemAtPoint:buttonPosition];
    //////DDLogInfo(@"Selected Index Position %@",indexPath);
    if (indexPath.row < sortedMessages.count){
        //DDLogInfo(@"\n%@ %@ 00028\n",THIS_METHOD,THIS_FILE);
        CMOMessage *message = sortedMessages[indexPath.row];
        //DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
        NSString *filePath = [_chatModel getFilePath:message.messageBody.body roomId:message.roomIDStr];
        BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:filePath]; //[CMOUtils isFileExistAtPath:filePath];

       
        if (!message){
            //DDLogInfo(@"\n%@ %@ 00029\n",THIS_METHOD,THIS_FILE);
            DDLogError(@"No Message found for the selected item");
            return;
        }
        
        if (!isFileExist && message.status == MessageDeliverySuccess){ //Message received. But download failed. So re-download document
            ////////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
            //DDLogInfo(@"\n%@ %@ 00030\n",THIS_METHOD,THIS_FILE);
            [self handleOutgoingMessage:MessageTypeDocument param:message document:nil];
        }
        else{
            //DDLogInfo(@"\n%@ %@ 00031\n",THIS_METHOD,THIS_FILE);
            //DDLogError(@"%@ %@ 6 %d",THIS_METHOD,THIS_FILE,shouldEnableRetry);
            if (self.roomInfo.roomProperty.isOffline && message.status == MessageDeliveryFailed){
                //DDLogError(@"######### New Chat Room - Send Message ##########");
                id document = [self.chatModel getDocument:message.messageBody.body roomID:message.roomIDStr];
                [self handleOutgoingMessage:MessageTypeDocument param:message document:document];
                message.status = MessageDeliveryPending;
                [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
                //Update messageStatus for CMOMessage in sortedMessage array
                [self replaceObjectInSortedArrayWithMessage:message];
            }
            else if (message.status == MessageDeliveryFailed && [self.roomModel isJoinedInRoom:message.roomIDStr] && shouldEnableRetry){
                DDLogInfo(@"Message status is in Failed state");
                id document = [self.chatModel getDocument:message.messageBody.body roomID:message.roomIDStr];
                [self handleOutgoingMessage:MessageTypeDocument param:message document:document];
                message.status = MessageDeliveryPending;
                [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
                //Update messageStatus for CMOMessage in sortedMessage array
                [self replaceObjectInSortedArrayWithMessage:message];
            }
            else{
                //DDLogInfo(@"\n%@ %@ 00032\n",THIS_METHOD,THIS_FILE);
                DDLogError(@"You might have deleted the document manually.");
                //////DDLogInfo(@"%@ %@ 8",THIS_METHOD,THIS_FILE);
            }
        }
    }
    //////DDLogInfo(@"%@ %@ 99",THIS_METHOD,THIS_FILE);
}


- (void)chatRoomCreationFailureAlert{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"Unable to create the chat. Please try again" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okButton = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
        //[self.navigationController popViewControllerAnimated:true];
    }];
    [alertController addAction:okButton];
    [self presentViewController:alertController animated:YES completion:nil];
}


- (BOOL)isParticipantAddedToRoom:(NSMutableDictionary *)participant{
    
     //CMORosterPresentation *rosterModel = [_coreComponents rosterPresentation];
    NSArray *contacts = [participant objectForKey:MACROS_CONTACTS];//[rosterModel eligibleParticipants:participant sent:true];
     NSArray *groups = [participant objectForKey:MACROS_GROUPS];
    
    return contacts.count > 0 || groups.count > 0;
}


- (void)showParticipantRequiredAlert{
    [self displayAlertWithTitle:PARTICIPANT_REQUIRED_MSG];
}

- (void)showMaxCharExceededAlert{
    if ([UIAlertController class])
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:MAX_CHAR_EXCEEDED_MSG preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
}

#pragma mark JSQMessage Text View Delegate Methods

- (void)resignJSQTextView{
    [self.inputToolbar.contentView.textView resignFirstResponder];
}

- (void)textViewDidBeginEditing:(UITextView *)textView{
    [super textViewDidBeginEditing:textView];
    if (_chatType == ChatTypeExistingChat){
        _chatTypeStatus = ChatTypeComposing;
        [self.chatModel sendChatStatus:self.receiverId status:ChatTypeComposing];
        [self schedulNotification];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    [super textViewDidEndEditing:textView];
     if (_chatType == ChatTypeExistingChat){
         _chatTypeStatus = ChatTypePaused;
         [self.chatModel sendChatStatus:self.receiverId status:ChatTypePaused];
     }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if(([[textView text] length] - range.length + text.length) > MAX_ALLOWED_CHARS_TEXT_MESSAGE) {
        [self showMaxCharExceededAlert];
        return NO;
    }
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView{
    [super textViewDidChange:textView];
     if (_chatType == ChatTypeExistingChat){
         if (_chatTypeStatus == ChatTypePaused){
             _chatTypeStatus = ChatTypeComposing;
             [self.chatModel sendChatStatus:self.receiverId status:ChatTypeComposing];
         }
         [self schedulNotification];
     }
}

//This function will send the user typing status to receiver.
- (void)schedulNotification{
    if (scheduleChatNotification){
        [scheduleChatNotification invalidate];
        scheduleChatNotification = nil;
    }
    
    scheduleChatNotification = [NSTimer scheduledTimerWithTimeInterval:5.0
                                                                target:self
                                                              selector:@selector(sendChatStatus:)
                                                              userInfo:nil
                                                               repeats:NO];
}

- (void)sendChatStatus:(id)sender{
     if (_chatType == ChatTypeExistingChat){
         [self.chatModel sendChatStatus:self.receiverId status:ChatTypePaused];
         _chatTypeStatus = ChatTypePaused;
     }
}


#pragma mark JSQMediaData Delegate Method

- (NSAttributedString *)collectionView:(JSQMessagesCollectionView *)collectionView attributedTextForCellTopLabelAtIndexPath:(NSIndexPath *)indexPath
{
    
    CMOMessage *message = sortedMessages[indexPath.item];
    
    if (indexPath.item == 0) {
        return [[JSQMessagesTimestampFormatter sharedFormatter] attributedTimestampForDate:message.date];
    }
    
    if (indexPath.item - 1 >= 0) {
        CMOMessage *previousMessage = [sortedMessages objectAtIndex:indexPath.item - 1];
        
        if (![self isDateOne:message.date sameAsDateTwo:previousMessage.date]) {
            return [[JSQMessagesTimestampFormatter sharedFormatter] attributedTimestampForDate:message.date];
        }
    }
    
    return nil;
}

- (CGFloat)collectionView:(JSQMessagesCollectionView *)collectionView
                   layout:(JSQMessagesCollectionViewFlowLayout *)collectionViewLayout heightForCellTopLabelAtIndexPath:(NSIndexPath *)indexPath
{
     if (indexPath.item == 0) {
         return 30;
     }
     
     if (indexPath.item - 1 >= 0) {
         CMOMessage *previousMessage = [sortedMessages objectAtIndex:indexPath.item - 1];
         CMOMessage *message = [sortedMessages objectAtIndex:indexPath.item];
         
         if (![self isDateOne:message.date sameAsDateTwo:previousMessage.date]) {
             return 30;
         }
     }
     
     return 0.0f;
    
}

#pragma mark JSQMessageViewController Delegate Methods

- (id<JSQMessageData>)collectionView:(JSQMessagesCollectionView *)collectionView messageDataForItemAtIndexPath:(NSIndexPath *)indexPath{
    CMOMessage *item = sortedMessages[indexPath.item];
    
    if (item.isMediaMessage){
        JSQMediaItem *mediaItem = (JSQMediaItem *)item.media;
        [mediaItem setAppliesMediaViewMaskAsOutgoing:[item.senderId isEqualToString:self.senderId]];
    
        DocumentType docType = [CMOUtils documentType:item.messageBody.body];
        
        NSString *filePath = [_chatModel getFilePath:item.messageBody.body roomId:item.roomIDStr];
        BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:filePath]; //[CMOUtils isFileExistAtPath:filePath];
        switch (docType) {
            case DocumentTypeImage:
            {
                CMOPhotoMediaItem *photoItem = (CMOPhotoMediaItem *)item.media;
                photoItem.status = item.status;
                photoItem.image = [UIImage imageWithData:isFileExist ? [_chatModel getDocument:item.messageBody.body roomID:self.receiverId] : nil]; //implement status mechanism in `CMOPhotoMediaItem`. Retry will be based on below condition.
            }
                break;
            case DocumentTypeAudio:
            {
                CMOAudioMediaItem *audioItem = (CMOAudioMediaItem *)item.media;
                audioItem.status = item.status;
                [audioItem setAudioData:isFileExist ? [_chatModel getDocument:item.messageBody.body roomID:self.receiverId] : nil path:[NSURL fileURLWithPath:filePath]];
                //implement status mechanism in `CMOAudioMediaItem`. Retry will be based on below condition.
            
            }
                break;
            case DocumentTypeVideo:
            {
                CMOVideoMediaItem *videoItem = (CMOVideoMediaItem *)item.media;
                videoItem.status = item.status;
                [videoItem setVidioUrl:isFileExist ? [NSURL fileURLWithPath:filePath] : nil];
//                [videoItem setFileURL:isFileExist ? [NSURL fileURLWithPath:filePath] : nil];//implement status mechanism in `CMOVideoMediaItem`. Retry will be based on below condition.
//                [videoItem setIsReadyToPlay:isFileExist];
            }
                break;
            case DocumentTypeMedia:
            {
                CMODocumentItem *docItem = (CMODocumentItem *)item.media;
                docItem.status = item.status;
                [docItem setDocumentPath:isFileExist ? [NSURL fileURLWithPath:filePath] : nil fileName:item.messageBody.fileName];
                //docItem.docUrl = isFileExist ? [NSURL fileURLWithPath:filePath] : nil;//implement status mechanism in `CMODocumentItem`. Retry will be based on below condition.
            }
                break;
            default:
                break;
        }
    }
    return item;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return sortedMessages.count;
}

- (id<JSQMessageBubbleImageDataSource>)collectionView:(JSQMessagesCollectionView *)collectionView messageBubbleImageDataForItemAtIndexPath:(NSIndexPath *)indexPath{
    CMOMessage *message = sortedMessages[indexPath.item];//messageSet.allValues[indexPath.item];
    
    if ([message.senderId isEqualToString:self.senderId]){
        return outgoingBubbleImageView;
    }
    else{
        return incomingBubbleImageView;
    }
}


- (UICollectionViewCell *)collectionView:(JSQMessagesCollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    JSQMessagesCollectionViewCell *cell = (JSQMessagesCollectionViewCell *)[super collectionView:collectionView cellForItemAtIndexPath:indexPath];

    CMOMessage *cmoMessage = sortedMessages[indexPath.item];
    if (isConnected){
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[self isUserOnline:cmoMessage] ? @"Status_Online" : @"Status_Offline"]];
        if (![self isStatusAlreadyAddedForCell:cell.avatarContainerView]){
            UIImageView *imageView = [[UIImageView alloc]initWithImage:image];//Status_Online
            CGRect imageViewFrame = [imageView frame];
            imageViewFrame.origin.x = 18;
            imageViewFrame.origin.y = 20;
            imageViewFrame.size.width = 12;
            imageViewFrame.size.height = 12;
            imageView.frame = imageViewFrame;
            
            imageView.tag = 100;
            [cell.avatarContainerView addSubview:imageView];
        }
        else{
            UIImageView *imageView = (UIImageView *)[cell.avatarContainerView viewWithTag:100];
            imageView.image = image;
        }
    }
    else{ //If user is disconnected from internet or if he becomes offline, then update all the status of users as offline
        UIImage *image = [UIImage imageNamed:@"Status_Offline.png"];
        UIImageView *imageView = (UIImageView *)[cell.avatarContainerView viewWithTag:100];
        imageView.image = image;
    }
    NSDateFormatter *timeFormatter = [[NSDateFormatter alloc]init];
    timeFormatter.dateFormat = @"hh:mm a";
    
    if ([cmoMessage.senderId isEqualToString:self.senderId]){
        cell.cellBottomLabel.text = [NSString stringWithFormat:@"%@    %@",[timeFormatter stringFromDate: cmoMessage.date], [self getStatusString:cmoMessage.status]];
    }
    else{
        cell.cellBottomLabel.text = [NSString stringWithFormat:@"%@    %@", [self getStatusString:cmoMessage.status], [timeFormatter stringFromDate: cmoMessage.date]];
    }

    
    return cell;
}


- (BOOL)isUserOnline:(CMOMessage *)message{
    BOOL isOnline = false;
    
    NSMutableDictionary *userPresenceDictionary  = [((CMOTabBarController *)self.tabBarController) getUserPresenceDictonary];
    
    if ([userPresenceDictionary valueForKey:[message.userName lowercaseString]]){
        CMOUserPresence *presence = [userPresenceDictionary valueForKey:[message.userName lowercaseString]];
        if ([presence.from isEqualToString:self.senderId]){
            isOnline = true;
        }
        else {
            if ([presence.type isEqualToString:XMPP_PRESENCE_UNAVAILABLE]){
                isOnline = false;
            }
            else if (!presence){
                isOnline = false;
            }
            else{
                isOnline = true;
            }
        }
    }
    return isOnline;
}


- (BOOL)isStatusAlreadyAddedForCell:(UIView *)avatarView{
    //If avatar content view contains status online/offline view.
    if (avatarView.subviews.count > 1){
        return true;
    }
    return false;
}


- (NSString *)getStatusString:(MessageDeliveryStatus)messageStatus{
    NSString *messageStatusString = MSGSTATUS_PENDING;
    switch (messageStatus) {
        case MessageDeliverySuccess:
            messageStatusString = MSGSTATUS_SENT;
            break;
        case MessageDeliveryFailed:
            messageStatusString = MSGSTATUS_Failed;
            break;
        case MessageDeliveryPending:
            messageStatusString = MSGSTATUS_PENDING;
            break;
        default:
            messageStatusString = MSGSTATUS_PENDING;
            break;
    }
    return messageStatusString;
}

//Sender name of the message
- (NSAttributedString *)collectionView:(JSQMessagesCollectionView *)collectionView attributedTextForMessageBubbleTopLabelAtIndexPath:(NSIndexPath *)indexPath
{
    CMOMessage *message = sortedMessages[indexPath.item];
    
    /**
     *  Don't specify attributes to use the defaults.
     */
    
    UIFont *font = [UIFont fontWithName:@"Helvetica-BoldItalic" size:14];
    UIColor *fontColor = [UIColor redColor];
    NSDictionary *attrsDictionary = [NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName,fontColor,NSForegroundColorAttributeName, nil];
    
    //[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:font,fontColor, nil] forKeys:[NSArray arrayWithObjects:NSFontAttributeName,NSForegroundColorAttributeName,nil]];
    
    //DDLogError(@"An error occured");
    if ([message.userName length] == 0){
        DDLogError(@"\n\n\n\n *********** USERNAME IS EMPTY and BODY IS %@ *************\n\n\n\n",message.messageBody.body);
    }
    
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:message.senderDisplayName == nil ? message.userName : message.senderDisplayName attributes:attrsDictionary];
    [attrString addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0,attrString.length)];

    return attrString;
}



#pragma mark JSQMessagesCollectionViewDelegateFlowLayout delegate method - Tap Message
- (CGFloat)collectionView:(JSQMessagesCollectionView *)collectionView
                   layout:(JSQMessagesCollectionViewFlowLayout *)collectionViewLayout heightForCellBottomLabelAtIndexPath:(NSIndexPath *)indexPath{
    return 20.0f;
}


//For date
//- (CGFloat)collectionView:(JSQMessagesCollectionView *)collectionView
//                   layout:(JSQMessagesCollectionViewFlowLayout *)collectionViewLayout heightForCellTopLabelAtIndexPath:(NSIndexPath *)indexPath{
//    return 20.0f;
//}

//For sender name of the message

- (CGFloat)collectionView:(JSQMessagesCollectionView *)collectionView
                   layout:(JSQMessagesCollectionViewFlowLayout *)collectionViewLayout heightForMessageBubbleTopLabelAtIndexPath:(NSIndexPath *)indexPath
{
    return 20.0f;
}

//Need to check
- (void)collectionView:(JSQMessagesCollectionView *)collectionView didTapMessageBubbleAtIndexPath:(NSIndexPath *)indexPath{
    
    CMOMessage *message = sortedMessages[indexPath.item];
    if (message.isMediaMessage){
        //DDLogInfo(@"Show Media in Full Screen if available, else do nothing");
        DocumentType docType = [CMOUtils documentType:message.messageBody.body];
        if (docType == DocumentTypeUnknown)return;
        if (docType == DocumentTypeImage){
            [self showImageFullScreenWithObject:message];
        }
        else{
            [self showDocumentFullScreenWithObject:message];
        }
    }
    else{
        if (![CMOUtils isNetworkAvailable]){
            [self displayAlertWithTitle:NETWORK_ERROR];
            return;
        }
        
        if (message.status == MessageDeliveryFailed){
            //Update Message Date
            CMOChatPresentation *chatPresentation = [_coreComponents chatPresentation];
            message = [chatPresentation getUpdatedDateMessage:message delegate:self];
            
            sortedMessages[indexPath.item]  = message;
            
            message.status = MessageDeliveryPending;
            [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
            [self handleOutgoingMessage:MessageTypeText param:message document:nil];
        }
    }
}


- (id<JSQMessageAvatarImageDataSource>)collectionView:(JSQMessagesCollectionView *)collectionView avatarImageDataForItemAtIndexPath:(NSIndexPath *)indexPath{
    CMOMessage *message = sortedMessages[indexPath.row];
    CGFloat diameter = 100.0f;
    //vCardArray
    if (message.status == MessageDeliveryFailed){
        return errorProfileAvatarImage;
    }
    
    if ([userAvatarImages objectForKey:message.userName]) {
        return [userAvatarImages objectForKey:message.userName];
    } else {
        CMOUser *user = [userService fetchUservCard:message.userName];
        if (user.userAvatar){
            JSQMessagesAvatarImage *usrAvatarImage= [JSQMessagesAvatarImageFactory avatarImageWithImage:user.userAvatar diameter:diameter];
            [userAvatarImages setObject:usrAvatarImage forKey:message.userName];
            return usrAvatarImage;
        }
    }
    
    return defaultProfileAvatarImage;
}

#pragma mark Text Message Functionality

- (void)didPressSendButton:(UIButton *)button
           withMessageText:(NSString *)text
                  senderId:(NSString *)senderId
         senderDisplayName:(NSString *)senderDisplayName
                      date:(NSDate *)date{

    //////DDLogInfo(@"%@ 1",THIS_METHOD);
    if (![CMOUtils isNetworkAvailable]){
        [self displayAlertWithTitle:NETWORK_ERROR];
        //////DDLogInfo(@"%@ 2",THIS_METHOD);
        return;
    }
    
    if (![self isParticipantAddedToRoom:self.partcipantsList]){
        [self displayAlertWithTitle:PARTICIPANT_REQUIRED_MSG];
        //////DDLogInfo(@"%@ 3",THIS_METHOD);
        return;
    }
    
    CMOMessageParam *param = [self constructMessageParam:text media:nil type:DocumentTypeUnknown fileName:nil roomId:self.receiverId date:date show:false smsSent:false];
    CMOMessage *message = [self.chatModel constructMessage:param target:self messagesDict:nil];
    [self addMessagesToChatScreen:message];//This should be called here
    [self handleOutgoingMessage:MessageTypeText param:message document:nil];
    //////DDLogInfo(@"%@ 99",THIS_METHOD);
}




#pragma mark  Did Accessor Button - Image Picker
- (void)didPressAccessoryButton:(UIButton *)sender
{
    if (![CMOUtils isNetworkAvailable]){
        [self displayAlertWithTitle:NETWORK_ERROR];
        return;
    }
    
    if (![self isParticipantAddedToRoom:self.partcipantsList]){
        [self displayAlertWithTitle:PARTICIPANT_REQUIRED_MSG];
        return;
    }
    
    if (_chatType == ChatTypeNewChat){
        //Check for NON App users if any.
        if ([[[_coreComponents rosterPresentation]hasSMSUsers:self.partcipantsList] count] > 0){
            [self displayAlertWithTitle:MMS_NOT_SUPPORTED_MSG];
            return;
        }
    }
    [self showAttachmentOptions];
}


#pragma mark Common Alert

- (void)displayAlertWithTitle:(NSString *)title{
    if ([UIAlertController class]){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@""
                                    message:title
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* okButton = [UIAlertAction
                                   actionWithTitle:@"OK"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action)
                                   {
                                       
                                   }];
        
        [alert addAction:okButton];
        [self presentViewController:alert animated:YES completion:nil];
    }
}



#pragma mark  Did Receive Message
- (void)didReceiveMessage:(NSNotification *)notification{
    XMPPRoomMessageCoreDataStorageObject *roommessage = notification.userInfo[@"message"];
    //DDLogVerbose(@"DAMAC: 1 %@ %@ %@ %d",THIS_METHOD,THIS_FILE,roommessage.message,roommessage.isFromMe);
    //DDLogVerbose(@"DAMAC 1-2 %@ %@",roommessage.roomJID,self.receiverId);
    if (roommessage.isFromMe){ //It is an Outgoing message which is already saved in the db.
        //DDLogVerbose(@"DAMAC: 2 %@ %@ %@ %@",THIS_METHOD,THIS_FILE,roommessage.roomJID,self.receiverId);
        return;
    }
    
    //This condition is added to avoid rendering messages of different rooms. Suppose in iPad, if you are in Room 1 and switched to Room 2. Room 1 message may have rendered in the Room 2 whent there is new incoming message to Room 1. To Avoid that, this condition is added.
    if (![[roommessage.roomJID user]isEqualToString:self.receiverId]){
        return;
    }
    //DDLogVerbose(@"DAMAC: 3 %@ %@",THIS_METHOD,THIS_FILE);
    //#warning Check SMS Sent case
    CMOMessageParam *param = [self.chatModel constructMessageParamFromXMPP:roommessage];
    CMOMessage *message = [self.chatModel constructMessage:param target:self messagesDict:nil];
    //DDLogInfo(@"Message is %@ and Date is %@",message.messageBody.body,message.messageBody.messageDate);
    
    /* Why this condition?
        Scenario: Suppose, sender has sent a message, but before receving the acknowledgement (see `didReceiveMessage` in XMPPManager), network goes off. But the actual message is received by the receiver. Since network interpution happens for the sender, the message will be displayed as failed state in sender screen, but the message is actually sent. Because of this, we are storing the message in offline table. Now when network comes again, sender will get the message that has been sent earlier. There will be a occurence of duplicate message. One which is already saved in the offline table & other which is received when the sender comes online. So when we receive the new message, we'll check whether that message is already avaialable in Offline table. If yes, then remove that message in Offline table & `SortedMessages` array.
     */
    
    if ([self.chatModel isOfflineMessage:message]){
        //DDLogVerbose(@"DAMAC: 4 %@ %@",THIS_METHOD,THIS_FILE);
         NSArray *messages = [sortedMessages filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"messageBody.messageDateString == %@",message.messageBody.messageDateString]];
        CMOMessage *sMessage = [messages lastObject];
        if (sMessage){
            //DDLogVerbose(@"DAMAC: 5 %@ %@",THIS_METHOD,THIS_FILE);
            if ([sortedMessages indexOfObject:sMessage] != NSNotFound){
                NSInteger messageToDeleteIndex = [sortedMessages indexOfObject:sMessage];
                [sortedMessages removeObjectAtIndex:messageToDeleteIndex];
            }
            //DDLogVerbose(@"DAMAC: 6 %@ %@",THIS_METHOD,THIS_FILE);
            [self.chatModel removeOfflineMessage:message];
        }
    }
    
    //BOOL shouldVisible = [message.messageBody.shouldVisible boolValue];
    
    CMOChatContainerViewController *chatVc = (CMOChatContainerViewController *)self.parentViewController;
    
    
    //1. Check if user is a chairman, (can initiate or not)
    //2. If user is a chairman & hide chat is selected, then add the incoming message to `allMessages` array.
    //3. Reload Data.
    //4. If user is a chairman & show chat is selected, then add the incoming message to `allMessages` & `sortedMessages` array.
    
    //5. Reload Data
    
    //6. If user is not a chairman, then step 4 will be applicable (add incoming message to `allMessages` & `sortedMessages` array).
    // Same case applicable for image & other documents.
    
   
    if([message.messageBody.mediaItem integerValue] == 1 || [message.messageBody.mediaType integerValue] == 1) //Message available
    {
        if ([self.chatModel getDocument:message.messageBody.body roomID:self.receiverId]){
            
            if ([self.chatModel shouldProvideHideShowOption]){
                [self shouldAddMessageToChatLoop:message toAdd:false];
            }
            else{
                [self shouldAddMessageToChatLoop:message toAdd:true];
            }
            return; //You got the image from local folder. so don't go further (download). This will happen when you get history message which are already available in db.
        }
        //CMOMessage *msgData = [self messageForImage:message document:nil type:[CMOUtils documentType:message.messageBody.body]];
        
        //CMOMessage *msgData = [self.chatModel constructMessage:<#(CMOMessageParam *)#> target:<#(id)#>]
        //loading indicator
        
        if ([self.chatModel shouldProvideHideShowOption]){
            [self shouldAddMessageToChatLoop:message toAdd:false];
        }
        else{
            [self shouldAddMessageToChatLoop:message toAdd:true];
        }
#warning Need to verify the status - What if the document download failed.
        message.status = MessageDeliverySuccess;
        [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
        
        [self downloadDocument:message OnProgress:^(id progress) {
            //NSProgress *prog = progress;
            //////DDLogInfo(@"Progress ========= (%f)",prog.fractionCompleted*100);
            //[(CMOPhotoMediaItem *)message.media setProgress:prog.fractionCompleted * 100];
            
        } onSuccess:^(id result) {
            //////DDLogInfo(@"Download Success %@",THIS_METHOD);
        } onFailure:^(NSError *error) {
            DDLogError(@"Download Failed %@", THIS_METHOD);
        }];
        
    }
    else
    {
        if ([self.chatModel shouldProvideHideShowOption]){
            [self shouldAddMessageToChatLoop:message toAdd:false];
        }
        else{
            //Add always for participants
            [self shouldAddMessageToChatLoop:message toAdd:true];
        }
    }
    
    //[self scheduldedSortMessages];
    //[self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
    //Scroll to  Bottom
    NSInteger noOfItems = [self.collectionView numberOfItemsInSection:0];
    if (sortedMessages.count-1 <= noOfItems){
        [self.collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:sortedMessages.count-1 inSection:0] atScrollPosition:UICollectionViewScrollPositionBottom animated:true];
    }
}


- (void)shouldAddMessageToChatLoop:(CMOMessage *)message toAdd:(BOOL)add{
    BOOL shouldVisible = [message.messageBody.shouldVisible boolValue];
    if (![self isMessageAlreadyLoaded:message]){
        //If `add` true, (i.e) Chairman has selected the show option. Add all incoming messages. This case will be applicable for participants (i.e)participants should able to add messages.
        if (add){
            [sortedMessages addObject:message];
        }
        else{//If `add` false, Only summary should be added
            if (shouldVisible){
               [sortedMessages addObject:message];
            }
        }
        if (allMessages.count > 0){
             NSArray *messages = [allMessages filteredArrayUsingPredicate:
                                  [NSPredicate predicateWithFormat:
                                   @"messageBody.messageDate == %@",
                                   message.messageBody.messageDateString]];
            
            if (messages.count > 0){//There will be only one message, if it is available
                [allMessages addObject:[messages lastObject]];
            }
        }
    }
    [self.collectionView reloadData];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    //DDLogInfo(@"didReceiveMemoryWarning %@ %@",THIS_METHOD,THIS_FILE);
}


#pragma mark Action sheet
- (void)showAttachmentOptions{
    UIAlertController* alert = [UIAlertController
                                alertControllerWithTitle:nil      //  Must be "nil", otherwise a blank title area will appear above our two buttons
                                message:nil
                                preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* cancelButton = [UIAlertAction
                              actionWithTitle:@"Cancel"
                              style:UIAlertActionStyleCancel
                              handler:^(UIAlertAction * action)
                              {
                                  //  UIAlertController will automatically dismiss the view
                              }];
    
    UIAlertAction* cameraButton = [UIAlertAction
                              actionWithTitle:@"Take photo"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  //  The user tapped on "Take a photo"
                                  if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
                                  {
                                      //Set rool reload no
                                      if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
                                      {
                                          appDelegate.isReloadSplitView = NO;
                                          appDelegate.isConversationReload = NO;
                                      }
                                      imagePickerController= [[UIImagePickerController alloc] init];
                                      imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                                      imagePickerController.delegate = self;
                                      [self presentViewController:imagePickerController animated:YES completion:^{}];
                                  }
                              }];
    
    UIAlertAction* photoLibraryButton = [UIAlertAction
                              actionWithTitle:@"Choose Existing"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  //  The user tapped on "Choose existing"
                                  if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
                                  {
                                      appDelegate.isPortrait = YES;
                                      imagePickerController = [[UIImagePickerController alloc] init];
                                      imagePickerController.allowsEditing = YES;
                                      imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                      imagePickerController.delegate = self;
//                                      imagePickerController.mediaTypes = [NSArray arrayWithObjects:(NSString *)kUTTypeVideo,(NSString *)kUTTypeImage,(NSString *)kUTTypeMovie,nil];//(NSString *)kUTTypeMovie,
                                      imagePickerController.mediaTypes = [NSArray arrayWithObjects:(NSString *)kUTTypeImage,nil];
                                      [self presentViewController:imagePickerController animated:YES completion:^{}];
                                }
                              }];
    
    UIAlertAction *iCloudButton = [UIAlertAction actionWithTitle:@"iCloud" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
//        NSArray *types = @[(NSString*)kUTTypeImage,(NSString*)kUTTypeSpreadsheet,(NSString*)kUTTypePresentation,(NSString*)kUTTypeDatabase,(NSString*)kUTTypeFolder,(NSString*)kUTTypeZipArchive,(NSString*)kUTTypeVideo,(NSString*)kUTTypePDF];
        NSArray *types = @[(NSString*)kUTTypeImage,(NSString*)kUTTypeZipArchive,(NSString*)kUTTypeSpreadsheet,(NSString*)kUTTypePresentation,(NSString*)kUTTypePDF];//,(NSString*)kUTTypeVideo,(NSString *)kUTTypeMovie
        
//        NSArray *types = @[(NSString*)kUTTypeImage];
        
        
        //Init the DcoumentViewController With the Type Document Like Image, Text File etc.
        UIDocumentPickerViewController *documentPicker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:types inMode:UIDocumentPickerModeImport];
        
        //Call Delegate
        documentPicker.delegate = self;
        
        //set the Document Open Style and Present the Controller
        documentPicker.modalPresentationStyle = UIModalPresentationPageSheet;
        [self presentViewController:documentPicker animated:YES completion:nil];
        
    }];
    
    
    UIAlertAction *recordAudio = [UIAlertAction actionWithTitle:@"Record Audio" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        PermissionBlock permissionBlock = ^(BOOL granted) {
            if (granted)
            {
                //////DDLogInfo(@"Record permission granted");
                [self doStartRecording];
            }
            else
            {
                //////DDLogInfo(@"Record permission denied");
                // display no microphne access warning alter in main thread
                dispatch_async(dispatch_get_main_queue(), ^{
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Microphone Access Denied" message:@"You must allow microphone access in Settings" preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction *cancelButton = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                   {
                                                       //Discard alert
                                                   }];
                    [alertController addAction:cancelButton];
                    [self presentViewController:alertController animated:YES completion:nil];
                });
                
            }
        };
        
        
        if([[AVAudioSession sharedInstance] respondsToSelector:@selector(requestRecordPermission:)])
        {
            [[AVAudioSession sharedInstance] performSelector:@selector(requestRecordPermission:)
                                                  withObject:permissionBlock];
        }
        else
        {
            [self doStartRecording];
        }
        
    }];
    
    [alert addAction:cancelButton];
    [alert addAction:cameraButton];
    [alert addAction:photoLibraryButton];
    [alert addAction:iCloudButton];
    [alert addAction:recordAudio];
    
    //Action sheet configuration for iPad
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        alert.popoverPresentationController.sourceView = self.view;
        alert.popoverPresentationController.sourceRect = CGRectMake(0, [UIScreen mainScreen].bounds.size.height - 80, 30, 30);
        [alert.popoverPresentationController setPermittedArrowDirections:UIPopoverArrowDirectionDown];
    }
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void) doStartRecording {
    if (!recorder) {
        recorder = [[CMOAudioRecorder alloc] init];
        recorder.recorderDelegate = self;
    }
    if([recorder startRecording]) {
        recordingCancelled = false;
        
        UIAlertController* recordAlert = [UIAlertController
                                          alertControllerWithTitle:nil      //  Must be "nil", otherwise a blank title area will appear above our two buttons
                                          message:nil
                                          preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction* recordCancelButton = [UIAlertAction
                                             actionWithTitle:@"Cancel"
                                             style:UIAlertActionStyleDefault
                                             handler:^(UIAlertAction * action)
                                             {
                                                 recordingCancelled = true;
                                                 [recorder stopRecording];
                                                 //  UIAlertController will automatically dismiss the view
                                             }];
        
        UIAlertAction* recordDoneButton = [UIAlertAction
                                           actionWithTitle:@"Stop"
                                           style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction * action)
                                           {
                                               //  UIAlertController will automatically dismiss the view
                                               recordingCancelled = false;
                                               [recorder stopRecording];
                                           }];
        
        [recordAlert addAction:recordDoneButton];
        [recordAlert addAction:recordCancelButton];
        
        //Action sheet configuration for iPad
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        {
            //this will be called when tapped outside popup.Also button will not apear in menu
            [recordAlert addAction:[UIAlertAction actionWithTitle:@"Other" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                recordingCancelled = true;
                [recorder stopRecording];
            }]];
            
            recordAlert.popoverPresentationController.sourceView = self.view;
            recordAlert.popoverPresentationController.sourceRect = CGRectMake(0, [UIScreen mainScreen].bounds.size.height - 80, 60, 30);
            [recordAlert.popoverPresentationController setPermittedArrowDirections:UIPopoverArrowDirectionDown];
        }
        
        [self presentViewController:recordAlert animated:YES completion:nil];
    }
    
}


#pragma mark - Audio Recorder delegate methods
- (void)audioRecordingFinished:(NSURL *)recordedUrl {
    //////DDLogInfo(@"ChatViewController audioRecordingFinished");
    //////DDLogInfo(@"URL : %@",recordedUrl);
    
     if (recordingCancelled) {
        //canceled . Do nothing
        return;
    }
    appDelegate.isPortrait = NO;
    if (![CMOUtils isNetworkAvailable]) {
        [self showErrorAlertWithMessage:NETWORK_ERROR];
        // return;
    }
   
    /*
     NSURL *mediaURL = [mediaInfo objectForKey:UIImagePickerControllerMediaURL];
     media = [NSData dataWithContentsOfURL:mediaURL];
     
     CFStringRef fileExtension = (__bridge CFStringRef) [mediaURL pathExtension];
     NSString *fileExt = (__bridge NSString *)fileExtension;
     mediaName = [NSString stringWithFormat:@"%@_%@.%@",self.senderId,[[CMOUtils getUniqueString] lowercaseString],fileExt == nil ? @"mov" : fileExt];
     */
    
    NSData *mediaData = [NSData dataWithContentsOfURL:recordedUrl];
    CFStringRef fileExtension = (__bridge CFStringRef) [recordedUrl pathExtension];
    NSString *fileExt = (__bridge NSString *)fileExtension;
    NSString *mediaName = [NSString stringWithFormat:@"%@_%@.%@",self.senderId,[[CMOUtils getUniqueString] lowercaseString],fileExt == nil ? @"m4u" : fileExt];
    
    CMOMessageParam *param = [self constructMessageParam:mediaName media:mediaData type:DocumentTypeAudio fileName:nil roomId:self.receiverId date:[NSDate date] show:false smsSent:false];
    CMOMessage *message = [self.chatModel constructMessage:param target:self messagesDict:nil];
    [self addMessagesToChatScreen:message];//This should be called here
    [self handleOutgoingMessage:MessageTypeDocument param:message document:param.media];
    
}

- (void) recordingStarted {
    //////DDLogInfo(@"ChatViewController recordingStarted");
}

- (void)stopRecording:(id)sender{
    //////DDLogInfo(@"ChatViewController stopRecording");
    [recorder stopRecording];
}

#pragma mark - Document Picker delegate methods

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentAtURL:(NSURL *)url {
    //////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (controller.documentPickerMode == UIDocumentPickerModeImport)
    {
        //////DDLogInfo(@"Imported data url %@",url);
        //////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        CMOMessageParam *param = [self pickerController:controller info:nil documentURL:url];
        CMOMessage *message = [self.chatModel constructMessage:param target:self messagesDict:nil];
        [self addMessagesToChatScreen:message];//This should be called here
        [self handleOutgoingMessage:MessageTypeDocument param:message document:param.media];
    }
}

#pragma mark - Image Picker Controller delegate methods

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    //////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    appDelegate.isPortrait = NO;
    if (![CMOUtils isNetworkAvailable]) {
        //////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        [picker dismissViewControllerAnimated:YES completion:nil];
        [self showErrorAlertWithMessage:NETWORK_ERROR];
       // return;
    }
    isPickerDismissed = true;
    
    CMOMessageParam *param = [self pickerController:picker info:info documentURL:nil];
    CMOMessage *message = [self.chatModel constructMessage:param target:self messagesDict:nil];
    [self addMessagesToChatScreen:message];//This should be called here
    [self handleOutgoingMessage:MessageTypeDocument param:message document:param.media];
    [picker dismissViewControllerAnimated:YES completion:nil];
}



- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    isPickerDismissed = true;
    documentProcessed = false;
    appDelegate.isPortrait = NO;
    [picker dismissViewControllerAnimated:YES completion:NULL];
}


#pragma mark Document/Image Picker Controller

- (CMOMessageParam *)pickerController:(id)controller info:(NSDictionary *)mediaInfo documentURL:(NSURL *)URL{
    
    //////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    BOOL isDocumentPicker = [controller isKindOfClass:[UIDocumentPickerViewController class]];
    BOOL isiPad = [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad;
    DocumentType documentType = DocumentTypeUnknown;
    UIImagePickerController *imagePicker = nil;
    UIDocumentPickerViewController *documentPicker = nil;
    id media = nil;
    NSString *mediaName;
    
    if (!isDocumentPicker){
        //////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        /*UIImage *image = (picker.sourceType == UIImagePickerControllerSourceTypeCamera) ? info[UIImagePickerControllerOriginalImage] :  info[UIImagePickerControllerEditedImage];
        scaledImage = [image normalizedImage:CGSizeMake(1024, 1024)];*/
        imagePicker = controller;
        //UIImagePickerControllerMediaType = "public.image";
        NSString* mediaType = [mediaInfo objectForKey:UIImagePickerControllerMediaType];
        
        documentType = (CFStringCompare((CFStringRef) mediaType,  kUTTypeImage, 0) == kCFCompareEqualTo) ? DocumentTypeImage : DocumentTypeVideo;
        
//        documentType = (imagePicker.sourceType == UIImagePickerControllerSourceTypeCamera ? DocumentTypeImage : [CMOUtils fileType:[mediaInfo objectForKey:UIImagePickerControllerMediaURL]]);
        //documentType = [CMOUtils fileType:[mediaInfo objectForKey:UIImagePickerControllerReferenceURL]];
        
    }
    else{
        //////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
        documentType = [CMOUtils documentType:[URL lastPathComponent]];
        documentPicker = controller;
    }
    
    if (documentType == DocumentTypeUnknown){
        DDLogError(@"******* Document Type is Unknown. Something is Wrong. Review Required ********");
        return nil;
    }
    
    switch (documentType) {
        case DocumentTypeImage:
        {
            UIImage *scaledImage;
            UIImage *originalImage;
           //////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
            if (!isDocumentPicker){
                //////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
                originalImage = isiPad ? mediaInfo[UIImagePickerControllerOriginalImage] :(imagePicker.sourceType == UIImagePickerControllerSourceTypeCamera) ? mediaInfo[UIImagePickerControllerOriginalImage] :  mediaInfo[UIImagePickerControllerEditedImage];
                scaledImage = [originalImage normalizedImage:CGSizeMake(originalImage.size.width * 0.75, originalImage.size.height * 0.75)];
                
                //Media Name
                CFStringRef fileExtension = (__bridge CFStringRef) [[mediaInfo objectForKey:UIImagePickerControllerReferenceURL] pathExtension];
                NSString *fileExt = (__bridge NSString *)fileExtension;
                mediaName = [NSString stringWithFormat:@"%@_%@.%@",self.senderId,[[CMOUtils getUniqueString] lowercaseString],fileExt == nil ? @"png" : fileExt];
            }
            else{
                //////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
                originalImage = [UIImage imageWithContentsOfFile:[URL path]];
                scaledImage = [originalImage normalizedImage:CGSizeMake(1024, 1024)];
                
                NSString *fileExt = [URL pathExtension];
                mediaName = [NSString stringWithFormat:@"%@_%@.%@",self.senderId,[[CMOUtils getUniqueString] lowercaseString],fileExt];
            }
            media = UIImageJPEGRepresentation(scaledImage, 0);
        }
            break;
        case DocumentTypeVideo:
        {
            if (!isDocumentPicker){
                //////DDLogInfo(@"%@ %@ 7",THIS_METHOD,THIS_FILE);
                NSURL *mediaURL = [mediaInfo objectForKey:UIImagePickerControllerMediaURL];
                NSString *tempFileName = [NSString stringWithFormat:@"tempVideo.%@",[[mediaURL lastPathComponent] pathExtension]];
                
                NSURL *tmpMediaUrl  = [[mediaURL URLByDeletingLastPathComponent] URLByAppendingPathComponent:tempFileName];
                //Need to compress video here
                [self convertVideoToLowQuailtyWithInputURL:mediaURL outputURL:tmpMediaUrl];
                media = [NSData dataWithContentsOfURL:tmpMediaUrl];
                
//                //For uncomment for testing only
//                NSData *origiData = [NSData dataWithContentsOfURL:mediaURL];
//                NSLog(@"##### ####original Size = %.2f MB",(origiData.length / pow(1024, 2)));
//                NSData *compressedData = (NSData*)media;
//                NSLog(@"##### ####compressed Size = %.2f MB",(compressedData.length / pow(1024, 2)));
                
                CFStringRef fileExtension = (__bridge CFStringRef) [tmpMediaUrl pathExtension];
                NSString *fileExt = (__bridge NSString *)fileExtension;
                mediaName = [NSString stringWithFormat:@"%@_%@.%@",self.senderId,[[CMOUtils getUniqueString] lowercaseString],fileExt == nil ? @"mov" : fileExt];
            }
            else{
                //////DDLogInfo(@"%@ %@ 8",THIS_METHOD,THIS_FILE);
                //Need to compress video here
                NSString *tempFileName = [NSString stringWithFormat:@"tempVideo.%@",[[URL lastPathComponent] pathExtension]];
                
                NSURL *tmpMediaUrl  = [[URL URLByDeletingLastPathComponent] URLByAppendingPathComponent:tempFileName];
                //Need to compress video here
                [self convertVideoToLowQuailtyWithInputURL:URL outputURL:tmpMediaUrl];
                media = [NSData dataWithContentsOfURL:tmpMediaUrl];
                
//                //For uncomment for testing only
//                NSData *origiData = [NSData dataWithContentsOfURL:URL];
//                NSLog(@"##### ####original Size = %.2f MB",(origiData.length / pow(1024, 2)));
//                NSData *compressedData = (NSData*)media;
//                NSLog(@"##### ####compressed Size = %.2f MB",(compressedData.length / pow(1024, 2)));
                
                NSString *fileExt = [tmpMediaUrl pathExtension];
                mediaName = [NSString stringWithFormat:@"%@_%@.%@",self.senderId,[[CMOUtils getUniqueString] lowercaseString],fileExt];
            }
        }
            break;
        case DocumentTypeAudio: //This cases are not applicable for UIImagePickerController
        case DocumentTypeMedia:
        {
            //////DDLogInfo(@"%@ %@ 9",THIS_METHOD,THIS_FILE);
            media = [NSData dataWithContentsOfURL:URL];
            NSString *fileExt = [URL pathExtension];
            mediaName = [NSString stringWithFormat:@"%@_%@.%@",self.senderId,[[CMOUtils getUniqueString] lowercaseString],fileExt];
        
        }
            break;
        default:
            break;
    }
    //This will return the MessageParam required to create room or message.
    return [self constructMessageParam:mediaName media:media type:documentType fileName:((documentType == DocumentTypeMedia) ? [URL lastPathComponent] : nil) roomId:self.receiverId date:[NSDate date] show:false smsSent:false];
}

- (void)convertVideoToLowQuailtyWithInputURL:(NSURL*)inputURL
                                   outputURL:(NSURL*)outputURL
{
    @autoreleasepool {
        [[NSFileManager defaultManager] removeItemAtURL:outputURL error:nil];
        AVURLAsset *asset = [AVURLAsset URLAssetWithURL:inputURL options:nil];
        AVAssetExportSession *exportSession = [[AVAssetExportSession alloc] initWithAsset:asset presetName:AVAssetExportPresetMediumQuality];
        exportSession.outputURL = outputURL;
        exportSession.outputFileType = AVFileTypeQuickTimeMovie;
        dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
        [exportSession exportAsynchronouslyWithCompletionHandler:^(void)
         {
             dispatch_semaphore_signal(semaphore);
             //         handler(exportSession);
         }];
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
    }
}


#pragma mark Handle Outgoing Messages
//This method will handle the outgoing message (i.e) Whether to create a room or not. Send a message etc.
- (void)handleOutgoingMessage:(MessageType)type param:(CMOMessage *)message document:(id)document{
    
    //This function should handle the condition that whether chat room is created or not and other cases. Refer Flow chart.
    
    ////////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
    //DDLogInfo(@"\n%@ %@ 00033\n",THIS_METHOD,THIS_FILE);
    switch (_chatType) {
        case ChatTypeNewChat:
            ////////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
            if (document){
                //DDLogInfo(@"\n%@ %@ 00040\n",THIS_METHOD,THIS_FILE);
                [self saveDocument:message document:document];
            }
            [self createRoomWithMessage:message participants:[self eligibleParticipants:self.partcipantsList smsSent:[message.messageBody.smsUsers length] > 0] document:document];
            break;
        case ChatTypeExistingChat:
        {
            //DDLogInfo(@"\n%@ %@ 00041\n",THIS_METHOD,THIS_FILE);
            ////////DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
            BOOL shouldCreateRoom = [self.roomModel shouldRoomToBeCreated:self.receiverId];
            if (shouldCreateRoom){
                //DDLogInfo(@"\n%@ %@ 00042\n",THIS_METHOD,THIS_FILE);
                ////////DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
                [self showHUDWithMessage:@"Creating chat..."];
                [self.roomModel retreiveChatRoom:self.receiverId onSuccess:^(id result) {
                    //DDLogInfo(@"\n%@ %@ 00043\n",THIS_METHOD,THIS_FILE);
                    ////////DDLogInfo(@"%@ %@ 7",THIS_METHOD,THIS_FILE);
                  //  #warning Check whether you're getting the correct response.
                    [self handleExistingRoomProcess:type message:message document:document];
                    [self hideHUDIndicator];
                    
                } onFailure:^(NSError *error) {
                    //DDLogInfo(@"\n%@ %@ 00047\n",THIS_METHOD,THIS_FILE);
                    ////////DDLogInfo(@"%@ %@ 8",THIS_METHOD,THIS_FILE);
                    
                    if (error.code == 404){ //Room Not available, create room
                        //[self handleNewRoomProcess:type message:message document:document];
                        ////////DDLogInfo(@"%@ %@ 9",THIS_METHOD,THIS_FILE);
                        //DDLogInfo(@"\n%@ %@ 00048\n",THIS_METHOD,THIS_FILE);
                         [self createRoomWithMessage:message participants:[self eligibleParticipants:self.partcipantsList smsSent:[message.messageBody.smsUsers length] > 0] document:document];
                    }
                    else{
                        //DDLogInfo(@"\n%@ %@ 00049\n",THIS_METHOD,THIS_FILE);
                        ////////DDLogInfo(@"%@ %@ 10",THIS_METHOD,THIS_FILE);
                       // #warning Handle Network Errors Logic
                        message.status = MessageDeliveryFailed;
                        [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
                        [self displayAlertWithTitle:SERVER_ACCESS_ERROR_MSG];
                    }
                    [self hideHUDIndicator];
                }];
            }
            else{
                //DDLogInfo(@"\n%@ %@ 00050\n",THIS_METHOD,THIS_FILE);
                [self handleExistingRoomProcess:type message:message document:document];
            }
        }
            break;
        default:
            //DDLogInfo(@"\n%@ %@ 00051\n",THIS_METHOD,THIS_FILE);
            break;
    }
    //DDLogInfo(@"\n%@ %@ 00052\n",THIS_METHOD,THIS_FILE);
}




- (void)handleExistingRoomProcess:(MessageType)type
                          message:(CMOMessage *)message
                         document:(id)document {
    //#warning Save Message Offline
    //#warning Check whether you joined or not before sending a message.
    ////////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    //[self addMessagesToChatScreen:message];
    if (type == MessageTypeText){
        //DDLogInfo(@"\n%@ %@ 00044\n",THIS_METHOD,THIS_FILE);
        //DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        NSMutableArray *roomArray = [self arrayForDict:cmoMessagesDictionary key:message.roomIDStr];
        NSArray *messages = [roomArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"messageBody.messageId == %@",message.messageBody.messageId]];
        if (messages.count == 0){
            [roomArray addObject:message];
        }
        __weak typeof(self) weakSelf = self;
        [self handleSendMessageProcess:message onSuccess:^(id result) {
            [weakSelf removeObjectFromCMOMessagesDict:message];
        } onFailure:^(NSError *error) {
            //DDLogInfo(@"\n%@ %@ 00045\n",THIS_METHOD,THIS_FILE);
            [weakSelf removeObjectFromCMOMessagesDict:message];
            DDLogError(@"Existing Chat - Send Text Message Failed %@, FILE: %@, METHOD: %@",error, THIS_FILE, THIS_METHOD);
            //DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
        }];
    }
    else{
        //DDLogInfo(@"\n%@ %@ 00046\n",THIS_METHOD,THIS_FILE);
        //DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
        //if there is no document. Download and save it to local folder.
        [self processDocumentWithMessage:message document:document];
    }
}


- (void)processDocumentWithMessage:(CMOMessage *)message
                          document:(id)document{
    
    
    DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    if (!document){
        //DDLogInfo(@"\n%@ %@ enrty 0007\n",THIS_METHOD,THIS_FILE);
        ////////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        
        [self downloadDocument:message OnProgress:^(id progress) {
           
        } onSuccess:^(id result) {
            ////////DDLogInfo(@"Download Success");
            ////////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
        } onFailure:^(NSError *error) {
            DDLogError(@"Download Failed");
            ////////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
        }];
        
    }
    else{
        //DDLogInfo(@"\n%@ %@ 0008\n",THIS_METHOD,THIS_FILE);
        //Save Document to Local Folder
        DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        if (message.upload){
            DDLogInfo(@"%@ %@ uploaded already 3",THIS_METHOD,THIS_FILE);
            //DDLogInfo(@"\n%@ %@ calling sending message after upload success  000125\n",THIS_METHOD,THIS_FILE);
            [self handleSendMessageProcess:message onSuccess:^(id result) {
                DDLogInfo(@"Existing Chat - Send Document Message Success");
               // ////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
                //DDLogInfo(@"\n%@ %@ sending message success   0009\n",THIS_METHOD,THIS_FILE);
            } onFailure:^(NSError *error) {
                DDLogError(@"Existing Chat - Send Document Message Failed %@, FILE: %@, METHOD: %@",error, THIS_FILE, THIS_METHOD);
                //DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
                //DDLogInfo(@"\n%@ %@ sending message failed 00010\n",THIS_METHOD,THIS_FILE);
            }];
            return;
        }
        
        //DDLogInfo(@"%@ %@ 6",THIS_METHOD,THIS_FILE);
        [self saveDocument:message document:document];
        
        CMOMessage *nMessage = message;
        if (message.status == MessageDeliveryFailed){
            DDLogInfo(@"Message Delivery Failed %@ %@",message.messageBody.messageId, message.messageBody.messageDateString);
            
            CMOChatPresentation *chatPresentation = [_coreComponents chatPresentation];
            nMessage = [chatPresentation getUpdatedDateMessage:message delegate:self];
            //nMessage.status = MessageDeliveryFailed;
            [self replaceObjectInSortedArrayWithMessage:nMessage];
            for (CMOMessage *msg in sortedMessages){
                DDLogInfo(@"Message Id is %@ and Date is %@",msg.messageBody.messageId, msg.messageBody.messageDateString);
            }
            [self reloadCollectionViewCellWithIdentifier:nMessage.messageBody.messageDateString];
        }
        
        NSMutableArray *roomArray = [self arrayForDict:cmoMessagesDictionary key:message.roomIDStr];
        
        NSArray *messages = [roomArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"messageBody.messageId == %@",nMessage.messageBody.messageId]];
        if (messages.count == 0){
            [roomArray addObject:nMessage];
        }
        __weak typeof(self) weakSelf = self;
        //DDLogInfo(@"\n%@ %@ start uploading document 000126\n",THIS_METHOD,THIS_FILE);
        [self uploadDocumentWithMessage:nMessage data:document OnProgress:^(id progress) {
            //DDLogInfo(@"\n%@ %@ 00011\n",THIS_METHOD,THIS_FILE);
        }onSuccess:^(id result) {
            DDLogInfo(@"Upload Status %d",((CMOMessage *)roomArray[0]).upload);
                    
            [self handleSendMessageProcess:nMessage ? nMessage:message onSuccess:^(id result) {
                DDLogInfo(@"Existing Chat - Send Document Message Success");
                //DDLogInfo(@"\n%@ %@ 00013\n",THIS_METHOD,THIS_FILE);
//                ////DDLogInfo(@"%@ %@ 8",THIS_METHOD,THIS_FILE);
                [weakSelf removeObjectFromCMOMessagesDict:nMessage];
            } onFailure:^(NSError *error) {
                DDLogInfo(@"\n%@ %@ 00014\n",THIS_METHOD,THIS_FILE);
//                DDLogError(@"Existing Chat - Send Document Message Failed %@, FILE: %@, METHOD: %@",error, THIS_FILE, THIS_METHOD);
                [weakSelf removeObjectFromCMOMessagesDict:nMessage];

//                ////DDLogInfo(@"%@ %@ 9",THIS_METHOD,THIS_FILE);
            }];
        } onFailure:^(NSError *error) {
            DDLogInfo(@"\n%@ %@ 00018\n",THIS_METHOD,THIS_FILE);
            ////////DDLogInfo(@"Existing Chat - Upload Document Failed %@, FILE: %@, METHOD: %@",error, THIS_FILE, THIS_METHOD);
           ////DDLogInfo(@"%@ %@ 10",THIS_METHOD,THIS_FILE);
        }];
    }
    ////DDLogInfo(@"%@ %@ 99",THIS_METHOD,THIS_FILE);
}

#pragma mark Replace Object in SortedMessages Array

- (void)replaceObjectInSortedArrayWithMessage:(CMOMessage *)message{
    NSUInteger index = [sortedMessages indexOfObjectPassingTest:^BOOL(id obj, NSUInteger idx, BOOL *stop) {
        
        if ([((CMOMessage *)obj).messageBody.messageId isEqualToString:message.messageBody.messageId]){
            *stop = YES;
            return YES;
        }
        return NO;
    }];
    if (index != NSNotFound){
        [sortedMessages replaceObjectAtIndex:index withObject:message];
    }
}


- (void)saveDocument:(CMOMessage *)message document:(id)document{
    NSString *filePath = [_chatModel getFilePath:message.messageBody.body roomId:message.roomIDStr];
    BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:filePath];//[CMOUtils isFileExistAtPath:filePath];
    if (!isFileExist){
        [self.chatModel saveDocument:message.messageBody.body docData:document roomID:self.receiverId];
    }
}


#pragma mark Upload Document


- (void)uploadDocumentWithMessage:(CMOMessage *)message data:(id)documentData
            OnProgress:(void (^)(id progress))onProgress
             onSuccess:(void (^)(id result))success
             onFailure:(void (^)(NSError *error))failure{
    DDLogInfo(@"%@ %@ 1 %@",THIS_METHOD,THIS_FILE,message);
    
    if (![self.roomModel isJoinedInRoom:message.roomIDStr]){
        ////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
         //DDLogInfo(@"\n%@ %@ room not joined hence dont upload 00025\n",THIS_METHOD,THIS_FILE);
        message.status = MessageDeliveryFailed;
        [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
        [self displayAlertWithTitle:SERVER_ACCESS_ERROR_MSG];
        NSError *err = [NSError errorWithDomain:@"CMOChat" code:111 userInfo:nil];
        message.upload = false;
        message.status = MessageDeliveryFailed;
        [self.chatModel saveMessageOffline:message];
        [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
        failure(err);
        return;
    }
    
    DocumentType docType = [CMOUtils documentType:message.messageBody.body];
    DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
    //Whenever the document message is processed, status will be pending.
    message.status = MessageDeliveryPending;
    [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
    DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
    dispatch_async(uploadQueue, ^(void){
        //////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
        [self.chatModel uploadDocumentWithMessage:message data:documentData OnProgress:^(id progress) {
            NSProgress *prog = progress;
            //DDLogInfo(@"Progress ========= (%f)",prog.fractionCompleted*100);
            
            switch (docType) {
                case DocumentTypeImage:
                    [(CMOPhotoMediaItem *)message.media setProgress:prog.fractionCompleted * 100];
                    break;
                case DocumentTypeAudio:
                     [(CMOAudioMediaItem *)message.media setProgress:prog.fractionCompleted * 100];
                case DocumentTypeMedia:
                    [(CMODocumentItem *)message.media setProgress:prog.fractionCompleted * 100];
                case DocumentTypeVideo:
                    [(CMOVideoMediaItem *)message.media setProgress:prog.fractionCompleted * 100];
                default:
                    break;
            }
            onProgress(progress);
        } onSuccess:^(id result) {
            DDLogInfo(@"%@ %@ upload successful 4",THIS_METHOD,THIS_FILE);
            //DDLogInfo(@"\n%@ %@ upload successful 000127\n",THIS_METHOD,THIS_FILE);
            message.upload = true;
            message.status = MessageDeliveryPending;
            
            [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
            success(result);
        } onFailure:^(NSError *error) {
            DDLogInfo(@"\n%@ %@ upload failed 000128\n",THIS_METHOD,THIS_FILE);
           //DDLogInfo(@"%@ %@ 5",THIS_METHOD,THIS_FILE);
            message.upload = false;
            message.status = MessageDeliveryFailed;
            [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
            failure(error);
        }];
    });
    //DDLogInfo(@"%@ %@ 99",THIS_METHOD,THIS_FILE);
}


- (void)downloadDocument:(CMOMessage *)message
              OnProgress:(void (^)(id progress))onProgress
             onSuccess:(void (^)(id result))success
             onFailure:(void (^)(NSError *error))failure{
    
    //////DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    DocumentType docType = [CMOUtils documentType:message.messageBody.body];

    //Whenever the document message is processed, status will be pending.
    message.status = MessageDeliveryPending;
    [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
    
    NSMutableArray *roomArray = [self arrayForDict:cmoMessagesDictionary key:message.roomIDStr];
    [roomArray addObject:message];
    
    __weak typeof(self) weakSelf = self;
    dispatch_async(downloadQueue, ^(void){
        //////DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        [self.chatModel downloadDocument:message.messageBody.body OnProgress:^(id progress){
            NSProgress *prog = progress;
            //DDLogInfo(@"Progress %@ %@ ========= (%f)",THIS_METHOD,message,prog.fractionCompleted*100);
            switch (docType) {
                case DocumentTypeImage:
                    [(CMOPhotoMediaItem *)message.media setProgress:prog.fractionCompleted * 100];
                    break;
                case DocumentTypeAudio:
                    [(CMOAudioMediaItem *)message.media setProgress:prog.fractionCompleted * 100];
                    break;
                case DocumentTypeMedia:
                    [(CMODocumentItem *)message.media setProgress:prog.fractionCompleted * 100];
                case DocumentTypeVideo:
                    [(CMOVideoMediaItem *)message.media setProgress:prog.fractionCompleted * 100];
                default:
                    break;
            }
            onProgress(progress);
        }onSuccess:^(id result) {
            //////DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
            [weakSelf removeObjectFromCMOMessagesDict:message];
            [self.chatModel saveDocument:message.messageBody.body docData:result roomID:message.roomIDStr];
            message.status = MessageDeliverySuccess;
            [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
            //[self scrollCollectionViewToBottom];
            success(result);
        } onFailure:^(NSError *error) {
            //////DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
            [weakSelf removeObjectFromCMOMessagesDict:message];
            message.status = MessageDeliverySuccess; //Status is success bcoz message already received but the document download failed. Still user can tap on retry.
            [self reloadCollectionViewCellWithIdentifier:message.messageBody.messageDateString];
            [self scrollCollectionViewToBottom];
            failure(error);
        }];
    });
}


- (void)scrollCollectionViewToBottom{
    NSInteger noOfItems = [self.collectionView numberOfItemsInSection:0];
    if (sortedMessages.count-1 <= noOfItems){
        [self.collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:sortedMessages.count-1 inSection:0] atScrollPosition:UICollectionViewScrollPositionBottom animated:true];
    }
}

- (NSMutableArray *)arrayForDict:(NSMutableDictionary *)dict key:(NSString *)key{
    //DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    id value = [dict valueForKey:key];
    if (!value){
        //DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
        value = [[NSMutableArray alloc]init];
        [dict setObject:value forKey:key];
    }
    //DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    return value;
}

- (void)removeObjectFromCMOMessagesDict:(CMOMessage *)message{
    //DDLogInfo(@"%@ %@ 1",THIS_METHOD,THIS_FILE);
    NSMutableArray *value = [cmoMessagesDictionary valueForKey:message.roomIDStr];
    if (value){
        //DDLogInfo(@"%@ %@ 2",THIS_METHOD,THIS_FILE);
         NSArray *messages = [value filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"messageBody.messageId == %@",message.messageBody.messageId]];
        if (messages.count > 0){
            //DDLogInfo(@"%@ %@ 3",THIS_METHOD,THIS_FILE);
            [value removeObject:messages[0]];
        }
        if (value.count == 0){
            [cmoMessagesDictionary removeObjectForKey:message.roomIDStr];
        }
        //DDLogInfo(@"%@ %@ 4",THIS_METHOD,THIS_FILE);
    }
    //DDLogInfo(@"%@ %@ 99",THIS_METHOD,THIS_FILE);
}



- (void)reloadMessage:(CMOMessage *)message{
   
    /*dispatch_async(dispatch_get_main_queue(), ^(void){
    });*/
    
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:[sortedMessages indexOfObject:message] inSection:0];
    if (indexPath.row < sortedMessages.count){
        [self.collectionView reloadItemsAtIndexPaths:@[indexPath]];
    }
}

- (BOOL)isMessageAlreadyLoaded:(CMOMessage *)message{
    //////DDLogInfo(@"Message UserName: %@",message.userName);
    //CMOMessage *cmomessage = [_chatModel getMessage:message sender:message.userName messages:sortedMessages];
    //return cmomessage != nil;
    NSArray *messages = [sortedMessages filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"messageBody.messageDateString == %@",message.messageBody.messageDateString]];
    return messages.count > 0;
}

- (CMOMessage *)getMessageFromSortedArray:(CMOMessage *)message{
    return  [_chatModel getMessage:message sender:message.userName messages:allMessages];
}

#pragma mark - grid image or full image

- (void)gotoAttachmentScreen
{
    NSMutableArray *mediaList = [[NSMutableArray alloc]init];
    NSMutableArray *documentList = [[NSMutableArray alloc]init];
    
    for(int index = 0; index < sortedMessages.count; index++)
    {
        CMOMessage *message = sortedMessages[index];
        if (message.isMediaMessage && [_chatModel getDocument:message.messageBody.body roomID:self.receiverId])
        {
            if ([message.media isKindOfClass:[CMOPhotoMediaItem class]] || [message.media isKindOfClass:[CMOVideoMediaItem class]] || [message.media isKindOfClass:[CMOAudioMediaItem class]])
            {
                [mediaList addObject:message];
            }
            else if([message.media isKindOfClass:[CMODocumentItem class]]){
                [documentList addObject:message];
            }
        }
    }
    
    if (attachmentsVC)
    {
        attachmentsVC = nil;
    }
    attachmentsVC = [_assembly attachmentsviewcontroller];
    [attachmentsVC.messagesArray removeAllObjects];
    attachmentsVC.roomID = _receiverId;
    attachmentsVC.docsArray = documentList;
    attachmentsVC.messagesArray = mediaList;
    [self.parentViewController.navigationController pushViewController:attachmentsVC animated:YES];
}

- (void) showImageFullScreenWithObject:(CMOMessage *)message
{
    NSMutableArray *mediaList = [[NSMutableArray alloc]init];
    //UIImage *image;
    for(int index = 0; index < sortedMessages.count; index++)
    {
        CMOMessage *message = sortedMessages[index];
        //image = [self.chatModel getDocument:message.messageBody.body roomID:self.receiverId];
        if (message.isMediaMessage && [_chatModel getDocument:message.messageBody.body roomID:self.receiverId])
        {
            if ([message.media isKindOfClass:[CMOPhotoMediaItem class]] || [message.media isKindOfClass:[CMOVideoMediaItem class]] || [message.media isKindOfClass:[CMOAudioMediaItem class]])
            {
                [mediaList addObject:message];
            }
        }
    }
    //image = nil;
    
    NSUInteger index = [mediaList indexOfObject:message];
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:index inSection:0];
    
    if (fullimageVC)
    {
        fullimageVC = nil;
    }
    
    fullimageVC = [_assembly fullimageviewcontroller];//Need to add roomInfo
    fullimageVC.roomID = _receiverId;
    fullimageVC.selectedIndex = indexPath;
    [fullimageVC.mediaMessage removeAllObjects];
    fullimageVC.mediaMessage = [NSMutableArray arrayWithArray: mediaList];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        appDelegate.isReloadSplitView = NO;
        appDelegate.isConversationReload = NO;
        [self.navigationController presentViewController:fullimageVC animated:YES completion:nil];
    } else {
        [self.parentViewController.navigationController pushViewController:fullimageVC animated:YES];
    }
}

- (void) showDocumentFullScreenWithObject:(CMOMessage *)message
{
    appDelegate.isReloadSplitView = NO;
    
    NSUInteger index = [sortedMessages indexOfObject:message];
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:index inSection:0];
    
    if (documentPreview)
    {
        documentPreview = nil;
    }
    
    documentPreview = [_assembly documentpreviewviewcontroller];
    documentPreview.delegate = self;
    
    if ([message.media isKindOfClass:[CMOVideoMediaItem class]]){
        CMOVideoMediaItem *mediaMessage = (CMOVideoMediaItem *) message.media;
        documentPreview.docURL = mediaMessage.fileURL;
        documentPreview.isDocument = NO;
    }
    else if ([message.media isKindOfClass:[CMOAudioMediaItem class]]) {
        CMOAudioMediaItem *mediaMessage = (CMOAudioMediaItem *) message.media;
        documentPreview.docURL = mediaMessage.audioUrl;
        documentPreview.isDocument = NO;
    }
    else if ([message.media isKindOfClass:[CMODocumentItem class]])
    {
        CMODocumentItem *documentMessage = (CMODocumentItem *) message.media;
        documentPreview.docURL = documentMessage.docUrl;
        documentPreview.isDocument = YES;
    }
    else{
        //handel other type
    }
    
    documentPreview.selectedIndex = indexPath;
    documentPreview.roomID = _receiverId;
    documentPreview.message = [sortedMessages objectAtIndex:indexPath.row];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        appDelegate.isReloadSplitView = NO;
        [self.navigationController presentViewController:documentPreview animated:YES completion:nil];
    } else {
        CMONavigationController *navController = (CMONavigationController *)self.navigationController;
        [navController pushViewController:documentPreview];
    }
}

- (void)updateDocumentListOnDeletionWithObject:(NSUInteger)index
{
    [self.collectionView reloadData];
}

-(void)updateAttachmentOnDeletionWithObjectFromPreview:(NSUInteger)index
{
    [self.collectionView reloadData];
}


#pragma mark --
#pragma mark Error Messages

- (void) showErrorAlertWithMessage: (NSString *)errorMessage
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:errorMessage preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //Handle Ok button action
    }];
    [alertController addAction:ok];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)updatePresence:(NSNotification *)notification{
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        dispatch_async(dispatch_get_main_queue(), ^(){
            [self.collectionView reloadData];
        });
    }
    else{
        [self.collectionView reloadData];
    }
}

- (BOOL) isDateOne: (NSDate *) dateOne sameAsDateTwo: (NSDate *) dateTwo
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    
    if ([[dateFormat stringFromDate:dateOne] isEqualToString:[dateFormat stringFromDate:dateTwo]])
    {
        return YES;
    }
    return NO;
}

- (void)applicationLoggedOut:(NSNotification *)notification{
    [self unRegisterNotifications];
}


- (NSMutableDictionary *)eligibleParticipants:(NSMutableDictionary *)allParticipants
                                      smsSent:(BOOL)smsSent{
    
    CMORosterPresentation *rosterModel = [_coreComponents rosterPresentation];
    NSArray *participants = [rosterModel eligibleParticipants:self.partcipantsList sent:smsSent];
    NSMutableDictionary *eligibleParticipants = [[NSMutableDictionary alloc]init];
    if (participants.count > 0){
        [eligibleParticipants setObject:participants forKey:MACROS_CONTACTS];
    }
    if ([self.partcipantsList objectForKey:MACROS_GROUPS]){
        [eligibleParticipants setObject:[self.partcipantsList objectForKey:MACROS_GROUPS] forKey:MACROS_GROUPS];
    }
    return eligibleParticipants;
}

@end
