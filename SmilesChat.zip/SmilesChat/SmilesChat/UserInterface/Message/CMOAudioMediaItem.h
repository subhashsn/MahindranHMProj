//
//  CMOAudioMediaItem.h
//  CMOChat
//
//  Created by Administrator on 1/14/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSQAudioMediaItem.h"

@protocol CMOAudioMediaItemDelegate <NSObject>

- (void)didPressRetry:(id)target;

@end


@interface CMOAudioMediaItem : JSQAudioMediaItem

@property (nonatomic, weak) id <CMOAudioMediaItemDelegate>audioMediaDelegate;

@property (nonatomic, strong) NSURL* audioUrl;

@property (nonatomic, assign)MessageDeliveryStatus status;;

- (id)initWithData:(NSData *)audioData target:(id)target;

- (void)setAudioData:(NSData *)audioData path:(NSURL *)audioPath;

- (void)setUpload:(BOOL)upload;

- (void)setDownload:(BOOL)download;

- (void) setProgress:(float)progressCompleted;

@end
