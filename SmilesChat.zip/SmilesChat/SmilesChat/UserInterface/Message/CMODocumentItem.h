//
//  CMOPhotoItem.h
//  CMOChat
//
//  Created by Administrator on 11/19/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <JSQMessagesViewController/JSQMessagesViewController.h>
#import "JSQPhotoMediaItem.h"

@class CMOMessage;

@protocol CMODocumentItemDelegate <NSObject>

- (void)didPressRetry:(id)target;

@end


@interface CMODocumentItem : JSQPhotoMediaItem

@property (nonatomic, strong) UIImageView *asyncImageView;

@property (nonatomic, assign)MessageDeliveryStatus status;
//@property (nonatomic, readonly) PhotoItemTask photoTask;

@property (nonatomic, weak) id <CMODocumentItemDelegate>documentMediaDelegate;
@property (nonatomic, strong) NSURL* docUrl;
@property (nonatomic, strong) NSString* fileName;


- (instancetype)initWithData:(NSData *)data target:(id)target;

- (void) setProgress:(float)progressCompleted;

- (void)setDocumentPath:(NSURL *)documentUrl fileName:(NSString *)fileName;

//- (instancetype)initWithURL:(NSURL *)URL outgoing:(BOOL)outgoing;

//- (void)setUpload:(BOOL)upload;

//- (void)setDownload:(BOOL)download;

@end
