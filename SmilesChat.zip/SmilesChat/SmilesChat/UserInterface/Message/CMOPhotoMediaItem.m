//
//  CMOPhotoItem.m
//  CMOChat
//
//  Created by Administrator on 11/19/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOPhotoMediaItem.h"
#import "UIColor+JSQMessages.h"
#import "JSQMessagesMediaPlaceholderView.h"
#import "CMOMessage.h"

#define RETRY_UPLOAD_IMAGE @"retryUpload"
#define RETRY_DOWNLOAD_IMAGE @"retryDownload"

@interface CMOPhotoMediaItem(){

    UIButton *retryButton;
    CGRect buttonFrame;
    id _target;
    UIView *activityIndicatorView;
    
    CMOMessage *cmoMessage;
    
    UILabel *statusPercentage;
}

@property (nonatomic, strong)UIView *photoItemView;
@property (nonatomic, strong)UIImageView *photoItemImageView;

@end

@implementation CMOPhotoMediaItem



- (instancetype)init
{
    return [self initWithMaskAsOutgoing:YES];
}


- (instancetype)initWithUIImage:(UIImage *)image target:(id)target{
    self = [super initWithImage:image];
    if (self) {
                
        _target = target;
        CGSize size = [self mediaViewDisplaySize];

       // buttonFrame = CGRectMake(0, size.height/2 - 15, size.width,30);
        
        self.photoItemView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        self.photoItemView.contentMode = UIViewContentModeScaleToFill;
        self.photoItemView.clipsToBounds = YES;
        self.photoItemView.layer.cornerRadius = 20;
        self.photoItemView.backgroundColor = [UIColor jsq_messageBubbleLightGrayColor];
        
        
        self.photoItemImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        self.photoItemImageView.contentMode = UIViewContentModeScaleToFill;
        self.photoItemImageView.clipsToBounds = YES;
        [self.photoItemView addSubview:self.photoItemImageView];
        [self.photoItemImageView setImage:image];
        
        /*
        activityIndicatorView = [JSQMessagesMediaPlaceholderView viewWithActivityIndicator];
        activityIndicatorView.hidden = true;
        activityIndicatorView.frame = self.photoItemView.frame;
        [self.photoItemView addSubview:activityIndicatorView];
        */
        
       //[UIImage imageNamed:[NSString stringWithFormat:@"%@.png",upload ?@"retryUpload" : @"retryDownload"]];
        
        retryButton = [UIButton buttonWithType:UIButtonTypeCustom];
        retryButton.frame = CGRectMake(0, size.height/2 - 15, size.width,30);
        retryButton.hidden = true;
        [retryButton addTarget:target action:@selector(didPressRetry:) forControlEvents:UIControlEventTouchUpInside];
        [self.photoItemView addSubview:retryButton];
        
        self.photoItemView.frame = CGRectMake(0, 0, size.width, size.height);
        [self.photoItemView layoutIfNeeded];
        
        [self configureLabel];
    }
    
    return self;
}

- (void) configureLabel{
    CGSize size = [self mediaViewDisplaySize];
    statusPercentage = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, size.width, size.height)];
    statusPercentage.text = @"Loading...";
    //DDLogInfo(@"\n%@ %@ 000120\n",THIS_METHOD,THIS_FILE);
    statusPercentage.textColor = [UIColor whiteColor];
    statusPercentage.backgroundColor = [UIColor grayColor];
    statusPercentage.textAlignment = UIBaselineAdjustmentAlignCenters;
    [self.photoItemView addSubview:statusPercentage];
    [self.photoItemView bringSubviewToFront:statusPercentage];
    [statusPercentage setHidden:true];
}



//Override JSQPhotoItem Set Image
- (void)setImage:(UIImage *)image
{
    switch (self.status) {
        case MessageDeliveryPending:
            [self jsq_activityIndicator:true];
            [self updateImage:image];
            [self updateRetry:image];
            break;
        case MessageDeliveryFailed:
            [self jsq_activityIndicator:false];
            [self updateImage:image];
            [self updateRetry:image];
            break;
        case MessageDeliverySuccess:
            [self jsq_activityIndicator:false];
            [self updateImage:image];
            [self updateRetry:image];
            break;
        default:
            break;
    }
}


- (void)updateImage:(UIImage *)image{
    //if (image){
        [super setImage:image];
        CGSize imageSize = [self mediaViewDisplaySize];
        _photoItemImageView.frame = CGRectMake(0, 0,imageSize.width ,imageSize.height);
        [self.photoItemImageView setImage:image];
    //}
}

- (void)updateRetry:(UIImage *)image{
    
    switch (self.status) {
        case MessageDeliverySuccess:
        {
            if (!image){//If Actual Image not Available, then show retry with download option
                retryButton.hidden = false;
                [retryButton setImage:[UIImage imageNamed:RETRY_DOWNLOAD_IMAGE] forState:UIControlStateNormal];
            }
            else{
                retryButton.hidden = true;
            }
        
        }
            break;
        case MessageDeliveryFailed:
        {
             retryButton.hidden = false;
             [retryButton setImage:image ? [UIImage imageNamed:RETRY_UPLOAD_IMAGE] : [UIImage imageNamed:RETRY_DOWNLOAD_IMAGE]  forState:UIControlStateNormal];
        }
            break;
        case MessageDeliveryPending:
        {
            retryButton.hidden = true;
        }
            break;
            
        default:
            break;
    }
}

- (void)updateRetryFrame:(CGSize)size{
    if (!retryButton.hidden){
        retryButton.frame = CGRectMake(0, size.height/2 - 15, size.width,30);
    }
}

//new function

- (void)jsq_activityIndicator:(BOOL)show{
//    activityIndicatorView.hidden = !show;
    [statusPercentage setHidden:!show];
}

//Ends here

#pragma mark - JSQMessageMediaData protocol

- (void)setAppliesMediaViewMaskAsOutgoing:(BOOL)appliesMediaViewMaskAsOutgoing
{
    [super setAppliesMediaViewMaskAsOutgoing:appliesMediaViewMaskAsOutgoing];
}

- (CGSize)mediaViewDisplaySize
{
    CGSize size = CGSizeMake(210.0f, 150.0f);
    BOOL isiPad = ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad);
    BOOL isImageAvailable = self.photoItemImageView.image != nil;
    
    size = isiPad ? (isImageAvailable ? CGSizeMake(315.0f, 225.0f) : CGSizeMake(315.0f, 125.0f)) : (isImageAvailable ? CGSizeMake(210.0f, 150.0f) : CGSizeMake(210.0f, 50.0f));
    
    [self updateRetryFrame:size];
    return size;
    /*if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        if (self.photoItemImageView.image) {
            [self updateRetryButtonFrame];
            size = CGSizeMake(315.0f, 225.0f);
        }
        else{
            [self updateRetryButtonFrame];
            size =  CGSizeMake(315.0f, 125.0f);
        }
    }
    
    if (self.photoItemImageView.image) {
        [self updateRetryButtonFrame];
        size =  CGSizeMake(210.0f, 150.0f);
    }
    [self updateRetryButtonFrame];
    return CGSizeMake(210.0f, 50.0f);*/
}

- (UIView *)mediaView
{
    return self.photoItemView;
}

//- (UIView *)mediaPlaceholderView{
//    return self.photoItemImageView;
//}

#pragma mark - NSCoding
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    NSLog(@"init coder has not been implemented");
    
    return self;
}

- (void) setProgress:(float)progressCompleted{
    ////DDLogInfo(@"Image Progress %f",progressCompleted);    
    dispatch_async(dispatch_get_main_queue(), ^{
        statusPercentage.text = [NSString stringWithFormat:@"%d %%",(int)progressCompleted];
    });
}

@end
