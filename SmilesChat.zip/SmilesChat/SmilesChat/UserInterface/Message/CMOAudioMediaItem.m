//
//  CMOAudioMediaItem.m
//  CMOChat
//
//  Created by Administrator on 1/14/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMOAudioMediaItem.h"
#import "JSQMessagesMediaPlaceholderView.h"
#import "UIColor+JSQMessages.h"

#define RETRY_UPLOAD_IMAGE @"retryUpload"
#define RETRY_DOWNLOAD_IMAGE @"retryDownload"

@interface CMOAudioMediaItem(){
    BOOL isUploaded;
    BOOL isDownloaded;
    
    UIButton *retryButton;
    CGRect buttonFrame;
    UIView *activityIndicator;
    UIImageView *audioItemBackgroundView;
    
    UILabel *statusPercentage;
}

@property (nonatomic, strong)UIView *audioItemView;

@end

@implementation CMOAudioMediaItem


- (id)initWithData:(NSData *)audioData target:(id)target{
    self = [super initWithData:audioData];
    if (self) {
       // self.audioUrl = audioURL;
        //[self setAudioDataWithUrl:audioURL];
        self.audioMediaDelegate =  target;
        
        CGSize size = [self mediaViewDisplaySize];
        buttonFrame = CGRectMake(0, size.height/2 - 15, size.width,30);
        self.audioItemView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        self.audioItemView.contentMode = UIViewContentModeScaleToFill;
        self.audioItemView.clipsToBounds = YES;
        self.audioItemView.layer.cornerRadius = 20;
        self.audioItemView.backgroundColor = [UIColor jsq_messageBubbleLightGrayColor];
        
        audioItemBackgroundView =  [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        audioItemBackgroundView.contentMode = UIViewContentModeScaleToFill;
        audioItemBackgroundView.clipsToBounds = YES;
        audioItemBackgroundView.hidden = false;
        [self.audioItemView addSubview:audioItemBackgroundView];
        
        UIImage *bgImage = [UIImage imageNamed:@"audioBackground"];
        [audioItemBackgroundView setImage:bgImage];
        
        retryButton = [UIButton buttonWithType:UIButtonTypeCustom];
        retryButton.frame = CGRectMake(0, size.height/2 - 15, size.width,30);
        retryButton.hidden = true;
        [retryButton addTarget:target action:@selector(didPressRetry:) forControlEvents:UIControlEventTouchUpInside];
        [self.audioItemView addSubview:retryButton];
        
        [self configureLabel];
        //[self addActivityIndicator];
        
    }
    return self;
}



- (id)initWithData:(NSData *)audioData audioViewAttributes:(JSQAudioMediaViewAttributes *)audioViewAttributes{
    self = [super initWithData:audioData audioViewAttributes:audioViewAttributes];
    
    return self;
}


- (void) configureLabel{
    CGSize size = [self mediaViewDisplaySize];
    statusPercentage = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, size.width, size.height)];
    statusPercentage.text = @"Loading...";
    //DDLogInfo(@"\n%@ %@ audio 000121\n",THIS_METHOD,THIS_FILE);
    statusPercentage.textColor = [UIColor whiteColor];
    statusPercentage.backgroundColor = [UIColor grayColor];
    statusPercentage.textAlignment = UIBaselineAdjustmentAlignCenters;
    [self.audioItemView addSubview:statusPercentage];
    [self.audioItemView bringSubviewToFront:statusPercentage];
    [statusPercentage setHidden:true];
}

/*
 NSString *audioPath = [self.chatModel getDocumentFilePath:self.receiverId fileName:message.messageBody.body];
 CMOAudioMediaItem *audioMediaItem = (CMOAudioMediaItem *)cmomessage.media;
 [audioMediaItem setAudioDataWithUrl:[NSURL fileURLWithPath:audioPath]];
 
 */


- (void)setAudioData:(NSData *)audioData path:(NSURL *)audioPath{
    self.audioUrl = audioPath;
    switch (self.status) {
        case MessageDeliveryPending:
            [self jsq_activityIndicator:true];
            [self updateAudioPath:audioData];
            [self updateRetry:audioData];
            break;
        case MessageDeliveryFailed:
            [self jsq_activityIndicator:false];
            [self updateAudioPath:audioData];
            [self updateRetry:audioData];
            break;
        case MessageDeliverySuccess:
            [self jsq_activityIndicator:false];
            [self updateAudioPath:audioData];
            [self updateRetry:audioData];
            break;
        default:
            break;
    }
}

/*- (void)setAudioUrl:(NSURL *)audioUrl{
        switch (self.status) {
            case MessageDeliveryPending:
                [self jsq_activityIndicator:true];
                [self updateAudioPath:[audioUrl absoluteString]];
                [self updateRetry:[audioUrl absoluteString]];
                break;
            case MessageDeliveryFailed:
                [self jsq_activityIndicator:false];
                [self updateAudioPath:[audioUrl absoluteString]];
                [self updateRetry:[audioUrl absoluteString]];
                break;
            case MessageDeliverySuccess:
                [self jsq_activityIndicator:false];
                [self updateAudioPath:[audioUrl absoluteString]];
                [self updateRetry:[audioUrl absoluteString]];
                break;
            default:
                break;
        }
    
}*/

- (void)updateAudioPath:(NSData *)audioData{
    //BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:path];
    if (audioData){
        [super setAudioData:audioData];
        //[super setAudioDataWithUrl:[NSURL URLWithString:path]];
    }
}

/*- (void)updateAudioPath:(NSString *)path{
    BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:path];
    if (isFileExist){
        [super setAudioDataWithUrl:[NSURL URLWithString:path]];
    }
}*/


- (void)updateRetry:(NSData *)data{
    //BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:path];
    switch (self.status) {
        case MessageDeliverySuccess:
        {
            if (!data){//If Actual Image not Available, then show retry with download option
                retryButton.hidden = false;
                [retryButton setImage:[UIImage imageNamed:RETRY_DOWNLOAD_IMAGE] forState:UIControlStateNormal];
            }
            else{
                retryButton.hidden = true;
            }
            
        }
            break;
        case MessageDeliveryFailed:
        {
            retryButton.hidden = false;
            [retryButton setImage:data ? [UIImage imageNamed:RETRY_UPLOAD_IMAGE] : [UIImage imageNamed:RETRY_DOWNLOAD_IMAGE]  forState:UIControlStateNormal];
        }
            break;
        case MessageDeliveryPending:
        {
            retryButton.hidden = true;
        }
            break;
            
        default:
            break;
    }
}



//new function

- (void)jsq_activityIndicator:(BOOL)show{
    //    activityIndicatorView.hidden = !show;
    [statusPercentage setHidden:!show];
}




- (void)setUpload:(BOOL)upload{
    [self removeActivityIndicator];
    [self removeRetryButton];
    if (!upload){
        [self addRetryButton:true];
    }
}

- (void)setDownload:(BOOL)download{
    [self removeActivityIndicator];
    [self removeRetryButton];
    if (!download){
        [self addRetryButton:false];
    }
}


- (void)addRetryButton:(BOOL)upload{
    if (!retryButton){
        UIImage *retryImage = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",upload ?@"retryUpload" : @"retryDownload"]];
        retryButton = [UIButton buttonWithType:UIButtonTypeCustom];
        retryButton.frame = buttonFrame;
        [retryButton setImage:retryImage forState:UIControlStateNormal];
        [retryButton addTarget:self action:@selector(retryUpload:) forControlEvents:UIControlEventTouchUpInside];
        [self.audioItemView addSubview:retryButton];
    }
}

- (void)retryUpload:(id)sender{
    //[self addActivityIndicator];
    [self.audioMediaDelegate didPressRetry:self];
}


- (void)removeRetryButton{
    if (retryButton){
        [retryButton removeFromSuperview];
        retryButton = nil;
    }
}


- (void)addActivityIndicator{
    if (!activityIndicator){
        activityIndicator = [JSQMessagesMediaPlaceholderView viewWithActivityIndicator];
        activityIndicator.frame = self.mediaPlaceholderView.frame;
        [self.audioItemView addSubview:activityIndicator];
    }
}

- (void)removeActivityIndicator{
    if (activityIndicator){
        [activityIndicator removeFromSuperview];
        activityIndicator = nil;
    }
}

- (UIView *)mediaView
{
    return self.audioItemView;
}


- (void) setProgress:(float)progressCompleted{
    ////DDLogInfo(@"Audio Progress %f",progressCompleted);
    dispatch_async(dispatch_get_main_queue(), ^{
        statusPercentage.text = [NSString stringWithFormat:@"%d %%",(int)progressCompleted];
    });
}

@end
