//
//  CMOVideoMediaItem.m
//  CMOChat
//
//  Created by Administrator on 11/20/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOVideoMediaItem.h"
#import "JSQMessagesMediaPlaceholderView.h"
#import "JSQMessagesMediaViewBubbleImageMasker.h"
#import "UIColor+JSQMessages.h"
#import "UIImage+JSQMessages.h"

#import <AVFoundation/AVFoundation.h>

#define RETRY_UPLOAD_VIDEO @"retryUpload"
#define RETRY_DOWNLOAD_VIDEO @"retryDownload"


@interface CMOVideoMediaItem (){
    BOOL isUploaded;
    BOOL isDownloaded;
    
    UIButton *retryButton;
    id _target;
    UIView *activityIndicator;
    UILabel *statusPercentage;
    
}

@property (nonatomic, strong)UIView *videoItemView;

@property (strong, nonatomic) UIImageView *videoItemImageView;

@end

@implementation CMOVideoMediaItem


- (id)initWithFileURL:(NSURL *)fileURL isReadyToPlay:(BOOL)isReadyToPlay delegate:(id)target{
    self = [super initWithFileURL:fileURL isReadyToPlay:isReadyToPlay];
    
    CGSize size = [self mediaViewDisplaySize];
    
    self.videoMediaDelegate = target;
    
    self.videoItemView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
    self.videoItemView.contentMode = UIViewContentModeScaleToFill;
    self.videoItemView.clipsToBounds = YES;
    self.videoItemView.layer.cornerRadius = 20;
    self.videoItemView.backgroundColor = [UIColor jsq_messageBubbleLightGrayColor];

    UIImage *videoThumbnail = [self generateThumbnailFromVideo];
    
    self.videoItemImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
    self.videoItemImageView.contentMode = UIViewContentModeScaleToFill;
    self.videoItemImageView.clipsToBounds = YES;
    [self.videoItemView addSubview:self.videoItemImageView];
    [self.videoItemImageView setImage:videoThumbnail];
    
    retryButton = [UIButton buttonWithType:UIButtonTypeCustom];
    retryButton.frame = CGRectMake(0, size.height/2 - 15, size.width,30);
    retryButton.hidden = true;
    [retryButton addTarget:target action:@selector(didPressRetry:) forControlEvents:UIControlEventTouchUpInside];
    [self.videoItemView addSubview:retryButton];
    
    UIImage *bgImage = [UIImage imageNamed:@"video-icon"];
    
    UIImageView *videoImageView =  [[UIImageView alloc] initWithFrame:CGRectMake(15, size.height - (15 + bgImage.size.height), bgImage.size.width,bgImage.size.height)];
    videoImageView.contentMode = UIViewContentModeScaleToFill;
    videoImageView.clipsToBounds = YES;
    videoImageView.hidden = false;
    [self.videoItemView addSubview:videoImageView];
    [videoImageView setImage:bgImage];
    
    [self configureLabel];
    //[self addActivityIndicator];
    return self;
}

//- (void)setFileURL:(NSURL *)fileURL {
//    _fileURL = fileURL;
//    UIImage *videoThumbnail = [self generateThumbnailFromVideo];
//    [self.videoItemImageView setImage:videoThumbnail];
//}

- (UIView *)mediaView
{
    return self.videoItemView;
    
//    if (self.fileURL == nil || !self.isReadyToPlay) {
//        return self.videoItemView;
//    }
//    
//    //if (self.videoItemView == nil) {
//        CGSize size = [self mediaViewDisplaySize];
//        UIImage *videoThumbnail = [self generateThumbnailFromVideo];
//        
//        UIImageView *imageView = [[UIImageView alloc] initWithImage:videoThumbnail];
//        imageView.backgroundColor = [UIColor blackColor];
//        imageView.frame = CGRectMake(0.0f, 0.0f, size.width, size.height);
//        imageView.contentMode = UIViewContentModeCenter;
//        imageView.clipsToBounds = YES;
//        [JSQMessagesMediaViewBubbleImageMasker applyBubbleImageMaskToMediaView:imageView isOutgoing:self.appliesMediaViewMaskAsOutgoing];
//        //[self.videoItemView addSubview:imageView];
//    //}
//    return self.videoItemView;
}

- (void) configureLabel{
    CGSize size = [self mediaViewDisplaySize];
    statusPercentage = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, size.width, size.height)];
    statusPercentage.text = @"Loading...";
    //DDLogInfo(@"\n%@ %@ audio 000121\n",THIS_METHOD,THIS_FILE);
    statusPercentage.textColor = [UIColor whiteColor];
    statusPercentage.backgroundColor = [UIColor grayColor];
    statusPercentage.textAlignment = UIBaselineAdjustmentAlignCenters;
    [self.videoItemView addSubview:statusPercentage];
    [self.videoItemView bringSubviewToFront:statusPercentage];
    [statusPercentage setHidden:true];
}


- (UIImage*)generateThumbnailFromVideo
{
    UIImage *thumbnail = nil;

    //if fileUrl set as NSURL generate thumbnail for video
    if ([self.fileURL isKindOfClass:[NSURL class]]) {
        NSString *previewFileName = [[self.fileURL lastPathComponent] stringByDeletingPathExtension];
        previewFileName = [NSString stringWithFormat:@"%@_preview.png",previewFileName];
        NSURL *previewMediaUrl  = [[self.fileURL URLByDeletingLastPathComponent] URLByAppendingPathComponent:previewFileName];
        
        //if preview file exist,then generate thumbnail.Else generate preview from video file and save in preview file
        thumbnail = [UIImage imageWithContentsOfFile:[previewMediaUrl path]];
        if (!thumbnail) {
            @autoreleasepool {
                AVAsset *asset = [AVAsset assetWithURL: self.fileURL];
                AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc]initWithAsset:asset];
                
                [imageGenerator setAppliesPreferredTrackTransform:YES];
                CMTime time = CMTimeMake(1, 1);
                CGImageRef imageRef = [imageGenerator copyCGImageAtTime:time actualTime:NULL error:NULL];
                thumbnail = [UIImage imageWithCGImage:imageRef];
                CGImageRelease(imageRef);
                [UIImagePNGRepresentation(thumbnail) writeToFile:[previewMediaUrl path] atomically:YES];
            }
        }
    }
    
    return thumbnail;
}

- (void)setVidioUrl:(NSURL *)videoUrl {
    self.fileURL = videoUrl;
    [self setIsReadyToPlay:(videoUrl != nil)];
    switch (self.status) {
        case MessageDeliveryPending:
            [self jsq_activityIndicator:true];
//            [self updateAudioPath:audioData];
            [self updateRetry:videoUrl];
            break;
        case MessageDeliveryFailed:
            [self jsq_activityIndicator:false];
//            [self updateAudioPath:audioData];
            [self updateRetry:videoUrl];
            break;
        case MessageDeliverySuccess:
            [self jsq_activityIndicator:false];
//            [self updateAudioPath:audioData];
            [self updateRetry:videoUrl];
            break;
        default:
            break;
    }
}

- (void)updateRetry:(NSURL *)videoUrl{
    //BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:path];
    switch (self.status) {
        case MessageDeliverySuccess:
        {
            if (!videoUrl){//If Actual Image not Available, then show retry with download option
                retryButton.hidden = false;
                [retryButton setImage:[UIImage imageNamed:RETRY_DOWNLOAD_VIDEO] forState:UIControlStateNormal];
            }
            else{
                retryButton.hidden = true;
                UIImage *videoThumbnail = [self generateThumbnailFromVideo];
                [self.videoItemImageView setImage:videoThumbnail];
            }
            
        }
            break;
        case MessageDeliveryFailed:
        {
            retryButton.hidden = false;
            [retryButton setImage:videoUrl ? [UIImage imageNamed:RETRY_UPLOAD_VIDEO] : [UIImage imageNamed:RETRY_DOWNLOAD_VIDEO]  forState:UIControlStateNormal];
        }
            break;
        case MessageDeliveryPending:
        {
            retryButton.hidden = true;
            UIImage *videoThumbnail = [self generateThumbnailFromVideo];
            [self.videoItemImageView setImage:videoThumbnail];
        }
            break;
            
        default:
            break;
    }
}



- (void)jsq_activityIndicator:(BOOL)show{
    //    activityIndicatorView.hidden = !show;
    [statusPercentage setHidden:!show];
}


- (void)setUpload:(BOOL)upload{
    [self removeActivityIndicator];
    [self removeRetryButton];
    if (!upload){
        [self addRetryButton:true];
    }
    UIImage *videoThumbnail = [self generateThumbnailFromVideo];
    [self.videoItemImageView setImage:videoThumbnail];

}

- (void)setDownload:(BOOL)download{
    [self removeActivityIndicator];
    [self removeRetryButton];
    if (!download){
        [self addRetryButton:false];
    }
    UIImage *videoThumbnail = [self generateThumbnailFromVideo];
    [self.videoItemImageView setImage:videoThumbnail];
}

- (void)addRetryButton:(BOOL)upload{
    if (!retryButton){
        CGSize size = [self mediaViewDisplaySize];
        
        UIImage *retryImage = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",upload ?@"retryUpload" : @"retryDownload"]];
        retryButton = [UIButton buttonWithType:UIButtonTypeCustom];
        retryButton.frame = CGRectMake(0, size.height/2 - 15, size.width,30);
        [retryButton setImage:retryImage forState:UIControlStateNormal];
        [retryButton addTarget:self action:@selector(retryUpload:) forControlEvents:UIControlEventTouchUpInside];
        [self.videoItemView addSubview:retryButton];
    }
}


- (void)retryUpload:(id)sender{
    //[self addActivityIndicator];
    [self.videoMediaDelegate didPressRetry:self];
}


- (void)removeRetryButton{
    if (retryButton){
        [retryButton removeFromSuperview];
        retryButton = nil;
    }
}


- (void)addActivityIndicator{
    if (!activityIndicator){
        activityIndicator = [JSQMessagesMediaPlaceholderView viewWithActivityIndicator];
        activityIndicator.frame = self.videoItemView.frame;
        [self.videoItemView addSubview:activityIndicator];
    }
}

- (void)removeActivityIndicator{
    if (activityIndicator){
        [activityIndicator removeFromSuperview];
        activityIndicator = nil;
    }
}

- (void) setProgress:(float)progressCompleted{
    ////DDLogInfo(@"Audio Progress %f",progressCompleted);
    dispatch_async(dispatch_get_main_queue(), ^{
        statusPercentage.text = [NSString stringWithFormat:@"%d %%",(int)progressCompleted];
    });
}


#pragma mark - JSQMessageMediaData protocol

- (void)setAppliesMediaViewMaskAsOutgoing:(BOOL)appliesMediaViewMaskAsOutgoing
{
    [super setAppliesMediaViewMaskAsOutgoing:appliesMediaViewMaskAsOutgoing];
}


#pragma mark - NSCoding
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    NSLog(@"init coder has not been implemented");
    
    return self;
}

@end
