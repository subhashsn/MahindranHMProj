//
//  CMODocumentMediaItem.h
//  CMOChat
//
//  Created by Administrator on 1/14/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSQMediaItem.h"

@interface CMOMediaItem : JSQMediaItem

@property (nonatomic, strong)UIView *containerView;

@property (strong, nonatomic)UIImageView *imageView;

@property (nonatomic, assign)MessageDeliveryStatus status;

@end
