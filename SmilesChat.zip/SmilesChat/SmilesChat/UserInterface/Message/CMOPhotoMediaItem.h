//
//  CMOPhotoItem.h
//  CMOChat
//
//  Created by Administrator on 11/19/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <JSQMessagesViewController/JSQMessagesViewController.h>
#import "JSQPhotoMediaItem.h"

@class CMOMessage;



@interface CMOPhotoMediaItem : JSQPhotoMediaItem

@property (nonatomic, strong) UIImageView *asyncImageView;

@property (nonatomic, assign)MessageDeliveryStatus status;

- (instancetype)initWithUIImage:(UIImage *)image target:(id)target;

- (void) setProgress:(float)progress;



@end
