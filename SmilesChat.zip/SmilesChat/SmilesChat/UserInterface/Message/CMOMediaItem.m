//
//  CMODocumentMediaItem.m
//  CMOChat
//
//  Created by Administrator on 1/14/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import "CMOMediaItem.h"

@implementation CMOMediaItem

@end
