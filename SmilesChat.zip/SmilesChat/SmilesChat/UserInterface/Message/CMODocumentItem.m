//
//  CMOPhotoItem.m
//  CMOChat
//
//  Created by Administrator on 11/19/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMODocumentItem.h"
#import "UIColor+JSQMessages.h"
#import "JSQMessagesMediaPlaceholderView.h"
#import "CMOMessage.h"

#define RETRY_UPLOAD_IMAGE @"retryUpload"
#define RETRY_DOWNLOAD_IMAGE @"retryDownload"

@interface CMODocumentItem(){
    BOOL isUploaded;
    BOOL isDownloaded;
    
    UIButton *retryButton;
    CGRect buttonFrame;
    id _target;
    UIView *activityIndicator;
    UILabel *fileNameLabel;
    
    CMOMessage *cmoMessage;
    
//    PhotoItemTask photoItemTask;
    BOOL imageDownloded;
    UILabel *statusPercentage;
}

@property (nonatomic, strong)UIView *photoItemView;
@property (nonatomic, strong)UIImageView *photoItemImageView;

@end

@implementation CMODocumentItem


- (instancetype)init
{
    return [self initWithMaskAsOutgoing:YES];
}


- (instancetype)initWithData:(NSData *)data target:(id)target {
    self = [super initWithImage:nil];
    if (self) {
        //self.docUrl = docURL;
        self.documentMediaDelegate = target;
        
        _target = target;
        imageDownloded = true;
        CGSize size = [self mediaViewDisplaySize];

        buttonFrame = CGRectMake(0, size.height/2 - 15, size.width,30);
        
        self.photoItemView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        self.photoItemView.contentMode = UIViewContentModeScaleToFill;
        self.photoItemView.clipsToBounds = YES;
        self.photoItemView.layer.cornerRadius = 20;
        self.photoItemView.backgroundColor = [UIColor jsq_messageBubbleLightGrayColor];
        
        self.photoItemImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 50, 50)];
        self.photoItemImageView.contentMode = UIViewContentModeScaleToFill;
        self.photoItemImageView.clipsToBounds = YES;
        [self.photoItemView addSubview:self.photoItemImageView];
        
        retryButton = [UIButton buttonWithType:UIButtonTypeCustom];
        retryButton.frame = CGRectMake(0, size.height/2 - 15, size.width,30);
        retryButton.hidden = true;
        [retryButton addTarget:target action:@selector(didPressRetry:) forControlEvents:UIControlEventTouchUpInside];
        [self.photoItemView addSubview:retryButton];
        
        [self configureLabel];

        
        fileNameLabel = [[UILabel alloc] init];
        fileNameLabel.text = self.fileName;
        fileNameLabel.textColor = [UIColor blackColor];
        fileNameLabel.font = [UIFont fontWithName:@"Helvetica" size:16.0f];
        CGRect fileNameFrame = CGRectMake(CGRectGetMaxX(self.photoItemImageView.frame) + 10, CGRectGetMaxY(self.photoItemImageView.frame)/2 - 10 , size.width - CGRectGetMaxX(self.photoItemImageView.frame) - 20,30);
        fileNameLabel.frame = fileNameFrame;
        fileNameLabel.hidden = true;
        [self.photoItemView addSubview:fileNameLabel];
        
        [self.photoItemView bringSubviewToFront:fileNameLabel];
        //[self updateBackgroundImage:self.fileName];
       // [self addActivityIndicator];
    }
    
    return self;
}

- (void) configureLabel{
    CGSize size = [self mediaViewDisplaySize];
    statusPercentage = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, size.width, size.height)];
    statusPercentage.text = @"Loading...";
    statusPercentage.textColor = [UIColor whiteColor];
    statusPercentage.backgroundColor = [UIColor grayColor];
    statusPercentage.textAlignment = UIBaselineAdjustmentAlignCenters;
    [self.photoItemView addSubview:statusPercentage];
    [self.photoItemView bringSubviewToFront:statusPercentage];
    [statusPercentage setHidden:true];
}

- (void)updateBackgroundImage:(NSString *)fileName {
    NSString *previewImageName = @"";
    if (fileName) {
        NSString *fileExt = [[[fileName componentsSeparatedByString:@"."] lastObject] lowercaseString];
        
        if ([fileExt isEqualToString:@"pdf"]) {
            previewImageName = @"preview-pdf";
        } else if ([fileExt isEqualToString:@"doc"] || [fileExt isEqualToString:@"docx"]) {
            previewImageName = @"preview-doc";
        } else if ([fileExt isEqualToString:@"xls"] || [fileExt isEqualToString:@"xlsx"]) {
            previewImageName = @"preview-xls";
        } else {
            //ppt
            previewImageName = @"preview-ppt";
        }
    }
    
    UIImage *image = [UIImage imageNamed:previewImageName];
    [self.photoItemImageView setImage:image];
}

- (void)setDocumentPath:(NSURL *)documentUrl fileName:(NSString *)fileName{
    self.fileName = fileName;
    self.docUrl = documentUrl;
    switch (self.status) {
        case MessageDeliveryPending:
            [self jsq_activityIndicator:true];
            //[self updateImage:image];
            [self updateRetry:documentUrl];
            break;
        case MessageDeliveryFailed:
            [self jsq_activityIndicator:false];
            //[self updateImage:image];
            [self updateRetry:documentUrl];
            break;
        case MessageDeliverySuccess:
            [self jsq_activityIndicator:false];
            //[self updateImage:image];
            [self updateRetry:documentUrl];
            break;
        default:
            break;
    }
}



/*- (void)updateDocumentUrl:(NSString *)documentPath{
    //if (image){
        [super setImage:image];
        CGSize imageSize = [self mediaViewDisplaySize];
        _photoItemImageView.frame = CGRectMake(0, 0,imageSize.width ,imageSize.height);
        [self.photoItemImageView setImage:image];
    //}
}*/

- (void)updateRetry:(NSURL *)documentPath{
    //[[NSFileManager defaultManager]fileExistsAtPath:filePath];
    //BOOL isFileExist = [[NSFileManager defaultManager]fileExistsAtPath:[documentPath absoluteString]];
    switch (self.status) {
        case MessageDeliverySuccess:
        {
            if (!documentPath){//If Actual Image not Available, then show retry with download option
                retryButton.hidden = false;
                fileNameLabel.hidden = true;
                [retryButton setImage:[UIImage imageNamed:RETRY_DOWNLOAD_IMAGE] forState:UIControlStateNormal];
            }
            else{
                retryButton.hidden = true;
                fileNameLabel.text = self.fileName;
                fileNameLabel.hidden = false;
               // [self updateBackgroundImage:self.fileName];

            }
            
        }
            break;
        case MessageDeliveryFailed:
        {
            retryButton.hidden = false;
            fileNameLabel.hidden = true;
            [retryButton setImage:documentPath ? [UIImage imageNamed:RETRY_UPLOAD_IMAGE] : [UIImage imageNamed:RETRY_DOWNLOAD_IMAGE]  forState:UIControlStateNormal];
        }
            break;
        case MessageDeliveryPending:
        {
            retryButton.hidden = true;
            fileNameLabel.hidden = true;
        }
            break;
            
        default:
            break;
    }
}



//new function

- (void)jsq_activityIndicator:(BOOL)show{
    //    activityIndicatorView.hidden = !show;
    [statusPercentage setHidden:!show];
}




/*- (void)setUpload:(BOOL)upload{
    [self removeActivityIndicator];
    [self removeRetryButton];
    [self addFileNameLabel];
    if (!upload){
        [self addRetryButton:true];
    }
}

- (void)setDownload:(BOOL)download{
    [self removeActivityIndicator];
    [self removeRetryButton];
    [self addFileNameLabel];
    if (!download){
        [self addRetryButton:false];
    }
}*/

- (void)setFileName:(NSString *)fileName {
    _fileName = fileName;
    
    [self updateBackgroundImage:fileName];
}

//Override JSQPhotoItem Set Image
/*- (void)setImage:(UIImage *)image
{
    [super setImage:image];
    [self.photoItemImageView setImage:image];
}

- (void)setPhoto:(UIImage *)image
{
    [self.photoItemImageView setImage:image];
}

- (void)addRetryButton:(BOOL)upload{
    if (!retryButton){
        imageDownloded = false;
        UIImage *retryImage = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",upload ?@"retryUpload" : @"retryDownload"]];
        
        CGSize size = [self mediaViewDisplaySize];
        
        retryButton = [UIButton buttonWithType:UIButtonTypeCustom];
        buttonFrame = CGRectMake(0, size.height/2 -15 , size.width,30);
        retryButton.frame = buttonFrame;
        [retryButton setImage:retryImage forState:UIControlStateNormal];
        [retryButton addTarget:self action:@selector(retryUpload:) forControlEvents:UIControlEventTouchUpInside];
        [self.photoItemView addSubview:retryButton];
        
        self.photoItemView.frame = CGRectMake(0, 0, size.width, size.height);
        [self.photoItemView layoutIfNeeded];
    }
}*/

- (void)addFileNameLabel {
    if (!fileNameLabel) {
        fileNameLabel = [[UILabel alloc] init];
        fileNameLabel.text = self.fileName;
        CGSize size = [self mediaViewDisplaySize];
        CGRect fileNameFrame = CGRectMake(75, size.height - 40 , size.width,30);
        fileNameLabel.frame = fileNameFrame;
        [self.photoItemView addSubview:fileNameLabel];
    }
}

/*- (void)retryUpload:(id)sender{
    [self addActivityIndicator];
    [self.documentMediaDelegate didPressRetry:self];
}


- (void)removeRetryButton{
    if (retryButton){
        imageDownloded = true;
        CGSize size = [self mediaViewDisplaySize];
        self.photoItemView.frame = CGRectMake(0, 0, size.width, size.height);
        [self.photoItemView layoutIfNeeded];
        [retryButton removeFromSuperview];
        retryButton = nil;
    }
}


- (void)addActivityIndicator{
    if (!activityIndicator){
        activityIndicator = [JSQMessagesMediaPlaceholderView viewWithActivityIndicator];
        activityIndicator.frame = self.photoItemView.frame;
        [self.photoItemView addSubview:activityIndicator];
    }
}

- (void)removeActivityIndicator{
    if (activityIndicator){
        [activityIndicator removeFromSuperview];
        activityIndicator = nil;
    }
}*/


#pragma mark - JSQMessageMediaData protocol

- (void)setAppliesMediaViewMaskAsOutgoing:(BOOL)appliesMediaViewMaskAsOutgoing
{
    [super setAppliesMediaViewMaskAsOutgoing:appliesMediaViewMaskAsOutgoing];
}

- (CGSize)mediaViewDisplaySize
{
    return CGSizeMake(250.0f, 75.0f);
}

- (UIView *)mediaView
{
    return self.photoItemView;
}


#pragma mark - NSCoding
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    NSLog(@"init coder has not been implemented");
    
    return self;
}

- (void) setProgress:(float)progressCompleted{
    ////DDLogInfo(@"Document Progress %f",progressCompleted);
    dispatch_async(dispatch_get_main_queue(), ^{
        statusPercentage.text = [NSString stringWithFormat:@"%d %%",(int)progressCompleted];
    });
}

@end
