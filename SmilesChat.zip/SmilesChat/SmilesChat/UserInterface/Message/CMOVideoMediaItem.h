//
//  CMOVideoMediaItem.h
//  CMOChat
//
//  Created by Administrator on 11/20/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <JSQMessagesViewController/JSQMessagesViewController.h>
#import "JSQVideoMediaItem.h"


@protocol CMOVideoMediaItemDelegate <NSObject>

- (void)didPressRetry:(id)target;

@end

@interface CMOVideoMediaItem : JSQVideoMediaItem

@property (nonatomic, weak) id <CMOVideoMediaItemDelegate>videoMediaDelegate;

@property (nonatomic, assign)MessageDeliveryStatus status;

- (id)initWithFileURL:(NSURL *)fileURL isReadyToPlay:(BOOL)isReadyToPlay delegate:(id)target;

- (void)setUpload:(BOOL)upload;

- (void)setDownload:(BOOL)download;

- (void)setVidioUrl:(NSURL *)videoUrl;

- (void) setProgress:(float)progressCompleted;

@end
