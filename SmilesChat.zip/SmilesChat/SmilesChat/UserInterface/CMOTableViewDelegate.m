//
//  CMOTableViewDelegate.m
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOTableViewDelegate.h"

@interface CMOTableViewDelegate(){
    NSArray *_items;
    ConfigureCellDelegateBlock _configureCellBlock;
    CGFloat cellHeight;
    NSArray *editActionArray;
    BOOL alphabeticalScrollBarEnabled;
    
    //added for alphabet scroll
    NSMutableDictionary *tableItems;
    NSArray *tableItemSectionTitles;
    NSIndexPath *lastSelectedIndexPath;

}

@end

@implementation CMOTableViewDelegate


- (instancetype)initWithItems:(NSArray *)items
                configureCell:(ConfigureCellDelegateBlock)configureCellBlock{
    self = [super init];
    if (self) {
        _items = items;
        _configureCellBlock = configureCellBlock;
        cellHeight = 44.0f;
        editActionArray = nil;
        alphabeticalScrollBarEnabled = false;
        lastSelectedIndexPath = nil;
    }
    return self;
}

/*
- (instancetype)initWithItems:(NSArray *)items
                configureCell:(ConfigureCellDelegateBlock)configureCellBlock
               editActionCell:(editActionsCellDelegateBlock)editActionCellBlock
{
    self = [super init];
    if (self) {
        _items = items;
        _configureCellBlock = configureCellBlock;
        _editActionCellBlock = editActionCellBlock;
        cellHeight = 44.0f;
    }
    return self;
}
*/

- (void)setAlphbeticalScrollBar {
    alphabeticalScrollBarEnabled = true;
    [self generateIndexData];
}

- (void)generateIndexData {
    if(!tableItems) {
        tableItems = [NSMutableDictionary dictionary];
    } else {
        [tableItems removeAllObjects];
    }
    
    NSSortDescriptor *sortByName = [NSSortDescriptor sortDescriptorWithKey:@"name"
                                                                 ascending:YES];
    NSArray *sortDescriptors = [NSArray arrayWithObject:sortByName];
    _items = [_items sortedArrayUsingDescriptors:sortDescriptors];

    for (id item in _items) {
        NSString *firstLetter = [[[item name] substringToIndex:1] uppercaseString];
        NSMutableArray *letterList = [tableItems objectForKey:firstLetter];
        if (!letterList) {
            letterList = [NSMutableArray array];
            [tableItems setObject:letterList forKey:firstLetter];
        }
        [letterList addObject:item];
    }
    
    NSLog(@"%@",tableItems);
    
    tableItemSectionTitles = [[tableItems allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
}


- (id)itemAtIndexPath:(NSIndexPath*)indexPath {
    if (alphabeticalScrollBarEnabled) {
        NSString *sectionTitle = [tableItemSectionTitles objectAtIndex:indexPath.section];
        NSArray *sectionItems = [tableItems objectForKey:sectionTitle];
        id item = [sectionItems objectAtIndex:indexPath.row];
        return item;
    }
    return _items[(NSUInteger)indexPath.row];
}

- (void)setCellHeight:(CGFloat)height{
    cellHeight = height;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return cellHeight;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath == lastSelectedIndexPath) {
        return;
    }
    if (!alphabeticalScrollBarEnabled) {
        lastSelectedIndexPath = indexPath;
    }
    id item = [self itemAtIndexPath:indexPath];
    _configureCellBlock(indexPath,item);
}

- (void)updateDelegate:(NSArray *)items {
    _items = items;
    if (alphabeticalScrollBarEnabled) {
        [self generateIndexData];
    }
}

-(void)setEditAction:(NSArray *)array
{
    editActionArray = array;
}

- (NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*UITableViewRowAction *moreAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"Archive" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath){
     // maybe show an action sheet with more options
     //[self.tableView setEditing:NO];
     NSLog(@"Action");
     }];
     moreAction.backgroundColor = [UIColor blackColor];
     
     return @[moreAction];
     */
    
    return editActionArray;
}

- (void)tableView:(UITableView *)tableView didEndDisplayingCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([tableView.indexPathsForVisibleRows indexOfObject:indexPath] == NSNotFound)
    {
        // This indeed is an indexPath no longer visible
        // Do something to this non-visible cell...
        if (_archievedCellNotVisbleBlock) {
            _archievedCellNotVisbleBlock(indexPath);
        }
    }
}

@end
