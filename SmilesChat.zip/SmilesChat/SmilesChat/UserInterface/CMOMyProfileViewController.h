//
//  CMOMyProfileViewController.h
//  CMOChat
//
//  Created by Administrator on 11/21/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CMOAssembly;
@class CMOUser;
@class CMOCoreComponents;
@class CMORoster;
#import "CMOEditProfileViewController.h"

@protocol MyProfileDelegate <NSObject>

@optional
- (void) gotoConversationScreenWithUser: (CMORoster *) userInfo;

@end

@interface CMOMyProfileViewController : UIViewController<updateProfileDelegate>

@property (nonatomic, weak) IBOutlet UIImageView *profilePicture;
@property (nonatomic, weak) IBOutlet UILabel *designation;
@property (nonatomic, weak) IBOutlet UILabel *mobileNumber;
@property (nonatomic, weak) IBOutlet UILabel *emailId;
@property (nonatomic, weak) IBOutlet UILabel *profileName;

@property (nonatomic, strong) IBOutlet UIImageView *profileOuterPicture;
@property (nonatomic, weak) IBOutlet UIButton *backButton;
@property (nonatomic, weak) IBOutlet UIButton *editProfileButton;
@property (nonatomic, weak) IBOutlet UIButton *startConversationButton;
@property (nonatomic, strong) CMOUser *userInfo;
@property (nonatomic, assign) BOOL isEditEnable;
@property (nonatomic, weak) IBOutlet UILabel *titleLabel;

@property (strong, nonatomic) CMOCoreComponents *coreComponents;
@property (strong, nonatomic) CMORoster *rosterInfo;

@property (nonatomic, weak) id <MyProfileDelegate> delegate;

@property (strong, nonatomic) CMOAssembly *assembly;

@end
