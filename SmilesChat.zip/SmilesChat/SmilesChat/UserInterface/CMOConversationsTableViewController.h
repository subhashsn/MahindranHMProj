//
//  CMOConversationsTableViewController.h
//  CMOChat
//
//  Created by Amit Kumar on 05/04/17.
//  Copyright © 2017 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class CMOChatPresentation;
@class CMOCoreComponents;
@class CMOAssembly;
@class CMOSplitViewController;
@class CMORoomPresentation;
@class CMORosterPresentation;

@interface CMOConversationsTableViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, NSFetchedResultsControllerDelegate>

@property (strong, nonatomic) IBOutlet UITableView *conversationsTableView;
@property (weak, nonatomic) IBOutlet UIImageView *noCoversationImg;
@property (weak, nonatomic) IBOutlet UIButton *btnNoCoversationToast;
@property (weak, nonatomic) IBOutlet UILabel *noCoversationToasttext;
@property (weak, nonatomic) IBOutlet UILabel *noCoversationtext;

@property (strong, nonatomic) MBProgressHUD *hudProgress;

@property (nonatomic, strong) NSManagedObjectContext *managedObjectContext;

@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;

@property (strong, nonatomic) CMOChatPresentation *chatModel;

@property (strong, nonatomic) CMORosterPresentation *rosterModel;

@property (strong, nonatomic) CMORoomPresentation *roomModel;

@property (strong, nonatomic) CMOCoreComponents *coreComponents;

@property (strong, nonatomic) CMOAssembly *assembly;

@end
