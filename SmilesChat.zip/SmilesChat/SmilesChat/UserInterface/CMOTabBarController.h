//
//  CMORootViewController.h
//  CMOChat
//
//  Created by Anish on 10/22/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CMOAssembly.h"

 typedef enum tabBarNavigation
 {
     Conversation = 0,
     Contacts,
     Settings
 }tabBarStates;
 

@interface CMOTabBarController : UITabBarController<UITabBarControllerDelegate>

@property (readwrite, nonatomic)tabBarStates tabState;

- (id)initWithAssembly:(CMOAssembly *)assembly;

-(void)setHidden:(BOOL)flag;

- (NSMutableDictionary *) getUserPresenceDictonary;

- (void) removeUserPresence;

@end
