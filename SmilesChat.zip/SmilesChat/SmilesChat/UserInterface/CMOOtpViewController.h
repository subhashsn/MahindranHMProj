//
//  CMOOtpViewController.h
//  CMOChat
//
//  Created by Subhash on 03/11/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CMOAssembly;
@class CMOCoreComponents;
@class CMOOtpViewController;

@protocol MyOTPViewDelegate <NSObject>
- (void)addOTPViewController:(CMOOtpViewController *)controller didFinishEnteringItem:(BOOL)flag;
@end

@interface CMOOtpViewController : UIViewController<UINavigationControllerDelegate>

@property (nonatomic, weak)IBOutlet UITextField *txtOTP1;
@property (nonatomic, weak)IBOutlet UITextField *txtOTP2;
@property (nonatomic, weak)IBOutlet UITextField *txtOTP3;
@property (nonatomic, weak)IBOutlet UITextField *txtOTP4;
@property (nonatomic, weak)IBOutlet UILabel *lblVerifyMobileNumber;
@property (nonatomic, weak)IBOutlet UILabel *lblOTPError;

@property (strong, nonatomic) CMOAssembly *assembly;
@property (strong, nonatomic) CMOCoreComponents *coreComponents;
@property (strong, nonatomic) NSString *mobileNumber;
@property (strong, nonatomic) NSString *userName;
@property (readwrite, nonatomic) BOOL bSaveFlag;
@property (nonatomic, weak) id <MyOTPViewDelegate> cmoOTPDelegate;

@end
