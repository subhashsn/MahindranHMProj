//
//  CMOTableViewDatasource.m
//  CMOChat
//
//  Created by Anish on 10/23/16.
//  Copyright © 2016 DAMAC. All rights reserved.
//

#import "CMOTableViewDatasource.h"
#import "CMORosterGroup+CoreDataClass.h"
#import "CMORoster+CoreDataClass.h"
#import "CMOParticipantInfo.h"
#import "CMOUserClient.h"
#import "CMOUser.h"
#import "CMOCoreComponents.h"

#define MATCH_STRING  @"rostercell"

@interface CMOTableViewDatasource(){
    NSArray *_items;
    NSString *_cellIdentifier;
    ConfigureCellDataSourceBlock _configureCellBlock;
    deleteCellDataSourceBlock _deleteRowBlock;
    NSInteger numberOfSection;
    
    //added for alphabet scroll
    NSMutableDictionary *tableItems;
    NSArray *tableItemSectionTitles;
    
}

@end

@implementation CMOTableViewDatasource


- (instancetype)initWithItems:(NSArray *)items
                       identifier:(NSString *)identifier
                    configureCell:(ConfigureCellDataSourceBlock)configureCellBlock
{
    self = [super init];
    if (self) {
        _items = items;
        _cellIdentifier = identifier;
        _configureCellBlock = configureCellBlock;
        _deleteRowBlock = nil;
        numberOfSection = 1;
        [self generateIndexData];
    }
    return self;
}

- (instancetype)initWithItems:(NSArray *)items
                   identifier:(NSString *)identifier
                configureCell:(ConfigureCellDataSourceBlock)configureCellBlock
                deleteHandler:(deleteCellDataSourceBlock)deleteBlock
{
    self = [super init];
    if (self) {
        _items = items;
        _cellIdentifier = identifier;
        _configureCellBlock = configureCellBlock;
        _deleteRowBlock = deleteBlock;
        numberOfSection = 1;
        [self generateIndexData];
    }
    return self;
}

- (void)updateDatasource:(NSArray *)items {
    _items = items;
    
    [self generateIndexData];
}

- (void)generateIndexData {
    if ([_cellIdentifier isEqualToString:MATCH_STRING]) {

        NSSortDescriptor *sortByName = [NSSortDescriptor sortDescriptorWithKey:@"name"
                                                                     ascending:YES];
        NSArray *sortDescriptors = [NSArray arrayWithObject:sortByName];
        _items = [_items sortedArrayUsingDescriptors:sortDescriptors];

        if(!tableItems) {
            tableItems = [NSMutableDictionary dictionary];
        } else {
            [tableItems removeAllObjects];
        }

        for (id item in _items) {
            NSString *firstLetter = [[[item name] substringToIndex:1] uppercaseString];
            NSMutableArray *letterList = [tableItems objectForKey:firstLetter];
            if (!letterList) {
                letterList = [NSMutableArray array];
                [tableItems setObject:letterList forKey:firstLetter];
            }
            [letterList addObject:item];
        }
        
        NSLog(@"%@",tableItems);
        
        tableItemSectionTitles = [[tableItems allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    }
    
}

- (id)itemAtIndexPath:(NSIndexPath*)indexPath {
    return _items[(NSUInteger)indexPath.row];
}

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    if ([_cellIdentifier isEqualToString:MATCH_STRING]) {
        NSString *sectionTitle = [tableItemSectionTitles objectAtIndex:section];
        NSArray *sectionItems = [tableItems objectForKey:sectionTitle];
        return [sectionItems count];
    }

    return _items.count;
}

- (void)setNumberOfSection:(NSInteger)section{
    numberOfSection = section;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if ([_cellIdentifier isEqualToString:MATCH_STRING]) {
        return tableItemSectionTitles.count;
    }
    return numberOfSection;
}

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    id cell = [tableView dequeueReusableCellWithIdentifier:_cellIdentifier
                                              forIndexPath:indexPath];
    if ([_cellIdentifier isEqualToString:MATCH_STRING]) {
        NSString *sectionTitle = [tableItemSectionTitles objectAtIndex:indexPath.section];
        NSArray *sectionItems = [tableItems objectForKey:sectionTitle];
        id item = [sectionItems objectAtIndex:indexPath.row];
        _configureCellBlock(cell,item,indexPath);
        return cell;
    }

    id item = [self itemAtIndexPath:indexPath];
    _configureCellBlock(cell,item,indexPath);
    return cell;
}

- (void)setdeleteItems:(NSArray *)deleteItems{
    _deleteItemsArray = deleteItems;
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if (_deleteRowBlock == nil) {
        return false;
    }
    
    for (NSIndexPath *index in _deleteItemsArray) {
        //NSLog(@"_undoButtonIndexPath %ld",index.row);
        //NSLog(@"indexPath %ld",indexPath.row);
        if (index.row == indexPath.row)
            return FALSE;
    }
    
    //check if in participant info screen
    if ([[self itemAtIndexPath:indexPath] isKindOfClass:[CMOParticipantInfo class]]) {
        NSString *jid = [[self itemAtIndexPath:indexPath] jid];
        //check for group.group jid does not have "@"
        if (![jid containsString:@"@"]) {
            return false;
        }
        //check for current user and don't allow delete for this user
        if (_coreComponents) {
            id <CMOUserClient>userClient = [_coreComponents userService];
            CMOUser *loggedInUser = [userClient user];
            if ([([jid componentsSeparatedByString:@"@"][0]) isEqualToString:loggedInUser.username]) {
                return false;
            }
        }
    }
    return true;
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        _deleteRowBlock(indexPath);
        [tableView reloadData];
    }
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return tableItemSectionTitles;
    //return animalIndexTitles;
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
    return [tableItemSectionTitles indexOfObject:title];
}


@end
